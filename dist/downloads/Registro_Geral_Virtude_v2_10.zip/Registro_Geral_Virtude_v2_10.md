# Registro Geral de Virtude 2.10

Base de continuidade autoral. Em divergências, prevalecem as decisões mais recentes; os capítulos anteriores permanecem como histórico.

## 1. Finalidade, autoridade e uso

Edição 2.5 - organização e referências

A presente edição acrescenta a cronologia geral e o índice de vínculos dos capítulos 30 a 33. As decisões substantivas anteriores permanecem, com sua numeração e procedência. Estados antigos de implantação são históricos; os índices novos apresentam sua própria cobertura e fontes.

A regra de consulta

Em caso de conflito entre uma obra e uma definição normativa vigente deste Registro, vale a definição do Registro. Uma decisão posterior expressa de Tiago Luis Custódio prevalece e deve ser incorporada à próxima versão. Questões marcadas EM ABERTO não são decisões e não autorizam preencher lacunas como fatos.

O que muda nesta edição

A edição 2.4 incorpora a história política de Vaelen Endor a partir de VE, publicado pelo autor em 5 de novembro de 2026. A base 2.3 permanece preservada como referência histórica. Novos reinados, datas, pessoas e instituições passam a referência operacional nos registros RC-VE desta edição.



Este é o documento editorial de continuidade do universo de Virtude. Sua finalidade é conservar decisões, estabilizar nomes e relações, distinguir conhecimento de hipótese e orientar a criação de novos materiais. Não é uma crônica escrita por alguém de Virtude: contém informações de bastidores e desfechos que personagens e leitores de introdução podem desconhecer. A autoria do universo e a autoridade final pertencem a Tiago Luis Custódio.



O Registro não exige que cada livro antigo seja refeito imediatamente. Uma definição pode estar vigente aqui enquanto uma edição anterior ainda conserva outra versão. Por isso, a regra oficial e o estado de implantação são campos distintos. Uma ocorrência só é marcada como corrigida depois de se conferir o material alterado; encontrar a forma correta em um trecho não certifica todo o livro.



A base documental original consolidou as decisões explícitas desta conversa, o inventário da wikia 0.9 e a consulta temática aos onze PDFs nela disponíveis. Reúne um núcleo normativo, uma cronologia de referência, fichas de continuidade de lugares e personagens, um índice natural e um relatório de divergências. O alcance é a base identificada nesta edição, não todo arquivo ou rascunho que possa existir fora dela.



Quatro formas de informação

{"type": "table", "heads": ["Marca", "Significado e efeito"], "rows": [["AUTORAL", "Decisão explicitamente confirmada pelo autor nesta conversa. É normativa."], ["CONSOLIDADO", "Síntese das fontes identificadas, adotada como referência nesta edição. A atribuição ou incerteza faz parte da definição."], ["EDITORIAL ADOTADO", "Escolha de continuidade feita nesta edição para resolver um conflito, com justificativa e localização. É a referência operacional até decisão autoral posterior."], ["EM ABERTO", "Pergunta ou incompatibilidade ainda sem solução. Não adquire autoridade apenas por estar registrada."]], "widths": [0.27, 0.73]}



Os dossiês e os índices dos capítulos finais reproduzem a base de consulta identificada. Não acrescentam confirmação autoral independente a cada frase da wikia. Quando um dossiê conflitar com um registro normativo específico, este prevalece; quando aparecer um conflito novo não resolvido, conserve a dúvida e abra uma ocorrência.



Ordem de precedência



Primeiro, uma decisão autoral expressa mais recente; em seguida, o registro normativo específico vigente; depois, as fontes indicadas para aquele assunto. Para acontecimentos dramatizados, a cena do romance fornece a referência mais direta. Para regras de jogo, vale a versão mecânica identificada. Uma ilustração interpretativa não supera uma descrição física explícita, e uma data recente de arquivo não transforma automaticamente um testemunho ficcional em verdade absoluta.



A wikia deve acompanhar as decisões vigentes, mas não precisa carregar toda a discussão editorial. Os livros podem receber lotes de correções em revisões futuras. Este PDF congela a versão 2.2; o arquivo editável é a matriz para uma nova edição. Nenhuma atualização é automática: modificar a wikia ou um livro exige uma ação posterior.

Aviso de leitura

Este volume contém spoilers integrais dos dois romances e informações destinadas à criação e revisão do universo. Não deve ser usado como apresentação inicial para jogadores que desejam descobrir a trama.

## 2. Fontes, versões e método



A base W09 desta matriz corresponde à wikia 0.9, inventariada em 3 de novembro de 2026, com 220 verbetes, 75 personagens ilustrados, 70 lugares e onze PDFs. Esse retrato é histórico. A edição 2.4 acrescenta a obra VE e não revalida, por esse acréscimo, os inventários ou estados de implantação posteriores da wikia.



A base documental anterior é preservada para rastreabilidade. A edição 2.0 acrescentou decisões autorais desta conversa, identificadas por DA2, e detalhamento criativo autorizado. O número de verbetes ou imagens da wikia não muda por causa deste documento. As páginas das fontes continuam referindo-se às edições inventariadas, não às futuras reescritas.

{"type": "table", "heads": ["Código", "Material consultado", "Páginas"], "rows": [["AN", "Anais da Ordem dos Magos", "34"], ["BA", "Bichos e Assombros dos Caminhos", "37"], ["C1", "As Guias Partidas", "156"], ["C2", "As Quatro Hostes", "154"], ["FA", "As Formas da Ausência", "48"], ["FR", "Entre Feras e Raízes", "73"], ["GJ", "Crônicas de Virtude — Guia do Jogador", "58"], ["GV", "Guia dos Viajantes de 788", "43"], ["HG", "História Geral de Virtude", "147"], ["LR", "Crônicas de Virtude — Livro de Regras", "64"], ["ME", "O Mar das Espadas na Época de Selvar II", "41"], ["VE", "Vaelen Endor — A construção e a queda do Império", "66"]], "widths": [0.12, 0.76, 0.12]}



As páginas citadas são posições de página no PDF, contando a capa como página 1. Os arquivos foram identificados por conteúdo e resumo SHA-256, reproduzido no apêndice. W09 designa os verbetes da wikia 0.9; DA designa as decisões autorais expressas nesta conversa, sem numeração fictícia de página.



O que foi conferido



A conferência combinou extração textual dos onze PDFs, busca de nomes e variantes, leitura dirigida de passagens geográficas, cronológicas, narrativas e mecânicas e comparação com os verbetes. O relatório localiza ocorrências efetivamente verificadas e separa erros confirmados de dúvidas. Não constitui uma certificação de revisão linha a linha de todas as páginas, de cada viagem ou de todos os detalhes visuais.



A criação de uma concordância não apaga a perspectiva das fontes: Aveline compila história, Nerion recomenda viagens, Maelis descreve observações naturais, Odran relata experiências e Edrien escreve de dentro da Ordem. A verdade editorial pode ser mais precisa que o conhecimento disponível a esses autores.

{"type": "table", "heads": ["Obra interna", "Data e posição do relato"], "rows": [["História Geral / Aveline Sarven", "Publicação no Quinto Dia da Vigília de 788; conhece o encerramento do ano."], ["Anais / Edrien Vaust", "Aethravel, 787; exemplar interno com folhas reservadas."], ["Bichos e Assombros / Odran Velis", "Morvek, 2386 da II Era; não é um viajante contemporâneo de 788."], ["As Formas da Ausência / Ishara Vel-Sen", "Samarith, 780 da II Era; possui nota posterior de Aveline."], ["Mar das Espadas / Teren Vassel", "Morvek, 664 da III Era; trata de 2078-2149 da II Era e possui nota de 788."], ["Entre Feras e Raízes / Maelis Varen", "Ihfarilse, último mês de 787; ampliação editorial real não antecipa o futuro ficcional."], ["Guia dos Viajantes / Nerion Fales", "Edição para 788; distingue visitas, pousos e itinerários de uma história completa."]], "widths": [0.38, 0.62]}

## 3. Decisões estruturantes da edição 2.0



O autor aprovou o aprofundamento conjunto dos cinco eixos, a mudança de romance, a relação discreta entre NPCs, a traição entre coroas, o sistema monetário e cenas de cotidiano. Também autorizou detalhamento social e visual e personagens adjacentes. As definições abaixo já são vigentes; sua implantação nos livros é uma etapa posterior.

### RC-A01 — Marevim: da reparação à apropriação

Após 731, Marevim procura testemunhos e responsabilização. Passa da preservação de memórias à tentativa de obter respostas delas e, por fim, à sustentação de consciências sem consentimento. Os estágios são distintos; não recebem anos novos sem necessidade. A injustiça sofrida não lhe concede autoridade sobre mortos e sobreviventes. Eline defendia consentimento.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Acrescentar a transição por cenas, documentos e decisões; não apresentar toda pesquisa de memória como necromancia desde o começo.

### RC-A02 — Responsabilidades na Ordem

Distinguir autorização, execução, alteração de relatório, conhecimento posterior e contestação. Ivela apoiou revisão limitada e aceitou um resultado insuficiente; Rul preservou provas e demorou a romper o silêncio institucional. As responsabilidades são próprias e desiguais. Há opositores de Marevim que também reconhecem o crime de 731.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Distribuir informação e poder; os novos NPCs da Ordem individualizam funções sem substituir Ivela ou Rul.

### RC-A03 — Quatro hostes e cooperação condicionada

Aelvar busca conter a ruptura e conservar controle técnico; Quinder defende habitantes e soberania; os contingentes centrais possuem comandos e financiadores divergentes; o exército de Marevim inclui mortos, consciências retidas e aliados com diferentes margens de escolha. Provas técnicas, dissidentes e garantias tornam possível uma cooperação parcial.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Manter sinais acordados, tratamento de prisioneiros e corredores verificáveis. Unidades não recebem todas as ordens ao mesmo tempo; continuam existindo perdas após o primeiro entendimento.

### RC-A04 — Os seis permanecem por motivos próprios

Liana responde por caminhos e pessoas sem decidir por elas; Demer protege quem não consegue partir; Le Rink enfrenta o uso da autoridade paterna; Nyssara precisa renunciar ao controle sobre Narel; Kharug distingue negociação de perdão; Sera divide autoria e responsabilidade.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: A separação temporária do grupo tem efeitos reais sobre competências, informação e decisões. Nenhum protagonista substitui todos os demais.

### RC-A05 — Liana e Rul

A amizade vem de 778; a aproximação amorosa começa pouco antes da abertura de C2. São adultas, com interesses próprios. Liana conduz Rul a Aethravel após uma inspeção por trabalho combinado: o afeto não é remuneração. Encontram-se de tempos em tempos, trocam cartas irregulares e não assumem coabitação ou disponibilidade permanente.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Reescrever a abertura, reencontros e epílogo. O desacordo sobre proteção e autonomia permanece; a relação não depende apenas da ferida de Rul.

### RC-A06 — Rul não é destinatária passiva

Rul escolhe tarefas, recusa decisões tomadas em seu nome e possui contatos, obrigações e capacidade técnica independentes. Liana pode partir sem abandono automático; Rul pode ficar sem que isso signifique recusa do vínculo.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Não transformar a goblin em prêmio, mascote, paciente permanente ou motivação para apagar as escolhas de Liana.

### RC-A07 — Elthara e Tavian

Elthara Sorn e Tavian Ordel tiveram aproximação afetiva em negociações militares anteriores e retomam encontros ocasionais. Ambos são adultos. Omitem o vínculo de parte dos subordinados; isso cria conflito de confiança entre comandos de interesses distintos.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Mostrar intimidade por gestos, cartas e conhecimento de hábitos. Não usar o vínculo como explicação automática da aliança, de uma traição ou de acesso irrestrito a segredos.

### RC-A08 — Limites operacionais da magia

Conhecer uma técnica não fornece materiais ou condições. Transmitir informação não comprova autoria ou integridade. Interferências possuem condições identificáveis e preparação narrativa. Cura e comunicação não restituem automaticamente membros, memória, consentimento ou confiança.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Evitar bloqueios inventados apenas para uma cena. Preservar função de pilotos, mensageiros, curadores, técnicos e arquivos; quantidades pertencem ao sistema de RPG.

### RC-A09 — Consequências de Samarith

O pós-guerra acompanha apuração de 731, assistência a sobreviventes dos diferentes exércitos e cobrança das garantias financeiras da campanha. Revelação não produz reparação instantânea. Demer participa do cuidado sem precisar fundar uma ordem excepcional.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Definir quem assume custos e quem continua esperando. Processos podem permanecer abertos depois de 788.

### RC-A10 — Cenas de mundo vivido

Distribuir cenas breves de trabalho, costumes, humor, beleza e conflito. Algumas retornam à investigação; outras concluem uma pequena história no próprio encontro. Nem toda cena contém uma pista ou objeto secreto.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Usar a matriz de cenas desta edição, preservando a causalidade e o conhecimento de cada personagem.

## 4. Traição de Sar-Nobil e sucessão de Nobilith

### RC-S01 — Promessa e acordo secreto

Maressa II promete a Osric Dalm respeitar a condução da sucessão e garantir abastecimento. Negocia secretamente com Martan Edris reconhecimento e crédito em troca de garantias sobre receitas e postos de Sar-Nobil. É compromisso político limitado: não transfere automaticamente a soberania de Nobilith.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Introduzir a promessa antes de mostrar sua violação; distinguir receita empenhada, administração de posto e anexação.

### RC-S02 — O custo da decisão

Durante a guerra, Maressa autoriza desviar parte de recursos prometidos a Nobilith apesar de avisos de escassez. Martan ajuda a ocultar o acordo. O socorro parte tarde; comunidades ficam expostas, e casas perdem pessoas e animais de serviço.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Mostrar ordens, transportes, testemunhas e efeitos. Não culpar uma magia secreta nem tornar Maressa responsável por todo atraso da guerra.

### RC-S03 — Osric e a coroação

Osric morre de sua condição já existente no décimo mês de 788, depois da batalha. Não se introduz envenenamento. Martan obtém coroação com apoio de parte da casta dos cavaleiros; as concessões vêm à tona e sua legitimidade é contestada. O dia preciso não é fixado.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Substituir o encerramento anterior que mantinha Osric vivo e a sucessão apenas em expectativa. No início de 788, ele continua vivo e reinante.

### RC-S04 — Helena e a contestação

Helena reúne casas prejudicadas, administradores e credores para contestar concessões e procedimento sucessório. Não recebe automaticamente a coroa. Promete reformas enquanto tenta proteger rendas próprias. Ao fechar 788 há um rei coroado e postos que não obedecem às mesmas ordens.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Evitar reduzir Martan a fantoche e Helena a solução moral. A sucessão contestada é política, sem comprovação sobrenatural.



A sequência deve mostrar: promessa pública; negociação reservada; aviso de escassez; decisão de desvio; perdas e registros; morte de Osric; coroação; revelação; recusa de parte dos postos. Esses acontecimentos não precisam ocupar cenas consecutivas. A autenticidade do acordo depende de vias independentes, testemunhos e atos efetivos, não de uma carta encontrada que explique tudo.

{"type": "table", "heads": ["Pessoa", "Responsabilidade e limite"], "rows": [["Maressa II", "Escolhe priorizar sua campanha e ampliar influência; conhece os avisos e não pode alegar ignorância total. Perde confiança diplomática."], ["Martan Edris", "Aceita e ajuda a ocultar o compromisso; também possui partidários e programa próprios. Sua coroa não encerra a disputa."], ["Helena Dalm", "Organiza contestação com interesses próprios. A denúncia não a torna herdeira indiscutível."], ["Osric Dalm", "Governa no início de 788 e sofre limitações já existentes. Sua morte posterior não é assassinato introduzido por esta revisão."], ["Cavaleiros e moradores", "Escolhem entre juramentos, serviço, terra e subsistência; comunidades sofrem cobranças duplicadas e perda de proteção."]], "widths": [0.25, 0.75]}



As disputas resultantes continuam além de 788. Esta edição não decreta uma guerra continental, não escolhe o vencedor final da contestação nem atribui parentesco novo aos candidatos. O parentesco anterior é preservado: Martan é sobrinho de Osric; Helena é sua neta.

## 5. Moedas, emissão e circulação

### RC-M01 — Ráculo e nordum preservados

Ráculo e nordum permanecem com sua história e circulação anteriores. Os sete Reinos Centrais são Valerith, Nobilith, Sokeria, Heria, Rácia, Cávia e Milles. Bergen não ganha uma moeda substituta. Milles mantém a convivência de nordum e ráculo.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Conservar diferenças de cunhagem, peso, desgaste e os conflitos de ensaio já descritos.

### RC-M02 — Novas definições monetárias

O quadro desta edição estabelece as moedas dos demais estados e os lugares sem cunhagem soberana comum. Nome de moeda não implica exclusividade de circulação. Dorgal, como moeda, é distinguido da cidade pelo contexto.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Implantar nas descrições econômicas, contratos, mercados e cenas; não renomear preços de toda obra sem conferir contexto.

{"type": "table", "heads": ["Território", "Nome / padrão", "Definição vigente"], "rows": [["Aelvar", "Ilvar", "Prata régia; emissões antigas continuam circulando."], ["Iltharion", "Vaess", "Prata fiscalizada pela coroa e casas autorizadas."], ["Naerath", "Nareth", "Prata; emissões dinásticas com diferenças de teor."], ["Quinder", "Lâmpada", "Prata; cobre e crédito em compras pequenas."], ["Thaelorien", "Folha", "Prata para mercados e pagamentos públicos; prestações locais também existem."], ["Dorgamar", "Dorgal", "Prata; barras ensaiadas e documentos de depósito em grandes operações."], ["Nogard", "Escama", "Prata imperial; emissões de ouro em grandes pagamentos."], ["Sularien", "Âncora", "Prata de circulação portuária."], ["Jacomb", "Maré", "Prata de contratos e comércio costeiro."], ["Vardessa", "Vardo", "Prata imperial, de circulação desigual fora dos centros."], ["Pellanor", "Ponte", "Padrão de prata reconhecido por casas emissoras; não pressupõe coroa confederativa."], ["Oleakia", "Sem moeda soberana comum", "Moedas externas, crédito e vales de depósitos identificados."], ["Confederação Orc", "Sem cunhagem confederativa única", "Moedas externas, metal pesado e convenções de comunidades."], ["Ayak", "Circulação múltipla", "Ráculos, norduns e moedas marítimas; sem moeda própria definida."], ["Chisiague", "Circulação múltipla", "Moedas vizinhas e pagamentos locais; sem cunhagem comum à Liga."], ["Povos Livres", "Práticas por comunidade", "Sem moeda universal atribuída a todos."]], "widths": [0.2, 0.23, 0.57]}



Não há câmbio universal e perpétuo. Teor, peso, desgaste, procedência e confiança afetam aceitação; a Liga das Balanças mantém função técnica e interesses próprios. Um vale de depósito identifica emissor e obrigação: não pode ser gasto em toda Virtude como se fosse prata. Sem moeda própria não significa sem comércio, riqueza ou crédito.



Valores pequenos podem usar cobre, frações reconhecidas e crédito local. Esta edição não fixa uma relação universal entre ouro, prata e cobre, nem uma série de denominações por reino. No RPG, os preços continuam em prata de referência; o câmbio entra quando acrescenta uma escolha relevante. Não se obriga a mesa a recalcular toda compra.



Para diferenciar imagens, o ilvar apresenta um ramo estreito; o vaess, um arco aberto; o nareth, duas incisões paralelas; a lâmpada, uma chama estilizada; a folha, uma nervura central; o dorgal, uma comporta; a escama, três placas sobrepostas; a âncora, uma haste bifurcada; a maré, duas ondas; o vardo, um marco de estrada; a ponte, três vãos baixos. Esses motivos são complementos visuais novos, não prova de símbolo religioso universal. Perfis de soberanos e marcas de casa variam entre emissões.

## 6. Reinos e localidades: diferenças sociais e visuais



Cada ficha estabelece composição de cena, grupos sociais e conflito, sem transformar população em bloco uniforme. Os topônimos e governantes anteriores são preservados. Os complementos de materiais e usos são novos detalhes de continuidade; não implicam clima único para um reino inteiro. Para os Povos Livres, a ficha não cria um estado soberano.



Valerith



<b>Localidades e paisagem:</b> Vaelen Endor, arquivos, pátios de carga e edifícios imperiais adaptados; Nerevala é uma fronteira portuária disputada, não uma segunda capital.



<b>Grupos e disputa:</b> Corte, administração urbana, credores e associações de moradores disputam precedência e receita. Maressa empenha rendas; Lethia negocia autonomia urbana; Alessa depende de abastecimento externo.



<b>Direção visual:</b> Cantaria reparada com tijolo, roupa de audiência bem cortada e trajes de trabalho variados; nenhum padrão obrigatório para todo morador.



Reino de Nobilith



<b>Localidades e paisagem:</b> Cidade de casas antigas e acessos de serra; postos e hospedarias de Sar-Nobil têm espaços para animais, arreios e reparos.



<b>Grupos e disputa:</b> Casta dos cavaleiros, proprietários, administradores, transportadores e dependentes disputam obrigações. Casas apoiam Martan ou Helena por combinações de juramento, crédito e serviço; a coroação posterior divide postos.



<b>Direção visual:</b> Brasões gastos, ferro mantido por oficina e mantos de viagem pesados; distinguir riqueza herdada de equipamento realmente disponível.



Sokeria



<b>Localidades e paisagem:</b> Isnymelha militar e marítima; Vaelora combina floresta trabalhada, cultivo, coleta e direitos de acesso.



<b>Grupos e disputa:</b> Senhores, aldeias endividadas, trabalhadores móveis, clero e guarnições competem por braços e reservas. A Questão dos Celeiros contrapõe alívio prometido, exceções senhoriais e petições camponesas.



<b>Direção visual:</b> Celeiros, pátios de serviço, remendos de lona e ferramentas agrícolas; evitar tornar todo o reino um castelo.



Reino de Heria



<b>Localidades e paisagem:</b> Corte e casas de cavaleiros convivem com abrigos, propriedades e caminhos de serviço.



<b>Grupos e disputa:</b> Nobreza militar, dependentes, escrivães e membros dos Heróis disputam manutenção e isenções. Livro das Esporas: pagamentos indevidos e amparo real coexistem; uma apuração pode retirar alimento de quem não cometeu fraude.



<b>Direção visual:</b> Armaduras antigas restauradas, cavalos de condições diversas e arquivos modestos; pompa não é prosperidade geral.



Reino da Rácia



<b>Localidades e paisagem:</b> Ihfarilse combina oficinas, biblioteca e instalações do Circuito; Valada é corredor de autos e transporte; Atlante articula saída costeira.



<b>Grupos e disputa:</b> Patrocinadores, inventores, operários, aprendizes, corporações e redes clandestinas competem por acesso e autoria. Prestígio do Circuito sustenta a coroa e favorece patrocinados; reparadores sem nome cobram crédito e segurança.



<b>Direção visual:</b> Metais manchados, peças etiquetadas, proteção de oficina e roupa de corte contrastante; evitar vapor ou máquinas sem base no lore.



Reino da Cávia



<b>Localidades e paisagem:</b> Trogu tem docas e estaleiros; Juu Daixo, combustível e metal; galerias possuem moradores e direitos próprios.



<b>Grupos e disputa:</b> Concessionários, cooperativas mineiras, armadores, pilotos e comunidades subterrâneas negociam risco e acesso. A coroa adia conflitos de concessão; trabalhadores exigem participação em achados e condições de segurança.



<b>Direção visual:</b> Poeira e sal em zonas diferentes, suportes de carga e oficinas; não colocar toda cidade dentro de uma mina.



Reino de Milles



<b>Localidades e paisagem:</b> Cidade capital, floresta, localidades frias e passagens do Estreito do Norte compõem percursos distintos.



<b>Grupos e disputa:</b> Corte, casas de ensaio, comerciantes, condutores e comunidades de manutenção disputam câmbio e auxílio. Rovena negocia nordum e ráculo; crise de receitas pode virar acusação contra estrangeiros.



<b>Direção visual:</b> Tecidos sobrepostos, depósitos secos e madeira de manutenção; neve e gelo dependem de estação e altitude.



Reino de Bergen



<b>Localidades e paisagem:</b> Muralha de Hravn, postos e povoados do norte, com gelo e abastecimento condicionando serviço.



<b>Grupos e disputa:</b> Guarnições, comunidades tributadas, corte, mercadores e autoridades de Auvren disputam proteção e informação. Relatos do norte sustentam gastos e suspeitas, sem confirmar um exército oculto ou os Thul Verenari.



<b>Direção visual:</b> Pedra escurecida, madeira protegida do tempo, lã e sinais de reparo; evitar neve uniforme em qualquer mês.



Reino de Aelvar



<b>Localidades e paisagem:</b> Emvale é capital; Aston tem pomares e residência de Le Rink; Aethravel possui instalações e autonomia pactuada. Let-Thalara é bosque.



<b>Grupos e disputa:</b> Coroa, casas antigas, famílias de cultivo, ofícios e setores da Ordem negociam obrigações. Arriot busca controle sem possuir todos os arquivos; os direitos dos Pomares mantêm dependências.



<b>Direção visual:</b> Pomares manejados, alvenaria sóbria e circulação de mantimentos; vestes cerimoniais diferem da roupa de campo.



Reino de Iltharion



<b>Localidades e paisagem:</b> Nerathiel e seus acessos orientais relacionam serra, costa e interior; não repetir a imagem de Emvale.



<b>Grupos e disputa:</b> Casas portuárias, guardiões do interior, corte e pilotos disputam inspeções e autonomia. Elyndra sustenta acordo entre interesses distintos; sinais costeiros também podem servir à vigilância comercial.



<b>Direção visual:</b> Pedra clara de tons variados, estruturas de sinal e tecido bem preso ao vento em ambientes costeiros, sem arquitetura universal obrigatória.



Domínio de Naerath



<b>Localidades e paisagem:</b> Vel-Narim e Floresta Negra incluem terrenos manejados, assentamentos e estradas, não escuridão sobrenatural contínua.



<b>Grupos e disputa:</b> Grandes casas, cultivadores, dependentes, comerciantes e comunidades humanas negociam terra e renda. Zeryssa e conselho das casas enfrentam disputas herdadas da relação com Quinder.



<b>Direção visual:</b> Folhagem fechada e clareiras de trabalho, tons escuros usados de maneiras variadas; povo e moralidade não se confundem.



Quinder



<b>Localidades e paisagem:</b> Xeo Taoju tem monumentos, água e corte; Samarith, santuários e serviços. Campos irrigados passam a áreas mais secas.



<b>Grupos e disputa:</b> Corte, santuários, irrigantes, famílias humanas com reivindicações e proprietários de origens diversas disputam água e restituição. Selyra oferece abrigo e mantém controle dos caminhos; o Conselho das Duas Margens administra parte da irrigação.



<b>Direção visual:</b> Canais úteis, sombra localizada e superfícies de solo diferentes; evitar deserto total ou jardim contínuo.



Reino de Thaelorien



<b>Localidades e paisagem:</b> Nael-Sul cidade é distinta da Grande Floresta; Vradrath e as vertentes condicionam caminhos; Orvalda e Edramil possuem circuitos próprios.



<b>Grupos e disputa:</b> Coroa, pactos de bosques, comunidades urbanas, extratores e responsáveis por viveiros disputam uso. Conservação pode proteger comunidades ou legitimar cobrança e exclusão; Ariessa não é dona de cada bosque.



<b>Direção visual:</b> Madeira trabalhada e pedra adaptadas ao lugar, áreas cultivadas e usos cotidianos; não uniformizar tudo em casas nas árvores.



Império de Dorgamar



<b>Localidades e paisagem:</b> Dorgal é centro político; Morvek é portuária; cidades, minas e canais desativados têm economias diferentes.



<b>Grupos e disputa:</b> Coroa, assembleias urbanas, casas de canal, mineiros, credores e técnicos migrantes disputam investimento. Brunna quer recuperar parte da rede; algumas casas preferem manter taxas ou abandonar obras.



<b>Direção visual:</b> Marcas de nível de água, comportas mantidas e setores abandonados; evitar montanhas de ouro como paisagem nacional.



Império de Nogard



<b>Localidades e paisagem:</b> Corte do Estreito é insular; ancoradouros, depósitos e fiscalização distinguem o núcleo imperial.



<b>Grupos e disputa:</b> Dinastia, comandos navais, armadores, seguradores e comunidades de meio-dragões possuem interesses diversos. Cobranças sobre Oleakia e a Mesa do Lastro não são uma só autoridade nem uma única política.



<b>Direção visual:</b> Escamas e cristas individuais variadas, cabos e pedra portuária; não colocar asas ou chifres iguais em todos.



Reino de Sularien



<b>Localidades e paisagem:</b> Nhal-Sular articula portos e relações costeiras com Nogard e Jacomb.



<b>Grupos e disputa:</b> Coroa, pilotos, casas mercantis, abastecedores e vítimas de apresamentos disputam intermediação. Tharven financia ações contra rivais; a Querela das Âncoras conserva compensações contestadas.



<b>Direção visual:</b> Cais de condições distintas, armazéns apertados e roupa prática de bordo; origem élfica negra não replica Naerath.



Reino de Jacomb



<b>Localidades e paisagem:</b> Portos, pontos de aviso e oficinas de navegação ligam o reino aos circuitos orientais.



<b>Grupos e disputa:</b> Corte de Celvar, casas de contrato, pilotos e guardiões costeiros disputam risco e informação. O Ofício das Marés cobra prudência onde agentes comerciais vendem promessas de acesso.



<b>Direção visual:</b> Instrumentos reparados, marcas de maré e mapas anotados; não apresentar Lombonia como passeio regular.



Vardessa — Império Ocidental



<b>Localidades e paisagem:</b> Império Ocidental conhecido por tratados e relatos; centros e estradas não recebem aqui um mapa urbano completo inventado.



<b>Grupos e disputa:</b> Corte apresentada por Ilaris, representantes comerciais, cobradores e autoridades locais aparecem como interlocutores, sem uma constituição exaustiva. A distância entre pretensão imperial e cobrança efetiva admite disputa; detalhes não documentados ficam limitados aos novos contatos definidos.



<b>Direção visual:</b> Usar selos, marcos e peças de vestuário de emissários; não fixar clima, capital ou monumentalidade não descritos.



Confederação Halfling de Pellanor



<b>Localidades e paisagem:</b> Vales ocidentais além de Welkar / Velkar, com pontes, correios e pequenas soberanias; sem capital confederativa única.



<b>Grupos e disputa:</b> Pequenas cortes, comunidades, hospedeiros, reparadores e comerciantes negociam pesos e isenções. A Mesa das Sete Panelas coordena sem abolir governos locais; privilégio de parentes pode distorcer manutenção.



<b>Direção visual:</b> Escalas de mobiliário variadas, despensas e pontes ajustadas a usos reais; halflings não são apenas uma estética de festa.



União das Tocas de Oleakia



<b>Localidades e paisagem:</b> Terras baixas úmidas, Aurenval, túneis e depósitos dispersos relacionados a comunidades.



<b>Grupos e disputa:</b> Tocas, assembleias, matriarcas, cultivadores, pescadores e gente de vigília disputam reservas e acesso costeiro. Ima coordena; cobrança nogard permanece contestada; interesses de famílias não são idênticos.



<b>Direção visual:</b> Entradas protegidas de água, ferramentas de portes diversos e sinais discretos; oleakes possuem feições e pelagens individuais.



Confederação Orc



<b>Localidades e paisagem:</b> Comunidades e rotas ocidentais com assembleias locais; não há capital nacional única definida aqui.



<b>Grupos e disputa:</b> Chefias, famílias deslocadas, negociantes, criadores e trabalhadores divergem sobre terra e tratados. Indenização parcial pode ser reparação para uns e renúncia inaceitável para outros, como no conflito de Kharug e Druvak.



<b>Direção visual:</b> Equipamento mantido, materiais de origem diversa e registros de pacto; não reduzir assentamentos a acampamentos de guerra.



Cidade-Estado de Ayak



<b>Localidades e paisagem:</b> Cais, balsas, depósitos e desembocaduras ligam circulação fluvial e costeira.



<b>Grupos e disputa:</b> Conselho, síndica, carregadores, barqueiros e comerciantes disputam armazenagem e prioridade. Autonomia do porto não resolve o acesso igual aos serviços ou o preço da espera.



<b>Direção visual:</b> Madeira molhada, marcas de carga e passagens estreitas; embarcações e níveis de água orientam a composição.



Liga dos Passos de Chisiague



<b>Localidades e paisagem:</b> Coroa montanhosa e entrada de mar aberta a leste; passos, cidade e acessos de água precisam aparecer distintos.



<b>Grupos e disputa:</b> Liga, guardiões de passo, transportadores, moradores de encosta e comunidades das margens disputam manutenção. Taxas de travessia e direitos de água podem divergir mesmo entre aliados de Halessa Norn.



<b>Direção visual:</b> Rocha estratificada, espaços de abrigo e vegetação conforme encosta ou margem; não fechar o acesso oriental.



Terras dos Povos Livres



<b>Localidades e paisagem:</b> Territórios amplos do nordeste com comunidades distintas; não existe paisagem política única.



<b>Grupos e disputa:</b> Assembleias e autoridades locais, rotas sazonais e visitantes negociam condições próprias. Tratados de uma comunidade não obrigam todas as demais; um porta-voz precisa de mandato delimitado.



<b>Direção visual:</b> Distinguir assentamento e estação na futura cena; não inventar uma roupa tribal universal.

### RC-L01 — Distinguir localidades dentro do mesmo reino

Uma ilustração deve escolher localidade, estação, função do espaço e presença social. Não usar o mesmo perfil de torres, praça, rio e montanha em todas as cidades. Sem descrição suficiente, omitir o detalhe em vez de converter uma hipótese em geografia.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Aplicar as 24 fichas territoriais às 70 localidades inventariadas. Relações espaciais anteriores permanecem prioritárias.



Ficha de imagem de local: nome e época; água e acesso; relevo; vegetação e manejo; materiais e escala; trabalho visível; grupos presentes; ponto de vista; elementos que não podem mudar. Uma imagem da capital não representa automaticamente todo o reino.

## 7. Personagens adjacentes: novas fichas



As 25 pessoas seguintes são criações novas vigentes desta edição, sob autorização do autor. Não são apresentadas como personagens já existentes nos romances. Todos os vínculos de serviço são delimitados. Semelhança de sobrenome não cria genealogia; nenhuma ficha escolhe automaticamente uma lealdade para um povo inteiro.



Aparência, vestimenta e objeto de trabalho servem de base a futuras imagens. Arma não é obrigatória: um funcionário pode portar ferramentas e uma pessoa armada não precisa posar em combate. Nenhuma imagem nova é criada por esta atualização do Registro.



PN-01 | Sovel Aneth



<b>Elfo alto · Ordem / Aelvar · Custódio de autorizações.</b> Conhece a circulação de vias de 731, mas não assinou a operação. Teme perder sustento e confunde dever de sigilo com lealdade aos vivos.



<b>Aparência:</b> Face comprida, nariz largo, cabelo cinzento rente à nuca; mãos de dedos grossos.



<b>Vestimenta e equipamento:</b> Túnica de lã azul apagado, mangas curtas sobre camisa clara; estojo de selos e chave de arquivo. Sem arma habitual.



<b>Relação com a trama:</b> Rul compara matrizes sob sua guarda; Ivela precisa reconhecer o alcance das negativas anteriores.



PN-02 | Brena Uld



<b>Humana · Ordem / sobreviventes de 731 · Curadora e testemunha.</b> Sobreviveu ao isolamento já adulta; esta edição a apresenta idosa em 788, sem fixar nascimento. Recusa virar apenas prova da dor de Marevim.



<b>Aparência:</b> Rosto quadrado, cabelo crespo muito curto, sobrancelhas baixas; movimento deliberado do ombro direito.



<b>Vestimenta e equipamento:</b> Casaco castanho com fechos de osso e bolsa de curativos; faca de trabalho, sem uso marcial habitual.



<b>Relação com a trama:</b> Demer a escuta; documentos da Ordem precisam distinguir seu testemunho das interpretações do pesquisador.



PN-03 | Nereth Cal



<b>Humano · Valerith / crédito de campanha · Escrivão de garantias.</b> Registra a garantia de Sar-Nobil sem conhecer de início todas as promessas feitas a Osric. Deseja preservar o posto e não aceita assumir sozinho a decisão régia.



<b>Aparência:</b> Rosto oval, nariz curto, entradas pronunciadas e cabelo castanho liso; fala devagar.



<b>Vestimenta e equipamento:</b> Colete cinzento sem bordado, bolsa plana e caneta curta; sem arma de serviço.



<b>Relação com a trama:</b> Lethia administra sua circulação; vias independentes podem confirmar partes do acordo.



PN-04 | Varda En



<b>Humana · Nobilith / Sar-Nobil · Administradora de um posto de muda.</b> Conhece a diferença entre suprimentos prometidos e entregues. Protege moradores e depende de renda de passagem que também os onera.



<b>Aparência:</b> Face larga, olhos pequenos, cabelo escuro trançado baixo; antebraços fortes.



<b>Vestimenta e equipamento:</b> Sobretúnica verde gasta, botas altas reparadas, chaves e cordel de contas; lança curta guardada para defesa do posto.



<b>Relação com a trama:</b> Kharug confere cargas com ela; Helena procura seu apoio e não recebe obediência gratuita.



PN-05 | Ceris Dalmere



<b>Humano · Nobilith / cavalaria · Cavaleiro de uma casa de renda curta.</b> Apoia Martan por juramento e receia uma concessão que entregue o sustento do posto a credores. Não é parente dos Dalm por semelhança de nome.



<b>Aparência:</b> Rosto estreito, olhos fundos, nariz convexo e cabelo preto comprido preso; barba rala.



<b>Vestimenta e equipamento:</b> Cota antiga com reparos visíveis, manto bege e escudo com pintura renovada; lança e espada curta.



<b>Relação com a trama:</b> Sua dúvida materializa a divisão da casta; não comanda todos os cavaleiros.



PN-06 | Dena Arl



<b>Humana · Sokeria / aldeias · Organizadora de armazenamento.</b> Negocia reservas entre famílias e discorda de Yarine sobre quanto entregar à campanha. Não substitui Marta Eren.



<b>Aparência:</b> Rosto triangular, olhos afastados, cabelo castanho em duas tranças curtas.



<b>Vestimenta e equipamento:</b> Saia de trabalho sobre calças estreitas, avental de fibra grossa e medidas de madeira; foice de trabalho, não arma obrigatória.



<b>Relação com a trama:</b> Atrasos de socorro a afetam; sua petição acompanha sementes e trabalho, não só números da corte.



PN-07 | Orel Vennas



<b>Anão · Heria / dependentes · Responsável por uma casa de veteranos.</b> Recebe recursos de uma casa investigada por Isembra. Quer apuração e teme que o corte abrupto de verbas abandone os dependentes.



<b>Aparência:</b> Nariz largo, barba ruiva curta com fios brancos, olhos claros profundos; porte robusto.



<b>Vestimenta e equipamento:</b> Casaco remendado nos cotovelos, livro de refeições e bengala; sem arma cotidiana.



<b>Relação com a trama:</b> Ysenda precisa negociar continuidade do cuidado sem preservar a fraude.



PN-08 | Terenna Vos



<b>Humana · Rácia / oficinas · Representante de reparadores.</b> Exige que nomes de quem ajusta as peças constem dos registros. Pode atrasar serviço ao recusar trabalho inseguro.



<b>Aparência:</b> Rosto retangular, maxilar forte, cabelo liso preto preso em rabo curto; sorriso raro.



<b>Vestimenta e equipamento:</b> Colete de lona ferrugem, mangas presas e caixa de gabaritos; martelo de trabalho, sem arma pessoal definida.



<b>Relação com a trama:</b> Contesta Sera e os patrocinadores de Loria; sua competência não se resume a ajudá-las.



PN-09 | Borrin Tas



<b>Anão · Cávia / carregadores · Conferente de doca.</b> Defende equipes que pagam pelo tempo de espera imposto por inspeções. Também favorece conhecidos quando escolhe um turno.



<b>Aparência:</b> Rosto redondo, barba cinzenta dividida em duas pontas, um dente frontal ausente.



<b>Vestimenta e equipamento:</b> Capa curta impermeabilizada, calças folgadas presas na canela e placa de contagem; faca de corda.



<b>Relação com a trama:</b> Vessa precisa de sua equipe para uma operação; Dorna contesta que risco de mina seja tratado como peso de carga.



PN-10 | Edda Fenn



<b>Humana · Milles / abastecimento · Condutora de comboios.</b> Aceita moedas diferentes conforme destino e recusa lotes sem ensaio. Cobra adiantamento porque uma rota interrompida pode arruinar a equipe.



<b>Aparência:</b> Face longa, nariz arrebitado, cabelo castanho cortado rente às orelhas; bochechas marcadas pelo frio.



<b>Vestimenta e equipamento:</b> Lã em camadas, luvas de palmas reforçadas e lista de provisões; machadinha de serviço, sem papel militar fixo.



<b>Relação com a trama:</b> Rovena enfrenta as consequências de decisões monetárias nas entregas de Edda.



PN-11 | Haldis Ruun



<b>Humana · Bergen / muralha · Responsável por mantimentos de um posto.</b> Registra consumo e avisos do norte sem concluir que toda falta é sabotagem ou toda aparição é mentira.



<b>Aparência:</b> Rosto largo, queixo curto, cabelo muito claro em trança apertada; voz rouca.



<b>Vestimenta e equipamento:</b> Manto de lã cinzenta, botas de solado renovado e medidas de ração; lança de posto, usada em serviço.



<b>Relação com a trama:</b> Seus pedidos mostram o custo da proteção e o limite das notícias vendidas a viajantes.



PN-12 | Irenel Avar



<b>Elfa alta · Iltharion / sinalização · Guardiã de um farol.</b> Recusa registrar carga privada como se fosse segurança de navegação. Não fala em nome de toda a rainha Elyndra.



<b>Aparência:</b> Face pequena, nariz comprido, cabelo castanho escuro em trança lateral; olhos de pálpebras pesadas.



<b>Vestimenta e equipamento:</b> Casaco curto fechado alto, tecido preso ao vento e lente de inspeção; bastão de caminhada.



<b>Relação com a trama:</b> Oferece um contraste entre aviso público e espionagem comercial nos circuitos de Jacomb.



PN-13 | Vael Ner



<b>Elfo negro · Naerath / propriedades · Administrador de arrendamentos.</b> Conhece limites antigos de terrenos e lucra com mediações. Pode provar uma reivindicação e discordar da restituição proposta.



<b>Aparência:</b> Rosto oval largo, olhos quase redondos, cabelo branco curto penteado para trás.



<b>Vestimenta e equipamento:</b> Túnica marrom-escura de bainha clara e pasta de cordões; sem arma habitual.



<b>Relação com a trama:</b> Nyssara enfrenta o uso seletivo de sua própria pesquisa sem receber uma solução simples de arquivo.



PN-14 | Mira Saven



<b>Humana · Quinder / irrigação · Medidora ligada a comunidades irrigantes.</b> Disputa prioridades entre hortas e propriedades maiores. Depende de autorizações e não possui poder sobre todo o Conselho das Duas Margens.



<b>Aparência:</b> Face quadrada, nariz fino, cabelo preto com fios brancos preso baixo; unhas curtas.



<b>Vestimenta e equipamento:</b> Camisa clara, faixa azul desbotada e vara graduada; faca pequena de serviço.



<b>Relação com a trama:</b> Liana atravessa um desvio que ela mandou fechar; Selyra precisa responder à petição dos prejudicados.



PN-15 | Aelra Tis



<b>Elfa da floresta · Thaelorien / viveiros · Responsável por um viveiro comunitário.</b> Protege mudas e cobra limites de coleta, mas os direitos de acesso não são igualmente fáceis para todos.



<b>Aparência:</b> Face longa, maçãs baixas, cabelo castanho acinzentado preso em laço simples.



<b>Vestimenta e equipamento:</b> Tecido verde desbotado com bainha reforçada, avental e faca de enxertia; arco de caça somente em saídas combinadas.



<b>Relação com a trama:</b> Elenva negocia com seu grupo; Liana não pode aceitar compromissos por serem do mesmo povo.



PN-16 | Dovra Kelun



<b>Anã · Dorgamar / canais · Inspetora de uma associação de manutenção.</b> Defende recuperação de trechos úteis e rejeita reabrir uma rede inteira por prestígio. A nova cicatriz é detalhe criado nesta edição, não inferido de imagem.



<b>Aparência:</b> Face larga, nariz quebrado antigo já cicatrizado, cabelo preto raspado nas laterais; barba não definida nesta ficha.



<b>Vestimenta e equipamento:</b> Casaco de tecido ocre, botas com polainas, régua e instrumento de nível; sem arma de rotina.



<b>Relação com a trama:</b> Sera encontra seu critério de segurança; a corte de Brunna precisa escolher obras com efeitos desiguais.



PN-17 | Kesh Aruv



<b>Nogard · Nogard / ancoradouros · Piloto de serviço costeiro.</b> Vive de serviços autorizados pela fiscalização e perde clientes com taxas que considera abusivas.



<b>Aparência:</b> Focinho curto, escamas cinza-azuladas, crista baixa e chifres curtos voltados para trás; sem asas definidas.



<b>Vestimenta e equipamento:</b> Colete de couro flexível com aberturas adaptadas, corda de sondagem e faca de bordo.



<b>Relação com a trama:</b> Pode negociar com pescadores oleakes sem representar Azhvar ou a Mesa do Lastro.



PN-18 | Sareth Vin



<b>Elfa negra · Sularien / abastecimento · Representante de carregadores.</b> Busca compensação por alimento apresado; discorda de armadores e também de colegas que lucram com o contrabando.



<b>Aparência:</b> Rosto de queixo largo, cabelo preto muito curto, olhos estreitos; mãos grandes.



<b>Vestimenta e equipamento:</b> Jaqueta de linho grosso azul-escuro, cinto de bolsas e gancho de carga; sem arma marcial obrigatória.



<b>Relação com a trama:</b> Sua reclamação dá consequência concreta à política de Tharven e aos contratos com Jacomb.



PN-19 | Neral Doss



<b>Humano · Jacomb / navegação · Piloto do Ofício das Marés.</b> Não vende certeza sobre Lombonia. Sua prudência custa um contrato e pode salvar uma tripulação.



<b>Aparência:</b> Face triangular, nariz curto torto, cabelo grisalho crespo, barba curta desigual.



<b>Vestimenta e equipamento:</b> Capa de tecido encerado, mapa dobrado e linha de sondagem; faca de bordo.



<b>Relação com a trama:</b> Cruza notícias com Vessa e enfrenta agentes que prometem passagem segura sem base.



PN-20 | Pella Vintor



<b>Halfling · Pellanor / pontes · Responsável por inspeção de passagem.</b> Aplica tabelas por peso e enfrenta isenções de famílias influentes. Não é parente de Lessa Vint por semelhança nominal.



<b>Aparência:</b> Rosto oval, nariz arredondado, cabelo castanho em coque baixo, sobrancelhas muito retas.



<b>Vestimenta e equipamento:</b> Colete de lã curta, calças de trabalho e gabarito de roda; sem arma de ofício.



<b>Relação com a trama:</b> Sua cena mostra por que pontes custam trabalho; não confundir com a ancestral Pella Três-Pontes.



PN-21 | Tima Oren



<b>Oleake · Oleakia / reservas · Conferente de um depósito comunitário.</b> Discorda da localização de uma reserva nova e precisa ouvir famílias que querem guardar comida perto de casa.



<b>Aparência:</b> Focinho curto, face larga, pelagem bege-clara com orelhas de pontas castanhas; porte pequeno.



<b>Vestimenta e equipamento:</b> Sobretúnica curta verde-musgo, bolsos de tecido cru e contas de estoque; bastão de vigília, sem armamento universal do povo.



<b>Relação com a trama:</b> Ima coordena sem impor propriedade; Rima e a observação de cultivo ajudam a mostrar as diferenças de trabalho.



PN-22 | Rughen Tal



<b>Orc · Confederação Orc / terra · Delegado de duas comunidades.</b> Pode negociar por duas comunidades, não por toda a Confederação. Aceita compensação que alguns parentes recusam.



<b>Aparência:</b> Mandíbula estreita para seu povo, nariz largo, pele castanho-oliva, cabelo em duas tranças; presas inteiras.



<b>Vestimenta e equipamento:</b> Casaco de tecidos de origens diferentes, cordão de mandatos e escudo reparado; lança quando viaja em escolta.



<b>Relação com a trama:</b> Dialoga com Kharug e dissidentes sem substituir Rugha Sen ou Druvak.



PN-23 | Lenna Uss



<b>Goblin · Ayak / balsas · Organizadora de turnos de carregamento.</b> Distribui trabalhos escassos e é cobrada por favorecimento. Sua rede é local e não uma representação de todos os goblins.



<b>Aparência:</b> Face triangular, nariz largo curto, cabelo preto rente à cabeça, orelhas compridas estreitas sem as queimaduras de Rul.



<b>Vestimenta e equipamento:</b> Colete cinza de bolsos externos, lenço amarelo e tabuinhas de turno; faca de corda.



<b>Relação com a trama:</b> A missão precisa aguardar equipe e maré; a autonomia de Ilyne Tess não elimina disputas no cais.



PN-24 | Darel Nornas



<b>Humano · Chisiague / passos · Administrador de abrigo de encosta.</b> Quer manutenção de uma rota que recebe menos mercadorias, mas serve moradores. Não possui parentesco automático com Halessa Norn ou Darel Oss.



<b>Aparência:</b> Face comprida, nariz fino, cabelo castanho ondulado sobre a nuca; olhos claros fundos.



<b>Vestimenta e equipamento:</b> Capa de duas camadas, botas de sola grossa e chave de depósito; bastão de caminho.



<b>Relação com a trama:</b> Seu conflito conecta direitos de água e passagem sem fechar a abertura marítima oriental.



PN-25 | Siva Orlen



<b>Humana · Vardessa / contatos comerciais · Agente de contratos de uma casa ocidental.</b> Afirma um mandato comercial verificável, não intimidade com toda a corte imperial. Defende cláusulas que favorecem sua casa.



<b>Aparência:</b> Rosto redondo, queixo pronunciado, cabelo preto em trança única enrolada; olhos pequenos atentos.



<b>Vestimenta e equipamento:</b> Casaco bege de fechos escuros, carteira de selos e pequena balança; sem arma definida.



<b>Relação com a trama:</b> Seu vardo e suas cartas apresentam Vardessa sem inventar um domínio completo de geografia ainda pouco descrita.

## 8. Fichas visuais dos personagens já existentes



As 75 fichas desta seção complementam o inventário W09. Os sinais distintivos anteriores continuam prioritários e são reproduzidos no dossiê de consulta. As formulações abaixo são detalhamento novo autorizado; não são descrições extraídas de imagens. Para personagens cujo povo ou idade não foi explicitado, a incerteza permanece: um formato facial não define espécie, idade exata ou genealogia.

### RC-V05 — Contrato visual de personagem

Preservar povo confirmado, idade contextual, marcas físicas, cabelo e limitações; acrescentar silhueta, fisionomia, roupa, instrumento e gesto. A ficha textual prevalece sobre uma imagem incompatível. Suplementos novos desta edição são canônicos no alcance indicado.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Comparar personagens lado a lado antes de gerar retratos. Detalhes não descritos continuam interpretação; variantes de roupa e posição são possíveis.

### RC-V06 — Armas e ofícios

Nem todo personagem possui arma pessoal habitual. Diferenciar arma de serviço, ferramenta cortante, equipamento cerimonial e objeto mágico vinculado a um evento. Não inventar encantamento para dar destaque visual.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Usar equipamento em tarefas naturais e respeitar mãos, próteses, ferimentos e época da cena.



Ansa Mer



<b>Fisionomia:</b> Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Aren Varn



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Arriot Ilvar



<b>Fisionomia:</b> Rosto muito magro, nariz comprido, cabelos cinzentos presos; luvas conservam função cerimonial e ocultamento da queimadura.



<b>Vestimenta:</b> Casaco verde-escuro de tecido fino e bordado contido; roupas de audiência diferentes das de viagem. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Selo e documentos; espada cerimonial apenas em contexto apropriado, sem torná-la arma constante. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Avren Dal



<b>Fisionomia:</b> Preservar: rosto largo, postura firme. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Beral Oss



<b>Fisionomia:</b> Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Calven IX



<b>Fisionomia:</b> Face longa, testa alta e nariz pronunciado; altura, cabelo ralo e sobrancelhas espessas preservados.



<b>Vestimenta:</b> Vestes claras com faixa escura, bem conservadas; mudança de tecido em funções públicas e privadas. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Selo e livro de audiências; não portar cajado mágico por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Darel Oss



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Demer Vault



<b>Fisionomia:</b> Rosto retangular, nariz de ponte larga, barba curta; a queimadura no antebraço permanece.



<b>Vestimenta:</b> Camisa clara, proteção de malha e placas mantidas, manto vinho gasto; símbolo de Ardanus. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Espada e escudo para serviço; em atendimento pode estar desarmado. Após a batalha perde insígnia de função, não o símbolo de fé. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Dorna Kel



<b>Fisionomia:</b> Preservar: sobrancelhas claras, ombro esquerdo mais baixo. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Druvak



<b>Fisionomia:</b> Preservar: mais novo que Kharug, tranças curtas, cicatriz junto ao queixo. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Dália Ress



<b>Fisionomia:</b> Preservar: ombros largos, cabelo preto preso num pano. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Edranna Halven



<b>Fisionomia:</b> Preservar: postura ereta, cabelo castanho com branco, sorriso preciso. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Edren Sol



<b>Fisionomia:</b> Preservar: tornozelo deformado, barba irregular. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Elenva Tair



<b>Fisionomia:</b> Preservar: ruivo muito escuro, dois dedos unidos por cicatriz. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Eline



<b>Fisionomia:</b> Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Elthara Sorn



<b>Fisionomia:</b> Preservar: Rosto largo, cabelo preso junto à cabeça, dois dedos substituídos por prótese simples. Complemento de olhar: sobrancelhas móveis e atenção lateral.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Eran Pel



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Form



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem cinza-clara, face triangular e nariz pequeno. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Forty



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem ruiva apagada, maxilar largo e orelhas ligeiramente desiguais. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Hadrik Vel



<b>Fisionomia:</b> Preservar: pescoço grosso, pequena cicatriz sobre o nariz. Complemento de olhar: atenção aos gestos do interlocutor.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Happidoh



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem areia escura, focinho alongado e orelhas de pontas escuras. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Ilven Sar



<b>Fisionomia:</b> Preservar: pequena joia no fecho do casaco, apresentação impecável. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Ima Olek



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanha dourada, face estreita e olhos de pálpebras baixas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Ima Teren



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanha, face arredondada; pelo castanho nas mãos preservado. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Irena Sol



<b>Fisionomia:</b> Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Istren Vaul



<b>Fisionomia:</b> Preservar: marcas de varíola, expressão cautelosa. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Ivela Dorn



<b>Fisionomia:</b> Preservar: 67 anos, cabelo branco preso por fita, dedos com artrite. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Jassa



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Kharug Venn



<b>Fisionomia:</b> Maxilar largo, nariz achatado, presa inferior quebrada, cabelo raspado e mãos com marcas de corda.



<b>Vestimenta:</b> Casaco de tecidos reparados em tons terrosos, botas firmes e bolsas de contrato. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança curta, faca utilitária e equipamento de animais; não posar sempre com a arma erguida. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Khoram Tesh



<b>Fisionomia:</b> Rosto largo, arcadas fortes e olhar preciso; pele verde acinzentada, presa com capa, lentes e nós no cabelo.



<b>Vestimenta:</b> Mangas claras protegidas por colete escuro, tecido gasto na borda da mesa. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Apoios de leitura e instrumentos de conservação, sem arma de rotina. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Le Rink



<b>Fisionomia:</b> Rosto comprido, queixo fino, sobrancelhas retas; olhos cinzentos e marca no pescoço preservados.



<b>Vestimenta:</b> Casaco azul-escuro de acabamento fino, luvas e camisa clara; traje de estrada mais cuidado que luxuoso. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Espada de esgrima e instrumento de proteção; luvas não ocultam automaticamente todos os gestos. Ferida de braço só depois do evento. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Lethia Arven



<b>Fisionomia:</b> Preservar: rosto pequeno, expressão contida. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Lethra Noll



<b>Fisionomia:</b> Preservar: cabelo muito curto, um olho com película leitosa. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Liana Meywood



<b>Fisionomia:</b> Face estreita de maçãs altas, sobrancelhas de alturas discretamente diferentes; cabelo irregular na altura dos ombros preserva a mecha branca.



<b>Vestimenta:</b> Túnica de viagem verde apagado, camisa clara, calças castanhas e botas reparadas; sem ornamento régio. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Arco de madeira sem decoração ostensiva, aljava e faca de campo. Pose atenta com opção real de retirada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Loria Halven



<b>Fisionomia:</b> Preservar: jovem adulta, roupa de manutenção. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Maela Dorn



<b>Fisionomia:</b> Preservar: magra, cabelo castanho preso, tinta no polegar. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Marevim



<b>Fisionomia:</b> Face angulosa, olhos fundos e olheiras discretas, cabelo quase branco; dois dedos pouco móveis. Maturidade e cansaço sem aparência adolescente.



<b>Vestimenta:</b> Tecido cinza-esverdeado e manto escuro com reparos cuidadosos; sem armadura decorativa de vilão. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Instrumentos e superfícies de pesquisa. Agulha e Gema aparecem somente quando a época e a cena permitirem. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Mavra Senn



<b>Fisionomia:</b> Preservar: rosto redondo, parte de uma orelha perdida. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Meral



<b>Fisionomia:</b> Preservar: rosto mais velho, nariz largo, cabelo claro. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Meren Voss



<b>Fisionomia:</b> Preservar: queixo largo, um olho esbranquiçado. Complemento de olhar: canto da boca discretamente assimétrico.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Mereth Sal



<b>Fisionomia:</b> Preservar: gestos precisos. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Mina



<b>Fisionomia:</b> Preservar: cabelo preso de modo informal, tinta seca no punho. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Mira Olek



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanho-acinzentada, focinho curto e face larga. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Narel



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Neris



<b>Fisionomia:</b> Preservar: manto áspero, recipiente de água vazio, rosto comum. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Nima Tel



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem creme, face pequena e orelhas de bases largas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Nyssara Veyl



<b>Fisionomia:</b> Maçãs salientes, nariz suavemente convexo e olhar medido; preservar tranças brancas e mínimo direito parcialmente perdido.



<b>Vestimenta:</b> Casaco vinho-escuro de mangas amplas, faixa de cintura e bolsa de cadernos; roupa prática bem apresentada. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Instrumentos de leitura, luz de trabalho e faca de viagem; magia de sombras não exige arma inventada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Odran Fess



<b>Fisionomia:</b> Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Olen Des



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Orelna Voss



<b>Fisionomia:</b> Preservar: cabelos brancos, voz baixa. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Oren Val



<b>Fisionomia:</b> Preservar: cabeça raspada, olhos lacrimejantes ao vento. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Orven Tal



<b>Fisionomia:</b> Preservar: mão deformada por acidente antigo, roupas austeras. Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Oth Salven



<b>Fisionomia:</b> Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Ressa Til



<b>Fisionomia:</b> Preservar: cicatriz antiga na bochecha, unhas roídas. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Rima Vel



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanho-escura, focinho estreito e maçãs marcadas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Rovan Ess



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Rul Aven



<b>Fisionomia:</b> Rosto de queixo curto e maçãs largas, nariz arredondado, sobrancelhas baixas; orelhas largas com queimaduras antigas preservadas.



<b>Vestimenta:</b> Sobretúnica vinho apagado, camisa de gola simples e bolsos internos; fechos acessíveis ao próprio porte. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lentes de inspeção, caderno e estojo acolchoado; faca utilitária pequena, sem arma marcial habitual. Não replicar a silhueta de Sera. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Saeren Il



<b>Fisionomia:</b> Preservar: cabelo escuro, marca clara na base da orelha. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Seldo Mer



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Seli Ar



<b>Fisionomia:</b> Preservar: ferimento no pé na cena de encontro. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Selk Arven



<b>Fisionomia:</b> Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Selyra Naereth



<b>Fisionomia:</b> Face triangular madura, olhos de pálpebras baixas e lábios finos; nó branco único e rigidez para poupar o joelho.



<b>Vestimenta:</b> Veste violeta apagada de corte amplo e faixas claras; sem decoração que transforme toda cena em cerimônia. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Documentos e apoio de assento conforme necessidade. Nenhuma arma pessoal obrigatória definida. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Sera Vennor



<b>Fisionomia:</b> Rosto arredondado, nariz curto, olhos vivos; cabelo preto, sardas claras e lente esquerda preservados.



<b>Vestimenta:</b> Camisa clara de mangas presas, colete castanho de oficina, calças resistentes e avental conforme tarefa. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Estojo de ferramentas e peças de mana; martelo de trabalho não equivale a arma de guerra. Posição concentrada na peça. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Sirr-Vek



<b>Fisionomia:</b> Preservar: Escamas quase negras; pequena argola de cobre na mandíbula. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Tavian Ordel



<b>Fisionomia:</b> Preservar: rosto marcado, barriga saliente, cansaço visível. Complemento de olhar: sobrancelhas móveis e atenção lateral.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Tavin Orr



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Tessa Mal



<b>Fisionomia:</b> Preservar: cabelo curto, cicatriz no queixo. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Tessa Varn



<b>Fisionomia:</b> Preservar: alta, cabelo cortado à altura do maxilar. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Toren Kel



<b>Fisionomia:</b> Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Varek Oss



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Varesh Khor



<b>Fisionomia:</b> Preservar: escamas cor de cobre, crista serrada. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Varna Il



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Vessa Cor



<b>Fisionomia:</b> Preservar: baixa, ombros fortes, mãos enfaixadas. Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Yarine Vel



<b>Fisionomia:</b> Preservar: Robusta, cabelo ruivo desbotado, movimentos rápidos. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Ysenda Corval



<b>Fisionomia:</b> Preservar: cabelo grisalho raspado de um lado, uma perna rígida. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.

## 9. Matriz de cenas e implantação nas obras



As cenas são diretrizes de composição aprovadas, não trechos já escritos nem uma sequência rígida. Distribuir por rotas e competências reais. Para os novos NPCs, marcar estreia e conhecimento disponível antes de usá-los como testemunhas. Evitar um encontro obrigatório com cada personagem novo no mesmo romance.



Renda de um morto



Uma viúva tenta manter um pagamento no Livro das Esporas. <b>Conexão:</b> Heria: fraude, dependentes e proteção. <b>Participantes possíveis:</b> Demer ou Kharug. Uma conversa encerra a cena; a questão pode voltar com Isembra.



Prata recusada



Um vendedor recusa moeda vistosa e aceita outra gasta depois de ensaio. <b>Conexão:</b> Moedas e confiança, Liga das Balanças. <b>Participantes possíveis:</b> Kharug. Preparar um contrato, sem transformar toda moeda em cifra secreta.



A peça da balsa



Trabalhadores suspendem passagem para trocar uma peça pequena. <b>Conexão:</b> Trabalho, atraso e manutenção em Ayak. <b>Participantes possíveis:</b> Liana e Lenna. Perder tempo tem efeito; a peça não precisa ser sabotada.



Brinquedo antigo



Uma criança brinca com réplica de objeto Eldenari. <b>Conexão:</b> Memória cotidiana e diferença de olhar. <b>Participantes possíveis:</b> Nyssara. Não tornar o brinquedo artefato mágico.



A cadeira de Rul



Ajuste de móvel exige orçamento, prazo e escolhas de quem o usa. <b>Conexão:</b> Porte, ofício e autonomia. <b>Participantes possíveis:</b> Rul e Liana. Liana precisa ouvir em vez de decidir pelo conforto da outra.



Proteção e cobrança



Um cavaleiro afasta um cobrador e exige serviço gratuito. <b>Conexão:</b> Casta de Nobilith e dependência. <b>Participantes possíveis:</b> Kharug ou Demer. Antecipar divisão de juramentos sem revelar o acordo secreto.



Reserva nova



Famílias discutem a localização de um depósito oleake. <b>Conexão:</b> Defesa dispersa e trabalho doméstico. <b>Participantes possíveis:</b> Tima Oren. Pequena história com decisão comunitária própria.



Partida suspensa



Piloto muda horário por sinais costeiros que outros não percebem. <b>Conexão:</b> Conhecimento local e economia do risco. <b>Participantes possíveis:</b> Neral Doss ou Vessa. Não confirmar explicação sobrenatural obrigatória.



Carta atrasada



Uma carta chega depois de ambas terem mudado os planos. <b>Conexão:</b> Intimidade, correios e vida profissional. <b>Participantes possíveis:</b> Liana e Rul. Não criar abandono onde houve desencontro de informação.



Duas medidas de água



Um desvio beneficia uma propriedade e prejudica hortas. <b>Conexão:</b> Quinder: irrigação e representação. <b>Participantes possíveis:</b> Mira Saven. A missão atravessa um conflito que não pode resolver numa tarde.



Comporta silenciosa



Uma instalação parada continua exigindo manutenção mínima. <b>Conexão:</b> Dorgamar: custo do abandono e decisão de investimento. <b>Participantes possíveis:</b> Dovra e Sera. Conhecimento técnico tem história social e prioridade política.



O turno disputado



Uma equipe perde o trabalho após horas esperando inspeção. <b>Conexão:</b> Cávia: trabalho portuário e quem paga a espera. <b>Participantes possíveis:</b> Borrin e Vessa. Concluir a reclamação local sem exigir grande conspiração.

{"type": "table", "heads": ["Material", "Implantação necessária"], "rows": [["Registro 2.0", "Vigente nesta entrega: substituir decisões superadas e conservar pendências de implantação."], ["C1 e C2 em conjunto", "Retirar romance Liana-Demer; preparar Liana-Rul; incorporar responsabilidades da Ordem, negociação militar, custos e cenas adequadas. Rever epílogos e cronologia de Nobilith."], ["História Geral", "Alinhar relações, sucessão, moedas, grupos sociais e cronologia. A publicação ao fechar 788 pode conhecer a morte de Osric e a coroação contestada."], ["Anais", "Conhecimento até 787: aprofundar antecedentes e responsabilidade, sem narrar como passado a batalha ou a sucessão de 788. Um adendo futuro precisa de data e autor."], ["Guias e obras temáticas", "Aplicar moedas e descrições dentro da época de cada autor. ME trata do passado e não recebe moedas modernas como se fossem universais no reinado de Selvar. BA, publicado em 2386 da II Era, não recebe pessoas novas de 788."], ["Manuais de RPG", "Preservar início de 788; não apresentar a morte de Osric ou desfechos como situação inicial. Moedas entram como ambientação sem substituir preços de referência."], ["Wikia", "Atualizar textos, perfis, relações, filtros e imagens em tarefa própria; W09 continua sendo versão anterior até publicação efetiva."]], "widths": [0.23, 0.77]}



A cada atualização, conferir impacto no Registro na mesma tarefa. Alteração factual, cronológica, física, relacional ou mecânica pede anotação; estilo e layout isolados não exigem decisão canônica. Acompanhamento é procedimento de trabalho, sem sincronização automática em segundo plano.

## 10. Fichas de composição das localidades



Complementos para as 70 entradas de lugar já inventariadas. As vistas de reinos ou estados são recortes representativos e devem nomear a localidade escolhida. O objetivo é diferenciar função, materiais, trabalho e composição sem inventar relevo ou edifícios incompatíveis com o mapa. A estação permanece uma escolha explicitada na encomenda de imagem.



356 Milles



<b>Base preservada:</b> Povoação de Milles cujo nome se associa a um antigo marco de levantamento imperial.



<b>Composição e peculiaridade:</b> Pátio de parada, volumes de carga e abrigo de manutenção: mostrar circulação e trabalho em vez de uma segunda capital monumental.



Aethravel



<b>Base preservada:</b> Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.



<b>Composição e peculiaridade:</b> Recintos de estudo, corredores de serviço e pátio de abastecimento; equipamentos em manutenção e móveis de portes diversos. A Ordem não é só uma torre isolada.



Aston



<b>Base preservada:</b> Cidade do circuito meridional de Aelvar, entre as relações de Emvale e Thalendriel.



<b>Composição e peculiaridade:</b> Pomares manejados, acesso de propriedades e edifícios de residência; deixar visível o trabalho que sustenta a aparência ordenada.



Atlante



<b>Base preservada:</b> Cidade costeira da Rácia articulada às relações de rio e aos trajetos do Mar das Espadas.



<b>Composição e peculiaridade:</b> Margem de desembocadura e transição entre transporte fluvial e saída costeira; distinguir equipamentos de rio e de mar.



Bosque de Aurenval



<b>Base preservada:</b> Bosque de Oleakia ligado a coleta, abrigo e negociação dos caminhos.



<b>Composição e peculiaridade:</b> Áreas de bosque, cultivo, caminhos e cercados; mostrar o manejo humano e oleake sem transformar toda árvore em moradia.



Bosque de Let-Thalara



<b>Base preservada:</b> Bosque de Aelvar entre os acessos de Emvale e Aston.



<b>Composição e peculiaridade:</b> Bosque de Aelvar e acessos entre Emvale e Aston; clareiras e árvores de portes diferentes, sem sede de coroa florestal.



Bosque de Leth-Auren



<b>Base preservada:</b> Área de manejo, coleta e acordos na Grande Floresta de Nael-Sul.



<b>Composição e peculiaridade:</b> Postos e áreas de uso da comunidade, com sinais de acordos de coleta; não repetir a cena urbana de Nael-Sul.



Cidade de Bergen



<b>Base preservada:</b> Centro urbano setentrional ligado a abastecimento, rotas e tradições locais de Bergen.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Cidade de Chisiague



<b>Base preservada:</b> Núcleo de conselho, desembarque e armazenagem na porção interior da entrada marítima.



<b>Composição e peculiaridade:</b> A cidade integra os acessos de passos e margens; rocha, abrigo e circulação são prioritários. Respeitar a abertura marítima a leste.



Cidade de Heria



<b>Base preservada:</b> Centro urbano do reino de Heria e de suas relações de corte, serviço e cavalaria.



<b>Composição e peculiaridade:</b> Audiência, serviço de cavalaria e vida de trabalhadores em espaços distintos; contrastar manutenção real e apresentação nobre.



Cidade de Jacomb



<b>Base preservada:</b> Centro urbano de Jacomb ligado às atividades de porto e às referências de pilotos.



<b>Composição e peculiaridade:</b> Ponto de contratação e circulação de notícias marítimas, com mapas de trabalho e referências de pilotos; não representar Lombonia como parte urbana.



Cidade de Milles



<b>Base preservada:</b> Capital do Reino de Milles, ao sul da grande área florestal.



<b>Composição e peculiaridade:</b> Capital com administração e depósitos ligados a percursos frios; serviços e moradores distinguem a cena de uma simples parada de comboios.



Cidade de Nobilith



<b>Base preservada:</b> Centro urbano de Nobilith, com casas antigas, ofícios e relações de apresentação.



<b>Composição e peculiaridade:</b> Casas antigas e administração de rendas; cavaleiros, servidores e proprietários usam os mesmos acessos com posições sociais diferentes.



Cidade-Estado de Ayak



<b>Base preservada:</b> Governo dos cais nas desembocaduras ao norte de Quinder.



<b>Composição e peculiaridade:</b> Conselho e turnos de cais coexistem com balsas, correntes e depósitos; a margem condiciona os movimentos.



Cidadela do Norte



<b>Base preservada:</b> Posto e cidade na margem ocidental do Estreito do Norte.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Confederação Halfling de Pellanor



<b>Base preservada:</b> Rede de pequenos estados e comunidades halflings sem capital soberana única.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Confederação Orc



<b>Base preservada:</b> Pacto entre comunidades orcs que conservam autonomia e decisões em assembleia.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Corte do Estreito



<b>Base preservada:</b> Centro político insular de Nogard, articulado às casas e comandos de frota dos meio-dragões.



<b>Composição e peculiaridade:</b> Núcleo insular de governo e fiscalização nogard; pessoas de feições dracônicas variadas, embarcações e acesso controlado.



Domínio de Naerath



<b>Base preservada:</b> Casas de elfos negros e caminhos junto à Floresta Negra.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Dorgal



<b>Base preservada:</b> Centro político de Dorgamar, ligado a assembleias, casas e saberes de trabalho com pedra e água.



<b>Composição e peculiaridade:</b> Audiência de governo, contas e interlocutores de cidades e canais; pedra trabalhada e instrumentos de obra, sem tesouro espalhado como mobiliário.



Emvale



<b>Base preservada:</b> Capital de Aelvar, ligada à corte de Arriot Ilvar e aos circuitos de Aston e Thalendriel.



<b>Composição e peculiaridade:</b> Capital de Aelvar: funções de corte e de abastecimento convivem; roupa de cerimônia contrasta com carregadores e artífices.



Grande Floresta de Nael-Sul



<b>Base preservada:</b> Grande região florestal em torno do relevo central de Vradrath.



<b>Composição e peculiaridade:</b> Distinguir áreas manejadas, usos e caminhos de comunidades da vegetação menos alterada; não repetir a floresta de outro reino como imagem intercambiável.



Grande Muralha de Hravn



<b>Base preservada:</b> Fortificações de Bergen sustentadas por postos, trabalho e abastecimento.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Ihfarilse



<b>Base preservada:</b> Centro urbano da Rácia associado a oficinas, biblioteca e aos trabalhos do Circuito do Vento Arcano.



<b>Composição e peculiaridade:</b> Oficinas, biblioteca e Circuito em espaços com funções diferentes; equipamentos não ocupam cada praça como cenário de exposição.



Império de Dorgamar



<b>Base preservada:</b> O império anão, suas cidades e a infraestrutura que atravessa a pedra.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Império de Nogard



<b>Base preservada:</b> Terra dos meio-dragões, cujo império insular controla passagens orientais do Mar das Espadas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Isnymelha



<b>Base preservada:</b> Capital da Sokeria, conhecida pela presença da pedra e pelas relações entre costa e interior.



<b>Composição e peculiaridade:</b> Cidade militar marítima: armazenamento e manutenção de defesa convivem com vida de mercado e dependência dos campos.



Juu Daixo



<b>Base preservada:</b> Cidade de trabalho mineral, carvão e transporte nos acessos montanhosos da Cávia.



<b>Composição e peculiaridade:</b> Carvão, metal, combustível e transporte; madeira, fuligem e ferramentas de trabalho sem transformar toda pessoa em mineiro.



Leopoldina



<b>Base preservada:</b> Localidade de Milles entre os itinerários que articulam povoações e bordas florestais.



<b>Composição e peculiaridade:</b> Circulação do Estreito e apoio a viajantes; mostrar carga e acesso por embarcação, sem inventar ponte marítima contínua.



Liga dos Passos de Chisiague



<b>Base preservada:</b> Liga em torno de uma entrada marítima alongada, aberta a leste entre faixas montanhosas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Lombonia Ghostland



<b>Base preservada:</b> Ilhas cercadas por relatos inquietantes e investigações incompletas.



<b>Composição e peculiaridade:</b> Ilhas e vestígios sob condições de risco; preservar incerteza e a época da cena. Não antecipar a ocupação de Marevim em imagens da II Era.



Mar das Espadas



<b>Base preservada:</b> Águas que ligam reinos, cidades portuárias e memórias do comércio imperial.



<b>Composição e peculiaridade:</b> Água entre circuitos costeiros com navegação e esperas reais; não desenhar uma estrada sobre o mar.



Mar de Lombonia



<b>Base preservada:</b> Mar dos circuitos orientais, associado às ilhas de Lombonia e a portos de diferentes estados.



<b>Composição e peculiaridade:</b> Respeitar a posição cartográfica e acessos costeiros. A existência de relatos ameaçadores não exige uma tempestade eterna.



Morvek



<b>Base preservada:</b> Cidade portuária de Dorgamar, com oficinas, depósitos, moradias e serviços de navegação.



<b>Composição e peculiaridade:</b> Porto e circulação comercial de Dorgamar; diferenciar da sede política e dos canais interiores.



Nael-Sul



<b>Base preservada:</b> Capital de Thaelorien, nos acessos da Grande Floresta de Nael-Sul e dos relevos de Vradrath.



<b>Composição e peculiaridade:</b> Cidade de governo e santuários nos acessos da floresta; edifícios, caminhos e moradores, sem fundir a cidade inteira na formação florestal.



Nerathiel



<b>Base preservada:</b> Capital de Iltharion e centro da corte de Elyndra Vaess.



<b>Composição e peculiaridade:</b> Corte e acessos orientais; mostrar trabalho e circulação próprios de Iltharion, sem copiar Emvale ou apresentar todos os habitantes em visita cerimonial.



Nerevala



<b>Base preservada:</b> Cidade meridional de Valerith, disputada por reivindicações da Sokeria e da Rácia.



<b>Composição e peculiaridade:</b> Cais e entradas fiscalizadas por interesses rivais; recibos, mantimentos e guarda pequena, sem três coroas reinando simultaneamente na cidade.



Nhal-Sular



<b>Base preservada:</b> Capital de Sularien, ligada à vida política e às relações costeiras de seu reino.



<b>Composição e peculiaridade:</b> Contratação marítima e disputa por intermediação; armazéns e pontos de cobrança em vez de monumentalidade genérica de reino élfico.



Nova Milles



<b>Base preservada:</b> Cidade de Milles nos circuitos de campos, pousos e floresta do interior.



<b>Composição e peculiaridade:</b> Etapa do circuito do norte com abastecimento, espera e manutenção; escala de serviço distinta da capital.



Orvalda



<b>Base preservada:</b> Cidade de Thaelorien ligada aos acessos costeiros e aos caminhos florestais.



<b>Composição e peculiaridade:</b> Circuito costeiro de Thaelorien: roupa e ferramentas de transporte podem conviver com materiais de floresta sem transformar o porto em bosque fechado.



Passagem de Sar-Nobil



<b>Base preservada:</b> Rota de travessia associada à Serra de Sar-Nobil.



<b>Composição e peculiaridade:</b> Mostrar a rota praticável, curvas, espera, animais e manutenção; não confundir o trajeto com a totalidade da serra.



Pombo Torto



<b>Base preservada:</b> A estalagem de Lethra Noll em Samarith.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Quinder



<b>Base preservada:</b> Reino entre campos verdes e terras mais secas, com cultivo sustentado pelo Taoju e pelo Asmarith.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Rada de Vau-Cinzento



<b>Base preservada:</b> Ancoragem e pequenos acessos de cabotagem da costa meridional de Quinder.



<b>Composição e peculiaridade:</b> Margens e acessos de desembarque devem deixar legível o trecho terrestre posterior; não transportar Samarith até a praia.



Reino da Cávia



<b>Base preservada:</b> Reino de portos, mineração e transporte entre Trogu e as subidas de Juu Daixo.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino da Rácia



<b>Base preservada:</b> Oficinas, arquivos e circulação de técnicas nos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Aelvar



<b>Base preservada:</b> O reino setentrional dos elfos altos, entre cidades antigas e a influência da Ordem.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Bergen



<b>Base preservada:</b> Reino setentrional de rotas frias, fortificações e tradições religiosas próprias.



<b>Composição e peculiaridade:</b> Pedra e serviços ligados à corte e às rotas do norte; conservar circulação de moradores e mantimentos, sem transformar toda cena em muralha.



Reino de Heria



<b>Base preservada:</b> Tradições de cavalaria e tensões sobre serviço, rendas e privilégios num dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Iltharion



<b>Base preservada:</b> Reino oriental de elfos altos, independente da corte de Emvale.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Jacomb



<b>Base preservada:</b> Reino oriental ligado à navegação, aos pilotos e à circulação de notícias entre costas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Milles



<b>Base preservada:</b> Rotas setentrionais, floresta e relações de câmbio entre o Estreito e as cidades do interior.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Nobilith



<b>Base preservada:</b> Casas antigas, direitos de propriedade e disputas de sucessão num dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Sularien



<b>Base preservada:</b> Estado élfico negro do sudeste, com centro em Nhal-Sular e relações de costa próprias.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Thaelorien



<b>Base preservada:</b> O reino florestal ao sul dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Roial



<b>Base preservada:</b> Centro comercial e contábil de Milles, com funções próprias na rede de cidades do reino.



<b>Composição e peculiaridade:</b> Parada de circulação no reino de Milles; carga, abrigo e trabalho sazonal distinguem a vista de floresta ou palácio.



Samarith



<b>Base preservada:</b> Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.



<b>Composição e peculiaridade:</b> Santuários, hospedarias, petições e assistência em uma cidade habitada; a Torre não deve apagar o restante da vida urbana.



Serra de Sar-Nobil



<b>Base preservada:</b> Conjunto montanhoso que atravessa predominantemente Nobilith de norte a sul.



<b>Composição e peculiaridade:</b> Eixo montanhoso predominantemente norte-sul; trilhas de serviço e áreas de abrigo não são uma estrada sobre toda a crista.



Sokeria



<b>Base preservada:</b> Reino central ligado às margens do Mar das Espadas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Terras dos Povos Livres



<b>Base preservada:</b> Região de comunidades e autoridades distintas, sem soberano comum.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Thalendriel



<b>Base preservada:</b> Cidade de Aelvar nas rotas que descem rumo à Cidadela do Norte.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Trogu



<b>Base preservada:</b> Capital e cidade portuária da Cávia, ligada ao comércio marítimo e às remessas do interior.



<b>Composição e peculiaridade:</b> Docas, concessões, estaleiros e equipes de carga em condições diferentes; mostrar o trabalho que sustenta o porto.



União das Tocas de Oleakia



<b>Base preservada:</b> Comunidades oleakes, refúgios e depósitos dispersos numa união de tribos e assembleias.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vaelen Endor



<b>Base preservada:</b> Capital de Valerith e antiga capital imperial, com edifícios, mercados e arquivos de usos sucessivos.



<b>Composição e peculiaridade:</b> Antiga capital e corte atual de Valerith: cantaria histórica adaptada, arquivo, crédito e trabalho urbano em vez de ruína desabitada.



Valada



<b>Base preservada:</b> Cidade do corredor entre Ihfarilse, as passagens interiores e os acessos do Caminho Alto.



<b>Composição e peculiaridade:</b> Registros, audiência e trânsito de trabalhadores; água e corredor terrestre fazem parte da composição sem reduzir a cidade a tribunal.



Valerith



<b>Base preservada:</b> Reino central que conserva em Vaelen Endor uma herança imperial.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vardessa — Império Ocidental



<b>Base preservada:</b> Estado ocidental conhecido por contatos diplomáticos e comerciais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vel-Narim



<b>Base preservada:</b> Centro político de Naerath, ligado aos acessos orientais da Floresta Negra.



<b>Composição e peculiaridade:</b> Corte e circulação no Domínio, em relação com a Floresta Negra; edifícios e clareiras trabalhadas, sem noite sobrenatural permanente.



Wegas



<b>Base preservada:</b> Cidade dos percursos interiores de Milles, ligada à região da floresta e suas estradas.



<b>Composição e peculiaridade:</b> Travessia, cargas e aproximações do relevo; desenhar o acesso praticável em vez de carroças sobre uma crista aleatória.



Xeo Taoju



<b>Base preservada:</b> Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.



<b>Composição e peculiaridade:</b> Capital de Quinder com monumentos Eldenari, corte, canais e tarefas de manutenção; combinar solo seco e áreas irrigadas de maneira localizada.

## 11. Decisões geográficas vigentes

### RC-G01 — Let-Thalara

Let-Thalara designa somente o bosque de Aelvar, entre os acessos de Emvale e Aston. Não é a capital de Thaelorien.

Base: DA; HG pp. 5 e 78; GV pp. 28 e 32.

Aplicação: Corrigir menções de capital, ligações de verbetes e mapas derivados. Preservar o bosque.

### RC-G02 — Nael-Sul

Nael-Sul é a cidade capital de Thaelorien. A Grande Floresta de Nael-Sul existe normalmente como entidade geográfica distinta e homônima.

Base: DA; HG pp. 58 e 64; GJ p. 18.

Aplicação: Manter fichas e referências separadas para cidade e floresta; não apagar uma para resolver a ambiguidade.

### RC-G03 — Chisiague

O mapa de referência está correto: a entrada de água marítima abre-se a leste. Textos e imagens devem respeitar essa abertura.

Base: DA; HG p. 5; GV p. 4; FR caderno ambiental.

Aplicação: Não fechar a extremidade oriental nem deslocar a abertura para oeste. O mapa não determina sozinho a navegabilidade de cada trecho.

### RC-G04 — Mar de Lombonia

Mar de Lombonia é o nome oficial. Mar das Tormentas deixa de ser o nome canônico dessa água.

Base: DA; W09 mar-lombonia.

Aplicação: Substituir o antigo topônimo onde designar esse mar. A palavra tormentas, como fenômeno meteorológico, continua válida.

### RC-G05 — Nerevala

A grafia oficial é Nerevala, conforme o mapa. Neravala é variante legada para pesquisa e correção, sem constituir outra cidade.

Base: DA; HG pp. 5 e 73; GV p. 19.

Aplicação: Normalizar títulos e nomes visíveis. Um redirecionamento de endereço antigo pode ser preservado.

### RC-G06 — Reino e cidade de Milles

O reino de Milles e a cidade de Milles existem; a cidade é a capital do reino.

Base: DA; HG p. 5; W09 milles e cidade-milles.

Aplicação: Não fundir os dois verbetes. Em tabelas, explicitar se o campo trata da unidade política ou do centro urbano.

### RC-G07 — Serra de Sar-Nobil

A Serra de Sar-Nobil atravessa predominantemente Nobilith de norte a sul. É o conjunto montanhoso associado ao corredor.

Base: DA; HG pp. 60 e 81; GV p. 11.

Aplicação: Rever descrições de relevo e de orientação; não tratar a serra inteira como estrada.

### RC-G08 — Passagem de Sar-Nobil

A Passagem de Sar-Nobil é a rota de travessia associada ao corredor. Articula os acessos de Quinder e de Vaelen Endor com a descida por Nobilith rumo à Sokeria, e o percurso inverso.

Base: DA; HG pp. 81 e 110; GJ p. 12.

Aplicação: Preservar as ligações laterais e os acessos utilizáveis; não redesenhar um caminho reto sobre qualquer ponto da crista.

### RC-G09 — Cavaleiros de Nobilith

Os cavaleiros de Nobilith constituem uma casta importante da nobreza. Linhagem, patrimônio, formação e obrigações de serviço ajudam a organizar seu poder.

Base: DA; HG p. 60; W09 nobilith.

Aplicação: Desenvolver privilégios, dependências e serviço sem reduzir todos os cavaleiros a guardas de estrada.

### RC-G10 — Confederação Halfling

A Confederação Halfling de Pellanor fica a oeste, além da Cordilheira de Welkar. A folha cartográfica e a HG consultadas grafam Velkar. A posição ocidental está confirmada.

Base: DA; HG pp. 58 e 81; W09 pellanor.

Aplicação: Preservar a localização. Usar remissão Welkar / Velkar; a escolha de uma grafia única para todas as fontes permanece aberta.

### RC-G11 — Quinder

Quinder apresenta campos verdes em transição para terras mais secas, com agricultura dependente da água. Não é integralmente desértico.

Base: W09 quinder; HG seção de Quinder; GV capítulos de Quinder.

Aplicação: Variar imagens de campos, canais, solo seco e povoamento. Evitar dunas universais ou vegetação uniforme.

### RC-G12 — Nogard

Nogard é terra de meio-dragões. O nome pode designar o povo e o estado, conforme o contexto. A dinastia imperial não representa todos os indivíduos.

Base: DA sobre as imagens; LR p. 9; W09 nogard.

Aplicação: Incluir habitantes meio-dragões quando apropriado às cenas; não transformar toda a população em dragões de outra escala.

### RC-G13 — Nerevala e soberania

Nerevala pertence a Valerith no marco de referência, apesar de pretensões de Sokeria e Rácia. A Trégua das Três Portas não equivale a transferência de soberania.

Base: HG pp. 73 e 145; GV p. 19.

Aplicação: Distinguir administração, influência, pretensão e soberania.

### RC-G14 — Reino, capital e povo

Uma predominância de povo não torna um reino etnicamente uniforme. Capital, sede rotativa, corte insular e coordenação confederativa são categorias diferentes.

Base: HG pp. 45 e 49; LR pp. 8-9; W09.

Aplicação: Não inventar capital única para Pellanor, nem monarquia uniforme para toda confederação.

## 12. Tempo, eras e acesso à informação

Complemento vigente da cronologia imperial

Os registros RC-VE e as tabelas dos capítulos de integração imperial desta edição completam as datas anteriores. As marcas base e ampliação indicam a procedência no livro VE. Ambas são adotadas nesta edição, preservadas as incertezas e questões abertas expressas.

### RC-T01 — O marco comum

O estado padrão para RPG e apresentação sem spoilers é o início de 788 da III Era, antes dos acontecimentos posteriores da crise.

Base: DA; HG p. 8; GJ capa; W09 terceira-era.

Aplicação: Não apresentar mortos, ferimentos futuros ou mudanças de função como situação inicial.

### RC-T02 — Calendário da Concordância

O ano comum possui doze meses de trinta dias e cinco Dias da Vigília após o décimo segundo mês. Não há ano zero entre eras.

Base: HG p. 8.

Aplicação: Escrever era junto de datas antigas e distinguir calendário de data editorial real.

### RC-T03 — Precisão do passado

A I Era tem duração estimada em cerca de 6.400 anos, com incerteza aproximada de seis séculos. A II Era tem 2.431 anos registrados. A formação dos planos não recebe duração material demonstrada.

Base: HG p. 8.

Aplicação: Não transformar 9.619 anos, resultado de uma soma convencional até 788, numa idade exata do mundo.

### RC-T04 — Primeiro encontro dos seis

As Guias Partidas se passam entre 785 e 787. A Audiência das Guias em Valada, no décimo mês de 787, é o primeiro encontro documentado dos seis reunidos. Ainda não constitui companhia permanente.

Base: HG p. 145; C1; W09 liana e le-rink.

Aplicação: Preservar encontros parciais anteriores; não afirmar que seis viajavam sempre juntos desde 785.

### RC-T05 — Idade de Marevim

Marevim Aethros nasceu em 462 da III Era. Em 788 a diferença entre os anos é de 326; sem data de aniversário, não se fixa a idade completada em um dia. Pode ser relativamente jovem para um elfo alto e apresentar maturidade e cansaço.

Base: HG p. 102; AN p. 24; DA sobre maturidade visual.

Aplicação: Não ilustrá-lo automaticamente como adolescente, nem converter idade élfica em idade humana precisa.



Concordância anterior a 788

{"type": "table", "heads": ["Data / era", "Evento e cuidado de continuidade"], "rows": [["c. 1 / I", "Horizonte convencional dos primeiros dragões."], ["c. 2100 / I", "Primeiros assentamentos identificados como Eldenari."], ["c. 2550 / I", "Consolidação urbana de Xeo Taoju."], ["c. 5990 / I", "Travessia das Sete Portas."], ["c. 6035 / I", "Fundação da Ordem em Aethravel."], ["c. 6384 / I", "Ativação do Selo."], ["c. 6393-6399 / I", "Sete campanhas da Guerra das Nove Vigílias."], ["Fim da I Era", "Ruptura do Selo e Grande Punição, separadas por vinte e três dias, segundo a sequência adotada."], ["1-40 / II", "Período mais intenso de escuridão e destruição."], ["1-c. 1000 / II", "Milênio das Trevas; reconstruções regionais desiguais."], ["612 / II", "Desastre de Lombonia."], ["1084 / II", "Paz de Dorgal."], ["1261 / II", "Tratado das Três Margens."], ["1368 / II", "Fundação convencional do Império de Dorgamar."], ["1398 / II", "Concílio das Sete Portas."], ["1517-1546 / II", "Guerra dos Diques em Quinder; anterior ao império de Vaelen Endor e aos canais orientais."], ["1896 / II", "Proclamação imperial de Vaela."], ["2032; 2039; 2058 / II", "Tratado das Águas, início das obras e primeiro conjunto oriental de canais em serviço: marcos diferentes."], ["2078-2149 / II", "Reinado de Selvar II."], ["2386 / II", "Publicação de Bichos e Assombros dos Caminhos."], ["2424-2428 / II", "Campanhas de conquista de Quinder."], ["2429 / II", "Acordo das Lâmpadas."], ["2431 / II", "Concordata de Vaelen e fim da II Era."], ["1 / III", "Primeiro ano posterior à dissolução reconhecida, sem ano zero."], ["61-74 / III", "Guerra das Duas Cortes e independência de Quinder."], ["98 / III", "Reconhecimento da autonomia de Ayak; porto e nome são anteriores."], ["147 / III", "Fundação da Guilda dos Heróis."], ["208 / III", "Reunião inaugural da Mesa das Sete Panelas."], ["219 / III", "Programa da muralha de pedra de Bergen; não é o começo de todos os postos do norte."], ["286 / III", "Organização da Guilda dos Magos."], ["318 / III", "Desastre das Galerias de Anver."], ["326 / III", "Carta das Mãos Abertas: membros plenos não elfos na Ordem."], ["412; 438 / III", "Circuito precursor e carta da Guilda do Vento Arcano: marcos distintos."], ["462 / III", "Nascimento de Marevim Aethros."], ["588 / III", "Início do reinado de Ariessa em Thaelorien."], ["622 / III", "Início do reinado de Arriot em Aelvar."], ["731 / III", "Isolamento da aldeia e morte de Eline."], ["734 / III", "Autorização do Conselho das Duas Margens."], ["741 / III", "Ascensão de Elyndra em Iltharion."], ["754 / III", "Coroação de Brunna IV em Dorgamar."], ["755 / III", "Revisão limitada apoiada por Ivela."], ["759 / III", "Marevim alcança a Gema em Lombonia; dado posterior de reconstrução."], ["763-770 / III", "Querela de Terval e disputas ligadas às famílias de Kharug e Druvak."], ["772 / III", "Disputa das Pontes Baixas em Pellanor."], ["778 / III", "Trabalho de campo do qual vem a amizade de Liana e Rul, conforme W09; não confundir com o Apresamento das Três Bandeiras do mesmo ano."], ["779-783 / III", "Disputas das obras de irrigação de Quinder."], ["785-787 / III", "Caso das Guias Partidas."], ["786 / III", "Tensão naval entre Nogard e Oleakia; acordo provisório."], ["10º mês de 787", "Audiência em Valada; seis reunidos."], ["Último mês de 787", "Publicação ficcional de Entre Feras e Raízes."]], "widths": [0.24, 0.76]}



Fontes: HG pp. 141-145; capas de BA e FR; W09 liana. A lista seleciona marcos úteis à revisão e preserva aproximações. Eventos do mesmo ano não são automaticamente causa uns dos outros.

## 13. A crise de 788 e seus desfechos

Referência de autor e revisão

O conteúdo deste capítulo é canônico de bastidores e inclui o encerramento dos romances. Não deve entrar integralmente em páginas de introdução ou fichas de campanha no início de 788.

{"type": "table", "heads": ["Data em 788", "Sequência de referência"], "rows": [["11 / 2º mês", "Golpe de Marevim e roubo da Agulha."], ["19 / 4º mês", "Primeira chegada da missão a Samarith pelo eixo Aelvar-Naerath-Quinder."], ["27 / 4º mês", "Partida para diligência documental na Rácia, por Nobilith, Valerith e corredor de Valada."], ["5 / 5º mês", "Chegada de Rul a Samarith, enquanto a missão está ausente."], ["27 / 5º mês", "Passagem da missão por Ihfarilse."], ["28 / 6º mês", "Inspeção da urna na costa de Trogu; reencontro com Rul."], ["26 / 7º mês", "Retorno a Samarith pelo Mar das Espadas, desembarque perto de Vau-Cinzento e trecho terrestre."], ["7º e 8º meses", "Testes, ruptura temporária e negociações; oficina de campanha de Sera em Xeo Taoju."], ["Início do 9º mês", "Desembarque do exército principal de Marevim em Vau-Cinzento."], ["18-23 / 9º mês", "Batalha de Samarith."], ["23 / 9º mês", "Operação da Câmara e morte de Marevim."], ["3 e 27 / 10º mês", "Termos provisórios e pacto mais amplo; ratificações ainda parcialmente pendentes."], ["12 / 12º mês", "Recebimento da resposta de Arriot."], ["28 / 12º mês", "Encerramento da coleta de testemunhos da História Geral."], ["2º Dia da Vigília", "Sinos pelos mortos dos quatro exércitos."], ["5º Dia da Vigília", "Publicação ficcional da História Geral consultada."]], "widths": [0.25, 0.75]}



Fonte da sequência datada: HG pp. 145-146. As datas são marcos da concordância histórica; a presença de uma data nessa tabela não elimina conflitos pontuais com cenas ou colofões. O desfecho afetivo abaixo é uma correção editorial expressamente localizada.

### RC-N01 — Liana e Demer: amizade, sem romance

O romance entre Liana Meywood e Demer Vault é retirado da continuidade. Eles conservam amizade, confiança, cuidado e conflitos de valores. Cenas de beijo, desejo romântico, formação de casal ou separação amorosa devem ser removidas ou reescritas. O vínculo amoroso de Liana passa a ser com Rul Aven.

Base: DA2: decisão autoral posterior à edição 1.0; substitui RC-N01 / 1.0.

Aplicação: Revisar C1 e C2, HG, wikia e resumos. O antigo desfecho de separação também deixa de valer; nenhuma das duas versões anteriores é o novo cânone.

### RC-N02 — Demer e sua fé

Demer deixa a função institucional após a batalha, mas conserva sua fé e o símbolo de Ardanus. Não é automaticamente Arauto.

Base: C2 pp. 144-145; W09 demer.

Aplicação: Distinguir afastamento de função, perda de fé e condição divina.

### RC-N03 — Consequências persistentes

Le Rink conserva perda de sensibilidade em parte do braço e mão; a recuperação não é imediata. O protótipo de Sera é consumido na operação. Registros técnicos não equivalem a possuir novamente o exemplar.

Base: C2 pp. 143 e 149; W09 le-rink e sera.

Aplicação: Em cenas posteriores, manter limitações, adaptação e perda material; em retratos anteriores, não antecipá-las.

### RC-N04 — Narel e Druvak

O encontro ligado à consciência de Narel não devolve um corpo ao irmão de Nyssara. Druvak rompe com Marevim e morre protegendo uma retirada, segundo o desfecho adotado.

Base: C2; W09 nyssara, kharug, narel e druvak.

Aplicação: Não restituir personagens ou corpos por simplificação de resumo; um novo retorno exigiria decisão e explicação próprias.

### RC-N05 — Marevim e a responsabilidade

O crime institucional de 731 e o ocultamento do custo humano permanecem verdadeiros. As injustiças sofridas não absolvem Marevim de seus próprios atos. Sua morte na Câmara não apaga a necessidade de apuração.

Base: HG pp. 102 e 138-140; AN folhas reservadas; C2 pp. 138-141.

Aplicação: Preservar responsabilidades múltiplas e evitar uma versão na qual toda violência provém de um único culpado.



Coerência dos deslocamentos



A missão chega primeiro a Samarith, parte para a investigação na Rácia e depois retorna. Não se trata de uma caminhada linear única do norte até o clímax. Rul possui deslocamentos próprios. A rota de regresso e a rota do exército de Marevim não devem ser fundidas apenas porque ambas envolvem o Mar das Espadas e Vau-Cinzento.



Uma passagem de costa exige desembarque e acesso terrestre quando a cidade não está sobre a água. Um passo montanhoso exige uma rota utilizável, não apenas proximidade em linha reta. Uma mudança de mês não prova que todo o intervalo foi gasto em caminhada: controles, trabalho, reparos e espera também consomem tempo. Tempos de viagem do lore podem continuar existindo mesmo que a mecânica do RPG dispense metros e quilômetros obrigatórios.

## 14. Povos, instituições e mistérios

### RC-P01 — Oleakes e Oleakia

Oleakes são um povo de pequeno porte e traços leporinos, com orelhas longas. Há referência explícita a pelo castanho nas mãos de Ima Teren. Oleakia é a União das Tocas; pessoa, povo e estado não são sinônimos.

Base: HG p. 27; BA relato de Ima Teren; LR p. 9; W09 oleakes.

Aplicação: Não fixar altura ou pelagem única a todos. Não reduzir pessoas pequenas a encantamentos, mascotes ou uma profissão universal.

### RC-P02 — Identidades oleakes

Mira Olek pertence às tradições de origem e reservas. Ima Olek coordena a União das Tocas no presente. Ima Teren aparece no relato publicado em 2386 da II Era. Rima Vel é interlocutora de Maelis no caderno de 785. Nima Tel é exemplo de ficha de RPG.

Base: HG pp. 27 e 86; BA; FR; GJ; W09 perfis correspondentes.

Aplicação: Não fundir nomes semelhantes nem transplantar a anfitriã da II Era para o presente sem uma decisão explícita.

### RC-P03 — Defesa comunitária

Happidoh reconhece acessos; Form verifica relatos; Forty organiza defesa sem ataques autorizados a pescadores na tensão de 786. A coordenação não transforma Ima Olek em proprietária de todas as tocas.

Base: HG pp. 67 e 86; W09.

Aplicação: Preservar papéis distintos e a autonomia das comunidades.

### RC-P04 — Povos não fixam personalidade

Povo, cultura, cidadania, classe, culto e lealdade são campos distintos. As dez opções mortais de criação não esgotam todos os seres existentes no universo.

Base: LR pp. 8-10; GJ; HG quadro político.

Aplicação: Não converter bônus de ficha em temperamento obrigatório nem um governo em representante de todo o povo.

### RC-P05 — Kobolds

Kobolds foram retirados do catálogo comum de criação solicitado pelo autor. Isso não apaga Sirr-Vek ou os Tessik do Veio Frio da narrativa.

Base: DA sobre regras; LR pp. 8-10; C2; W09 sirr-vek e tessik-veio-frio.

Aplicação: Manter separadas disponibilidade mecânica e existência no mundo.

### RC-P06 — Ordem e Guilda dos Magos

Ordem dos Magos e Guilda dos Magos são instituições distintas. A Carta das Mãos Abertas de 326 da III Era trata de membros plenos não elfos na Ordem; a Guilda tem marco de organização em 286.

Base: HG p. 143; AN; W09 ordem.

Aplicação: Não fundir instituições por uma função mágica comum; não atribuir a Le Rink comando automático sobre a Ordem.

### RC-P07 — Planos e Arautos

Os planos são Noérion, Eomundus e Virtude. Arauto é uma encarnação divina excepcional, cujo chamado e reconhecimento podem ser incompletos ou disputados. Receber auxílio divino não basta para provar essa condição.

Base: W09 planos, arautos e demer; HG cosmologia.

Aplicação: Distinguir tradição cosmológica, reconhecimento institucional e confirmação narrativa.

### RC-P08 — Grande Punição e Thul Verenari

Causas e extensão da Grande Punição permanecem discutidas. A existência dos Thul Verenari e sua eventual relação com o acontecimento não estão demonstradas. A convicção de Odran integra o relato, não uma prova editorial conclusiva.

Base: FA; BA; HG; W09 thul e punicao.

Aplicação: Não preencher os mistérios com uma explicação única apresentada como descoberta já confirmada.

### RC-P09 — Neris

Neris não deve ser apresentada como manifestação divina confirmada. Relatos e interpretações sobre sua identidade permanecem abertos.

Base: HG p. 140; C2; W09 neris.

Aplicação: Conservar os depoimentos incompatíveis sem transformar uma imagem ou ficha em revelação definitiva.

### RC-P10 — História natural

Os sessenta registros de Maelis formam o catálogo de FR desta edição. Indivíduos acrescentados à categoria Natureza da wikia, como Avô Gotejo, não aumentam retroativamente o catálogo da autora.

Base: FR; W09 natureza e avo-gotejo.

Aplicação: Separar espécie, nome popular, classificação provisória e indivíduo. Não converter lenda local em propriedade universal de um organismo.



Narradores podem discordar



Uma diferença é preservável quando tem função clara: observação limitada, relato de época, interpretação religiosa, propaganda institucional ou hipótese. Para mantê-la, o texto deve dizer quem afirma, quando afirma e com que alcance. A explicação local do Sino Sem Badalo não encerra todas as versões da lenda. A discordância não precisa ser apagada para manter continuidade.



Não usar um narrador pouco confiável como desculpa automática para qualquer erro. Afirmar que uma capital está em outro continente, sem intenção narrativa nem atribuição, normalmente pede correção factual. Já uma cerimônia ou uma classificação natural pode variar entre comunidades sem contradição.

## 15. Aparência e continuidade visual

### RC-V01 — Estilo padrão

A arte padrão de Virtude usa fantasia estilizada. As figuras devem conservar posturas variadas e naturais; a composição de Liana pode ser mantida quando solicitado.

Base: DA sobre o estilo e as imagens.

Aplicação: Aplicar em novas encomendas e revisões. Uma exploração artística anterior não substitui a diretriz vigente.

### RC-V02 — Descrição antes de interpretação

Traços explicitamente descritos nos materiais orientam as imagens. Escolhas visuais não descritas, como pormenores de um rosto, não se tornam fatos canônicos automaticamente.

Base: Critério de continuidade adotado; legendas interpretativas de W09.

Aplicação: Se uma descrição física ainda não estiver ancorada em fonte ou decisão, registrar como interpretação visual, não como nova biografia.

### RC-V03 — Rostos distintos

Personagens não devem ter feições praticamente idênticas. Variar discretamente formatos de rosto, nariz, maxilar, olhos, sobrancelhas e expressão, respeitando os traços fixados no lore.

Base: DA da edição 0.9.

Aplicação: Não inventar cicatrizes, amputações, parentescos ou idade precisa apenas para diferenciar rostos.

### RC-V04 — Miniaturas e lugares

Miniaturas devem preservar rosto, cabelo e orelhas. Imagens de localidades devem acompanhar relevo, água, vegetação e povoamento descritos, com personalidade própria.

Base: DA sobre recortes e localidades.

Aplicação: Ajustar enquadramento e contenção sem alterar a anatomia. Evitar repetir uma cidade genérica para todo reino.



Fichas físicas de referência



<b>Liana Meywood.</b> Pele acobreada; mecha branca na têmpora; cicatriz no lábio inferior. Fonte de consulta: W09 / liana.



<b>Demer Vault.</b> Barba curta; cabelos pretos; queimadura no antebraço. Fonte de consulta: W09 / demer.



<b>Le Rink.</b> Olhos cinzentos; cabelo claro preso; marca no pescoço. Fonte de consulta: W09 / le-rink.



<b>Nyssara Veyl.</b> Tranças brancas finas; olhos castanhos; perda parcial do mínimo direito. Fonte de consulta: W09 / nyssara.



<b>Kharug Venn.</b> Presa inferior quebrada; cabelo raspado; marcas de corda nas mãos. Fonte de consulta: W09 / kharug.



<b>Sera Vennor.</b> Cabelo preto; sardas claras; lente no olho esquerdo. Fonte de consulta: W09 / sera.



<b>Marevim.</b> Cabelos quase brancos; olhos fundos; dois dedos pouco móveis. Fonte de consulta: W09 / marevim; conferir a passagem literária antes de acrescentar pormenores. Para Marevim, juventude relativa é compatível com cansaço e traços maduros; não há conversão numérica automática para um humano.



A ficha física descreve o corpo no momento apropriado. Um ferimento obtido em 788 não deve aparecer automaticamente em um retrato de 787. A presença de uma arma numa pintura não prova que seja o único equipamento usado pelo personagem. Sem descrição de vestuário exclusivo, variações coerentes de roupa são possíveis.

Aparência: escopo resolvido nesta edição

O autor solicitou aprofundamento de aparência, vestuário, armas e diferenças entre personagens e localidades. A edição 2.0 estabelece fichas visuais textuais, preservando marcas anteriores e identificando os complementos novos. As imagens existentes não foram regeneradas nesta tarefa.

## 16. Regras do RPG e cânone do mundo



A referência mecânica é o Livro de Regras 0.3, com Guia do Jogador 0.2 compatível. Regras de teste continuam sujeitas a partidas e revisão; a versão deve ser indicada quando houver mudança. Uma mecânica de campanha não precisa descrever literalmente cada fenômeno narrativo do mundo.

### RC-R01 — Atributos

FOR, DEX, CON, INT, VON e CAR variam de 2 a 18. MOD: 2-3 = -3; 4-5 = -2; 6-7 = -1; 8-12 = 0; 13-14 = +1; 15-16 = +2; 17-18 = +3.

Base: DA; LR p. 6.

Aplicação: Não voltar à faixa antiga de 3-18 nem substituir CON por Saúde nos campos da edição vigente.

### RC-R02 — Teste sem perícia

Uma tentativa permitida sem perícia treinada usa exatamente o atributo em porcentagem. Não recebe multiplicador, MOD, bônus circunstancial ou piso de 5%. Tarefas rotineiras podem dispensar teste; técnicas especializadas podem exigir treino.

Base: DA; LR p. 5.

Aplicação: FOR 14 significa 14%. A regra não concede conjuração ou fabricação especializada sem treinamento.

### RC-R03 — Leitura do d100

Dois dados de dez faces: um para dezena e outro para unidade, definidos antes. Os dois zeros representam 100.

Base: DA; LR p. 5.

Aplicação: Não interpretar 00 como sucesso zero.

### RC-R04 — Perícia treinada

Na regra 0.3, a fórmula é 35% + 5 × MOD + pontos investidos + bônus permanentes, respeitando os tetos da versão. A frase que manda multiplicar o atributo por cinco na mesma página é um erro editorial.

Base: LR p. 12, fórmula e frase em conflito.

Aplicação: Na revisão, escrever que entra cinco vezes o modificador do atributo. Não aplicar cinco vezes o valor bruto.

### RC-R05 — Criação

Nível 1: até três perícias treinadas e 40 pontos, no máximo 20 em uma; teto final inicial de 55%. PV máximos = CON. PM máximos = VON + MOD de INT, mínimo 6.

Base: LR p. 7.

Aplicação: Distinguir PV iniciais do ganho por avanço; não somar os 40 pontos em cada perícia.

### RC-R06 — Progressão

Um nível a cada três sessões concluídas, grupo no mesmo nível. Do 2 ao 30: +1d6 + MOD de CON PV máximos, mínimo 1; +2 PM e +5 pontos de perícia por avanço. Há marcos de aprimoramento e treinamento na tabela própria.

Base: DA sobre simplificação; LR pp. 16-18.

Aplicação: Não misturar XP antigo com sessões nem conceder o ganho por sessão individualmente.

### RC-R07 — Após o nível 30

A cada três sessões, um grau de legado: +1 PV máximo, +1 PM máximo e +5 pontos, seguindo os limites e opções de LR p. 19.

Base: LR p. 19.

Aplicação: Registrar nível 30, legado N; não extrapolar automaticamente o ganho de 1d6 para o nível 31.

### RC-R08 — Magia

Seis caminhos: Fogo, Água, Terra, Ar, Luz e Trevas. Técnicas exigem treinamento, magia conhecida e requisitos de círculo. Classe não é proibição absoluta de aprender magia.

Base: LR pp. 7, 11-12 e catálogo de magia.

Aplicação: Não trocar silenciosamente por escolas de outro sistema; mudanças exigem nova versão mecânica.

### RC-R09 — Distâncias e viagens

Posição, deslocamento e viagem são resolvidos pela cena, recursos e bom senso, sem metros ou quilômetros obrigatórios.

Base: DA; LR pp. 2 e 6.

Aplicação: Isso simplifica a mesa; não apaga geografia, obstáculos ou duração das viagens no lore.

### RC-R10 — Dano e proteção

O pedido base estabelece dano desarmado 1d3 + MOD e armas simples 1d6 + MOD. A aplicação final de tipo, mãos, FOR mínima e redução de dano segue o catálogo e o combate da versão 0.3.

Base: DA; LR catálogo de armas e combate.

Aplicação: Não transformar todo equipamento em um único dado nem somar duas proteções quando a regra manda usar o maior valor.



Limite entre sistemas e mundo



Os dez povos mortais comuns são humano, elfo alto, elfo da floresta, elfo negro, anão, orc, goblin, halfling, oleake e nogard. Eldenari é origem excepcional condicionada ao período ou à premissa. Dragões e Arautos não são pacotes comuns de criação. Elfos altos do norte e do leste são formações regionais, não um quarto pacote élfico automático (LR pp. 8-10).



As oito classes são Guerreiro, Guardião, Batedor, Ladino, Mago, Devoto, Artífice e Diplomata (LR p. 11). Títulos narrativos, como ranger ou paladino, não exigem uma classe adicional de mesmo nome. Uma ficha usada como exemplo não transforma a pessoa em participante obrigatório dos romances.

## 17. Divergências e fila de correções

Situação após a decisão autoral

DV-01 recebeu nova definição: todo romance Liana-Demer é retirado, incluindo o desfecho de separação escolhido na 1.0. DV-02 e DV-03 continuam pendentes; DV-04 e DV-05 permanecem abertos. As decisões 2.0 criam novas pendências de implantação, descritas na matriz, e não tornam corrigidos os PDFs antigos.



Os itens abaixo distinguem conflitos atuais confirmados, divergências históricas já harmonizadas nos trechos consultados e dúvidas novas. Nenhuma obra foi alterada pela produção deste Registro. A lista é uma fila de trabalho; não uma alegação de que cada ocorrência foi corrigida.

Desfecho de Liana e Demer

{"type": "audit", "id": "DV-01", "status": "IMPLANTADO NOS ROMANCES E NA HISTÓRIA GERAL / WIKIA PENDENTE", "title": "Desfecho de Liana e Demer", "evidence": "HG p. 140 mantinha o casal; C2 pp. 146-148 encerrava o romance; W09 reproduzia a separação. As três apresentações dependiam de um romance agora retirado pelo autor.", "rule": "Vale RC-N01 / 2.0: Liana e Demer não constituem casal. Liana e Rul desenvolvem relação amorosa.", "action": "Os dois romances revistos e a História Geral atualizada incorporam Liana e Rul e a amizade de Liana com Demer. Revisar a wikia, inclusive resumos, fichas e ligações entre verbetes."}

Fórmula de perícia treinada

{"type": "audit", "id": "DV-02", "status": "ALTA · CORREÇÃO PENDENTE", "title": "Fórmula de perícia treinada", "evidence": "LR p. 12 apresenta 35% + 5 × MOD + pontos; mais abaixo diz que o atributo entra multiplicado por cinco.", "rule": "Vale RC-R04: o termo é 5 × MOD. O atributo bruto não é multiplicado por cinco nessa fórmula.", "action": "Corrigir a frase e conferir exemplos e ficha de consulta numa revisão de LR. Testes sem treino permanecem atributo puro em porcentagem."}

Estado do sistema no verbete Magia

{"type": "audit", "id": "DV-03", "status": "MÉDIA · CORREÇÃO PENDENTE", "title": "Estado do sistema no verbete Magia", "evidence": "W09 / magia afirma que os caminhos poderão orientar o futuro sistema e que a conversão ainda exige definir aprendizagem e recursos. LR 0.3 já define essas regras.", "rule": "O sistema existe em versão de teste; não está ausente.", "action": "Na próxima atualização da wikia, reescrever o trecho para remeter ao sistema 0.3 e indicar que balanceamento e revisões continuam. Nenhuma publicação do site foi feita nesta tarefa."}

Welkar e Velkar

{"type": "audit", "id": "DV-04", "status": "ABERTO · PADRONIZAÇÃO", "title": "Welkar e Velkar", "evidence": "A instrução autoral mais recente usa Welkar; o mapa de referência e HG p. 81 usam Velkar. A localização além da barreira ocidental está confirmada.", "rule": "Usar remissão entre as grafias; não tratar como duas cordilheiras.", "action": "O autor poderá escolher uma grafia única em revisão futura. Até lá, não redesenhar o mapa ou substituir todas as ocorrências como se a escolha já tivesse sido explicitada."}

Nyssara e o filtro de reino

{"type": "audit", "id": "DV-05", "status": "ABERTO · VÍNCULO GEOGRÁFICO", "title": "Nyssara e o filtro de reino", "evidence": "W09 / nyssara descreve serviço da corte de Quinder, mas o campo kingdomIds aponta a Naerath. Um vínculo de origem poderia justificar o filtro, porém essa função não está explicada na ficha.", "rule": "Não é prova de contradição biográfica; a semântica do filtro precisa ser esclarecida.", "action": "Conferir origem, residência e vínculo de serviço nas fontes; depois nomear o campo e ajustar o filtro. Não atribuir lealdade por mera localização."}

Capital, bosque e floresta

{"type": "audit", "id": "DV-06", "status": "HARMONIZADO NOS TRECHOS CONSULTADOS", "title": "Capital, bosque e floresta", "evidence": "HG pp. 5, 58, 64 e 78; ME pp. 18 e 39; GV pp. 4 e 32; GJ p. 18; FR p. 12 usam a separação correta.", "rule": "Valem RC-G01 e RC-G02.", "action": "Manter o controle para PDFs anteriores e novas menções. Não afirmar que essas edições atuais ainda conservam o erro antigo com base apenas na conversa histórica."}

Nerevala e Sar-Nobil

{"type": "audit", "id": "DV-07", "status": "HARMONIZADO NOS TRECHOS CONSULTADOS", "title": "Nerevala e Sar-Nobil", "evidence": "HG pp. 73 e 81; GV pp. 11 e 19; GJ p. 12 registram grafia e distinção de serra/passagem compatíveis.", "rule": "Valem RC-G05, RC-G07 e RC-G08.", "action": "Revisar versões legadas quando forem republicadas. Preservar aliases úteis de busca."}

Tormentas como estação

{"type": "audit", "id": "DV-08", "status": "DIVERGÊNCIA APARENTE · SEM CORREÇÃO", "title": "Tormentas como estação", "evidence": "BA p. 30 e FR p. 27 usam tormentas para fenômenos e episódios de tempo, sem nomear o antigo Mar das Tormentas.", "rule": "RC-G04 elimina o topônimo antigo, não a palavra meteorológica.", "action": "Não fazer substituição global de tormentas por Lombonia."}

Datas de publicação e conhecimento

{"type": "audit", "id": "DV-09", "status": "ABERTO · CONFERÊNCIA NARRATIVA", "title": "Datas de publicação e conhecimento", "evidence": "AN é datado de 787 e contém folhas reservadas; FA possui nota posterior; HG conhece o encerramento de 788.", "rule": "Distinguir corpo original, adendo e conhecimento posterior.", "action": "Se uma passagem datada de 787 revelar um evento de 788, localizar o trecho e conferir se pertence ao adendo antes de corrigir. Esta edição não afirma ter encontrado anacronismo específico nesses casos."}

Feições e marcas físicas

{"type": "audit", "id": "DV-10", "status": "ABERTO · CONTINUIDADE VISUAL", "title": "Feições e marcas físicas", "evidence": "As imagens são interpretativas. A revisão 0.9 diferenciou retratos, mas isso não certifica a visibilidade de cada marca em toda miniatura ou cena.", "rule": "Valem RC-V02 e RC-V03.", "action": "Quando uma imagem for revista, conferir povo, cabelo, cicatrizes documentadas, equipamento, época e enquadramento; registrar a validação do arquivo exato."}



Não são erros por si só



Marevim ser relativamente jovem e parecer cansado; dois lugares compartilharem um nome quando são entidades distintas; um povo existir sem ser opção comum de RPG; um autor interno acreditar em um fenômeno que outro não confirma; a wikia reunir mais indivíduos na categoria Natureza que o número de entradas de Maelis. Cada comparação precisa preservar contexto e escala.

## 18. Lugares e relações territoriais

Inventário anterior com referência temporal

As fichas abaixo registram a base W09 no início de 788. As novas definições sociais e visuais estão no capítulo territorial desta edição; os acontecimentos posteriores de Nobilith prevalecem quando o período retratado for o encerramento do ano.



Inventário dos 70 lugares de W09, em ordem alfabética. Estas fichas conservam a referência territorial já publicada; não criam capital, fronteira ou data adicional. Os registros RC-G prevalecem sobre qualquer formulação genérica. Os vínculos abaixo indicam contexto, não necessariamente soberania ou posição atual.

356 Milles

Povoação de Milles cujo nome se associa a um antigo marco de levantamento imperial.

Aethravel

Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.

Aston

Cidade do circuito meridional de Aelvar, entre as relações de Emvale e Thalendriel.

Atlante

Cidade costeira da Rácia articulada às relações de rio e aos trajetos do Mar das Espadas.

Bosque de Aurenval

Bosque de Oleakia ligado a coleta, abrigo e negociação dos caminhos.

Bosque de Let-Thalara

Bosque de Aelvar entre os acessos de Emvale e Aston.

Bosque de Leth-Auren

Área de manejo, coleta e acordos na Grande Floresta de Nael-Sul.

Cidade de Bergen

Centro urbano setentrional ligado a abastecimento, rotas e tradições locais de Bergen.

Cidade de Chisiague

Núcleo de conselho, desembarque e armazenagem na porção interior da entrada marítima.

Cidade de Heria

Centro urbano do reino de Heria e de suas relações de corte, serviço e cavalaria.

Cidade de Jacomb

Centro urbano de Jacomb ligado às atividades de porto e às referências de pilotos.

Cidade de Milles

Capital do Reino de Milles, ao sul da grande área florestal.

Cidade de Nobilith

Centro urbano de Nobilith, com casas antigas, ofícios e relações de apresentação.

Cidade-Estado de Ayak

Governo dos cais nas desembocaduras ao norte de Quinder.

Cidadela do Norte

Posto e cidade na margem ocidental do Estreito do Norte.

Confederação Halfling de Pellanor

Rede de pequenos estados e comunidades halflings sem capital soberana única.

Confederação Orc

Pacto entre comunidades orcs que conservam autonomia e decisões em assembleia.

Corte do Estreito

Centro político insular de Nogard, articulado às casas e comandos de frota dos meio-dragões.

Domínio de Naerath

Casas de elfos negros e caminhos junto à Floresta Negra.

Dorgal

Centro político de Dorgamar, ligado a assembleias, casas e saberes de trabalho com pedra e água.

Emvale

Capital de Aelvar, ligada à corte de Arriot Ilvar e aos circuitos de Aston e Thalendriel.

Grande Floresta de Nael-Sul

Grande região florestal em torno do relevo central de Vradrath.

Grande Muralha de Hravn

Fortificações de Bergen sustentadas por postos, trabalho e abastecimento.

Ihfarilse

Centro urbano da Rácia associado a oficinas, biblioteca e aos trabalhos do Circuito do Vento Arcano.

Império de Dorgamar

O império anão, suas cidades e a infraestrutura que atravessa a pedra.

Império de Nogard

Terra dos meio-dragões, cujo império insular controla passagens orientais do Mar das Espadas.

Isnymelha

Capital da Sokeria, conhecida pela presença da pedra e pelas relações entre costa e interior.

Juu Daixo

Cidade de trabalho mineral, carvão e transporte nos acessos montanhosos da Cávia.

Leopoldina

Localidade de Milles entre os itinerários que articulam povoações e bordas florestais.

Liga dos Passos de Chisiague

Liga em torno de uma entrada marítima alongada, aberta a leste entre faixas montanhosas.

Lombonia Ghostland

Ilhas cercadas por relatos inquietantes e investigações incompletas.

Mar das Espadas

Águas que ligam reinos, cidades portuárias e memórias do comércio imperial.

Mar de Lombonia

Mar dos circuitos orientais, associado às ilhas de Lombonia e a portos de diferentes estados.

Morvek

Cidade portuária de Dorgamar, com oficinas, depósitos, moradias e serviços de navegação.

Nael-Sul

Capital de Thaelorien, nos acessos da Grande Floresta de Nael-Sul e dos relevos de Vradrath.

Nerathiel

Capital de Iltharion e centro da corte de Elyndra Vaess.

Nerevala

Cidade meridional de Valerith, disputada por reivindicações da Sokeria e da Rácia.

Nhal-Sular

Capital de Sularien, ligada à vida política e às relações costeiras de seu reino.

Nova Milles

Cidade de Milles nos circuitos de campos, pousos e floresta do interior.

Orvalda

Cidade de Thaelorien ligada aos acessos costeiros e aos caminhos florestais.

Passagem de Sar-Nobil

Rota de travessia associada à Serra de Sar-Nobil.

Pombo Torto

A estalagem de Lethra Noll em Samarith.

Quinder

Reino entre campos verdes e terras mais secas, com cultivo sustentado pelo Taoju e pelo Asmarith.

Rada de Vau-Cinzento

Ancoragem e pequenos acessos de cabotagem da costa meridional de Quinder.

Reino da Cávia

Reino de portos, mineração e transporte entre Trogu e as subidas de Juu Daixo.

Reino da Rácia

Oficinas, arquivos e circulação de técnicas nos Reinos Centrais.

Reino de Aelvar

O reino setentrional dos elfos altos, entre cidades antigas e a influência da Ordem.

Reino de Bergen

Reino setentrional de rotas frias, fortificações e tradições religiosas próprias.

Reino de Heria

Tradições de cavalaria e tensões sobre serviço, rendas e privilégios num dos Reinos Centrais.

Reino de Iltharion

Reino oriental de elfos altos, independente da corte de Emvale.

Reino de Jacomb

Reino oriental ligado à navegação, aos pilotos e à circulação de notícias entre costas.

Reino de Milles

Rotas setentrionais, floresta e relações de câmbio entre o Estreito e as cidades do interior.

Reino de Nobilith

Casas antigas, direitos de propriedade e disputas de sucessão num dos Reinos Centrais.

Reino de Sularien

Estado élfico negro do sudeste, com centro em Nhal-Sular e relações de costa próprias.

Reino de Thaelorien

O reino florestal ao sul dos Reinos Centrais.

Roial

Centro comercial e contábil de Milles, com funções próprias na rede de cidades do reino.

Samarith

Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.

Serra de Sar-Nobil

Conjunto montanhoso que atravessa predominantemente Nobilith de norte a sul.

Sokeria

Reino central ligado às margens do Mar das Espadas.

Terras dos Povos Livres

Região de comunidades e autoridades distintas, sem soberano comum.

Thalendriel

Cidade de Aelvar nas rotas que descem rumo à Cidadela do Norte.

Trogu

Capital e cidade portuária da Cávia, ligada ao comércio marítimo e às remessas do interior.

União das Tocas de Oleakia

Comunidades oleakes, refúgios e depósitos dispersos numa união de tribos e assembleias.

Vaelen Endor

Capital de Valerith e antiga capital imperial, com edifícios, mercados e arquivos de usos sucessivos.

Valada

Cidade do corredor entre Ihfarilse, as passagens interiores e os acessos do Caminho Alto.

Valerith

Reino central que conserva em Vaelen Endor uma herança imperial.

Vardessa — Império Ocidental

Estado ocidental conhecido por contatos diplomáticos e comerciais.

Vel-Narim

Centro político de Naerath, ligado aos acessos orientais da Floresta Negra.

Wegas

Cidade dos percursos interiores de Milles, ligada à região da floresta e suas estradas.

Xeo Taoju

Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.

## 19. Personagens e suas condições

Base anterior, vínculos já harmonizados

Os 75 perfis de W09 são conservados como índice de consulta, com Liana, Demer e Rul harmonizados ao novo vínculo. Os 25 novos personagens ficam no capítulo próprio. A descrição visual suplementar desta edição deve acompanhar futuras imagens.



Inventário dos 75 personagens de W09. O campo não explicitado é preservado; ausência de idade não autoriza estimá-la a partir de uma pintura. O perfil pertence ao contexto de referência indicado, e o campo posterior contém spoilers. Exemplos de RPG e pessoas de épocas antigas continuam identificados como tais. As informações de fichas não substituem a leitura de uma cena quando se revisam gestos, motivações e conhecimento disponível.

Ansa Mer

Trabalha com ajudantes, água aquecida e panos separados para atender pessoas que chegam da operação.

Aren Varn

Irmão de Tessa Varn, integra os registros de trabalhadores da caravana investigada em As Guias Partidas.

Arriot Ilvar

Rei de Aelvar e pai de Le Rink, acostumado à política da longa memória.

Avren Dal

Comanda os procedimentos de circulação na Cidadela do Norte.

Beral Oss

Contramestre ligado à tripulação de Vessa Cor.

Calven IX

O Grande Pombo de Samarith, guardião de uma instituição influente.

Darel Oss

Marinheiro ligado à operação de uma embarcação examinada em Trogu.

Demer Vault

Paladino de Ardanus, dividido entre o dever institucional e as pessoas diante dele.

Dorna Kel

Ligada à Cooperativa do Terceiro Veio, trata achados de galeria como questão de trabalho, registro e segurança.

Druvak

Irmão mais novo de Kharug Venn.

Dália Ress

Mantém a Roda Partida junto de oficinas de Ihfarilse.

Edranna Halven

Depende da receita e do prestígio do Circuito.

Edren Sol

Sua situação é discutida no caso de contratos e trabalho forçado.

Elenva Tair

Representa interesses de manejo, comunidades e concessões de madeira.

Eline

Filha de Marevim, atuou como curadora e morreu em 731, numa aldeia atingida por um Descompasso.

Elthara Sorn

Marechal a serviço de Arriot Ilvar, valoriza o cumprimento de ordens sob pressão.

Eran Pel

Conhece o acesso à casa de trabalho junto de uma pedreira desativada, a uma jornada de Valada.

Form

Ajuda a examinar relatos de infiltração nas relações costeiras de Oleakia.

Forty

Participa da defesa de Oleakia nas disputas com Nogard.

Hadrik Vel

Capataz conhecido por Kharug a partir de cobranças anteriores.

Happidoh

Participa da defesa de Oleakia pelo conhecimento dos acessos discretos e pela troca de informações com pescadores.

Ilven Sar

Agente em Vaelen Endor, apresenta relações de negócio e recibos organizados.

Ima Olek

Coordena relações entre tribos e assembleias de Oleakia, sem possuir autoridade uniforme sobre cada toca.

Ima Teren

Anfitriã oleake no relato de Odran Velis, o Três-Botas.

Irena Sol

Maga formada fora de Aethravel.

Istren Vaul

Conhece Marevim e o agravo ligado aos acontecimentos de 731.

Ivela Dorn

Conselheira ligada às reformas da Ordem.

Jassa

Nome preservado na relação de trabalhadores que Kharug leva consigo.

Kharug Venn

Orc negociador, comerciante e combatente que conhece o peso de um acordo.

Khoram Tesh

Bibliotecário orc de Ihfarilse, atento à conservação e ao acesso aos registros.

Le Rink

Príncipe de Aelvar, diplomata e mago de proteção.

Lethia Arven

Chanceler de Maressa II Veldan.

Lethra Noll

Administra uma hospedaria fora do recinto principal da Torre de Samarith.

Liana Meywood

Ranger elfa das florestas, observadora e pouco disposta a transformar afeto em permanência.

Loria Halven

Filha de Edranna Halven e piloto conhecida no Circuito do Vento Arcano.

Maela Dorn

Trabalha com registros de passagem em Valada.

Marevim

Mago elfo alto, ligado a uma história de perda e ocultação institucional.

Mavra Senn

Combina cortesia, ameaça, negócios e um fundo de auxílio às famílias dos agentes.

Meral

Pessoa encontrada por Kharug durante a operação das galerias.

Meren Voss

Comanda a Viúva de Sal e calcula o uso de pessoas, papéis e mercadorias como fontes de resgate e receita.

Mereth Sal

Mantém a hospedaria As Duas Chaves numa etapa mercantil de Naerath.

Mina

Filha adotiva de Khoram Tesh, trabalha com encadernação.

Mira Olek

Matriarca lembrada pela organização de depósitos dispersos de alimento.

Narel

Irmão de Nyssara Veyl, conhece o reconhecimento de objetos e mercadorias e procura escolher seu próprio caminho.

Neris

Nome usado por uma mulher associada à cisterna nos relatos das Crônicas.

Nima Tel

Personagem oleake de demonstração do Guia do Jogador.

Nyssara Veyl

Estudiosa elfa negra, atenta ao que inscrições e versões oficiais deixam de dizer.

Odran Fess

Nome associado a contratos de transporte e dívida.

Olen Des

Trabalha com acessos subterrâneos e retirada de materiais.

Orelna Voss

Conduz a audiência do caso das Guias Partidas.

Oren Val

Chamado de Irmão Oren Val, é uma referência institucional para Demer.

Orven Tal

Proprietário de oficinas, financia escavações associadas às chamadas Casas de Passagem.

Oth Salven

Moleiro associado ao Moinho de Salven, num circuito entre os acessos de Vel-Narim e Quinder.

Ressa Til

Participa das negociações e verificações do caso de transporte em Valada.

Rima Vel

Anfitriã oleake de Aurenval, interlocutora de Maelis Varen em observações de campo.

Rovan Ess

Participa dos procedimentos de busca e das condições de segurança do caso em Valada.

Rul Aven

Pesquisadora goblin da Ordem e amiga de Liana.

Saeren Il

Responsável pelo atendimento e encaminhamento em Thalendriel.

Seldo Mer

Seu nome aparece na relação de trabalhadores conservada por Kharug.

Seli Ar

Encontrada com o pé ferido e febre, recebe cuidados de Demer.

Selk Arven

Nome associado a uma entrega na trama de Ihfarilse.

Selyra Naereth

Rainha de Quinder, entre o dever de oferecer abrigo e o hábito de controlar os caminhos.

Sera Vennor

Inventora anã, ambiciosa e direta, que conhece a distância entre o desenho e a peça.

Sirr-Vek

Porta-voz de uma comunidade instalada em túneis ligados a antigas galerias.

Tavian Ordel

Militar experiente em articular interesses de contingentes distintos.

Tavin Orr

Aprendiz num ambiente de trabalho de Ihfarilse.

Tessa Mal

Conhece caminhos de serviço usados para distribuir alimento.

Tessa Varn

Irmã de Aren Varn e dona da mula Palha.

Toren Kel

Conhece o primeiro acesso utilizado na descida às ruínas de As Guias Partidas.

Varek Oss

Integra o ambiente de oficinas que Sera frequenta em Ihfarilse.

Varesh Khor

Atua num consórcio de armadores e agentes de seguro.

Varna Il

Participa de trabalho de escavação e segurança de acesso, em colaboração com Olen Des.

Vessa Cor

Comanda embarcações e mantém relações com o Ofício das Marés.

Yarine Vel

Sustenta uma rede de celeiros entre aldeias da Sokeria e Isnymelha.

Ysenda Corval

Mantém um abrigo na fronteira de Heria.

## 20. Catálogo natural e temas do universo



O catálogo abaixo inventaria a história natural já publicada. Códigos e classificações da autora são preservados quando disponíveis. Um nome popular não demonstra espécie biológica única. Uma alegação de observador e sua incerteza não podem ser removidas durante a adaptação para a wikia.



Fauna

{"type": "table", "heads": ["Registro", "Ambiente / contexto", "Estatuto"], "rows": [["Abelha rasa", "Campos e florestas", "Observação registrada"], ["Andorinha das escarpas", "Montanhas", "Observação registrada"], ["Ave dos troncos ocos", "Campos e florestas", "Observação registrada"], ["Avô do Gotejo", "Cavernas e galerias", "Relato narrativo"], ["Besouro dos arreios", "Cidades e trabalho", "Correspondência e fontes"], ["Bode coroado", "Montanhas", "Observação registrada"], ["Caracol de vidro fosco", "Campos e florestas", "Observação registrada"], ["Caranguejo de margem escura", "Mar e litoral", "Correspondência e fontes"], ["Caranguejo de sino", "Rios e áreas úmidas", "Observação registrada"], ["Coruja contadora", "Campos e florestas", "Observação registrada"], ["Enguia de vidro", "Rios e áreas úmidas", "Correspondência e fontes"], ["Garça de cobre", "Rios e áreas úmidas", "Correspondência e fontes"], ["Ladrão de cascas", "Campos e florestas", "Observação registrada"], ["Lagartixa dos muros quentes", "Cidades e trabalho", "Observação registrada"], ["Lagarto de rocha", "Campos e florestas", "Observação registrada"], ["Lobo de cinza", "Campos e florestas", "Observação registrada"], ["Lontra dos cais", "Rios e áreas úmidas", "Correspondência e fontes"], ["Mariposa de folha seca", "Campos e florestas", "Observação registrada"], ["Morcego de galeria", "Cidades e trabalho", "Observação registrada"], ["Peixe de barba curta", "Rios e áreas úmidas", "Observação registrada"], ["Porco de raiz", "Campos e florestas", "Observação registrada"], ["Pássaro do poente", "Mar e litoral", "Correspondência e fontes"], ["Rato dos celeiros", "Cidades e trabalho", "Observação registrada"], ["Recife que respira", "Mar e litoral", "Observação registrada"], ["Saltador de névoa", "Campos e florestas", "Observação registrada"], ["Traça de couro úmido", "Cidades e trabalho", "Observação registrada"], ["Veado de espelho", "Campos e florestas", "Correspondência e fontes"], ["Verme de ferro", "Cidades e trabalho", "Observação registrada"], ["Vespa de pote", "Cidades e trabalho", "Observação registrada"]], "widths": [0.28, 0.44, 0.28]}



Flora

{"type": "table", "heads": ["Registro", "Ambiente / contexto", "Estatuto"], "rows": [["Alga de fita parda", "Mar e litoral", "Observação registrada"], ["Arroz de várzea", "Rios e áreas úmidas", "Observação registrada"], ["Casca-mansa", "Campos e florestas", "Correspondência e fontes"], ["Castanheira mansa", "Campos e florestas", "Correspondência e fontes"], ["Centeio de inverno", "Campos e florestas", "Observação registrada"], ["Erva de margem salobra", "Mar e litoral", "Observação registrada"], ["Erva-de-chuva", "Campos e florestas", "Observação registrada"], ["Flor do último frio", "Campos e florestas", "Observação registrada"], ["Folha-de-costura", "Campos e florestas", "Observação registrada"], ["Freixo dos pátios", "Cidades e trabalho", "Observação registrada"], ["Junco de enseada", "Mar e litoral", "Correspondência e fontes"], ["Junco-de-fita", "Rios e áreas úmidas", "Observação registrada"], ["Lentilha de remanso", "Rios e áreas úmidas", "Correspondência e fontes"], ["Linho dos cais", "Cidades e trabalho", "Observação registrada"], ["Musgo de roldana", "Campos e florestas", "Observação registrada"], ["Pereira dos pomares de Aston", "Campos e florestas", "Observação registrada"], ["Pinheiro de casca escura", "Campos e florestas", "Observação registrada"], ["Raiz-âncora", "Rios e áreas úmidas", "Observação registrada"], ["Resineira negra", "Campos e florestas", "Observação registrada"], ["Sal-de-vidro", "Rios e áreas úmidas", "Observação registrada"], ["Salgueiro das duas margens", "Rios e áreas úmidas", "Observação registrada"], ["Trigo dos campos centrais", "Campos e florestas", "Observação registrada"], ["Urtiga de prata", "Campos e florestas", "Observação registrada"], ["Zimbro de passo", "Montanhas", "Correspondência e fontes"]], "widths": [0.28, 0.44, 0.28]}



Fungos e afins

{"type": "table", "heads": ["Registro", "Ambiente / contexto", "Estatuto"], "rows": [["Barba de pedra", "Campos e florestas", "Classificação em aberto"], ["Bolor de corda salgada", "Mar e litoral", "Classificação em aberto"], ["Bolor do saco quente", "Cidades e trabalho", "Observação registrada"], ["Crosta de vento", "Montanhas", "Classificação em aberto"], ["Orelha de tronco", "Campos e florestas", "Observação registrada"], ["Sino de casca", "Campos e florestas", "Classificação em aberto"], ["Vigia vermelho", "Campos e florestas", "Correspondência e fontes"], ["Véu das raízes", "Campos e florestas", "Classificação em aberto"]], "widths": [0.28, 0.44, 0.28]}



História, cosmologia, povos e organizações



<b>Ordem dos Magos.</b> Instituição setentrional de estudo, proteção e disputa pelo controle do conhecimento. Referência: W09 / ordem.



<b>Orcs e a Confederação.</b> Comunidades, pactos e experiências que não cabem numa única vontade política. Referência: W09 / orcs.



<b>Goblins.</b> Populações minoritárias espalhadas por muitas regiões de Virtude. Referência: W09 / goblins.



<b>Arautos.</b> Encarnações divinas que nascem sem conhecer necessariamente sua missão. Referência: W09 / arautos.



<b>Os três planos.</b> Virtude, Eomundus e Noérion na compreensão da criação. Referência: W09 / planos.



<b>Magia.</b> Estudo, prática e relações entre vontade, conhecimento e as condições do mundo. Referência: W09 / magia.



<b>Thul Verenari.</b> Lenda setentrional de um povo antigo cuja existência permanece controversa. Referência: W09 / thul.



<b>Grande Punição.</b> O acontecimento enigmático que encerra a Primeira Era. Referência: W09 / punicao.



<b>Primeira Era.</b> Dragões, eldenari, elfos altos e os conflitos em torno da criação e da magia. Referência: W09 / primeira-era.



<b>Segunda Era.</b> Reorganização dos povos, expansão imperial e fragmentação. Referência: W09 / segunda-era.



<b>Terceira Era.</b> Reinos fragmentados, antigas instituições e novas disputas. Referência: W09 / terceira-era.



<b>Caso das Guias Partidas.</b> A investigação que aproxima os futuros companheiros entre 785 e 787. Referência: W09 / guias-partidas.



<b>Oleakes.</b> Povo de pequeno porte e traços leporinos, associado às comunidades, tocas e redes de abrigo de Oleakia. Referência: W09 / oleakes.



<b>Tessik do Veio Frio.</b> Comunidade kobold ligada a túneis de galerias na região de Juu Daixo. Referência: W09 / tessik-veio-frio.



A categoria Organizações ainda não possui verbete separado para todas as instituições citadas. Isso é uma lacuna de indexação, não prova de que elas não existam. Guilda dos Magos, Heróis, Guerreiros, Vento Arcano, confrarias, cooperativas e redes podem receber dossiês próprios em uma expansão futura, mantendo os nomes e datas das fontes.

## 21. Manutenção, revisões e novas decisões



Este Registro deve ser atualizado quando surgir uma decisão que afete mais de um material, uma contradição relevante, uma mudança de nome, uma data estruturante, uma relação entre personagens ou uma regra mecânica. Pequenos ajustes de estilo não exigem nova decisão canônica. Não é necessário gerar um PDF a cada sessão de trabalho: acumule alterações na matriz editável e publique uma edição consolidada quando fizer sentido.



Como registrar uma alteração



Dê ao assunto um identificador estável. Escreva primeiro a definição vigente, com período e alcance. Depois informe de onde ela veio, qual versão substitui e quais materiais ainda precisam ser corrigidos. Quando a decisão mudar, conserve o histórico: marcar como substituída é mais útil que apagar uma escolha anterior e perder a explicação de sua existência.

{"type": "table", "heads": ["Campo", "Conteúdo esperado"], "rows": [["Identificador", "RC para definição; DV para divergência; usar numeração nova sem reutilizar código."], ["Assunto e período", "Entidade exata, época e alcance. Cidade, floresta, indivíduo e povo têm identidades diferentes."], ["Situação", "AUTORAL, CONSOLIDADO, EDITORIAL ADOTADO ou EM ABERTO."], ["Definição vigente", "Frase inequívoca que pode orientar a revisão. Se estiver em aberto, formular a pergunta."], ["Fonte e localização", "Obra, versão e página ou capítulo; para wikia, identificador do verbete."], ["Versão substituída", "Qual informação deixa de valer, se houver."], ["Impacto", "Textos, imagens, índices, relações, regras e filtros afetados."], ["Implantação", "Pendente, parcial ou conferida, separadamente para cada material."], ["Validação", "Data real da revisão e responsável; não inventar uma data de aprovação autoral."]], "widths": [0.27, 0.73]}



Fluxo de revisão de uma obra



Antes de editar, selecione as ocorrências abertas relativas àquela obra e consulte os registros normativos. Corrija o texto, confira referências cruzadas e reveja imagens, mapas, tabelas, sumário e notas quando afetados. Depois identifique a nova edição e marque apenas as ocorrências efetivamente verificadas como implantadas. Um arquivo com título novo e conteúdo antigo não encerra uma correção.



Atualizar o Registro não publica automaticamente alterações em outros materiais. A wikia pode ser alinhada em uma tarefa breve; PDFs maiores podem esperar uma revisão conjunta. A decisão canônica permanece disponível nesse intervalo, e o leitor editorial consegue saber por que uma versão antiga diverge.



Controle de versões



A versão 1.0 foi a primeira consolidação. A versão 2.0 incorpora mudanças estruturantes aprovadas em 3 de novembro de 2026, incluindo a retirada de um romance, novos vínculos, sucessão e moedas. Uma revisão 2.1 pode reunir ajustes pontuais; uma edição 3.0 poderá acompanhar outra mudança estrutural. A numeração é editorial real e não substitui o ano ficcional. A versão mecânica do RPG continua tendo numeração independente.

{"type": "table", "heads": ["Versão", "Data real", "Conteúdo"], "rows": [["1.0", "03/11/2026", "Primeira consolidação: núcleo normativo, concordância, dossiês da base 0.9 e relatório DV-01 a DV-10."], ["2.0", "03/11/2026", "Revisão estrutural aprovada: vínculos, política, sucessão, magia, moedas, grupos, 25 novos personagens e fichas visuais."], ["2.1", "03/11/2026", "Implantação no Volume I: 58 capítulos, seis novos NPCs em cena e preparação do vínculo Liana-Rul. Cânone 2.0 preservado."], ["2.2", "03/11/2026", "Implantação no Volume II: 74 capítulos, vínculo Liana-Rul, responsabilidade da Ordem, cooperação condicionada e crise sucessória de Nobilith."], ["2.3", "03/11/2026", "Consolidação das quatro obras complementares e fila da wikia."]], "widths": [0.15, 0.22, 0.63]}



Modelo para a próxima ocorrência



DV-[novo número] | Assunto: [...] | Material e versão: [...] | Localização: [...] | Trecho ou descrição do conflito: [...] | Registro normativo aplicável: [...] | Decisão: [...] | Pendências por material: [...] | Conferência final: [...]. Este é um modelo de trabalho, não uma ocorrência já encontrada.

Prioridade para a próxima rodada

Aplicar a matriz de implantação 2.0: revisar os romances em conjunto, depois a História Geral e obras temáticas; atualizar a wikia conforme os textos assentados. DV-02 e DV-03 continuam pendentes. Não corrigir o romance retirado para outro desfecho também superado.

{"type": "table", "heads": ["Versão", "Data real", "Conteúdo"], "rows": [["2.4", "5 de novembro de 2026", "Incorporação da história política imperial VE; sucessão, cronologia, pessoas, instituições, lugares e limites documentais."]], "widths": [0.13, 0.23, 0.64]}

## 22. Identificação das fontes e limites desta edição



Os resumos abaixo identificam os arquivos efetivamente consultados, para distinguir uma nova edição de um PDF homônimo antigo. SHA-256 é uma impressão digital dos bytes: mudar o arquivo muda o resumo. Não é uma classificação de qualidade nem uma aprovação autoral.



AN | Anais da Ordem dos Magos



34 páginas. Arquivo: Anais_da_Ordem_dos_Magos.pdf.



2c83376306e05d3610e9efd3abd29ad001cf06dccb11062aa483edd91f7106a3



BA | Bichos e Assombros dos Caminhos



37 páginas. Arquivo: Bichos_e_Assombros_dos_Caminhos.pdf.



c0da601c6a2596337038af7d8bd22895a19227fc3ba2c1f89e55ed0a42c371ca



C1 | As Guias Partidas



156 páginas. Arquivo: Cronicas_de_Virtude_I_As_Guias_Partidas.pdf.



02e87438b9cdd53523d16c2e83485eb487056fa13bb782ae6f72002d7d30d793



C2 | As Quatro Hostes



154 páginas. Arquivo: Cronicas_de_Virtude_II_As_Quatro_Hostes.pdf.



cf0df17aeb189c758bc72cc3a829c56c95a49005e5823209e2fad1bcee6098d1



FA | As Formas da Ausência



48 páginas. Arquivo: As_Formas_da_Ausencia.pdf.



4f661d535a9760973c6204dd39fa14348c6c7e8a2c415210182a8f1dc0fdb9dd



FR | Entre Feras e Raízes



73 páginas. Arquivo: Entre_Feras_e_Raizes_Edicao_Revista.pdf.



e25fbec7cdba9d97dc11da4d492b4f060f64013b7c5548e03db1f6a2950c1db6



GJ | Crônicas de Virtude — Guia do Jogador



58 páginas. Arquivo: Cronicas_de_Virtude_Guia_do_Jogador_Edicao_Revista.pdf.



1cce349444a8e3820a89ba34e5ab8c946524b41e6b6d5583d7666e6a7a71fd04



GV | Guia dos Viajantes de 788



43 páginas. Arquivo: Guia_dos_Viajantes_de_788.pdf.



d3ea0fa8719a581bc3e6a97e9b5abdc94a4a2b06cf1a1617c4a20d12b28f71b6



HG | História Geral de Virtude



147 páginas. Arquivo: Historia_Geral_de_Virtude.pdf.



3b19cd8d8a01e3f80d6bc8dda035f8ce81e7a492ed375920cab0e67a0d5a6c34



LR | Crônicas de Virtude — Livro de Regras



64 páginas. Arquivo: Cronicas_de_Virtude_Livro_de_Regras_v03.pdf.



0a97805b467b027733905bcccb37401e3594f7ddea795b7136f2fd32aa2d6bc4



ME | O Mar das Espadas na Época de Selvar II



41 páginas. Arquivo: Mar_das_Espadas_na_Epoca_de_Selvar_II.pdf.



314efd8edd170984efee8b2170da2106aece1f5e69428a31a9a33f47d8ffd2da



W09 e mapa



W09: Wiki e Biblioteca de Virtude, edição 0.9, fonte d9ae6b9d2843978ec59b34e401ad906efc014759. O inventário compreende 220 verbetes: 75 personagens, 70 lugares, 61 registros de Natureza e 14 outros temas. A imagem cartográfica preservada na base é a referência espacial usada nas decisões geográficas desta conversa; o mapa geral não fixa sozinho escala, estrada ou condição de acesso.



Este Registro não corrige silenciosamente arquivos anteriores. O relatório documenta o que foi encontrado, a regra adotada e o que permanece pendente. Não se afirma que todas as possíveis contradições foram eliminadas, nem se transforma uma questão sem resposta em certeza apenas para completar uma ficha.



O arquivo editável que acompanha o PDF conserva a mesma estrutura e pode receber novas decisões. A cópia em PDF é a edição de consulta correspondente à versão indicada na capa. Havendo divergência futura entre uma matriz alterada e este PDF congelado, identifique a versão vigente e gere nova edição, em vez de manter dois documentos contraditórios sob o mesmo número.



As impressões digitais acima continuam identificando as fontes anteriores à revisão 2.0. DA2 é a fonte das novas decisões, não uma suposta edição já publicada dos romances. A próxima conferência deverá atualizar esse inventário somente depois que os arquivos das obras forem efetivamente revisados.

## 23. Implantação no Volume I e concordância de capítulos



Implantação realizada no Volume I, edição 2.0. Foram preservados os 54 capítulos anteriores em sua ordem e acrescentados quatro capítulos, resultando em 58. Não houve participação de Rul no resgate ou na audiência de Valada. O primeiro encontro dos seis continua ocorrendo na audiência de 787.

{"type": "table", "heads": ["Assunto", "Situação após esta edição"], "rows": [["Liana e Demer", "Preparação romântica retirada; amizade e assistência preservadas."], ["Liana e Rul", "Amizade desde 778 e correspondência aprofundadas. Aproximação amorosa formal permanece perto da abertura de C2."], ["Novos personagens", "Terenna Vos, Sovel Aneth, Brena Uld, Varda En, Ceris Dalmere e Nereth Cal introduzidos em cenas. Os outros 19 continuam disponíveis para obras posteriores."], ["Sar-Nobil", "Antecedentes sociais e disputa sucessória apresentados em 787; traição, morte de Osric e coroação pertencem a 788 e não ocorrem neste volume."], ["Moedas", "Ilvar e lâmpada entram em circulação cotidiana, ao lado de ráculos e crédito. Não foram estabelecidas taxas universais."], ["Ordem", "Cenas de arquivo, revisão insuficiente e testemunho preparam as responsabilidades. Os atos posteriores de Marevim não são antecipados como conhecidos."], ["Cenas cotidianas", "Vale de depósito, trabalho de oficina, espera de viagem, manutenção de posto e responsabilidade por garantias integrados à narrativa."]], "widths": [0.25, 0.75]}



Arquivo: Cronicas_de_Virtude_Volume_I_Edicao_2.pdf. 136 páginas. SHA-256: 209a60c18529ae32f5f3df3ed2dc6b72a078d83f3dc71397dc0fccd90dea970b. O manuscrito editável conserva o texto integral da edição. Os localizadores antigos C1 continuam identificando a fonte anterior; para esta edição, usar a concordância de capítulos abaixo.

{"type": "table", "heads": ["Capítulo anterior", "Capítulo atual", "Título"], "rows": [["1", "1", "O animal que voltou"], ["2", "2", "A margem inferior"], ["3", "3", "Um reparo fora do lugar"], ["4", "4", "A tigela de sal"], ["5", "5", "Quem conhece o portão"], ["6", "6", "Sete lugares para dormir"], ["7", "7", "O peso do guincho"], ["8", "8", "As coisas que se recuperam"], ["9", "9", "O sinal de Ressa"], ["10", "10", "A data da renovação"], ["11", "11", "O serviço de Ardanus"], ["12", "12", "Uma tarde na Roda Partida"], ["13", "14", "A mão de Orven Tal"], ["14", "15", "O menino da ponte"], ["15", "16", "O que se promete em voz alta"], ["16", "17", "A laje e a visita"], ["17", "18", "Uma sala sem janela"], ["18", "19", "A mesa de Orven"], ["19", "20", "O lugar da cadeira"], ["20", "22", "A sombra na travessa"], ["21", "23", "A casa vazia"], ["22", "24", "Debaixo do alpendre"], ["23", "25", "O nome do vazamento"], ["24", "26", "O homem do avental limpo"], ["25", "27", "As contas abertas"], ["26", "28", "O pão de ninguém"], ["27", "29", "A chuva entre os anos"], ["28", "31", "A cuba rachada"], ["29", "32", "A laje em pé"], ["30", "33", "Um caminho de serviço"], ["31", "34", "A leitura de um medo"], ["32", "35", "As ferramentas de uma noite"], ["33", "36", "A escolha de Orven"], ["34", "37", "A autorização cabe num bolso"], ["35", "38", "O círculo incompleto"], ["36", "39", "Nove nomes na escuridão"], ["37", "40", "A sala de cima"], ["38", "41", "O que a pedra aceita"], ["39", "42", "A tira azul"], ["40", "43", "A parte que ficou com eles"], ["41", "44", "A ausência de uma resposta"], ["42", "45", "A água depois do calor"], ["43", "46", "Um selo fora de estação"], ["44", "47", "O preço de uma palavra"], ["45", "49", "O forno de Ressa"], ["46", "50", "Os seis na mesma sala"], ["47", "51", "O que uma testemunha reconhece"], ["48", "52", "O primeiro erro"], ["49", "53", "A parte do desenho que tem nome"], ["50", "54", "A cópia que pode sair"], ["51", "55", "Uma mesa sem ata"], ["52", "56", "As coisas que não entram na sentença"], ["53", "57", "O que cabe numa despedida"], ["54", "58", "O lugar dos nomes"]], "widths": [0.2, 0.2, 0.6]}



Capítulos novos: O nome na bancada; A via que permanecia; A largura de uma roda; A assinatura de baixo. A nova edição não implanta os acontecimentos futuros de Samarith, o vínculo de Elthara e Tavian ou toda a expansão monetária em cenas que não comportam esses assuntos.

## 24. Implantação no Volume II e concordância de capítulos



Implantação no Volume II, edição 2.0. Os 67 capítulos anteriores permanecem em sua ordem, com revisão de 22 deles e sete capítulos acrescentados, totalizando 74. As cenas de aproximação e separação amorosa entre Liana e Demer foram substituídas; o vínculo romântico vigente é Liana-Rul. A cronologia da investigação, as subtramas independentes e os custos físicos do desfecho foram preservados.

{"type": "table", "heads": ["Assunto", "Implantação e limite"], "widths": [0.25, 0.75], "rows": [["Liana e Rul", "Aproximação já existente pouco antes de 11/2/788; trabalho de escolta independente do afeto; reencontro em Trogu, cotidiano em Samarith e partida com correspondência irregular, sem coabitação prometida."], ["Liana e Demer", "Amizade, colaboração e cuidado mútuo. Não houve romance ou separação amorosa nesta continuidade."], ["Ordem e 731", "Sovel distingue matrizes e autorizações; Ivela responde pela revisão insuficiente; Rul declara a demora institucional; Brena presta testemunho próprio. A apuração não termina em 788."], ["Marevim", "Etapas de preservação, resposta e retenção sem consentimento; reconhecimento do crime original não absolve novos atos. Morre na Câmara em 23/9; corpo recuperado e identificado."], ["Quatro hostes", "Demonstração técnica com erros expostos; recusa de promessa universal; oficiais de ligação, rendição e inspeção, sem confiança instantânea ou fim imediato da violência."], ["Elthara e Tavian", "Intimidade anterior retomada; omissão causa conflito com subordinada e revisão das comunicações. Não determina automaticamente aliança nem prova troca de favores."], ["Sar-Nobil", "Orientação norte-sul e casta dos cavaleiros em cena; promessa a Osric, acordo reservado Maressa-Martan e desvio consciente do socorro. Morte pela doença existente no mês 10, coroação de Martan e contestação de Helena, sem vencedor definitivo."], ["Consequências", "Le Rink conserva perda de sensibilidade; Sera perde o protótipo; Narel não recebe corpo; Druvak morre sem corpo recuperado; Demer deixa a função, conserva a fé e participa da assistência."], ["Mundo cotidiano", "Oficinas, abastecimento, caução em moedas distintas e manejo da água em Quinder. Não se criaram câmbio universal nem conhecimento onisciente."], ["Personagens adjacentes", "Sovel, Brena, Nereth, Varda, Ceris, Terenna e Mira são mobilizados conforme funções aprovadas. Nem todos os novos personagens do Registro precisam aparecer neste romance."], ["Materiais pendentes", "História Geral, wikia e demais PDFs não foram atualizados por esta entrega. Manter o Registro como referência nas divergências restantes."]]}



Arquivo: Cronicas_de_Virtude_Volume_II_Edicao_2.pdf. 159 páginas. SHA-256: 175f8835f78f54eabcb2f495d92933c8dcc59ad90a2c4b112c86e72f6a68ef17. O manuscrito editável conserva o texto integral. Concordância: os localizadores C2 antigos continuam apontando para a edição anterior; usar os capítulos abaixo para a edição 2.0.

{"type": "table", "heads": ["Capítulo anterior", "Capítulo atual", "Título"], "rows": [["1", "2", "A marca que não podia estar ali"], ["2", "3", "A porta de abastecimento"], ["3", "5", "A filha no vidro"], ["4", "6", "Emvale ainda dormia"], ["5", "7", "Uma luva para a estrada"], ["6", "8", "O Vau das Corças"], ["7", "9", "As portas de Thalendriel"], ["8", "10", "A cidade junto ao Estreito"], ["9", "11", "Os dois livros de Mereth"], ["10", "12", "O que o preço não compra"], ["11", "13", "Farinha no sangue"], ["12", "14", "Um quarto fora da Torre"], ["13", "15", "O tempo de Calven IX"], ["14", "16", "O joelho da rainha"], ["15", "17", "O direito de continuar"], ["16", "18", "A voz que discordava"], ["17", "19", "A estrada não esqueceu"], ["18", "21", "O preço do aviso"], ["19", "22", "O pano azul"], ["20", "23", "A peça da qual Sera sabia"], ["21", "24", "As páginas de Mina"], ["22", "25", "A oferta de Mavra"], ["23", "26", "O óleo que não era entrega"], ["24", "27", "A primeira regra"], ["25", "28", "Os que ficavam na oficina"], ["26", "29", "A filha da rainha"], ["27", "31", "A água que mudou de dono"], ["28", "32", "Avô do Gotejo"], ["29", "33", "Os olhos no metal"], ["30", "34", "A amiga na porta"], ["31", "35", "As raízes chegam ao porto"], ["32", "36", "A urna no porão"], ["33", "37", "A culpa tem uma cadeira"], ["34", "38", "A pedra e o corrimão"], ["35", "39", "A caução do Estreito"], ["36", "40", "A Viúva de Sal"], ["37", "41", "O nome que não era de guerra"], ["38", "42", "Os cais de Vau-Cinzento"], ["39", "43", "Os nomes nos receptáculos"], ["40", "44", "Uma palavra introduzida"], ["41", "46", "A mulher da cisterna"], ["42", "47", "O Poço das Três Lajes"], ["43", "48", "O papel que Le Rink guardou"], ["44", "49", "Aqueles que esperavam a estrada"], ["45", "50", "O trabalho que pode ser dividido"], ["46", "51", "A carta de Druvak"], ["47", "52", "Uma mesa com espaço para a recusa"], ["48", "53", "A descarga"], ["49", "55", "Antes da névoa"], ["50", "56", "O caminho que a rainha abriu"], ["51", "57", "Três comandos e uma cidade"], ["52", "58", "A mulher que sabia o nome"], ["53", "59", "A passagem do irmão"], ["54", "60", "As Pontes das Lâmpadas"], ["55", "61", "O caminho melhor"], ["56", "62", "A Câmara não estava vazia"], ["57", "63", "O nome que ele escolheu"], ["58", "64", "O que não cabia no caderno"], ["59", "65", "O intervalo"], ["60", "66", "O homem diante da porta"], ["61", "67", "O que a justiça faria"], ["62", "68", "Eline não concordava"], ["63", "69", "Os que saíram"], ["64", "70", "A conta dos vivos"], ["65", "71", "O endereço de uma carta"], ["66", "72", "Seis caminhos"], ["67", "74", "As últimas badaladas"]], "widths": [0.2, 0.2, 0.6]}



Capítulos acrescentados: Antes da volta; As vias separadas; O posto da crista; A segunda garantia; A altura da água; O quarto sem mapa; A coroa e os postos. O endereço de uma carta substitui o antigo capítulo de separação amorosa. A pedra e o corrimão reescreve a antiga cena do cais como amizade e decisão pessoal de Demer.

## 25. Consolidação das edições e atualização da wikia

Recorte histórico da edição 2.3

Este quadro conserva a situação de implantação em 3 de novembro de 2026. A incorporação de VE na edição 2.4 é registrada nos capítulos seguintes. Uma pendência antiga não comprova que a mesma pendência exista hoje.



Inventário vigente em 3 de novembro de 2026. Os volumes I e II, edição 2.0, têm concordância nos dois capítulos anteriores. A linha de materiais pendentes do Volume II descreve a situação daquela entrega. O quadro abaixo registra as revisões que vieram depois.

{"type": "table", "heads": ["Edição atualizada", "Páginas", "Escopo incorporado"], "rows": [["Historia Geral de Virtude Edicao Atualizada.pdf", "148", "Liana e Rul, apuração de 731, moedas, sucessão de Nobilith e cronologia."], ["Mar das Espadas Selvar II Edicao Atualizada.pdf", "43", "Postos, pagamentos e abastecimento no recorte 2078–2149 da II Era. Nota editorial situa as referências de 788."], ["Guia dos Viajantes de 788 Edicao Atualizada.pdf", "45", "Caderno final com moedas e avisos de viagem posteriores à batalha. Texto de Nerion fechado na Vigília de 787."], ["Entre Feras e Raizes Edicao Atualizada.pdf", "76", "Caderno editorial sobre observações, amostras e rotas de 788. Tratado de Maelis datado do fim de 787."]], "widths": [0.35, 0.12, 0.53]}



Verbetes e pontos de conferência

{"type": "table", "heads": ["Área da wikia", "Revisão a aplicar"], "rows": [["Liana, Rul e Demer", "Atualizar fichas, relações e resumos dos romances. Liana e Rul têm vínculo amoroso. Demer e Liana mantêm amizade e colaboração."], ["Ordem, Marevim e Eline", "Distinguir autorização, execução, alteração de registros e apuração do isolamento de 731. Registrar Brena, Sovel, Ivela e Rul pelas funções demonstradas."], ["Nobilith, Sar-Nobil, Maressa, Martan e Helena", "Distinguir serra e rota de travessia. Situar Osric vivo no começo de 788. Após a batalha, registrar morte pela doença, coroação de Martan e contestação em curso."], ["Quinder e Samarith", "Distinguir a situação do início de 788, a batalha de 18 a 23/9 e o atendimento, as dívidas e a apuração no pós-guerra."], ["Moedas e comércio", "Registrar emissões nas fichas territoriais e ligar ao verbete geral. Preservar as práticas locais de Oleakia, Pellanor e comunidades sem cunhagem comum."], ["Geografia e filtros", "Conferir Nael-Sul, Let-Thalara, abertura leste de Chisiague, Nerevala, Milles e Pellanor além da Cordilheira de Welkar. Aplicar filtros a verbetes com localização pertinente."], ["Obras e downloads", "Vincular as quatro edições atualizadas nas respectivas fichas. Identificar o recorte imperial de Selvar II e os cadernos editoriais posteriores aos textos de Nerion e Maelis."]], "widths": [0.28, 0.72]}



Os manuais de RPG permanecem em etapa própria. Este quadro serve de base para revisar a wikia e conferir suas referências, textos, tabelas, filtros e downloads antes da publicação.

## 26. Vaelen Endor: incorporação política e histórica

Incorporação vigente

As ampliações de VE são adotadas nesta edição por autorização do criador do universo. A origem de cada dado é conservada. Questões explicitamente abertas continuam sem solução.

### RC-VE01 — Incorporação e autoridade de VE

As ampliações de VE são incorporadas como continuidade editorial adotada. A autorização desta atualização é do criador de Virtude. A origem nova de um dado continua registrada para rastreabilidade. Interpretações de Iria, falas de personagens e documentos internos não se transformam em verdade absoluta por serem citados.

Base: VE pp. 4, 51–65; solicitação de incorporação do autor.

Aplicação: Usar esta edição como referência operacional para novos materiais. Conservar a marca de incerteza onde a fonte a contém.

### RC-VE02 — Recorte e alcance do Império

A crise de 1872–1880 antecede a Guerra das Correntes de 1881–1895. Vaela é proclamada em 1896. A Concordata de 2431 encerra a II Era. A diferença entre as datas da proclamação e da dissolução é 535. O núcleo corresponde às regiões dos futuros sete Reinos Centrais, Quinder e domínio variável sobre partes de Bergen. Dorgamar e as outras potências externas mantêm soberania própria.

Base: VE caps. 1–6, pp. 7–18; caderno V.

Aplicação: Evitar projetar fronteiras e monarquias de 788 sobre toda a II Era.

### RC-VE03 — Sucessão imperial ampliada

Adota-se a sequência de 14 governantes apresentada na tabela desta edição. Vaela, Selvar II e Odravel IV eram figuras anteriores; os demais reinados completam intervalos. As datas são de reconhecimento político e não definem nascimento, morte ou parentesco de primeiro grau entre sucessores.

Base: VE cap. 7, pp. 19–20; caderno II, pp. 55–56.

Aplicação: Usar os intervalos completos ao criar fichas. Não inferir genealogia sem nova definição.

### RC-VE04 — Liga, Bar-Terval e Carta das Nove Estradas

O Pacto dos Celeiros de Reth é datado em 1876; o Acordo das Contas de Madeira, em 1892. A repressão de Bar-Terval e a ruptura de Rughan ficam situadas em 1904. A versão organizada da Carta das Nove Estradas utilizada por VE é datada em 1908. As nove estradas são corredores com ramais, sem desenho exato fixado.

Base: VE caps. 3–6; cronologia pp. 51–54.

Aplicação: Distinguir data de organização da versão de uma carta e data de fundação do direito nela reunido.

### RC-VE05 — Moeda e o norte

Ráculo e nordum permanecem distintos. A revisão monetária de Selvar I, em 2021 da II Era, admite certas obrigações em nordum mediante aferição de peso. A Petição dos Sacos Fechados, de 2024, trata de cobrança que desconsiderava entrega já realizada em grão. Não há câmbio universal permanente definido.

Base: VE cap. 8, pp. 21–22.

Aplicação: Descrever conversão em seu contexto de posto, ano e serviço.

### RC-VE06 — Dorgamar e a rede de águas

Mantêm-se 1368 da II Era para a fundação convencional de Dorgamar, 2032 para o Tratado das Águas de Morvek, 2039 para o início das obras, 2058 para a primeira operação e 2116 para as ligações principais. O Aditamento dos Quatro Dias é de 2063. A rede anã combina eclusas, transbordos e tração, com saída marítima por Morvek.

Base: VE cap. 9, pp. 23–24.

Aplicação: Distinguir Companhia das Eclusas Orientais, Vedores da Água Fundida e Vedores das Três Lanternas.

### RC-VE07 — Selvar II, Tessia e a sentença do Espelho

Selvar II é imperador entre 2078 e 2149 da II Era. A correspondência de Tessia com a Mesa dos Instrumentos Reservados é datada em 2093, sem fixar a descoberta da Agulha. O processo de Leva Senn na Controvérsia do Espelho é situado em 2101. Aren Voss recusa condenação por possibilidade futura.

Base: VE caps. 10–11, pp. 25–28.

Aplicação: Conservar a separação entre consciência, memória em mana e previsão. Não substituir prova de ação por visão futura.

### RC-VE08 — Cheia e reparações

A Cheia das Sete Comportas é de 2127 da II Era. Sella Dorn atua nos socorros e tem despesas discutidas em 2128. O Inventário das Tigelas é situado em 2129. A vedora Nerra Keld participa da escolha de reparos. A recuperação comercial não equivale à indenização de todas as famílias.

Base: VE cap. 12, pp. 29–30.

Aplicação: Distinguir o evento antigo das novas pessoas e contas que o livro acrescenta.

### RC-VE09 — Heranças, portos e repressão

Preserva-se o litígio de Celandra Vey entre 2258 e 2274 e a Carta das Viúvas e Tutores de 2274. Roda de Sarnel é o moinho local nomeado por VE. O acordo estável da Liga dos Portos fica em 2312; o Acordo dos Lastros, em 2315; a revolta de Sarn, em 2337; a arbitragem, em 2339. Sarn é distrito portuário da região de Trogu.

Base: VE caps. 14–15, pp. 33–36.

Aplicação: Não tratar Sarn como reino separado nem a Carta regional como igualdade jurídica geral.

### RC-VE10 — Bergen e Segundo Amanhecer

Guerra dos Postos do Norte nomeia em VE a fase de 2376–2388 da II Era. A ascensão de Odravel IV fica em 2394; o orçamento do Segundo Amanhecer, em 2402; uma previsão vendida, em 2407; e a Conferência dos Cadernos Vazios, em 2412. O projeto busca o Relógio de Avar, encontra instrumentos menores e envolve fraude.

Base: VE caps. 16–17, pp. 37–40.

Aplicação: Não atribuir ao projeto a recuperação comprovada do Relógio. Não confundir os postos da II Era com episódios de Hravn na III Era.

### RC-VE11 — Os três pretendentes de 2418

Após a morte de Odravel IV em 2418, Maeressa Endorin, sobrinha do imperador, reivindica continuidade da casa; Aldren Veyr se apoia em parentesco matrimonial, credores e concessões; Soren Talv invoca a emergência e seu comando militar. Nenhum obtém reconhecimento comum como imperador do conjunto.

Base: VE cap. 18, pp. 41–42; caderno II p. 56.

Aplicação: Usar os três nomes como referência da crise sem inventar coroação universal posterior a 2418.

### RC-VE12 — Crise final, Quinder e Concordata

Dupla chancelaria em 2419, Cerco das Casas de Grão em 2420 e abertura da Porta de Cal em 2421 integram a crise. Vaeliss Sareth conquista Quinder em campanhas de 2424–2428. Calven III permanece em Samarith; o Acordo das Lâmpadas é de 2429. A Concordata de 2431 reconhece os sucessores. Enna Vossel, Maela Torr e Dorven Keld são negociadores nomeados nesta ampliação.

Base: VE caps. 18–21, pp. 41–48.

Aplicação: Separar paz institucional, posse e restituição de patrimônio. Preservar a mudança de era sem ano zero.

### RC-VE13 — Iria Veldar e a data do relato

Iria Veldar nasce em 704 da III Era e publica VE pela Oficina da Folha Cinzenta, em Vaelen Endor, em 784. Teren Vassel publica em 664 e morre em 676, antes do nascimento de Iria. Ela o conhece por leitura. O Guia dos Viajantes de 788 é controle editorial posterior, inacessível à autora interna de 784.

Base: VE pp. 5–6, 63–66.

Aplicação: Não escrever Iria como testemunha direta da II Era nem como aluna presencial de Vassel. A idade em dia específico depende do aniversário.

### RC-VE14 — Locais novos e limites cartográficos

Reth, Vau das Cestas, Três Argolas, Posto da Cal, Porta de Cal, Pátio do Lastro, Roda de Sarnel e Sala das Nove Chaves são lugares de escala local. A posição de cada construção não está fixada em coordenadas. Não constituem novos reinos.

Base: VE caderno IV, p. 61; capítulos correspondentes.

Aplicação: Adicionar referências locais sem redesenhar fronteiras ou estabelecer uma capital independente.

### RC-VE15 — Documentos ficcionais e resolução aberta

Folha de Dena Ors, carta de Rughan, traslado do Espelho, memorial de Ilyra e cláusula de remessas são textos ficcionais compostos em VE. Seu conteúdo estabelece o que a obra atribui a essas vozes; não implica reprodução de documento real ou infalibilidade das testemunhas.

Base: VE pp. 10, 16, 28, 40, 48; caderno VI.

Aplicação: Preservar a atribuição e não transformar cada frase de uma personagem em norma universal.

## 27. Cronologia imperial e sucessão vigente



As expressões Base e Ampliação reproduzem a procedência indicada em VE. Nesta edição, ambas integram a continuidade adotada. Os limites explicitados em RC-VE03, RC-VE07 e RC-VE15 permanecem aplicáveis.

{"type": "table", "heads": ["Data", "Acontecimento", "Condição"], "rows": [["893 da II Era", "Acordo das Três Lanternas", "Base"], ["1368 da II Era", "Fundação imperial convencional de Dorgamar", "Base"], ["1398 da II Era", "Concílio das Sete Portas", "Base"], ["1517–1546 da II Era", "Guerra dos Diques na bacia de Taoju e Asmarith", "Base"], ["1872–1880 da II Era", "Crises de abastecimento que precedem a unificação", "Base"], ["1876 da II Era", "Pacto dos Celeiros de Reth", "Ampliação"], ["1878 da II Era", "Folha de Dena Ors sobre reconhecimento de recibos", "Ampliação"], ["1881–1895 da II Era", "Guerra das Correntes", "Base"], ["1887; 1889 da II Era", "Tomada das Três Argolas; compensações", "Ampliação"], ["1892 da II Era", "Acordo das Contas de Madeira", "Ampliação"], ["1896 da II Era", "Proclamação de Vaela e afirmação de Vaelen Endor como capital", "Base"], ["1904 da II Era", "Data atribuída à repressão de Bar-Terval e à ruptura de Rughan", "Ampliação da data; episódio é base"], ["1908 da II Era", "Organização da versão da Carta das Nove Estradas aqui utilizada", "Ampliação da data; carta é base"], ["1940 da II Era", "Acordo das Chaves", "Ampliação"], ["1946–1948 da II Era", "Petição de Ilma Tessik", "Ampliação"], ["1951 da II Era", "Conferência dos contratos de cavalos", "Ampliação"], ["1991 da II Era", "Conservação de cópias locais das contas", "Ampliação"], ["2021; 2024 da II Era", "Revisão monetária; Petição dos Sacos Fechados", "Ampliação"], ["2032; 2039 da II Era", "Tratado das Águas de Morvek; início das obras", "Base"], ["2058 da II Era", "Primeiro conjunto da rede anã entra em serviço", "Base"], ["2063 da II Era", "Aditamento dos Quatro Dias de manutenção", "Ampliação"], ["2078–2149 da II Era", "Reinado de Selvar II", "Base"], ["2093 da II Era", "Correspondência sobre os estudos de Tessia", "Ampliação"], ["2101 da II Era", "Julgamento de Leva Senn na Controvérsia do Espelho", "Ampliação da data e da acusada; controvérsia é base"], ["2108 da II Era", "Reclamação dos estaleiros de Trogu", "Base"], ["2110 da II Era", "Conferência atribuída a Nera Talven", "Ampliação"], ["2116 da II Era", "Conclusão das principais ligações dos canais", "Base"], ["2127 da II Era", "Cheia das Sete Comportas", "Base"], ["2128–2129 da II Era", "Contas de socorro e Inventário das Tigelas", "Ampliação"], ["2190 da II Era", "Garantias sobre depósitos a credores da capital", "Ampliação"], ["2223 da II Era", "Conferência dos Selos de Pedra", "Ampliação"], ["2258–2274 da II Era", "Litígio de Celandra Vey; Carta das Viúvas e Tutores", "Base"], ["2312; 2315 da II Era", "Acordo estável da Liga dos Portos; Acordo dos Lastros", "Ampliação das datas; liga é base"], ["2337; 2339 da II Era", "Revolta de Sarn; arbitragem", "Ampliação das datas; revolta é base"], ["2376–2388 da II Era", "Fase chamada Guerra dos Postos do Norte", "Ampliação das datas e nome; guerra dispendiosa com Bergen é base"], ["2394 da II Era", "Ascensão atribuída a Odravel IV", "Ampliação"], ["2402; 2407; 2412 da II Era", "Orçamento do Segundo Amanhecer; previsão vendida; conferência", "Ampliação das datas; projeto e fraude são base"], ["2418 da II Era", "Morte de Odravel IV e sucessão disputada", "Base"], ["2419; 2420; 2421 da II Era", "Duas Chancelarias; Casas de Grão; Porta de Cal", "Ampliação"], ["2422; 2425; 2426 da II Era", "Guarda de receitas; Assembleia dos Ferros; contratos de revisão local", "Ampliação"], ["2424–2428 da II Era", "Campanhas de Vaeliss Sareth e conquista de Quinder", "Base"], ["2429 da II Era", "Acordo das Lâmpadas", "Base"], ["2431 da II Era", "Concordata de Vaelen e fim da II Era", "Base"], ["1 da III Era", "Primeiro ano da nova contagem", "Base"], ["18 da III Era", "Inverno das Docas Vazias", "Base"], ["61–74 da III Era", "Guerra das Duas Cortes e independência de Quinder", "Base"], ["67 da III Era", "Concordata das Comportas em Dorgamar", "Base"], ["784 da III Era", "Publicação deste livro por Iria Veldar", "Ampliação"]], "widths": [0.24, 0.56, 0.2]}



Sucessão de reconhecimento político

{"type": "table", "heads": ["Governante", "Reinado na II Era", "Ponto de referência"], "rows": [["Vaela Endorin", "1896–1938", "Proclamação em 1896 é base; término ampliado"], ["Teren I Endorin", "1938–1979", "Confirmação das garantias e Acordo das Chaves"], ["Isera I", "1979–2018", "Depósitos e conservação de cópias locais"], ["Selvar I", "2018–2050", "Revisão monetária e Tratado de Morvek"], ["Maereth I", "2050–2078", "Primeira operação da rede anã e manutenção"], ["Selvar II", "2078–2149", "Reinado integral já estabelecido"], ["Isera II", "2149–2182", "Continuidade de contratos e revisão de obras"], ["Odravel I", "2182–2216", "Concessões de cobrança e crédito sobre depósitos"], ["Vaela II", "2216–2253", "Revisão de concessões provinciais"], ["Teren II", "2253–2294", "Período do litígio de Celandra Vey"], ["Odravel II", "2294–2330", "Negociações com a Liga dos Portos"], ["Selvar III", "2330–2361", "Período aqui atribuído à revolta de Sarn"], ["Odravel III", "2361–2394", "Campanhas dos Postos do Norte"], ["Odravel IV", "2394–2418", "Início ampliado; morte em 2418 é base"], ["Reconhecimento fragmentado", "2418–2431", "Três pretendentes, receitas provinciais e Concordata"]], "widths": [0.28, 0.22, 0.5]}



Após 2418 há reconhecimento fragmentado até 2431. A tabela não cria uma linha genealógica completa nem fixa a idade ou a data de morte de cada governante.



Reinos sucessores e herança

{"type": "table", "heads": ["Reino sucessor", "O que a fragmentação preservou ou fortaleceu"], "rows": [["Valerith", "A antiga capital, arquivos e pretensão de precedência diplomática"], ["Nobilith", "Casas de terra, direitos patrimoniais e serviço da nobreza de cavaleiros"], ["Heria", "Relações entre rendas senhoriais, manutenção de cavalaria e obrigações pessoais"], ["Sokeria", "Fortificações e autoridade de senhores que condicionam o alcance da coroa"], ["Milles", "Redes de cidades e recomposição das relações com Bergen e o Estreito"], ["Cávia", "Receitas portuárias e articulação de Trogu com o trabalho mineral do interior"], ["Rácia", "Oficinas, circulação de técnicas e desenvolvimento urbano posterior"]], "widths": [0.25, 0.75]}

## 28. Pessoas, instituições e locais da história imperial



A lista combina pessoas já estabelecidas e novas figuras de VE. A procedência detalhada consta da matriz imperial editável. Os governantes intermediários têm registro na tabela de sucessão. Homonímia não fixa parentesco.

{"type": "table", "heads": ["Pessoa", "Lugar na narrativa"], "rows": [["Vaela Endorin", "Governante da liga e primeira imperatriz; capacidade de coordenação e concentração de comando"], ["Dorrik Venn", "Estrategista anão, aliado de Vaela; objeções privadas à extensão de poderes"], ["Rughan das Duas Margens", "Negociador orc; limites dos acordos comunitários e ruptura após Bar-Terval"], ["Maressa de Merovél", "Sacerdotisa e organizadora de abastecimento; mediação por contratos e hospitalidade"], ["Dena Ors", "Nova escriba da liga, ativa em registros de 1878–1883"], ["Orma Tessik", "Nova delegada de fornecedores; confirmação local dos cobradores"], ["Sorenna Vale", "Nova capitã do episódio das Três Argolas"], ["Selvar II", "Imperador de 2078 a 2149; auge, obras e limites da administração"], ["Tessia Orven", "Arqueóloga que recuperou a Agulha de Namar e fez circular estudos"], ["Aren Voss", "Magistrado que recusou a condenação por uma possibilidade futura"], ["Leva Senn", "Nova acusada da reconstrução do processo do Espelho"], ["Nera Talven", "Nova comissária da conferência posterior à reclamação de Trogu"], ["Sella Dorn", "Nova barqueira nos socorros após a cheia"], ["Nerra Keld", "Nova vedora ligada à prioridade de reparos"], ["Celandra Vey", "Viúva que disputou a administração de uma propriedade em Nobilith"], ["Rovald Vey", "Primo adversário de Celandra; disputa de costume e rendas"], ["Ossa Merev", "Nova moradora que conserva um compromisso de alívio de serviço"], ["Mira Tovel", "Nova estivadora da revolta de Sarn"], ["Sora Hald", "Nova negociadora de Bergen durante as campanhas do norte"], ["Odravel IV", "Último grande imperador; patrocinador do Segundo Amanhecer"], ["Ilyra Tessan", "Nova pesquisadora que distingue vestígios e previsão"], ["Orel Veyr", "Novo agente financeiro que transforma incerteza em promessa"], ["Sera Namar", "Nova conferente das despesas do Segundo Amanhecer"], ["Maeressa, Aldren e Soren", "Novos nomes dos três pretendentes da sucessão de 2418"], ["Aressa Tonn", "Nova mediadora que registra famílias deslocadas em Quinder"], ["Ilvess Nor", "Nova comandante de Naerath na campanha de Quinder"], ["Vaeliss Sareth", "Rainha de Naerath, responsável pelas campanhas de 2424–2428"], ["Calven III", "Grande Pombo que permaneceu em Samarith e negociou em 2429"], ["Enna Vossel, Maela Torr e Dorven Keld", "Novos negociadores da conferência de 2431"], ["Nerissa Sareth", "Sucessora de Vaeliss; independência de Quinder após a Guerra das Duas Cortes"], ["Iria Veldar", "Nova autora interna, nascida em 704 e publicando em 784 da III Era"]], "widths": [0.31, 0.69]}



Outras pessoas nomeadas nos capítulos

{"type": "table", "heads": ["Pessoa", "Função e limite"], "rows": [["Ilma Tessik", "Peticionária por animais requisitados; ativa no processo de 1946–1948 da II Era."], ["Salenna Oss", "Governadora urbana que denuncia preferências nos contratos de cavalos em 1951."], ["Bren Ossel", "Ensaiador anão, ligado à revisão monetária e às tabelas de aferição do norte em 2021."], ["Ina Vel", "Escrivã humana da cobrança em duplicidade discutida em 2024."], ["Tessa Varnel", "Negociadora imperial de garantias de cargas em 2034."], ["Maevra Doss", "Vedora que defende janela de manutenção no Aditamento de 2063."], ["Ilven Tor", "Secretário da Mesa dos Instrumentos Reservados na correspondência de 2093."], ["Maren Tel", "Escrivão do traslado da Controvérsia do Espelho."], ["Berna Oss", "Curadora de mesa da celebração de 2116; reivindica refeições para os carregadores."], ["Ivera Veyr", "Negociadora provincial que defende preservação de sementes no contexto de 2190."], ["Dela Reth", "Comerciante humana entre os representantes da Liga dos Portos."], ["Ors Namar", "Armador anão interessado em garantias de depósitos."], ["Taeren Ilvar", "Delegado élfico interessado no reconhecimento de contratos com portos externos."], ["Aven Doss", "Comandante da repressão na revolta de Sarn."], ["Halven Reth", "Comissário imperial na fase dos Postos do Norte."], ["Rovan Sel", "Guardião que abre a Porta de Cal às tropas de Aldren em 2421 após obter salvo-conduto para parentes."], ["Nessa Veld", "Chefe de depósito que negocia alimento durante o Cerco das Casas de Grão em 2420."], ["Tem Oss", "Tabelião goblin que usa a fórmula até revisão das partes em contratos de 2426."], ["Maela Torr", "Governadora ligada ao Termo de Guarda das Receitas de Trogu em 2422; representante de depósitos na conferência final."], ["Edran Voss", "Comandante que autoriza destruição de cercas para uma faixa de passagem na repressão de Bar-Terval."]], "widths": [0.25, 0.75]}



Instituições

{"type": "table", "heads": ["Instituição", "Atuação e instrumento de poder"], "rows": [["Conselho do Abastecimento", "Reunião da liga anterior à coroa; reservas, comboios e reconhecimento de contribuições"], ["Comando de guerra da liga", "Poder emergencial cuja renovação ajudou a concentrar a autoridade de Vaela"], ["Corte imperial", "Nomeações, arbitragem e coordenação de recursos sob o selo comum"], ["Governadores provinciais", "Arrecadação, tropas e execução local; confirmação progressivamente ligada a casas"], ["Assembleias urbanas", "Negociação de obras, receitas e prerrogativas das cidades"], ["Colégio das Contas", "Fiscalização de receita e posterior validação de obrigações e títulos"], ["Mesa dos Percursos", "Nome criado neste volume para os serviços de correio, postos e cópias"], ["Mesa dos Instrumentos Reservados", "Repartição nova para pedidos de acesso a estudos e instrumentos de mana"], ["Companhia das Eclusas Orientais", "Administração por concessão de parte da rede anã independente"], ["Vedores da Água Fundida", "Fiscalização da operação e das obras da rede de águas"], ["Vedores das Três Lanternas", "Segurança de escavações; tradição do acordo de 893"], ["Liga dos Portos", "Coordenação de cidades e interesses marítimos; suspensão de remessas como pressão"], ["Casa de Conta de Namar-Tel", "Associação de credores criada neste volume; garantias sobre receita e depósitos"], ["Grande Pombo e santuários dos Sete", "Autoridade religiosa, acolhimento, patrimônio e negociação em Samarith"], ["Ordem dos Magos", "Pesquisa, guarda de instrumentos e regulação de acesso a conhecimentos"], ["Equipes do Segundo Amanhecer", "Pesquisa patrocinada pela última corte, atravessada por promessas e fraude"]], "widths": [0.34, 0.66]}



Locais e escalas

{"type": "table", "heads": ["Local", "Definição"], "rows": [["Reth", "Distrito de armazenagem do entroncamento anterior à capital; contexto do pacto de 1876."], ["Vau das Cestas", "Pouso e aferição na região da futura Valerith; não recebe coordenadas."], ["Três Argolas", "Posto de pedágio na região da futura Heria, tomado em 1887."], ["Posto da Cal", "Fiscalização de recibos nos acessos da capital."], ["Porta de Cal", "Posição defensiva da capital aberta em 2421. Não presumir identidade com o posto."], ["Pátio do Lastro", "Setor de Morvek ligado aos socorros da cheia."], ["Roda de Sarnel", "Moinho da propriedade em disputa no litígio de Celandra."], ["Sarn", "Distrito portuário da região de Trogu; episódio anterior recebe desenvolvimento e datas em VE."], ["Sala das Nove Chaves", "Dependência da antiga administração de Vaelen Endor onde VE situa a conferência final."], ["Ponte Seca", "Nome do protocolo de 2388 e referência local do conflito do norte, sem localização cartográfica precisa."]], "widths": [0.25, 0.75]}

## 29. Conferência de compatibilidade e implantação de VE



A conferência entre a base 2.3 e VE não identificou incompatibilidade nos marcos principais da unificação, do reinado de Selvar II, da dissolução ou da mudança de era. As novas precisões se somam ao núcleo anterior, com os limites registrados em RC-VE.

### RC-VE16 — Alegações de documentos e acontecimentos

A cronologia conserva datas de atos, conflitos e pessoas. Expressões de memória, reputação e interpretação presentes no livro são atribuídas aos seus participantes. Não se presume que todas as autoridades adotavam o mesmo calendário no momento do ato.

Base: VE caps. 1 e 21; caderno VI.

Aplicação: Manter era e origem ao transportar datas para resumos.



Questões em aberto

### RC-VEA01 — Lacuna preservada 1

Genealogia completa dos Endorin e das casas ligadas à coroa. Parentescos de primeiro grau não se deduzem da sequência de reinados.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA02 — Lacuna preservada 2

Nascimento, morte e idade dos governantes e pessoas sem datas expressas. Uma troca de governante não equivale automaticamente à morte do anterior.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA03 — Lacuna preservada 3

Traçado exato das Nove Estradas, ramais de canais e posição dos distritos locais.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA04 — Lacuna preservada 4

Extensão do domínio imperial em Bergen em cada fase. A presença de tropas e a cobrança variavam.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA05 — Lacuna preservada 5

Texto integral da Concordata de 2431 e datas diárias de seus atos. As cláusulas literárias de VE não constituem uma edição diplomática completa.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA06 — Lacuna preservada 6

Data exata da recuperação da Agulha de Namar. A carta de 2093 atesta correspondência, sem datar por si a descoberta.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA07 — Lacuna preservada 7

Data do aniversário de Iria Veldar. A diferença entre 704 e 784 é de oitenta anos, sem fixar a idade completada em um dia.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.



Implantação nas obras

{"type": "table", "heads": ["Material", "Situação após a edição 2.4"], "rows": [["VE", "Fonte incorporada; 66 páginas; nomes e datas ampliados adotados com os limites desta edição."], ["Registro de Continuidade", "Atualização efetuada nesta edição 2.4 em PDF e matriz editável."], ["História Geral de Virtude", "Usar RC-VE ao revisar a síntese imperial e sua cronologia; reescrita e novo PDF não fazem parte desta atualização."], ["O Mar das Espadas na Época de Selvar II", "Preservar o recorte de 2078–2149 e a data de Vassel em 664; detalhes adicionais só devem entrar conforme o acesso do autor interno."], ["Wikia", "Fila de incorporação de governantes, personagens, instituições, pactos e marcos. Este Registro não atesta a implantação desses itens no site."], ["Crônicas e manuais", "Aplicar como antecedente histórico em futuras revisões quando pertinente. Evitar acesso de personagens a obras ainda não publicadas em sua época."]], "widths": [0.26, 0.74]}

## 30. Organização geral: tempo, vínculos e referências

Finalidade da atualização

Esta edição conserva o corpo de definições 2.4 e acrescenta índices de consulta usados também pela wikia. Não substitui os livros por resumos nem cria relações para preencher lacunas. O Registro continua sendo a referência normativa em caso de divergência.

### RC-O01 — Cronologia única e identificável

Os índices da wikia e desta matriz compartilham os mesmos identificadores de acontecimentos e vínculos. Cada item conserva referência, precisão e limites. A organização não cria novas datas ou relações por inferência.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O02 — Precisão temporal preservada

Datas aproximadas continuam aproximadas; intervalos, anos agrupados e datas sem dia não se tornam datas completas. Os anos são comparados dentro de cada era. A ausência de ano zero é preservada. A formação dos planos não recebe duração material demonstrada.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O03 — Encontro, parentesco e sucessão

Sobrenome comum, presença numa cena e sequência de governantes não demonstram parentesco. Um encontro documentado não é automaticamente amizade, aliança ou cooperação permanente. A filiação explícita de Isera a Teren I permanece uma relação específica, sem preencher toda a cadeia genealógica.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O04 — Fonte e atribuição

Cada acontecimento e vínculo apresenta arquivo e página, ou registro normativo identificável. A interpretação de uma autora interna conserva atribuição. A fonte usada pelos novos índices é identificada por arquivo, páginas e impressão digital nesta matriz.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O05 — Spoilers e início de 788

A wikia usa o início de 788 como marco público. Acontecimentos posteriores e vínculos que revelam seus resultados são ocultados pelo controle de spoilers, inclusive na busca e nos filtros. O acesso a um PDF integral não elimina seus spoilers. Este Registro é referência autoral integral e contém os desfechos.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O06 — Escalas e cobertura

Regiões de referência orientam a consulta sem fixar as mesmas fronteiras em todas as eras. O índice de vínculos é uma seleção confirmada, não um cadastro exaustivo de toda relação possível. Nomes citados podem participar da rede antes de possuírem artigo próprio.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O07 — Manutenção conjunta

Uma decisão que modifique data, identidade, vínculo ou condição de conhecimento exige conferir o Registro, o índice da cronologia, a rede de vínculos e os verbetes afetados. As obras completas podem ser atualizadas em edições programadas. Nenhuma divergência em aberto recebe solução automática.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O08 — Continuidade visual

Retratos continuam subordinados às descrições canônicas. Feições, roupas e idades aparentes não especificadas são interpretação visual e não estabelecem novos fatos biográficos. Os retratos imperiais da wikia 0.24 não suprem lacunas genealógicas ou cronológicas.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

## 31. Cronologia geral com referências



O índice contém 148 marcos selecionados. As referências HG e VE desta seção apontam aos arquivos identificados no quadro de fontes do índice. R24 aponta à edição 2.4 como origem documental de definições aqui preservadas. Eventos do mesmo ano não são automaticamente causas uns dos outros.

{"type": "table", "heads": ["Código", "Fonte do índice / arquivo", "Páginas / SHA-256"], "rows": [["HG", "História Geral de Virtude / Historia_Geral_de_Virtude.pdf", "148 pp. / e48a8453cfcc8e62b26e88eed94c07366bb099ef5007750eab7cfb81207d45a8"], ["VE", "Vaelen Endor — A construção e a queda do Império / Vaelen_Endor_A_Construcao_e_a_Queda_do_Imperio.pdf", "66 pp. / d14fe79da436dd65fa4853c5bf07417c6e01a3d64c55518da95a533468f5bfcc"], ["R24", "Registro de Continuidade 2.4 — fonte das definições preservadas / Registro_de_Continuidade_Virtude_v2_4.pdf", "138 pp. / 9c97328532251bc4c546c5ed767efb5333f28ca994e6990fb01d6759c3d2b3b0"]], "widths": [0.1, 0.55, 0.35]}



Antes da contagem

{"type": "table", "heads": ["ID / data", "Acontecimento e limite", "Fonte"], "widths": [0.23, 0.58, 0.19], "rows": [["EV-001 / Antes da contagem", "Formação dos planos segundo as tradições da Consciência Una. Cosmologia; duração indeterminável. / Precisão: Indeterminada", "HG p. 142"]]}



I Era

{"type": "table", "heads": ["ID / data", "Acontecimento e limite", "Fonte"], "widths": [0.23, 0.58, 0.19], "rows": [["EV-002 / c. 1 da I Era", "Horizonte convencional dos primeiros dragões. Marco retrospectivo, não uma data de nascimento demonstrada. / Precisão: Aproximada", "HG p. 142"], ["EV-003 / c. 2100 da I Era", "Primeiros assentamentos identificados como Eldenari. Datação aproximada de vestígios. / Precisão: Aproximada", "HG p. 142"], ["EV-004 / c. 2550 da I Era", "Consolidação urbana de Xeo Taoju. Reconstrução arqueológica e textual. / Precisão: Aproximada", "HG p. 142"], ["EV-005 / c. 2700-2760 da I Era", "Trabalhos de Ilyra e fundação da Casa dos Nomes de Oren. Tradições e cópias de registros. / Precisão: Aproximada", "HG p. 142"], ["EV-006 / c. 5990 da I Era", "Travessia das Sete Portas. Concordância de relatos élficos. / Precisão: Aproximada", "HG p. 142"], ["EV-007 / c. 6035 da I Era", "Fundação da Ordem em Aethravel. Data relativa à Travessia. / Precisão: Aproximada", "HG p. 142"], ["EV-008 / c. 6360 da I Era", "Organização do círculo dos Primeiros Magos. Fragmentos das casas de pesquisa. / Precisão: Aproximada", "HG p. 142"], ["EV-009 / c. 6384 da I Era", "Ativação do Selo. Nove anos antes da abertura da guerra, segundo a sequência adotada. / Precisão: Aproximada", "HG p. 142"], ["EV-010 / c. 6393-6399 da I Era", "Sete campanhas da Guerra das Nove Vigílias. Sequência relativa melhor conhecida que a numeração. / Precisão: Aproximada", "HG p. 142"], ["EV-011 / Fim da I Era, c. 6400", "Ruptura do Selo e Grande Punição, separadas por vinte e três dias. Limite convencional da era. / Precisão: Aproximada", "HG p. 142"]]}



II Era

{"type": "table", "heads": ["ID / data", "Acontecimento e limite", "Fonte"], "widths": [0.23, 0.58, 0.19], "rows": [["EV-012 / 1-40 da II Era", "Período mais intenso de escuridão e destruição. Datas regionais convertidas. / Precisão: Intervalo", "HG p. 142"], ["EV-013 / 1-c. 1000 da II Era", "Milênio das Trevas; migrações e reconstruções desiguais. Período histórico amplo. / Precisão: Aproximada", "HG p. 142"], ["EV-014 / 173 da II Era", "União dos celeiros associada a Nara. Tradição datada em cópias posteriores. / Precisão: Datada", "HG p. 142"], ["EV-015 / c. 462 da II Era", "Paliçadas e postos setentrionais ligados ao Ano do Brilho Imóvel. Tradição de Bergen preservada em cópias posteriores; não comprova Thul Verenari. / Precisão: Aproximada", "HG p. 142"], ["EV-016 / 612 da II Era", "Desastre de Lombonia. Registros costeiros e documentos recuperados. / Precisão: Datada", "HG p. 142"], ["EV-017 / 893 da II Era", "Cópia mais antiga do Acordo das Três Lanternas. Testemunho documental preservado. / Precisão: Datada", "HG p. 143"], ["EV-018 / 1084 da II Era", "Paz de Dorgal. Tratado em cópias concordantes. / Precisão: Datada", "HG p. 143"], ["EV-019 / 1261 da II Era", "Tratado das Três Margens. Documento de irrigação e paz. / Precisão: Datada", "HG p. 143"], ["EV-020 / 1368 da II Era", "Fundação convencional do Império de Dorgamar. Reconhecimento da chefia comum entre cidades e casas. / Precisão: Datada", "HG p. 143"], ["EV-021 / 1398 da II Era", "Concílio das Sete Portas. Contagem reconhecida nos santuários de Samarith. / Precisão: Datada", "HG p. 143"], ["EV-022 / 1517-1546 da II Era", "Guerra dos Diques em Quinder, na bacia de Taoju e Asmarith. Conflito anterior ao império de Vaelen Endor e aos canais orientais de Dorgamar. / Precisão: Intervalo", "HG p. 143"], ["EV-023 / 1872-1880 da II Era", "Crise de abastecimento e formação da liga de Vaela. Registros de cidades e comboios. / Precisão: Intervalo", "HG p. 143"], ["EV-105 / 1876 da II Era", "Pacto dos Celeiros de Reth. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-106 / 1878 da II Era", "Folha de Dena Ors sobre reconhecimento de recibos. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-024 / 1881-1895 da II Era", "Campanhas da Guerra das Correntes. Concordância militar das cidades da liga. / Precisão: Intervalo", "HG p. 143"], ["EV-107 / 1887; 1889 da II Era", "Tomada das Três Argolas; compensações. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-108 / 1892 da II Era", "Acordo das Contas de Madeira. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-025 / 1896 da II Era", "Proclamação imperial de Vaela. Marco oficial de fundação. / Precisão: Datada", "HG p. 143"], ["EV-130 / 1896–1938 da II Era", "Governo de Vaela Endorin. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-109 / 1904 da II Era", "Data atribuída à repressão de Bar-Terval e à ruptura de Rughan. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-110 / 1908 da II Era", "Organização da versão da Carta das Nove Estradas aqui utilizada. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-131 / 1938–1979 da II Era", "Governo de Teren I Endorin. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-111 / 1940 da II Era", "Acordo das Chaves. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-112 / 1946–1948 da II Era", "Petição de Ilma Tessik. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo", "VE p. 51–54"], ["EV-113 / 1951 da II Era", "Conferência dos contratos de cavalos. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-132 / 1979–2018 da II Era", "Governo de Isera I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-114 / 1991 da II Era", "Conservação de cópias locais das contas. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-133 / 2018–2050 da II Era", "Governo de Selvar I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-115 / 2021; 2024 da II Era", "Revisão monetária; Petição dos Sacos Fechados. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-026 / 2032, 2039 e 2058 da II Era", "Tratado das Águas, começo das obras e primeiro conjunto de canais em serviço. Marcos distintos da rede oriental de Dorgamar. / Precisão: Datada", "HG p. 143"], ["EV-134 / 2050–2078 da II Era", "Governo de Maereth I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-116 / 2063 da II Era", "Aditamento dos Quatro Dias de manutenção. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-027 / 2078-2149 da II Era", "Reinado de Selvar II e auge da Paz das Estradas. Contagem de reinado. / Precisão: Intervalo", "HG p. 143"], ["EV-117 / 2093 da II Era", "Correspondência sobre os estudos de Tessia. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-118 / 2101 da II Era", "Julgamento de Leva Senn na Controvérsia do Espelho. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-119 / 2110 da II Era", "Conferência atribuída a Nera Talven. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-028 / 2116 e 2127 da II Era", "Conclusão das principais ligações e Cheia das Sete Comportas. Ampliações e conflito de operação. / Precisão: Datada", "HG p. 143"], ["EV-120 / 2128–2129 da II Era", "Contas de socorro e Inventário das Tigelas. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo", "VE p. 51–54"], ["EV-135 / 2149–2182 da II Era", "Governo de Isera II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-136 / 2182–2216 da II Era", "Governo de Odravel I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-121 / 2190 da II Era", "Garantias sobre depósitos a credores da capital. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-137 / 2216–2253 da II Era", "Governo de Vaela II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-122 / 2223 da II Era", "Conferência dos Selos de Pedra. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-138 / 2253–2294 da II Era", "Governo de Teren II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-029 / 2258-2274 da II Era", "Litígio de Celandra e Carta das Viúvas e Tutores. Processo e carta regional. / Precisão: Intervalo", "HG p. 143"], ["EV-139 / 2294–2330 da II Era", "Governo de Odravel II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 55"], ["EV-123 / 2312; 2315 da II Era", "Acordo estável da Liga dos Portos; Acordo dos Lastros. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-140 / 2330–2361 da II Era", "Governo de Selvar III. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 56"], ["EV-124 / 2337; 2339 da II Era", "Revolta de Sarn; arbitragem. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-141 / 2361–2394 da II Era", "Governo de Odravel III. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 56"], ["EV-125 / 2376–2388 da II Era", "Fase chamada Guerra dos Postos do Norte. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo", "VE p. 51–54"], ["EV-145 / 2386 da II Era", "Publicação de Bichos e Assombros dos Caminhos. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada", "R24 p. 8 / Cap. 12, concordância anterior a 788"], ["EV-142 / 2394–2418 da II Era", "Governo de Odravel IV. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo", "VE p. 56"], ["EV-126 / 2402; 2407; 2412 da II Era", "Orçamento do Segundo Amanhecer; previsão vendida; conferência. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-030 / 2418 da II Era", "Morte de Odravel IV e abertura da disputa sucessória. Registros da corte. / Precisão: Datada", "HG p. 143"], ["EV-127 / 2419; 2420; 2421 da II Era", "Duas Chancelarias; Casas de Grão; Porta de Cal. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-128 / 2422; 2425; 2426 da II Era", "Guarda de receitas; Assembleia dos Ferros; contratos de revisão local. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-031 / 2424-2428 da II Era", "Campanhas de conquista de Quinder. Fontes rivais concordam sobre o intervalo geral. / Precisão: Intervalo", "HG p. 143"], ["EV-032 / 2429 da II Era", "Acordo das Lâmpadas. Instrumento preservado em Samarith. / Precisão: Datada", "HG p. 143"], ["EV-033 / 2431 da II Era", "Concordata de Vaelen e fim da era. Marco utilizado nesta edição. / Precisão: Datada", "HG p. 143"]]}



III Era

{"type": "table", "heads": ["ID / data", "Acontecimento e limite", "Fonte"], "widths": [0.23, 0.58, 0.19], "rows": [["EV-034 / 1 da III Era", "Primeiro ano posterior à dissolução reconhecida. Sem ano zero. / Precisão: Datada", "HG p. 143"], ["EV-035 / 18 da III Era", "Inverno das Docas Vazias em Dorgamar. Crise comercial, dívidas e conflitos. / Precisão: Datada", "HG p. 143"], ["EV-036 / 27-46 da III Era", "Formação da rede reconhecida como Guilda dos Guerreiros. Casas locais anteriores ao acordo geral. / Precisão: Intervalo", "HG p. 143"], ["EV-037 / 61-74 da III Era", "Guerra das Duas Cortes e independência de Quinder. Acordos, remessas e crônicas. / Precisão: Intervalo", "HG p. 143"], ["EV-038 / 67 da III Era", "Concordata das Comportas. Reorganização e suspensão parcial de ramais em Dorgamar. / Precisão: Datada", "HG p. 144"], ["EV-039 / 98 da III Era", "Pacto das Duas Fozes e reconhecimento da autonomia de Ayak. A ocupação e o nome do porto são anteriores. / Precisão: Datada", "HG p. 144"], ["EV-040 / 147 da III Era", "Fundação da Guilda dos Heróis. Registros da Heria. / Precisão: Datada", "HG p. 144"], ["EV-041 / 150-200 da III Era", "Auge inicial dos Heróis. Periodização aproximada. / Precisão: Aproximada", "HG p. 144"], ["EV-042 / 164 da III Era", "Pacto dos Ancoradouros. Consolidação política associada a Sularien. / Precisão: Datada", "HG p. 144"], ["EV-043 / 208 da III Era", "Reunião inaugural da Mesa das Sete Panelas. Tradição documental halfling. / Precisão: Datada", "HG p. 144"], ["EV-044 / 219 da III Era", "Programa de construção da muralha de pedra de Bergen. Posterior a postos e paliçadas da II Era. / Precisão: Datada", "HG p. 144"], ["EV-045 / 286 da III Era", "Organização da Guilda dos Magos. Estatutos e cartas de adesão. / Precisão: Datada", "HG p. 144"], ["EV-046 / 318 da III Era", "Desastre das Galerias de Anver. Registros da Ordem e dos mineiros. / Precisão: Datada", "HG p. 144"], ["EV-047 / 326 da III Era", "Carta das Mãos Abertas. Admissão de não elfos como membros plenos da Ordem. / Precisão: Datada", "HG p. 144"], ["EV-048 / 412 e 438 da III Era", "Circuito precursor e carta da Guilda do Vento Arcano. Marcos distintos, frequentemente confundidos. / Precisão: Datada", "HG p. 144"], ["EV-143 / 462 da III Era", "Nascimento de Marevim Aethros. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada", "R24 p. 65 / RC-T05"], ["EV-049 / 521 da III Era", "Expansão naval documentada da dinastia Khor-Azhar. Início documental, não origem de Nogard. / Precisão: Datada", "HG p. 144"], ["EV-050 / 548 da III Era", "Fundação dos Irmãos da Ponte Fria. Acordos de transporte do norte. / Precisão: Datada", "HG p. 144"], ["EV-051 / 563 e 571 da III Era", "Inverno dos Sem-Rosto e ampliação da muralha. Incidentes e obras não são o mesmo evento. / Precisão: Datada", "HG p. 144"], ["EV-052 / 588 da III Era", "Início do reinado de Ariessa em Thaelorien. Registros de corte. / Precisão: Datada", "HG p. 144"], ["EV-053 / 602 da III Era", "Acordo inicial da Liga das Balanças. Cartas comerciais. / Precisão: Datada", "HG p. 144"], ["EV-054 / 622 e 631 da III Era", "Início do reinado de Arriot e Acordo dos Pomares de Aston. Governo de Aelvar e direitos de cultivo. / Precisão: Datada", "HG p. 144"], ["EV-055 / 654 da III Era", "Acordo dos Viveiros. Conservação, acesso e cobranças em Thaelorien. / Precisão: Datada", "HG p. 144"], ["EV-146 / 664 da III Era", "Publicação do estudo de Teren Vassel sobre o Mar das Espadas. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada", "VE p. 5"], ["EV-147 / 676 da III Era", "Morte de Teren Vassel. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada", "VE p. 5"], ["EV-056 / 681 da III Era", "Organização da Confraria do Carvão e do Ferro. Registros de Juu Daixo. / Precisão: Datada", "HG p. 144"], ["EV-057 / 689 da III Era", "Organização da Rede das Chaves Pequenas. Apoio a viajantes e famílias, sem território soberano goblin. / Precisão: Datada", "HG p. 144"], ["EV-058 / c. 697-713 da III Era", "Consolidação da aliança dos Ladrões. Intervalo inferido; ausência de estatuto verificável. / Precisão: Aproximada", "HG p. 144"], ["EV-059 / 703 e 716-722 da III Era", "Ascensão de Zeryssa e disputa das rendas entre Naerath e Quinder. Boicotes, processos e Acordo de Vel-Narim. / Precisão: Intervalo", "HG p. 145"], ["EV-148 / 704 da III Era", "Nascimento de Iria Veldar. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada", "VE p. 5"], ["EV-060 / 731 da III Era", "Isolamento da aldeia e morte de Eline. Investigação iniciada e documentos posteriormente abertos. / Precisão: Datada", "HG p. 145"], ["EV-061 / 734 da III Era", "Autorização do Conselho das Duas Margens. Carta de Quinder. / Precisão: Datada", "HG p. 145"], ["EV-062 / 739 e 741 da III Era", "Petição dos Filhos Sem Lote e ascensão de Elyndra em Iltharion. Eventos distintos de migração e governo. / Precisão: Datada", "HG p. 145"], ["EV-063 / 742 da III Era", "Acordo das Raízes Baixas. Direitos de uso de Leth-Auren. / Precisão: Datada", "HG p. 145"], ["EV-064 / 752-758 da III Era", "Disputa dos Faróis. Iltharion, Aelvar e fiscalização de sinais. / Precisão: Intervalo", "HG p. 145"], ["EV-065 / 754 da III Era", "Coroação de Brunna IV em Dorgamar. Registros da corte anã. / Precisão: Datada", "HG p. 145"], ["EV-066 / 755 da III Era", "Revisão limitada apoiada por Ivela. Procedimento da Ordem. / Precisão: Datada", "HG p. 145"], ["EV-067 / 758 e 759 da III Era", "Reconhecimento da Oficina dos Arcos e fundação da Casa do Tipo Azul. Ofícios e publicação em Samarith. / Precisão: Datada", "HG p. 145"], ["EV-068 / 759 da III Era", "Marevim alcança a Gema em Lombonia. Data reconstruída de seus registros e deslocamentos. [SPOILER] / Precisão: Datada", "HG p. 145"], ["EV-069 / 763-770 da III Era", "Querela de Terval. Terras, passagem e indenizações ligadas às famílias de Kharug e Druvak. / Precisão: Intervalo", "HG p. 145"], ["EV-070 / 769 da III Era", "Abertura do Livro das Esporas. Revisão de rendas da Heria. / Precisão: Datada", "HG p. 145"], ["EV-071 / 770 da III Era", "Início da compilação da História Geral de Virtude. Cadernos de trabalho da autora da História Geral. / Precisão: Datada", "HG p. 145"], ["EV-072 / 772 da III Era", "Disputa das Pontes Baixas. Pesos, taxas e passagens em Pellanor. / Precisão: Datada", "HG p. 145"], ["EV-073 / 774-777 da III Era", "Disputa de ensaios monetários entre a Liga e Milles. Contas e decisões comerciais. / Precisão: Intervalo", "HG p. 145"], ["EV-074 / 778 da III Era", "Apresamento das Três Bandeiras. Pirataria, documentos e seguros. / Precisão: Datada", "HG p. 145"], ["EV-144 / 778 da III Era", "Trabalho de campo do qual vem a amizade de Liana e Rul. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada", "R24 p. 10 / RC-A05"], ["EV-075 / 779-783 da III Era", "Disputa das obras de irrigação em Quinder. Conselho, medições e petições. / Precisão: Intervalo", "HG p. 145"], ["EV-076 / 781 da III Era", "Abertura da Questão dos Celeiros na Sokeria. Petições de aldeias. / Precisão: Datada", "HG p. 145"], ["EV-077 / 781 e 783 da III Era", "Querela das Âncoras e Petição das Margens Vazias. Conflitos distintos em Sularien e Dorgamar. / Precisão: Datada", "HG p. 145"], ["EV-078 / 782 da III Era", "Mandato de coordenação de Rugha Sen. Não constitui uma monarquia sobre a Confederação Orc. / Precisão: Datada", "HG p. 145"], ["EV-079 / 784 da III Era", "Acordo dos Sacos de Sal. Convenções aduaneiras. / Precisão: Datada", "HG p. 145"], ["EV-080 / 784 da III Era", "Incidente das Talhas e início do mandato de Ilyne Tess. Eventos distintos em Nerevala e Ayak. / Precisão: Datada", "HG p. 146"], ["EV-129 / 784 da III Era", "Publicação de Vaelen Endor — A construção e a queda do Império por Iria Veldar. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada", "VE p. 51–54"], ["EV-081 / 785 da III Era", "Incidente registrado no posto de Haldren. Observação sem prova da existência dos Thul Verenari. / Precisão: Datada", "HG p. 146"], ["EV-082 / 785 da III Era", "Exigências dos Jurados do Caminho Alto. Tabelas e termos de transporte. / Precisão: Datada", "HG p. 146"], ["EV-086 / 785-787 da III Era", "Caso das Guias Partidas; vínculos entre os futuros companheiros. Depoimentos, contratos e autos de Valada. / Precisão: Intervalo", "HG p. 146"], ["EV-083 / 786 da III Era", "Acordo parcial de Leth-Auren e crise naval entre Nogard e Oleakia. Conflitos distintos. / Precisão: Datada", "HG p. 146"], ["EV-084 / 787 da III Era", "Debate das Duas Portas. Disputa religiosa e contratual em Valerith. / Precisão: Datada", "HG p. 146"], ["EV-085 / 787 da III Era", "Trégua das Três Portas. Acordo provisório sem transferência da soberania valerithiana sobre Nerevala. / Precisão: Datada", "HG p. 146"], ["EV-087 / Décimo mês de 787", "Audiência das Guias, em Valada; primeiro encontro documentado dos seis reunidos. Atas e credenciais diplomáticas; ainda não constituíam companhia permanente. / Precisão: Datada", "HG p. 146"], ["EV-088 / 11 do segundo mês de 788", "Golpe de Marevim e roubo da Agulha. Registros e testemunhos cruzados. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-089 / 19 do quarto mês de 788", "Primeira chegada da missão a Samarith pelo eixo Aelvar-Naerath-Quinder. Entrega inicial do alerta, antes das diligências na Rácia. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-090 / 27 do quarto mês de 788", "Partida da diligência documental para a Rácia. Trajeto por Nobilith, Valerith e o corredor de Valada. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-091 / 5 do quinto mês de 788", "Chegada de Rul a Samarith. Via Aelvar e Naerath; trabalho de arquivos durante a ausência da missão. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-092 / 27 do quinto mês de 788", "Passagem registrada por Ihfarilse. Um mês após a partida; inclui estrada, controles e verificação em Vaelen Endor e Valada. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-093 / 28 do sexto mês de 788", "Inspeção da urna na costa de Trogu. Reencontro com Rul depois do Caminho Alto e da descida de Juu Daixo. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-094 / 26 do sétimo mês de 788", "Retorno da missão a Samarith. Regresso pelo Mar das Espadas, desembarque perto de Vau-Cinzento e marcha terrestre. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-095 / Sétimo e oitavo meses de 788", "Testes em Quinder, ruptura temporária e negociações. Deslocamentos locais; oficina de campanha de Sera em Xeo Taoju. [SPOILER] / Precisão: Datada", "HG p. 146"], ["EV-096 / Início do nono mês de 788", "Desembarque do exército principal de Marevim em Vau-Cinzento. De Lombonia ao Mar das Espadas, seguido da aproximação terrestre de Samarith. [SPOILER] / Precisão: Aproximada", "HG p. 146"], ["EV-097 / 18-23 do nono mês de 788", "Batalha de Samarith. Convergência dos registros das forças envolvidas. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-098 / 23 do nono mês de 788", "Operação da Câmara e morte de Marevim. Testemunhos independentes e registros técnicos. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-099 / 3 e 27 do décimo mês de 788", "Termos provisórios e assinatura do pacto mais amplo. Ratificações ainda parcialmente pendentes. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-100 / Décimo mês de 788, após a batalha", "Morte de Osric, coroação de Martan e contestação das concessões. Dia exato não estabelecido. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-101 / 12 do décimo segundo mês de 788", "Recebimento da resposta de Arriot. Registro da mensagem. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-102 / 28 do décimo segundo mês de 788", "Encerramento da coleta de testemunhos desta edição. Corte editorial, não fim das investigações. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-103 / Segundo Dia da Vigília de 788", "Sinos pelos mortos dos quatro exércitos. Cerimônia em Samarith. [SPOILER] / Precisão: Datada", "HG p. 147"], ["EV-104 / Quinto Dia da Vigília de 788", "Publicação desta edição revista. Data do colofão. [SPOILER] / Precisão: Datada", "HG p. 147"]]}

## 32. Vínculos confirmados entre personagens



O índice reúne 65 vínculos confirmados. A direção dos campos de cadastro não altera o sentido da descrição: quem é pai, filha, sobrinho ou sucessor é indicado por escrito. Um vínculo institucional não equivale a concordância com todos os atos da instituição. Os encontros dos seis em Valada são registrados como encontros, não como prova de amizade entre todos os pares.

{"type": "table", "heads": ["ID / pessoas", "Tipo e descrição", "Período / fonte"], "widths": [0.25, 0.52, 0.23], "rows": [["VL-001 / Liana Meywood / Rul Aven", "Afeto. Amizade desde 778; aproximação amorosa pouco antes da abertura do Volume II. Mantêm autonomia e encontros ocasionais.", "778 em diante; aproximação amorosa antes da abertura de C2 / R24 p. 10 / RC-A05"], ["VL-002 / Liana Meywood / Demer Vault", "Amizade e cooperação. Conservam amizade, confiança e cuidado; não constituem casal.", "Guias Partidas e crise de 788 / R24 p. 68 / RC-N01"], ["VL-003 / Elthara Sorn / Tavian Ordel", "Afeto. Aproximação afetiva em negociações militares anteriores e encontros ocasionais. O vínculo é reservado e não explica automaticamente uma aliança.", "Período não delimitado / R24 p. 10 / RC-A07"], ["VL-004 / Arriot Ilvar / Le Rink", "Parentesco. Arriot Ilvar é pai de Le Rink. A filiação não fornece comando automático sobre a Ordem.", "Período não delimitado / HG p. 105"], ["VL-005 / Nyssara Veyl / Narel", "Parentesco. Nyssara e Narel são irmãos. O desaparecimento de Narel não concede a Nyssara autoridade para decidir por ele.", "Período não delimitado / R24 p. 69 / RC-N04"], ["VL-006 / Kharug Venn / Druvak", "Parentesco. Kharug é o irmão mais velho de Druvak. Respondem de modos diferentes à perda de terras e à indenização parcial.", "Período não delimitado / HG p. 106"], ["VL-007 / Marevim / Eline", "Parentesco. Marevim é pai de Eline, curadora morta no isolamento de 731. Ela defendia o consentimento nos tratamentos.", "Até 731 da III Era / R24 p. 9 / RC-A01"], ["VL-008 / Osric Dalm / Martan Edris", "Parentesco. Martan é sobrinho de Osric; isso não lhe confere legitimidade sucessória indiscutível.", "Período não delimitado / R24 p. 12 / cap. 4, parentesco anterior preservado"], ["VL-009 / Osric Dalm / Helena Dalm", "Parentesco. Helena é neta de Osric. A contestação posterior não a torna automaticamente rainha.", "Período não delimitado / R24 p. 12 / cap. 4, parentesco anterior preservado"], ["VL-010 / Maressa II Veldan / Osric Dalm", "Compromisso político. Maressa promete abastecimento e respeito à condução da sucessão de Nobilith. [SPOILER]", "Crise de 788 / R24 p. 12 / RC-S01"], ["VL-011 / Maressa II Veldan / Martan Edris", "Acordo reservado. Negociam reconhecimento, crédito e garantias sobre receitas e postos de Sar-Nobil; não se trata de anexação automática. [SPOILER]", "Crise de 788 / R24 p. 12 / RC-S01"], ["VL-012 / Martan Edris / Helena Dalm", "Contestação política. Após a coroação de Martan, Helena organiza contestação das concessões e do procedimento sucessório. [SPOILER]", "Após a batalha, 788 / R24 p. 12 / RC-S04"], ["VL-013 / Ivela Dorn / Ordem dos Magos", "Vínculo institucional. Ivela apoia uma revisão limitada e aceita resultado insuficiente; sua responsabilidade deve ser distinguida das demais.", "Revisão de 755 e consequências / R24 p. 9 / RC-A02"], ["VL-014 / Rul Aven / Ordem dos Magos", "Vínculo institucional. Rul trabalha com conservação de instrumentos, preserva provas e possui responsabilidades próprias.", "Período não delimitado / R24 p. 9 / RC-A02"], ["VL-015 / Marevim / Ordem dos Magos", "Vínculo institucional. Pesquisador ligado à Ordem antes da ruptura; a apuração de 731 não elimina sua responsabilidade por atos posteriores.", "Período não delimitado / R24 p. 69 / RC-N05"], ["VL-016 / Liana Meywood / Le Rink", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-017 / Liana Meywood / Nyssara Veyl", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-018 / Liana Meywood / Kharug Venn", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-019 / Liana Meywood / Sera Vennor", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-020 / Demer Vault / Le Rink", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-021 / Demer Vault / Nyssara Veyl", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-022 / Demer Vault / Kharug Venn", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-023 / Demer Vault / Sera Vennor", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-024 / Le Rink / Nyssara Veyl", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-025 / Le Rink / Kharug Venn", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-026 / Le Rink / Sera Vennor", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-027 / Nyssara Veyl / Kharug Venn", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-028 / Nyssara Veyl / Sera Vennor", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-029 / Kharug Venn / Sera Vennor", "Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785.", "Décimo mês de 787 / R24 p. 64 / RC-T04"], ["VL-030 / Maressa II Veldan / Lethia Arven", "Governo e serviço. Maressa governa Valerith com a chanceler Lethia Arven.", "Período não delimitado / HG p. 72"], ["VL-031 / Vaela Endorin / Teren I Endorin", "Sucessão política. Teren I Endorin sucede a Vaela Endorin no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "1938–1979 da II Era / VE p. 55"], ["VL-032 / Teren I Endorin / Isera I", "Sucessão política. Isera I sucede a Teren I Endorin no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "1979–2018 da II Era / VE p. 55"], ["VL-033 / Isera I / Selvar I", "Sucessão política. Selvar I sucede a Isera I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2018–2050 da II Era / VE p. 55"], ["VL-034 / Selvar I / Maereth I", "Sucessão política. Maereth I sucede a Selvar I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2050–2078 da II Era / VE p. 55"], ["VL-035 / Maereth I / Selvar II", "Sucessão política. Selvar II sucede a Maereth I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2078–2149 da II Era / VE p. 55"], ["VL-036 / Selvar II / Isera II", "Sucessão política. Isera II sucede a Selvar II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2149–2182 da II Era / VE p. 55"], ["VL-037 / Isera II / Odravel I", "Sucessão política. Odravel I sucede a Isera II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2182–2216 da II Era / VE p. 55"], ["VL-038 / Odravel I / Vaela II", "Sucessão política. Vaela II sucede a Odravel I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2216–2253 da II Era / VE p. 55"], ["VL-039 / Vaela II / Teren II", "Sucessão política. Teren II sucede a Vaela II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2253–2294 da II Era / VE p. 55"], ["VL-040 / Teren II / Odravel II", "Sucessão política. Odravel II sucede a Teren II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2294–2330 da II Era / VE p. 55"], ["VL-041 / Odravel II / Selvar III", "Sucessão política. Selvar III sucede a Odravel II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2330–2361 da II Era / VE p. 56"], ["VL-042 / Selvar III / Odravel III", "Sucessão política. Odravel III sucede a Selvar III no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2361–2394 da II Era / VE p. 56"], ["VL-043 / Odravel III / Odravel IV", "Sucessão política. Odravel IV sucede a Odravel III no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco.", "2394–2418 da II Era / VE p. 56"], ["VL-044 / Teren I Endorin / Isera I", "Parentesco. Isera é filha de Teren I, que negociou seu casamento com um membro da casa Veyr.", "II Era / VE p. 19"], ["VL-045 / Odravel IV / Maeressa Endorin", "Parentesco. Maeressa Endorin é sobrinha de Odravel IV; reivindica a continuidade da casa após a morte dele.", "Crise de 2418 / VE p. 41"], ["VL-046 / Maeressa Endorin / Aldren Veyr", "Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto.", "2418–2431 da II Era / VE p. 41"], ["VL-047 / Maeressa Endorin / Soren Talv", "Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto.", "2418–2431 da II Era / VE p. 41"], ["VL-048 / Aldren Veyr / Soren Talv", "Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto.", "2418–2431 da II Era / VE p. 41"], ["VL-049 / Vaela Endorin / Dorrik Venn", "Aliança e negociação. Dorrik organiza escoltas e postos; sua aliança com Vaela não representa submissão de Dorgamar.", "Formação e consolidação imperial / VE p. 11"], ["VL-050 / Vaela Endorin / Rughan das Duas Margens", "Aliança e negociação. Rughan negocia contribuições comunitárias, mas rompe com Vaela após a repressão de Bar-Terval, em 1904.", "Formação e consolidação imperial / VE p. 15"], ["VL-051 / Vaela Endorin / Maressa de Merovél", "Aliança e negociação. Maressa organiza abastecimento, contratos e mediação; permanece junto à corte e obtém socorro a deslocados.", "Formação e consolidação imperial / VE p. 11"], ["VL-052 / Celandra Vey / Rovald Vey", "Disputa política. Disputam a administração de uma propriedade em Nobilith. Rovald é primo do marido falecido de Celandra; não se afirma parentesco entre ela e Rovald.", "2258–2274 da II Era / VE p. 33"], ["VL-053 / Celandra Vey / Ossa Merev", "Propriedade e obrigações. Ossa conserva prova de alívio de jornadas. Celandra preserva a administração, mas não torna permanente a cobrança suspensa.", "Litígio de 2258–2274 / VE p. 33"], ["VL-054 / Aren Voss / Leva Senn", "Atuação judicial. Aren recusa condenar Leva por uma possibilidade futura, no processo da Controvérsia do Espelho.", "2101 da II Era / VE p. 27"], ["VL-055 / Tessia Orven / Ilven Tor", "Relação institucional. Ilven, secretário da Mesa dos Instrumentos Reservados, contesta a ausência de cópia imperial dos estudos de Tessia.", "Correspondência de 2093 / VE p. 27"], ["VL-056 / Ilyra Tessan / Orel Veyr", "Pesquisa e financiamento. Ilyra distingue vestígios de previsão; Orel reorganiza os resumos e transforma incerteza técnica em promessa de entrega.", "Segundo Amanhecer / VE p. 39"], ["VL-057 / Mira Tovel / Aven Doss", "Conflito trabalhista. Mira preserva livros de jornada; Aven comanda a repressão da revolta de Sarn e atribui destruição de cargas aos insurgentes.", "2337–2339 da II Era / VE p. 35"], ["VL-058 / Sora Hald / Halven Reth", "Negociação política. Discutem cobrança sobre rebanhos e garantias das receitas do norte.", "2376–2388 da II Era / VE p. 37"], ["VL-059 / Rovan Sel / Aldren Veyr", "Acordo militar. Rovan abre a Porta de Cal às tropas de Aldren após obter salvo-conduto para parentes.", "2421 da II Era / VE p. 42"], ["VL-060 / Vaeliss Sareth / Calven III", "Acordo institucional. O Acordo das Lâmpadas reconhece o novo governo e garante a permanência do Grande Pombo em Samarith.", "2429 da II Era / VE p. 45"], ["VL-061 / Vaeliss Sareth / Nerissa Sareth", "Sucessão política. Nerissa sucede Vaeliss em Quinder. O uso do sobrenome não basta para fixar parentesco de primeiro grau.", "Primeiras décadas da III Era / VE p. 49"], ["VL-062 / Enna Vossel / Maela Torr", "Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação.", "2431 da II Era / VE p. 47"], ["VL-063 / Enna Vossel / Dorven Keld", "Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação.", "2431 da II Era / VE p. 47"], ["VL-064 / Maela Torr / Dorven Keld", "Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação.", "2431 da II Era / VE p. 47"], ["VL-065 / Iria Veldar / Teren Vassel", "Referência intelectual. Iria lê Vassel. Não o conheceu: ele morreu em 676, antes de seu nascimento em 704.", "Obra de Iria publicada em 784 da III Era / VE p. 5"]]}

## 33. Implantação, cobertura e manutenção da base



A base de trabalho desta rodada é a wikia 0.24, commit 475de5ab6e35f6f6523cb9c75c31485c56d47693. A edição 0.25 acrescenta páginas de cronologia e vínculos, referências clicáveis para os PDFs e relações nas fichas. A implementação mantém 351 verbetes e os materiais anteriores. A disponibilização da atualização deve ser verificada pela publicação do site.

{"type": "table", "heads": ["Área", "Condição e limite"], "rows": [["Cronologia", "148 marcos selecionados; datas agrupadas preservam seus segmentos."], ["Vínculos", "65 relações confirmadas; inclui o primeiro encontro dos seis, separado de amizade e parentesco."], ["Identidades", "Nomes sem artigo próprio continuam consultáveis na rede, sem criar biografias ou retratos por preenchimento automático."], ["Referências", "HG do índice é o arquivo de 148 páginas efetivamente incluído na wikia; não é a antiga identificação de HG preservada nos capítulos de auditoria."], ["Fontes anteriores", "As auditorias e estados de implantação das edições anteriores são preservados como histórico. Não significam que a wikia continua naquelas versões."], ["Pendências", "Continuam abertas as questões RC-VEA da edição 2.4, a cadeia genealógica integral e datas pessoais não especificadas."], ["Visuais", "A interpretação artística não modifica o estado documental de uma informação."]], "widths": [0.24, 0.76]}

Fila de aprofundamento

Ampliar gradualmente a cobertura de vínculos com fontes verificadas, revisar referências a cada edição e depois desenvolver geografia histórica. Não converter a ausência de um vínculo no índice em prova de ausência da relação. Nenhuma nova guerra, sucessão ou parentesco é decretado nesta rodada.

## 34. Governança atual e consolidação da wikia



O Registro Geral é a referência viva e normativa. Novas informações e decisões entram no Registro e são refletidas na wikia. Os PDFs anteriores conservam sua edição histórica; sua atualização será deliberada quando houver motivo para uma nova edição.



O autor autorizou a criação de acontecimentos, personagens e lugares sobre a base existente. Este recorte amplia a criação do mundo e a história de sua interpretação. Tradições são registradas com sua perspectiva; datas novas de estudiosos pertencem à história da I Era.



A consolidação incorpora a base da wikia 0.30, com seus 536 artigos, 168 marcos e 65 vínculos, incluindo engenharia dos vórtics, navegação entre menções e desenvolvimentos posteriores à edição 2.5. O retrato dessa base acompanha o arquivo editável. Estados de implantação descritos em capítulos anteriores são históricos.

## 35. Criação do mundo: definições vigentes

Leitura de continuidade

Aun integra a tradição da Consciência Una. Os três planos, os seis caminhos da mana e seus limites preservam a base da História Geral. Os relatos primordiais não recebem anos; 2874 e 2896 da I Era são novas datas autorais de história intelectual.

### RC-CM01 — A criação de Virtude

As tradições de origem descrevem a diferenciação da consciência, a formação dos planos e a circulação da mana. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM02 — Aun

Nome dado à consciência primordial na tradição da Consciência Una. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM03 — Noérion

O Mar das Formas: plano de pensamentos, afetos e possibilidades, com ritmos próprios de existência. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM04 — Eomundus

O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM05 — Virtude — Mundo do Devir

O plano material, onde ações se encadeiam e as vidas particulares enfrentam consequências duradouras. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM06 — Adunevar

Consciências de Noérion associadas a afinidades fundamentais e reconhecidas de maneiras distintas pelos cultos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM07 — Mana

Fluxo entre os três planos, trabalhado pelas práticas mágicas por meio de seis caminhos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM08 — Descompassos

Irregularidades no contato entre os planos que alteram experiência, passagem e sucessão dos acontecimentos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM09 — Mnêmides

Presenças de Noérion que conservam experiências sem lhes atribuir necessariamente um proprietário. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM10 — Anônimos

Presenças de Noérion com dificuldade para manter identidade, capazes de reproduzir vozes e rostos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM11 — Velários

Presenças de Eomundus que assumem formas ligadas à imaginação de quem as encontra. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM12 — Ishrael

Designação velária associada a transformações de vida em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM13 — Oruven

Designação velária associada a passagens improváveis em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM14 — Veyr, o Cortês

Designação velária associada a hospitalidade e obrigação em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM15 — Primeira Distância

Relato da Consciência Una sobre a diferenciação que torna possível encontrar o outro. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM16 — Confluência das Três Margens

Tradição que apresenta a circulação da mana pelo encontro entre os modos de existência dos três planos. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM17 — Contenda do Primeiro Nome

Tradição de Noérion sobre memória, identidade e os limites de usar uma experiência alheia. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM18 — Enseada das Promessas

Lugar de Eomundus cujas rotas de acesso e retorno respondem a compromissos reconhecidos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM19 — Patamar dos Ecos

Limiar de Eomundus em que vozes e gestos preservados despertam reconhecimento nos visitantes. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM20 — Talena Ors

Estudiosa Eldenari da I Era, compiladora dos Cadernos de Permanência e colaboradora de Edris Vaun. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM21 — Edris Vaun

Artífice Eldenari da I Era que conduziu o Ensaio da Pedra Velada em colaboração com Talena Ors. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM22 — Doutrina do Tear

Tradição de origem que descreve a realidade pelo entrelaçamento de experiências e vínculos. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM23 — Cadernos de Permanência

Compilação organizada por Talena Ors em 2874 da I Era sobre observação, transmissão e interpretação. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM24 — Ensaio da Pedra Velada

Investigação de Edris Vaun, registrada com Talena Ors em 2896 da I Era, sobre a permanência material. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

## 36. Dossiês da criação e tradições



A criação de Virtude



As tradições de origem descrevem a diferenciação da consciência, a formação dos planos e a circulação da mana.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Uma realidade que ganha diferenças. A doutrina da Consciência Una associa a origem a Aun. A Primeira Distância nomeia o momento em que conhecer passa a envolver uma posição e um limite: algo pode ser encontrado, desejado ou resistir. A existência concreta dos habitantes de Virtude conserva seu valor e suas consequências dentro dessa interpretação.



Os três planos. Noérion, o Mar das Formas, abriga possibilidades e afinidades anteriores à estabilidade dos corpos. Eomundus, o Entrelaço, dá contorno e duração às identidades. Virtude, o Mundo do Devir, reúne matéria, sucessão causal e vidas particulares. A Confluência das Três Margens apresenta o contato entre esses modos de existência como condição da circulação da mana.



Relatos e investigação. A Contenda do Primeiro Nome trata da posse da lembrança e da responsabilidade de reconhecer o outro. A Doutrina do Tear descreve a criação por fios entrelaçados e recebe leituras diferentes da Consciência Una. Na I Era, Talena Ors e Edris Vaun estudaram os relatos e a permanência material. Seus trabalhos pertencem à história dos intérpretes; os episódios primordiais permanecem anteriores à contagem das eras.



Aun



Nome dado à consciência primordial na tradição da Consciência Una.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



A consciência anterior às formas. Aun designa a origem comum da experiência nas versões da Consciência Una. Seu nome funciona como aproximação de algo anterior a estrelas, corpos e divindades particulares. Os narradores associam essa condição à possibilidade de toda relação, sem lhe atribuir uma residência no mapa ou uma genealogia de soberanos.



A Primeira Distância. A diferenciação permite que uma perspectiva encontre outra. A Primeira Distância conserva essa ideia por meio de imagens de abertura, intervalo e escuta. Aun permanece ligado à origem comum, enquanto Noérion, Eomundus e Virtude desenvolvem condições próprias de existência.



Leituras entre os habitantes. A Doutrina do Tear dá maior peso ao entrelaçamento de experiências. Talena Ors registrou diferenças entre fórmulas de origem e usos cotidianos das mesmas palavras. O reconhecimento da tradição de Aun integra o cenário; a interpretação de todas as culturas como um culto uniforme reduziria a diversidade de seus relatos.



Noérion



O Mar das Formas: plano de pensamentos, afetos e possibilidades, com ritmos próprios de existência.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Formas e afinidades. Em Noérion, pensamentos e afetos podem adquirir presença antes de dependerem de um corpo estável. As descrições do Mar das Formas recorrem a profundidades, correntes e constelações que se recombinam. Essas imagens expressam relações entre possibilidades; sua leitura como um oceano material perde parte de seu sentido.



Habitantes e memória. Os Adunevar mantêm afinidades fundamentais, como memória, crescimento ou conflito. As Mnêmides preservam experiências e os Anônimos encontram dificuldade para sustentar uma identidade. A Contenda do Primeiro Nome aproxima esses dois últimos modos de existência em um relato sobre lembrança e reconhecimento.



Tempo e contato. A sucessão universal de acontecimentos própria de Virtude não rege Noérion. Seus encontros são narrados por relações e transformações. A mana permite contatos entre os planos; lembranças recebidas por um visitante exigem interpretação, porque a experiência de outra vida pode ser sentida como íntima sem ter pertencido a ele.



Eomundus



O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



O Entrelaço. Eomundus aproxima possibilidades e vidas delimitadas. Seus caminhos respondem a expectativas, lembranças e vínculos, de modo que duas viagens pelo mesmo arco podem levar a encontros diferentes. Orientar-se envolve compreender relações de acesso, além de reconhecer formas da paisagem.



Povos e presenças. Os Aelthir, ancestrais dos elfos, os Namar que acompanham consciências após a morte e os Velários pertencem às descrições do Entrelaço. Ishrael, Oruven e Veyr, o Cortês, aparecem em narrativas de transformação, passagem e hospitalidade. A identidade por trás desses nomes varia entre os relatos.



Lugares e compromissos. A Enseada das Promessas e o Patamar dos Ecos exemplificam lugares cuja travessia depende da história do viajante. Seus mapas registram condições de encontro e retorno. Um compromisso reconhecido por outros pode orientar o caminho por mais tempo que uma intenção passageira, e a entrada em Eomundus nunca equivale a controle completo sobre sua paisagem.



Virtude — Mundo do Devir



O plano material, onde ações se encadeiam e as vidas particulares enfrentam consequências duradouras.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Matéria e sucessão. Virtude abriga corpos, paisagens e sociedades submetidos a uma sucessão causal. Uma ponte construída pode permanecer para quem chega depois; uma colheita consumida exige novo trabalho. A estabilidade dá às escolhas um peso que distingue o Mundo do Devir das transformações descritas em Noérion.



Vida e autonomia. A origem comum proposta pela Consciência Una convive com existências particulares. Pessoas possuem lembranças limitadas, compromissos e desejos próprios. A história das eras acompanha essas vidas e as instituições que constroem, enquanto a criação dos planos pertence a um horizonte anterior à sua contagem.



Fronteiras permeáveis. A mana atravessa relações entre os planos e sustenta práticas mágicas. Os Descompassos revelam que suas fronteiras podem apresentar irregularidades. O Ensaio da Pedra Velada investigou a permanência de objetos em condições controladas no plano material, contribuindo para separar observação, relato de viagem e interpretação cosmológica.



Adunevar



Consciências de Noérion associadas a afinidades fundamentais e reconhecidas de maneiras distintas pelos cultos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Natureza e domínio. Os Adunevar abrangem formas de consciência cuja existência se liga a afinidades como vínculo, ordem, crescimento, memória, transformação e conflito. Sua potência segue a natureza de cada domínio. Os cultos traduzem encontros e efeitos em nomes, histórias e práticas, produzindo reconhecimentos diferentes entre sociedades.



Presença no mundo. Uma intervenção em Virtude depende de âncoras: corpos, santuários, vínculos ou práticas que sustentam o contato. O instrumento e a afinidade da presença influenciam aquilo que ela consegue realizar. Uma âncora submetida a poder concentrado pode se desgastar, ferir um intermediário ou favorecer Descompassos.



Cultos e arautos. Os arautos tornam a relação com uma presença divina especialmente concreta, mas seu reconhecimento também envolve testemunho e disputa. Divergências entre afinidades produzem tensões sem estabelecer uma corte superior obedecida por todos. O auxílio cotidiano dos templos continua ligado a pessoas, alimentos, abrigo e organização.



Mana



Fluxo entre os três planos, trabalhado pelas práticas mágicas por meio de seis caminhos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Circulação entre planos. A mana expressa a permeabilidade entre Noérion, Eomundus e Virtude. A Confluência das Três Margens dá forma narrativa a essa circulação: diferenças permanecem, mas relações atravessam seus limites. O fluxo assume efeitos concretos conforme o meio, a técnica e as condições do contato.



Seis caminhos. Fogo, Água, Terra, Ar, Luz e Trevas organizam os caminhos da mana. Luz se associa a revelar e transmitir; Trevas a ocultar e proteger. O valor ético depende das escolhas de quem atua e de suas consequências. Espaço, Tempo e Mente descrevem condições de operação das práticas e se articulam aos caminhos.



Uso, limite e experiência. O praticante aprende a reconhecer resistência, consumo e risco. A manipulação encontra aplicações em ofícios, cura, investigação e engenhos, incluindo os vórtics. A mana participa da sustentação e do controle desses veículos; as descrições dos modelos distinguem chassi, estabilidade e comportamento na pista. Descompassos exigem atenção quando o contato entre planos se torna irregular.



Descompassos



Irregularidades no contato entre os planos que alteram experiência, passagem e sucessão dos acontecimentos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Sinais de uma fronteira irregular. Relatos de Descompassos incluem dias que parecem repetir-se, vozes de pessoas ainda não nascidas e viajantes que retornam sem envelhecer a comunidades já transformadas. A variedade exige registrar cada ocorrência em seu contexto. Um efeito reconhecível permite comparar testemunhos, mas não fornece sozinho a causa.



Causas e responsabilidade. A separação imperfeita entre os planos admite ocorrências espontâneas. Intervenções de Eomundus e desgaste de âncoras também podem contribuir. A presença de um Descompasso orienta a investigação sobre o contato e seus suportes; atribuir intenção depende de outras evidências.



Memória e cuidado. Talena Ors defendia separar a experiência de quem voltou, os registros preservados por quem ficou e os comentários posteriores. Essa distinção ajuda a compreender mudanças de calendário e perdas de convivência. O Patamar dos Ecos acrescenta outro problema: uma lembrança reconhecida pode emocionar profundamente sem constituir o retorno integral de uma pessoa.



Mnêmides



Presenças de Noérion que conservam experiências sem lhes atribuir necessariamente um proprietário.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Experiência preservada. As Mnêmides guardam experiências cuja continuidade não depende da identificação de um indivíduo. Nas descrições de Noérion, uma lembrança pode manter a textura de um gesto, o medo ou a alegria sem conservar o nome de quem viveu aquilo. Encontrá-la pode provocar reconhecimento e estranhamento ao mesmo tempo.



Encontros e interpretação. Um visitante do plano material pode receber uma impressão intensa como se tivesse vivido outra vida. A intimidade da sensação requer cuidado: a origem da lembrança e a história do visitante permanecem questões distintas. O Patamar dos Ecos aparece em narrativas de contato com vestígios semelhantes, sem estabelecer um arquivo universal de todas as consciências.



O Primeiro Nome. Na Contenda do Primeiro Nome, a preservação das Mnêmides entra em tensão com o uso de rostos e experiências pelos Anônimos. O relato interroga o que significa reconhecer alguém e quais obrigações surgem ao carregar sua lembrança. Cópias Eldenari empregaram essa história em discussões sobre testemunho e responsabilidade.



Anônimos



Presenças de Noérion com dificuldade para manter identidade, capazes de reproduzir vozes e rostos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Identidade instável. Os Anônimos encontram formas de se apresentar nos gestos, rostos e vozes com que entram em contato. Uma aparência tomada de outro pode durar apenas um encontro. A imitação exprime sua dificuldade de sustentar uma identidade própria e produz efeitos que eles nem sempre compreendem.



Reconhecimento e dano. Para habitantes de Virtude, uma voz íntima desperta expectativas e obrigações. Reproduzi-la pode perturbar luto, confiança e memória. O contato exige discernir continuidade pessoal e semelhança. As consequências para quem reconhece o rosto emprestado compõem parte importante dos relatos do Mar das Formas.



A Contenda do Primeiro Nome. A tradição coloca Anônimos e Mnêmides diante da mesma experiência preservada. Enquanto uns procuram nela um modo de existir, outras a conservam sem distribuí-la como propriedade. A narrativa desenvolve limites e reconhecimento mútuo, oferecendo às culturas uma linguagem para discutir o empréstimo de nomes e a responsabilidade por lembranças.



Velários



Presenças de Eomundus que assumem formas ligadas à imaginação de quem as encontra.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Formas de encontro. Os Velários entram nas narrativas por aparências parcialmente moldadas pelas expectativas do observador. Uma mesma figura pode ser descrita de maneiras diferentes em dois relatos. A forma facilita o encontro, mas também expressa aquilo que o visitante estava preparado para reconhecer.



Vontades e diferenças. Eomundus abriga presenças com comportamentos variados. Ishrael se associa à transformação de vidas; Oruven, a passagens improváveis; Veyr, o Cortês, à hospitalidade e a obrigações. Esses nomes podem designar indivíduos, famílias de manifestações ou papéis conservados pela tradição. A diversidade de relatos permanece parte de sua caracterização.



Hospitalidade e acesso. Na Enseada das Promessas, histórias de encontro com Velários enfatizam a relação entre uma oferta, a aceitação e o retorno. O compromisso reconhecido pode se tornar condição de passagem. Viajantes atentos procuram compreender os termos do encontro antes de tratar uma dádiva como posse sem vínculo.



Ishrael



Designação velária associada a transformações de vida em Eomundus.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"], ["Epíteto", "Portadora de Rostos"], ["Identidade", "Indivíduo, conjunto de manifestações ou papel: questão aberta"]], "widths": [1, 3]}



Encontros e tradição. Os relatos de Ishrael descrevem encontros após os quais um visitante modifica relações, ofício ou compreensão de si. Rostos distintos acompanham a mesma designação e reforçam a importância de quem observa. O alcance da transformação emerge das escolhas seguintes, das lembranças que persistem e da dificuldade de contar o encontro aos demais.



Nome e reconhecimento. A tradição de Ishrael preserva o epíteto Portadora de Rostos. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Ishrael e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Oruven



Designação velária associada a passagens improváveis em Eomundus.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"], ["Epíteto", "Pastor das Luzes"], ["Identidade", "Indivíduo, conjunto de manifestações ou papel: questão aberta"]], "widths": [1, 3]}



Encontros e tradição. Luzes guiando um viajante a uma passagem impossível constituem a imagem recorrente de Oruven. Segui-las envolve reconhecer uma rota e aceitar suas condições. Os relatos conservam diferenças sobre a forma do guia e sobre a duração da travessia; chegar ao destino não garante que o tempo da partida continue intacto.



Nome e reconhecimento. A tradição de Oruven preserva o epíteto Pastor das Luzes. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Oruven e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Veyr, o Cortês



Designação velária associada a hospitalidade e obrigação em Eomundus.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"], ["Epíteto", "o Cortês"], ["Identidade", "Indivíduo, conjunto de manifestações ou papel: questão aberta"]], "widths": [1, 3]}



Encontros e tradição. Veyr recebe viajantes, oferece abrigo e apresenta dádivas cujas obrigações se tornam claras na continuidade do encontro. As histórias valorizam a atenção ao que foi aceito, prometido e lembrado. A cortesia pode sustentar proteção duradoura e também prender o hóspede a compromissos mais amplos do que imaginava.



Nome e reconhecimento. A tradição de Veyr, o Cortês preserva o epíteto o Cortês. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Veyr, o Cortês e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Primeira Distância



Relato da Consciência Una sobre a diferenciação que torna possível encontrar o outro.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



O intervalo primordial. Na tradição da Consciência Una, a Primeira Distância é a diferenciação da experiência antes da estabilidade dos mundos. Conhecer passa a envolver posição, alcance e resistência. O relato oferece imagens de escuta e intervalo para expressar a possibilidade de algo existir diante de outra perspectiva.



Consequências da diferenciação. Aun permanece o nome da origem comum nessa doutrina. A distância permite afinidades e limites que serão descritos por meio de Noérion, Eomundus e Virtude. A diferença dá sentido a desejo, reconhecimento e responsabilidade: aquilo que uma consciência encontra possui condições próprias de existência.



Transmissão e tempo. A Primeira Distância pertence a uma ordem explicativa anterior à contagem das eras. Os narradores podem situá-la antes da Confluência das Três Margens dentro de sua versão, mas essa sequência não fornece anos decorridos. Os Cadernos de Permanência ajudam a compreender a separação entre o tempo de um relato e uma data histórica.



Confluência das Três Margens



Tradição que apresenta a circulação da mana pelo encontro entre os modos de existência dos três planos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



Três condições de existência. O relato descreve Noérion como possibilidade, Eomundus como contorno e vínculo, e Virtude como matéria em sucessão. Cada margem representa condições de existência reconhecíveis, e a confluência conserva a diferença entre elas. A imagem oferece uma linguagem para explicar contatos sem reduzir todos os planos à mesma paisagem.



A circulação. A mana atravessa as relações entre as margens. Na tradição, esse fluxo torna possíveis manifestações, práticas e encontros que relacionam pensamento, identidade e matéria. Seus seis caminhos organizam efeitos distintos, enquanto as condições de Espaço, Tempo e Mente influenciam a operação.



Limite e permanência. A circulação convive com fronteiras e resistências. Os Descompassos expressam contatos irregulares, e o trabalho de uma âncora pode exigir cuidado. A confluência é transmitida como episódio primordial, com ordem interna variável entre versões e sem data convertida em ano da I Era.



Contenda do Primeiro Nome



Tradição de Noérion sobre memória, identidade e os limites de usar uma experiência alheia.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



O conflito das lembranças. Na versão adotada nesta edição, Mnêmides conservam uma experiência que Anônimos passam a usar para obter rosto e voz. A lembrança ganha diversas aparências, e aqueles que a encontram reconhecem pessoas diferentes. A contenda surge da dificuldade de distinguir o encontro com alguém do encontro com algo preservado sobre essa pessoa.



O reconhecimento do limite. A resolução transmitida pelo relato se apoia no reconhecimento da origem emprestada de uma forma. As Mnêmides continuam a preservar; os Anônimos aprendem que apresentar uma voz pode criar obrigações diante de quem a escuta. O Primeiro Nome simboliza a responsabilidade de situar a própria presença perante outra.



Leituras posteriores. Copistas Eldenari empregaram a contenda em discussões sobre testemunho, lembrança e autoria. Talena Ors registrou seu valor como tradição interpretativa. O episódio integra a memória cultural de Noérion, e suas versões permitem examinar os efeitos materiais de reconhecer uma voz íntima, inclusive nos relatos do Patamar dos Ecos.



Enseada das Promessas



Lugar de Eomundus cujas rotas de acesso e retorno respondem a compromissos reconhecidos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"], ["Plano", "Eomundus"], ["Tipo", "Enseada de acesso relacional"]], "widths": [1, 3]}



Paisagem e orientação. A Enseada das Promessas é descrita como água calma entre margens que parecem próximas e caminhos que mudam ao serem retomados. Embarcadouros, passagens rasas e reflexos servem como pontos de reconhecimento. A orientação depende da relação entre o visitante, o destino e compromissos ainda ativos.



Promessas e passagem. Um voto testemunhado pode conservar uma rota por mais tempo que uma intenção de ocasião. Cumprimento, mudança de condições e reconhecimento da outra parte afetam o retorno. A enseada torna visível uma característica de Eomundus: relações possuem peso geográfico e podem sobreviver à lembrança imperfeita de um viajante.



Hospitalidade e relatos. Histórias de Veyr, o Cortês, associam abrigo e dádivas à responsabilidade de compreender aquilo que se aceita. Outros encontros velários variam conforme o visitante. Os registros da enseada descrevem condições de acesso, preservando o lugar fora das fronteiras materiais dos reinos e sem um ponto fixo no atlas de 788.



Patamar dos Ecos



Limiar de Eomundus em que vozes e gestos preservados despertam reconhecimento nos visitantes.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"], ["Plano", "Eomundus"], ["Tipo", "Limiar de memória e reconhecimento"]], "widths": [1, 3]}



O patamar junto à água. Relatos apresentam degraus gastos, água baixa e galerias cuja extensão muda com a aproximação. Sons voltam em direções diferentes, às vezes com a inflexão de uma voz reconhecida. O lugar recebe o nome de Patamar dos Ecos pela experiência de reencontrar fragmentos que parecem responder ao visitante.



Vestígios e luto. Uma frase, um gesto ou um afeto pode ser reconhecido com grande intensidade. O vestígio conserva uma experiência limitada, e sua presença não equivale ao retorno integral de quem morreu. Narrativas sobre Mnêmides e os acompanhantes Namar oferecem interpretações diferentes para esses encontros, sem resolver todos os testemunhos por uma causa única.



Atravessar e recordar. O caminho pode mudar quando o visitante tenta repetir exatamente um encontro anterior. Os registros valorizam aquilo que foi ouvido e as condições da passagem. Talena Ors incluiu testemunhos de ecos em sua reflexão sobre memória, distinguindo a experiência sentida da conclusão de que uma consciência completa teria sido recuperada.



Talena Ors



Estudiosa Eldenari da I Era, compiladora dos Cadernos de Permanência e colaboradora de Edris Vaun.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atividade", "Estudiosa e compiladora"], ["Marco documentado", "Cadernos de Permanência, 2874 da I Era"], ["Colaboração", "Edris Vaun"], ["Vestimenta", "Linho ocre com remendos azul-escuros"], ["Traço distintivo", "Pálpebra direita ligeiramente caída"]], "widths": [1, 3]}



Trabalho e contexto. Talena Ors reuniu relatos cosmológicos e registros de observação na I Era. Seus Cadernos de Permanência foram organizados em 2874 e circularam por cópias em Samarith. Ela separava a experiência relatada, a cadeia de transmissão e o comentário posterior, buscando conservar diferenças entre testemunhos.



Aparência e hábitos. Possuía rosto amplo, cabelos castanhos muito encaracolados cortados na nuca e uma leve queda da pálpebra direita. Tinta costumava marcar seu polegar. Preferia linho ocre com remendos azul-escuros e levava cadernos de folhas de tamanhos diferentes. Sua curiosidade vinha acompanhada de perguntas diretas sobre quem havia presenciado cada afirmação.



Colaboração e legado. Sua colaboração com Edris Vaun relacionou o estudo dos relatos à observação de objetos. Em 2896, acompanhou o registro do Ensaio da Pedra Velada. As distinções de seus cadernos permitem ler a Primeira Distância, a Contenda do Primeiro Nome e a Doutrina do Tear como tradições com contexto, preservando a riqueza de suas versões.



Edris Vaun



Artífice Eldenari da I Era que conduziu o Ensaio da Pedra Velada em colaboração com Talena Ors.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atividade", "Artífice e investigador"], ["Marco documentado", "Ensaio da Pedra Velada, 2896 da I Era"], ["Colaboração", "Talena Ors"], ["Vestimenta", "Linho cinzento e avental de couro"], ["Traço distintivo", "Dois dedos rígidos na mão esquerda"]], "widths": [1, 3]}



Ofício e investigação. Edris Vaun trabalhava com medidas, recipientes e pequenas peças de oficina. Sua colaboração com Talena Ors aproximou observação material e leitura crítica dos relatos. A repetição de uma operação interessava-lhe tanto quanto seu resultado: alterações de recipiente, observador e registro precisavam ser anotadas.



Aparência e maneira de trabalhar. Tinha rosto estreito, calvície no alto da cabeça, cabelos escuros nas laterais e barba curta com fios acobreados. Dois dedos da mão esquerda apresentavam rigidez. Usava linho cinzento e avental de couro. Paciente e pouco expansivo, organizava ferramentas pela sequência de uso e preferia demonstrar uma medida a defendê-la por autoridade.



A Pedra Velada. Em 2896 da I Era conduziu comparações de peso e permanência com objetos vedados, alternando observadores e registros. Talena Ors ajudou a documentar o trabalho. O ensaio sustentou conclusões limitadas às condições observadas no plano material, tornando-se uma referência para discutir a diferença entre percepção, permanência e explicação cosmológica.



Doutrina do Tear



Tradição de origem que descreve a realidade pelo entrelaçamento de experiências e vínculos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Tradição cosmológica"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



O mundo como trama. A Doutrina do Tear emprega fios, nós e intervalos para explicar a formação de uma realidade compartilhada. A continuidade de um fio depende de encontros com outros, e o desenho emerge dessas relações. Diferentes narradores dão maior peso à primeira trama ou à atividade contínua de tecer.



Relação com a Consciência Una. Os relatos dialogam com a ideia de uma origem comum e também deslocam a atenção para a pluralidade de vínculos. Aun recebe centralidade na Consciência Una; a Doutrina do Tear costuma enfatizar a composição da experiência. As duas linguagens podem se aproximar em uma comunidade e gerar discussão em outra.



Transmissão Eldenari. Talena Ors reuniu versões orais entre os materiais estudados para os Cadernos de Permanência. Ela observava que uma mesma imagem podia servir à explicação da origem, à memória de um grupo e à transmissão de obrigações. Sua compilação tornou essas diferenças parte do estudo histórico das tradições na I Era.



Cadernos de Permanência



Compilação organizada por Talena Ors em 2874 da I Era sobre observação, transmissão e interpretação.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "2874 da I Era"], ["Autoria", "Talena Ors"]], "widths": [1, 3]}



Organização em 2874. Talena Ors reuniu os Cadernos de Permanência em 2874 da I Era. O conjunto tratava de relatos cosmológicos, experiências de passagem e observações materiais. Cópias circularam em Samarith, acompanhadas de comentários que nem sempre mantinham a separação proposta pela compiladora.



Três camadas de um testemunho. A compilação distinguia o que alguém dizia ter experimentado, como esse relato havia chegado ao copista e qual explicação lhe fora acrescentada. Essa organização permitia conservar versões divergentes sem fundi-las em uma única voz. A Primeira Distância e a Doutrina do Tear integravam a discussão sobre modelos de origem.



Continuidade de uma pesquisa. O trabalho de Talena Ors com Edris Vaun aproximou os cadernos do registro de operações repetíveis. O Ensaio da Pedra Velada, em 2896, aprofundou esse interesse. Os cadernos pertencem à história intelectual Eldenari; seu conteúdo é conhecido no universo por cópias e referências, com lacunas de transmissão.



Ensaio da Pedra Velada



Investigação de Edris Vaun, registrada com Talena Ors em 2896 da I Era, sobre a permanência material.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "2896 da I Era"], ["Responsável", "Edris Vaun"]], "widths": [1, 3]}



Procedimento e registro. O ensaio comparou objetos pesados antes e depois de permanecerem em recipientes vedados. Edris Vaun alternava observadores, recipientes e a ordem das verificações. Talena Ors registrava condições, diferenças e limites daquilo que os participantes conseguiam afirmar a partir das operações.



Resultados e alcance. As comparações sustentavam a permanência dos objetos nas condições observadas, mesmo durante intervalos sem observação direta. O resultado fortaleceu uma linguagem de medida e repetição no estudo de Virtude. A conclusão conservava seu alcance material: a observação realizada não esgotava as condições de Noérion ou Eomundus.



Uma discussão sobre realidade. O trabalho tornou concreta uma questão presente nos Cadernos de Permanência: distinguir o que se percebe, o que se registra e o que se explica. Para leitores da Consciência Una, a estabilidade material podia coexistir com uma origem comum da experiência. A divergência entre interpretações continuou a alimentar debates Eldenari.

## 37. Implantação do recorte e referências



A wikia 0.31 reúne 560 artigos, 173 marcos e 66 vínculos. O recorte acrescenta 24 artigos, nove ilustrações, três tradições primordiais sem data histórica e dois marcos da I Era. Cinco artigos existentes recebem complementos. Os IDs RC-CM01–24 apontam para as definições deste Registro.



As imagens são interpretações visuais. Paisagens de Eomundus não recebem coordenadas no mapa material. Ishrael, Oruven e Veyr conservam em aberto a natureza de suas identidades; a figura em uma ilustração contextual não determina aparência única.

## 38. Primeira Era: definições e limites vigentes



Este recorte consolida dragões, Eldenari, chegada dos elfos altos, instituições, artefatos, conflitos e Grande Punição. As adições incluem Guerra dos Reparos (6262–6266), Retirada dos Armazéns (6337), Pacto das Barcas (6338), Veska Tor e Naeris Ul. As novas datas são definições autorais desta edição, não citações acrescentadas aos PDFs antigos.

### RC-IE00 — Limites e precedência do recorte

Mantêm-se a cronologia aproximada da I Era, as sete campanhas, o intervalo de vinte e três dias, as funções limitadas das peças e a existência não confirmada dos Thul Verenari. A Grande Punição não recebe causa única demonstrada. A ampliação cria datas e práticas explicitadas nos novos dossiês; não altera os desfechos conservados nas fontes.

Base: Decisão autoral de ampliar a I Era; História Geral de Virtude pp. 13–24; Registro 2.6.

Aplicação: Wikia e futuras obras; PDFs anteriores conservam sua edição.

### RC-IE01 — Dragões

Primeiros habitantes corpóreos duradouros lembrados pelas tradições de Virtude, de grande longevidade e vínculos profundos com a mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE01; História Geral de Virtude · pp. 13–14, 21–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE02 — Eldenari

Povo de vidas seculares, associado às primeiras cidades dos vales do Taoju e do Asmarith e às grandes instituições de pesquisa da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE02; História Geral de Virtude · pp. 14–16, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE03 — Aelthir e a chegada dos elfos altos

Comunidades de Eomundus cuja travessia para Virtude, conduzida por Arieth Ilvar, deu origem aos elfos altos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE03; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE04 — Vaelthar

Ouvinte das Estrelas na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE04; História Geral de Virtude · pp. 13, 18, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE05 — Khorvath

Ferreiro Vivo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE05; História Geral de Virtude · pp. 13–15, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE06 — Zhaurak

Coroa Rubra na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE06; História Geral de Virtude · pp. 13–14, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE07 — Varesh

Asa das Marés na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE07; História Geral de Virtude · pp. 13–14, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE08 — Arieth Ilvar

Regente da Travessia na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE08; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE09 — Caerion Thalas

Fundador da Ordem dos Magos na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE09; História Geral de Virtude · pp. 17–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE10 — Maeriel Sorn

Diplomata dos intercâmbios na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE10; História Geral de Virtude · pp. 17–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE11 — Avar Seneth

Especialista em tempo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE11; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE12 — Serath Namar

Pesquisadora da memória na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE12; História Geral de Virtude · pp. 17–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE13 — Saelith Vora

Sacerdotisa da Aliança da Brasa na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE13; História Geral de Virtude · pp. 15–16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE14 — Nimea Aral

Organizadora do Círculo das Testemunhas na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE14; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE15 — Teren Vos

Construtor dos instrumentos do Selo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE15; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE16 — Melian Or

Estudioso dos caminhos do espaço na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE16; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE17 — Eshara Vel

Preparadora da Gema na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE17; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE18 — Veska Tor

Barqueira de Elar-Tao na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE18

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE19 — Naeris Ul

Mensageira dos salvo-condutos na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE20 — Conclaves das Asas

Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE20; História Geral de Virtude · pp. 13, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE21 — Custódios da Esmeralda

Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE21; História Geral de Virtude · pp. 13, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE22 — Artífices da Brasa

Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE22; História Geral de Virtude · pp. 14–15, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE23 — Senhores do Zênite

Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE23; História Geral de Virtude · pp. 14–15, 18–21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE24 — Casa das Medidas

Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE24; História Geral de Virtude · pp. 16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE25 — Círculo das Testemunhas

Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE25; História Geral de Virtude · pp. 16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE26 — Primeiros Magos

Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE26; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE27 — Mesa das Portas

Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE27; História Geral de Virtude · pp. 17, 20–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE28 — Aliança da Brasa

Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE28; História Geral de Virtude · pp. 15–16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE29 — Selo do Tempo

Sistema Eldenari de três instrumentos e uma rede instalada para compatibilizar fluxos temporais presentes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE29; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE30 — Relógio de Avar

Instrumento que compara ritmos e delimita intervalos dentro do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE30; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE31 — Pergaminho das Concordâncias

Registro reativo à mana das condições de operação e interrupção do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE31; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE32 — Gema de Eshara

Instrumento preparado por Eshara Vel para vincular o Selo à rede material e distribuir mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE32; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE33 — Aerólito

Metal capaz de conservar padrões de mana, ensinado aos construtores Eldenari por Khorvath. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE33; História Geral de Virtude · pp. 15, 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE34 — Eshara, a lua esmeralda

Lua acompanhada pelos Custódios da Esmeralda e sede do refúgio dos dragões sobreviventes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE34; História Geral de Virtude · pp. 13, 18, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE35 — A Margem

Região de Eomundus sobrecarregada pelo desvio de experiências incompatíveis durante a operação do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE35; História Geral de Virtude · pp. 19–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE36 — O Inconcluso

Nome dado às respostas adaptativas identificadas na Margem durante a crise do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE36; História Geral de Virtude · pp. 19–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE37 — Leth Avar

Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE37; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE38 — Elar-Tao

Localidade fluvial Eldenari atingida pela repetição de uma estação de cheia. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE38; História Geral de Virtude · pp. 18

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE39 — Vel-Samar

Centro de arquivo cujo incêndio marcou a abertura da Guerra das Nove Vigílias. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE39; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE40 — Uldar

Cidade neutra cuja destruição levou Khorvath a romper com Zhaurak na quinta campanha. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE40; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE41 — Refúgio de Eshara

Abrigo de mana preparado pelos Custódios na lua esmeralda e alcançado pelos dragões após a ruptura. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE41; História Geral de Virtude · pp. 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE42 — Paralisação dos Nove Pátios

Trabalhadores interromperam serviços após a suspensão de pagamentos para financiar pesquisa. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE42; História Geral de Virtude · pp. 16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE43 — Guerra dos Reparos

Conflito entre cidades Eldenari pelo controle da manutenção dos canais e dos suportes de mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE43

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE44 — Retirada dos Armazéns de Elar-Tao

Evacuação que tornou pública a disputa por barcos entre casas de estudo e famílias atingidas pelos Descompassos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE44

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE45 — Pacto das Barcas

Acordo de Elar-Tao que incluiu tripulações nas decisões de transporte durante emergências. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE45

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE46 — Batalha das Pontes de Asmarith

Serath impediu uma inundação que atingiria famílias partidárias de Avar durante a segunda campanha. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE46; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE47 — Cinzas de Uldar

Destruição de uma cidade neutra que rompeu alianças entre dragões e sacerdotes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE47; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE48 — Os vinte e três dias de Xeo Taoju

Intervalo de ocupação e socorro entre a ruptura do Selo e a Grande Punição. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE48; História Geral de Virtude · pp. 22–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE49 — Guerra das Nove Vigílias

Sete campanhas nas quais a disputa pelo Selo desfez alianças entre cidades Eldenari, elfos altos e dragões. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE49; História Geral de Virtude · pp. 21–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE50 — Damar Esh

Sacerdote Eldenari que defendia a interpretação divina das aparições antigas. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE50; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE51 — Hared Sen

Príncipe que procurou apoiar seu governo de Xeo Taoju no prestígio de uma criança oracular. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE51; História Geral de Virtude · pp. 15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE52 — Doutrina dos Sinais Cruzados

Práticas de confronto de testemunhos destinadas a dificultar fraudes no reconhecimento de Arautos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE52; História Geral de Virtude · pp. 14–15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE53 — Pacto das Três Testemunhas

Acordo de observação entre Eldenari, dragões e elfos altos para autorizar o experimento do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE53; História Geral de Virtude · pp. 18–21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE54 — Incidente de Thar-Sen

Passagem de quarenta peregrinos que regressaram dezessete anos depois de viverem uma única noite. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE54; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE55 — Noite dos Dois Amanheceres

Descompasso observado por trabalhadores que passaram a discordar sobre os sete dias anteriores. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE55; História Geral de Virtude · pp. 15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

## 39. Primeira Era: dossiês de povos, pessoas, lugares e acontecimentos



Dragões



Primeiros habitantes corpóreos duradouros lembrados pelas tradições de Virtude, de grande longevidade e vínculos profundos com a mana.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Longevidade", "Sem morte por velhice; vulneráveis a ferimentos e esgotamento"], ["Reprodução", "Ovos entre os descendentes"], ["Horizonte tradicional", "c. 1 da I Era"]], "widths": [1, 3]}



Origem e duração. As tradições ligam a formação dos primeiros dragões a Azhravyr e Ithélion, em encontros dos caminhos da mana. O ano 1 da I Era é um horizonte convencional dessa memória. Os primeiros teriam se formado diretamente desses encontros; seus descendentes nasceram de ovos. Dragões não morrem de velhice, mas podem morrer por ferimentos, perda de vínculos com a mana e esgotamento de grandes encantamentos.



Paciência, torpor e responsabilidade. Séculos de existência permitem conhecimentos vastos e também criam desencontros com sociedades de vida mais breve. O torpor recupera forças, mas pode deixar lacunas e dificultar o reconhecimento de mudanças políticas. Uma promessa ainda recente para um dragão pode sustentar a vida de muitas gerações Eldenari. Os Conclaves das Asas procuravam arbitrar território, acesso à mana e cuidado dos ovos.



Tradições e dissidências. Os Custódios da Esmeralda, os Artífices da Brasa e os Senhores do Zênite desenvolveram orientações diferentes. Varesh preservou vínculos sem aderir permanentemente a nenhuma delas. A Guerra das Nove Vigílias atravessou essas divisões: Khorvath rompeu com Zhaurak, enquanto Vaelthar abandonou a neutralidade após sofrer um ataque.



Depois da ruptura. Vaelthar e Varesh conduziram sobreviventes ao refúgio de Eshara. O caminho consumiu os instrumentos capazes de mantê-lo, isolando o grupo. Ovos permaneceram em santuários de Virtude. As tradições posteriores de Nogard conservam o culto a figuras dracônicas, distinguindo a vida histórica de Khorvath e Varesh das interpretações religiosas de sua memória.



Eldenari



Povo de vidas seculares, associado às primeiras cidades dos vales do Taoju e do Asmarith e às grandes instituições de pesquisa da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Longevidade", "Vários séculos"], ["Primeiros assentamentos", "c. 2100 da I Era"], ["Centros históricos", "Vales do Taoju e Asmarith"], ["Depois da ruptura", "Mortes, deslocamentos e sobrevivências dispersas"]], "widths": [1, 3]}



Cidades e gerações. Vestígios situam assentamentos Eldenari por volta de 2100 da I Era. A consolidação urbana de Xeo Taoju é colocada em torno de 2550. Asterion e Nereth aparecem nas tradições de origem de um povo sensível à mana e dedicado a registrar experiências. Vidas de vários séculos permitiam pesquisas prolongadas, mas também concentravam autoridade em famílias e casas de estudo.



Trabalho e conhecimento. Calendários orientavam plantio, cobrança e armazenamento. Ilyra Seneth procurou tornar o céu compreensível; Oren Namar defendeu a permanência dos nomes dos mortos. Talena Ors e Edris Vaun distinguiram relato e observação. A manutenção dos centros dependia de barqueiros, carpinteiros, cuidadores e trabalhadores de oficina, cuja remuneração se tornou uma questão pública na Paralisação dos Nove Pátios.



Cidades em desacordo. A Casa das Medidas e os templos disputavam competências, enquanto alianças com dragões podiam trazer proteção, ensino ou tributo compulsório. A Guerra dos Reparos aprofundou conflitos pelo acesso à manutenção dos canais. Mais tarde, o Selo dividiu comunidades que temiam perder colheitas e outras que denunciavam o custo de sua estabilidade.



Ruptura e sobrevivência. A ligação de corpos e memórias aos instrumentos de pesquisa tornou os centros Eldenari particularmente vulneráveis à ruptura. Muitos morreram, outros foram arrastados à Margem e pequenos grupos sobreviveram longe das instalações. Seus descendentes se misturaram a outros povos. A perda de arquivos e comunidades explica a fragmentação posterior de sua história.



Aelthir e a chegada dos elfos altos



Comunidades de Eomundus cuja travessia para Virtude, conduzida por Arieth Ilvar, deu origem aos elfos altos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Origem", "Eomundus"], ["Travessia", "c. 5990 da I Era"], ["Transformação", "Corpos materiais; origem dos elfos altos"], ["Longevidade material", "Muitos séculos; raramente mais de um milênio"]], "widths": [1, 3]}



Leth Avar. Os Aelthir viviam em Eomundus, onde forma, memória e vínculo se relacionavam à paisagem. A região chamada Leth Avar perdeu estabilidade: pessoas esqueciam o próprio nome e cidades mudavam conforme os sonhos de seus habitantes. O problema atingia a possibilidade de conservar uma vida comum, e a travessia tornou-se uma decisão de sobrevivência.



As Sete Portas. Arieth Ilvar conduziu os refugiados durante a Travessia das Sete Portas, situada por volta de 5990. Ao aceitarem corpos materiais, perderam capacidades antigas e passaram a viver como elfos altos. Suas vidas alcançavam muitos séculos, raramente mais de um milênio. A chegada envolveu abrigo, alimento, reconhecimento de parentesco e adaptação às condições de Virtude.



Comunidades e conhecimento. Emvale e Aston pertencem à formação das comunidades setentrionais. Contatos posteriores alcançaram terras orientais. Ithélion ocupava posição religiosa central e Ardanus, chamado Arathiel, era invocado nos juramentos. A fundação da Ordem dos Magos por Caerion Thalas transformou a experiência das passagens em um programa de conservação, exame e responsabilização.



Trocas e tensões. Maeriel Sorn manteve intercâmbios com pesquisadores Eldenari. Técnicas de proteção mental e relatos do Entrelaço circularam junto ao conhecimento do aerólito. A cooperação não eliminou divergências sobre quem podia autorizar intervenções na mana; o conflito em torno do Selo atingiu as comunidades que haviam procurado em Virtude uma existência mais estável.



Vaelthar



Ouvinte das Estrelas na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Dragão"], ["Atuação", "Ouvinte das Estrelas"], ["Sinais distintivos", "Escamas verdes opacas, quase negras à sombra; fratura branca no chifre esquerdo."], ["Período", "I Era"], ["Vínculos principais", "Custódios da Esmeralda; Conclaves das Asas"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Escutava por longos períodos e lembrava visitantes de séculos anteriores. Sua prudência podia adiar uma decisão até transformá-la em abandono. Liderava os Custódios da Esmeralda, atentos aos Descompassos e aos ciclos de Eshara.



Vínculos e conflitos. Permanecia contrário ao Selo, mas não impediu a tentativa autorizada pelo Pacto das Três Testemunhas. Na guerra, buscou uma trégua e foi ferido por dragões do Zênite ao proteger uma delegação élfica. Seus Custódios passaram então a combater.



Legado e limites do registro. Com Varesh, conduziu sobreviventes ao refúgio preparado em Eshara. O isolamento posterior limita aquilo que as fontes de Virtude conseguem acompanhar sobre sua vida. A travessia encerra sua participação diretamente narrada na crise.



Aparência e presença. Escamas verdes opacas, quase negras à sombra; fratura branca no chifre esquerdo.



Khorvath



Ferreiro Vivo na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Dragão"], ["Atuação", "Ferreiro Vivo"], ["Sinais distintivos", "Peito largo, escamas cor de cobre e uma asa marcada por cicatrizes de metal fundido."], ["Período", "I Era"], ["Vínculos principais", "Artífices da Brasa; Aliança da Brasa"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Trabalhava junto aos aprendizes e ensinou os Eldenari a concentrar mana em pedra e metal. A dedicação ao ofício convivia com dificuldade de aceitar críticas ao que construíra. Os Artífices da Brasa e a Aliança da Brasa expressaram sua confiança no aperfeiçoamento da criação.



Vínculos e conflitos. Ajudou os Primeiros Magos a construir o Selo e apoiou a tentativa de Avar de corrigir os desvios sem desligá-lo. Temia que a interrupção condenasse cidades. Nas Cinzas de Uldar, rompeu com Zhaurak após a destruição da cidade neutra.



Legado e limites do registro. Morreu sustentando as fundações do zigurate durante a ruptura, permitindo uma evacuação. Seu culto posterior em Nogard transformou o artífice histórico em objeto de devoção, questão disputada entre sacerdotes.



Aparência e presença. Peito largo, escamas cor de cobre e uma asa marcada por cicatrizes de metal fundido.



Zhaurak



Coroa Rubra na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Dragão"], ["Atuação", "Coroa Rubra"], ["Sinais distintivos", "Escamas vermelhas de bordas douradas; postura elevada e cuidadosamente dominante."], ["Período", "I Era"], ["Vínculos principais", "Senhores do Zênite; Serath Namar"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Os Senhores do Zênite reuniam-se em torno de sua defesa do governo dos primeiros habitantes sobre os povos posteriores. Sua generosidade com protegidos se confundia com a exigência de obediência. Reconhecia a gratidão com mais facilidade do que a dependência criada por sua proteção.



Vínculos e conflitos. Aderiu ao Pacto após obter o reconhecimento dos próprios domínios. Impediu inspeções, perseguiu críticos e atacou a escolta de Serath. O incêndio de Vel-Samar e a destruição de Uldar ampliaram a guerra e romperam alianças.



Legado e limites do registro. Atacou o zigurate para impedir o desligamento do Selo. Maeriel o enfrentou nas galerias superiores; ambos desapareceram na descarga. Os relatos conservam esse desaparecimento sem uma confirmação separada de seus destinos.



Aparência e presença. Escamas vermelhas de bordas douradas; postura elevada e cuidadosamente dominante.



Varesh



Asa das Marés na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Dragão"], ["Atuação", "Asa das Marés"], ["Sinais distintivos", "Membranas das asas com cicatrizes de sal; nesta referência visual, escamas cinza-pérola de reflexos marinhos."], ["Período", "I Era"], ["Vínculos principais", "Conclaves das Asas; Vaelthar"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Percorreu oceanos e acolheu exilados sem aderir permanentemente às três tradições dracônicas. Alterava o ritmo da voz ao experimentar idiomas. Sua liberdade encantava viajantes, mas podia deixar desassistidas comunidades que dependiam de sua continuidade.



Vínculos e conflitos. Um santuário fundado para viajantes ficou sem apoio durante uma fome quando ela partiu para investigar uma corrente marítima. Esse episódio ocupa lugar importante nas leituras críticas de sua hospitalidade e da responsabilidade de quem oferece proteção.



Legado e limites do registro. Conduziu com Vaelthar os sobreviventes até Eshara. Sua memória seria cultuada em Nogard ao lado de Azhravyr e Khorvath, embora ela tivesse vivido como criatura de Virtude.



Aparência e presença. Membranas das asas com cicatrizes de sal; nesta referência visual, escamas cinza-pérola de reflexos marinhos.



Arieth Ilvar



Regente da Travessia na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Aelthir; depois elfa alta"], ["Atuação", "Regente da Travessia"], ["Sinais distintivos", "Rosto longo, pele escura e mecha branca trançada junto à têmpora."], ["Período", "I Era"], ["Vínculos principais", "Aelthir e a chegada dos elfos altos; Leth Avar"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Conduziu famílias de Leth Avar durante a Travessia das Sete Portas. Sua autoridade era marcada pela responsabilidade diante das pessoas que aceitara guiar. Manteve postos de acolhimento quando parte do conselho defendia fechar a passagem.



Vínculos e conflitos. A chegada exigiu organizar abrigo e recursos para corpos sujeitos a novas condições materiais. A regente protegeu a associação de estudiosos que Caerion transformaria na Ordem dos Magos. O consentimento nas intervenções e a conservação de conhecimentos de passagem pertencem a esse contexto.



Legado e limites do registro. Temia receber uma delegação que exigisse o retorno e descobrir que não restara ninguém a quem devolver o caminho. As fontes não estabelecem aqui uma data de morte ou uma sucessão completa de sua regência.



Aparência e presença. Rosto longo, pele escura e mecha branca trançada junto à têmpora.



Caerion Thalas



Fundador da Ordem dos Magos na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Elfo alto"], ["Atuação", "Fundador da Ordem dos Magos"], ["Sinais distintivos", "Mãos finas, com tremor quando cansado; referência visual de rosto retangular, cabelos presos e manto cinza-azulado."], ["Período", "I Era"], ["Vínculos principais", "Ordem dos Magos; Mesa das Portas"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Fundou a Ordem em Aethravel por volta de 6035. Defendia a revisão dos erros e o exame das intervenções por mais de uma escola. A responsabilidade institucional tornou-o progressivamente relutante em expor divergências internas.



Vínculos e conflitos. Enviou Maeriel a Xeo Taoju, negociou intercâmbios e exigiu um desligamento gradual do Selo diante de efeitos inesperados. Sua alternativa distribuía riscos por comunidades que nem sempre haviam consentido em suportá-los. Na crise final, ordenou uma intervenção antes de receber o novo acordo entre Avar e Serath.



Legado e limites do registro. Morreu durante a Grande Punição tentando proteger refugiados que seguiam para o norte. Sua trajetória reúne a criação de procedimentos de cuidado e os limites políticos que impediram seu funcionamento no momento decisivo.



Aparência e presença. Mãos finas, com tremor quando cansado; referência visual de rosto retangular, cabelos presos e manto cinza-azulado.



Maeriel Sorn



Diplomata dos intercâmbios na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Elfa alta"], ["Atuação", "Diplomata dos intercâmbios"], ["Sinais distintivos", "Cabelo negro no queixo, sobrancelha atravessada por cicatriz e roupas práticas de viagem."], ["Período", "I Era"], ["Vínculos principais", "Caerion Thalas; Serath Namar"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Enviada por Caerion a Xeo Taoju, aproximou-se de Serath Namar e dos pesquisadores Eldenari. Seu humor seco prejudicava cerimônias, mas sua disposição de conviver com oficinas e estudos abriu vínculos que a diplomacia formal dificilmente sustentaria.



Vínculos e conflitos. Com Serath, identificou o desvio de experiências para a Margem. Retirou a pesquisadora da prisão por volta de 6393, no episódio que antecedeu o ataque de Zhaurak. Na última campanha, procurou informar Caerion da cooperação renovada entre Avar e Serath.



Legado e limites do registro. Enfrentou Zhaurak nas galerias superiores do zigurate e desapareceu na descarga. Sua atuação permite acompanhar o custo de uma guerra que passou a tratar mediadores e salvo-condutos como ameaças.



Aparência e presença. Cabelo negro no queixo, sobrancelha atravessada por cicatriz e roupas práticas de viagem.



Avar Seneth



Especialista em tempo na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Especialista em tempo"], ["Sinais distintivos", "Cabelos negros presos por fios de cobre, rosto estreito e hábito de endireitar objetos enquanto falava."], ["Período", "I Era"], ["Vínculos principais", "Ilyra Seneth; Primeiros Magos"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Descendente de Ilyra Seneth, integrou os Primeiros Magos e procurou construir um calendário que jamais falhasse. A morte de um sobrinho numa cheia repetida agravou sua incapacidade de aceitar descanso diante de um cálculo aberto. Era atencioso com aprendizes e passou a ler advertências como pedidos de tolerar outras perdas.



Vínculos e conflitos. Foi reconhecido como Arauto de Asterion por seguidores e parte do sacerdócio; esse reconhecimento permanece disputado. Após os nove anos iniciais do Selo, sustentou que corrigiria o desvio sem desligá-lo. Não enfrentou Zhaurak quando o dragão bloqueou inspeções necessárias.



Legado e limites do registro. No cerco final, percebeu a atuação do Inconcluso através dos instrumentos e cooperou com Serath no desligamento. Permaneceu junto ao Relógio durante a ruptura. O registro conserva sua última atuação sem acrescentar uma cena de morte que as fontes não descrevem.



Aparência e presença. Cabelos negros presos por fios de cobre, rosto estreito e hábito de endireitar objetos enquanto falava.



Serath Namar



Pesquisadora da memória na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Pesquisadora da memória"], ["Sinais distintivos", "Cabelos precocemente grisalhos; roupas de viagem mesmo em cerimônias; anotações críticas nas margens."], ["Período", "I Era"], ["Vínculos principais", "Primeiros Magos; Maeriel Sorn"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Integra os Primeiros Magos como estudiosa da memória. Ambicionava demonstrar uma organização investigável das lembranças e ressentia-se quando seu trabalho era reduzido ao prestígio de Avar. A cooperação entre os dois atravessou afeto, competição e divergências sobre o direito de impor estabilidade ao mundo.



Vínculos e conflitos. Com Maeriel, identificou a Margem. Tentou reduzir a carga do Selo, foi presa e depois retirada da prisão pela diplomata. Nas Pontes de Asmarith, impediu uma inundação que atingiria famílias partidárias de Avar, mesmo permitindo a fuga de forças que voltariam a combater.



Legado e limites do registro. Na ruptura, acionou o Pergaminho para impedir que o Inconcluso atravessasse inteiramente. Seus cálculos sobre o retorno tardio de energia integram as explicações da Grande Punição, sem resolver sozinhos todas as evidências da catástrofe.



Aparência e presença. Cabelos precocemente grisalhos; roupas de viagem mesmo em cerimônias; anotações críticas nas margens.



Saelith Vora



Sacerdotisa da Aliança da Brasa na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Sacerdotisa da Aliança da Brasa"], ["Sinais distintivos", "Couro cabeludo tatuado e colares de cerâmica que estalavam quando se movia."], ["Período", "I Era"], ["Vínculos principais", "Aliança da Brasa; Khorvath"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Devota de Azhravyr, estabeleceu a Aliança da Brasa entre cidades Eldenari e dragões Artífices. Conhecia a fome dos campos e buscava proteção e estabilidade. Sua defesa da parceria dracônica encontrou o problema do trabalho compulsório exigido por Zhaurak.



Vínculos e conflitos. Via na desconfiança de Nimea Aral uma posição distante de quem precisava responder por uma colheita. A aproximação com os Senhores do Zênite dividiu seus sacerdotes. Nas Cinzas de Uldar, retirou a bênção às tropas após a destruição de uma cidade neutra.



Legado e limites do registro. Perdeu o cargo e passou os últimos anos conduzindo refugiados que antes a aclamavam. Sua trajetória conserva a responsabilidade por alianças anteriores e a mudança de posição diante das consequências da guerra.



Aparência e presença. Couro cabeludo tatuado e colares de cerâmica que estalavam quando se movia.



Nimea Aral



Organizadora do Círculo das Testemunhas na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Organizadora do Círculo das Testemunhas"], ["Sinais distintivos", "Voz rouca, nariz quebrado num tumulto e pouca disposição para reverenciar colegas."], ["Período", "I Era"], ["Vínculos principais", "Círculo das Testemunhas; Descompassos"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Defendia que uma entidade capaz de realizar maravilhas ainda podia mentir. Organizou o Círculo das Testemunhas para reunir relatos sem obrigar depoentes a concordar. O procedimento contrariava autoridades que buscavam uma versão única para cada manifestação.



Vínculos e conflitos. A disputa com o sacerdote Damar Esh atravessou a interpretação de Descompassos e encontros velários. Nimea procurava conservar o desacordo entre testemunhas como parte da evidência. A posição tensionava sacerdotes e patrocinadores que dependiam do reconhecimento de uma intervenção divina.



Legado e limites do registro. Sua prática influenciou a cultura de verificação herdada pelos pesquisadores posteriores. Não há uma data segura de nascimento ou morte neste recorte. O nome do Círculo continuou em uso por gerações; a atuação posterior da organização não implica a presença de sua fundadora em todos esses momentos.



Aparência e presença. Voz rouca, nariz quebrado num tumulto e pouca disposição para reverenciar colegas.



Teren Vos



Construtor dos instrumentos do Selo na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Construtor dos instrumentos do Selo"], ["Sinais distintivos", "Dedos deformados pelo trabalho; referência visual de rosto quadrado, cabelo crespo baixo e avental de oficina."], ["Período", "I Era"], ["Vínculos principais", "Primeiros Magos; Selo do Tempo"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Integrou os Primeiros Magos como construtor de instrumentos. Sua pouca tolerância a discursos religiosos fazia-o insistir na diferença entre autoridade ritual e funcionamento de uma peça. A estabilidade de encaixes, suportes e conexões exigia conhecimentos que nenhum outro membro dominava sozinho.



Vínculos e conflitos. Na ampliação do recorte, seus registros distinguem defeito do instrumento, alteração do meio e erro de leitura. Essa rotina foi usada para comparar operações da rede sem atribuir toda falha à capacidade do operador. Sua confiança na repetição encontrava limites quando o projeto mudava mais depressa que as condições de ensaio.



Legado e limites do registro. Participou da construção do Selo com Avar, Serath, Melian e Eshara Vel. As fontes não oferecem um destino individual seguro na ruptura. O desaparecimento de instalações e oficinas também limitou a identificação de seus trabalhos posteriores.



Aparência e presença. Dedos deformados pelo trabalho; referência visual de rosto quadrado, cabelo crespo baixo e avental de oficina.



Melian Or



Estudioso dos caminhos do espaço na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Estudioso dos caminhos do espaço"], ["Sinais distintivos", "Referência visual: rosto oval, nariz achatado, olhos fundos, cabelos longos presos e casaco de bolsos de tecido."], ["Período", "I Era"], ["Vínculos principais", "Primeiros Magos; Selo do Tempo"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Responsável pelos caminhos do espaço entre os Primeiros Magos, defendia partilhar o projeto entre cidades. Aceitou restrições de circulação para conservar o financiamento. Essa concessão colocou a pesquisa diante do conflito entre cooperação declarada e controle das instalações.



Vínculos e conflitos. Suas equipes faziam rotas de manutenção em pares, com registros de chegada e retorno. A prática protegia trabalhadores diante de mudanças nas passagens e gerava provas de acesso. Durante a crise, os mesmos registros passaram a servir à vigilância sobre quem podia atravessar cada setor.



Legado e limites do registro. Sua participação explica a dependência do Selo de uma rede instalada ao longo de décadas. Reunir as três peças fora dessa rede não reproduziria automaticamente a escala da operação antiga. Seu destino individual no colapso continua sem confirmação.



Aparência e presença. Referência visual: rosto oval, nariz achatado, olhos fundos, cabelos longos presos e casaco de bolsos de tecido.



Eshara Vel



Preparadora da Gema na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Preparadora da Gema"], ["Sinais distintivos", "Perda progressiva de audição; referência visual de cabelos curtos ruivos escuros, rosto miúdo e mãos expressivas."], ["Período", "I Era"], ["Vínculos principais", "Primeiros Magos; Gema de Eshara"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Integrava os Primeiros Magos e interpretava variações da mana nos seres vivos. Preparou a Gema que recebeu seu nome. A lua Eshara já era conhecida antes dela: a pesquisadora fora nomeada em homenagem ao astro. A perda de audição durante o trabalho levou-a a desenvolver sinais manuais adotados pelos operadores.



Vínculos e conflitos. As oficinas passaram a registrar sinais de interrupção em suportes visíveis, permitindo alertar equipes mesmo em ruído intenso. O gesto de interromper uma operação tornou-se uma questão de autoridade: reconhecer o alerta exigia aceitar que um auxiliar pudesse suspender o trabalho de alguém prestigiado.



Legado e limites do registro. Seu conhecimento sustentou a ligação entre o Selo e Virtude. A Gema conservava mana acumulada e precisava de reposição. O destino pessoal de Eshara durante a ruptura não é estabelecido por um registro conclusivo.



Aparência e presença. Perda progressiva de audição; referência visual de cabelos curtos ruivos escuros, rosto miúdo e mãos expressivas.



Veska Tor



Barqueira de Elar-Tao na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Eldenari"], ["Atuação", "Barqueira de Elar-Tao"], ["Sinais distintivos", "Corpo robusto, cabelo negro enrolado em pano, lábio inferior cheio e cicatriz curta no queixo."], ["Período", "I Era"], ["Vínculos principais", "Elar-Tao; Retirada dos Armazéns de Elar-Tao"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Transportava alimentos e famílias pelos canais de Elar-Tao. Durante a Retirada dos Armazéns, em 6337, confrontou a prioridade dada a instrumentos de pesquisa nos barcos de evacuação. Usava túnica de mangas curtas, faixas de lona e uma vara de travessia, guardando marcas de carga em pequenas peças de cerâmica.



Vínculos e conflitos. O Pacto das Barcas de 6338 reconheceu a presença de representantes das tripulações nas decisões sobre transporte emergencial. Veska defendia reservar espaço para pessoas, sementes e provisões, mesmo quando uma casa de estudo reivindicava o barco inteiro. Sua posição rendeu apoio de famílias e resistência dos proprietários das cargas.



Legado e limites do registro. O exemplo de Elar-Tao circulou nas discussões que antecederam o Selo. A pesquisa dependia de quem mantinha os caminhos e os corpos vivos durante as crises. Este recorte não fixa sua morte nem a transforma em testemunha de todos os acontecimentos finais.



Aparência e presença. Corpo robusto, cabelo negro enrolado em pano, lábio inferior cheio e cicatriz curta no queixo.



Naeris Ul



Mensageira dos salvo-condutos na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Elfa alta"], ["Atuação", "Mensageira dos salvo-condutos"], ["Sinais distintivos", "Rosto comprido com queixo curto, sardas escuras, trança castanha muito apertada e um incisivo lascado."], ["Período", "I Era"], ["Vínculos principais", "Maeriel Sorn; Caerion Thalas"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Serviu nas rotas de correspondência entre observadores élficos e cidades Eldenari durante a última campanha. Levava estojo impermeável, manto curto e uma lâmina de uso cotidiano. Aprendeu a reconhecer postos onde a assinatura aceita numa semana era tratada como ameaça na seguinte.



Vínculos e conflitos. Naeris é a mensageira detida por aliados ao levar a Caerion a notícia enviada por Maeriel sobre a cooperação entre Avar e Serath. Os guardas desconfiaram do salvo-conduto emitido numa área disputada. A demora consumiu a possibilidade de comparar o novo acordo com a intervenção já preparada.



Legado e limites do registro. Sua atuação dá um rosto à falha das comunicações que a História Geral já registra. O recorte não atribui a ela a causa única da ruptura. A detenção ocorreu dentro de procedimentos de guerra que haviam tornado suspeitos os próprios mecanismos de verificação.



Aparência e presença. Rosto comprido com queixo curto, sardas escuras, trança castanha muito apertada e um incisivo lascado.



Conclaves das Asas



Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos."]], "widths": [1, 3]}



Formação e práticas. As reuniões não formavam um governo de todos os dragões. Participação, reconhecimento de uma decisão e capacidade de fazê-la cumprir dependiam dos vínculos entre os presentes. O costume mais antigo proibia atacar um ninho para resolver uma disputa entre adultos.



Disputas internas. Os Conclaves distinguem proteção de ninho e submissão territorial: aceitar abrigo para ovos não transfere automaticamente a um protetor a obediência dos adultos. A regra permitia negociações entre tradições rivais, embora cada uma interpretasse de modo diferente os deveres de proteção.



Na história da era. A violação dos ninhos na Guerra das Nove Vigílias destruiu possibilidades de reconciliação. A perda de ovos atingiu gerações futuras de um povo pouco numeroso e lento para se reproduzir. O cuidado dos sobreviventes ajuda a compreender a retirada para Eshara.



Custódios da Esmeralda



Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato."]], "widths": [1, 3]}



Formação e práticas. Seus santuários nas montanhas acompanhavam ciclos da lua esmeralda, Eshara. A observação prolongada e a prudência forneciam uma alternativa às ambições de transformação dos Artífices e de domínio dos Senhores do Zênite.



Disputas internas. Havia uma disputa interna entre vigílias longas e auxílio imediato: parte dos Custódios temia que intervir modificasse o fenômeno observado; outros consideravam que a obrigação de abrigo já vinculava o observador à vida dos visitantes. Vaelthar não resolveu sempre essa tensão a tempo.



Na história da era. Após o ataque à delegação protegida por Vaelthar, os Custódios entraram na guerra. O refúgio preparado em Eshara tornou-se a saída para parte dos dragões, mas a travessia esgotou os instrumentos de acesso.



Artífices da Brasa



Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos."]], "widths": [1, 3]}



Formação e práticas. Os Artífices ensinaram a concentrar mana em pedra e metal. A relação com cidades Eldenari gerou oficinas, aprendizagem e obras de grande escala. O trabalho do aerólito tornou essa cooperação especialmente importante para a construção de instrumentos.



Disputas internas. As oficinas distinguem o direito de aprender de uma obrigação de servir por toda a vida. Mestres e patrocinadores divergiam sobre a abertura dos registros de fabricação. O ensino podia emancipar uma cidade e, ao mesmo tempo, torná-la dependente de manutenção especializada.



Na história da era. O apoio de Khorvath ao Selo nasceu dessa confiança na possibilidade de corrigir uma construção. Sua ruptura com Zhaurak após Uldar mostra que a aliança técnica e política não foi uniforme durante toda a guerra.



Senhores do Zênite



Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores."]], "widths": [1, 3]}



Formação e práticas. A proteção oferecida por dragões do Zênite vinha acompanhada de tributos e serviços. Seus defensores alegavam que a longevidade permitia governar para além de interesses passageiros; comunidades tributadas contestavam o direito de transformar proteção em trabalho compulsório.



Disputas internas. Os domínios mantinham listas diferentes para cidades protegidas, tributárias e obedientes. A mudança de uma lista para outra permitia ampliar cobranças sem renegociar todos os acordos. A discrepância entre proteção proclamada e autonomia efetiva se tornou um foco de resistência.



Na história da era. Zhaurak condicionou sua adesão ao Pacto ao reconhecimento dos domínios, bloqueou inspeções e perseguiu críticos do Selo. A violência contra emissários e cidades neutras afastou antigos aliados. Outros dragões do Zênite participaram do ataque a Vaelthar.



Casa das Medidas



Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança."]], "widths": [1, 3]}



Formação e práticas. Medir não era uma atividade afastada da política. Alterar a data de um tributo podia comprometer sementes e provisões. A Casa disputava com o sacerdócio a competência sobre cobranças e dependia do trabalho de equipes que transportavam, construíam e mantinham instrumentos.



Disputas internas. A Paralisação dos Nove Pátios obrigou a reservar mantimentos para trabalhadores. Na Guerra dos Reparos, a Casa tentou distinguir inspeção de ocupação das instalações; a arbitragem de 6266 ampliou a participação das comunidades afetadas. Os acordos não encerraram o uso político de mapas e registros.



Na história da era. Durante as Nove Vigílias, especialistas guiaram ofensivas, enquanto outros falsificaram mapas para proteger localidades. A divisão mostrou como um conhecimento útil ao cuidado dos canais também podia sustentar campanhas militares.



Círculo das Testemunhas



Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes."]], "widths": [1, 3]}



Formação e práticas. A prática admitia que duas testemunhas sinceras oferecessem versões incompatíveis. Essa diferença devia ser conservada para estudo, especialmente em encontros velários, reconhecimento de Arautos e Descompassos. Autoridades que buscavam um único relato frequentemente contestavam seus métodos.



Disputas internas. Os cadernos do Círculo separam o nome fornecido, o nome reconhecido e a descrição da aparência. Uma mesma figura podia ser identificada de modos diferentes por observadores próximos. O procedimento aproximava cuidado com o depoente e atenção à história da transmissão.



Na história da era. A organização sobreviveu por gerações à sua fundação. Durante a Guerra das Nove Vigílias, manteve corredores de troca de prisioneiros até receber acusações de espionagem dos dois lados. Essa atuação posterior pertence à instituição e não fixa a longevidade de Nimea.



Primeiros Magos



Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo."]], "widths": [1, 3]}



Formação e práticas. O círculo formou-se por volta de 6360, diante de Descompassos como os de Elar-Tao. Avar Seneth, Serath Namar, Teren Vos, Melian Or e Eshara Vel reuniam especialidades distintas. Seu título expressa a organização comum dessas artes; encantamentos já existiam havia muito tempo.



Disputas internas. Avar estudava tempo, Serath memória, Teren instrumentos, Melian espaço e Eshara mana nos seres vivos. O trabalho dependia de tradução entre práticas, equipes de instalação e financiamento das cidades. Divergências pessoais e institucionais atravessavam decisões que nenhum integrante podia tomar sozinho com pleno conhecimento.



Na história da era. Com Khorvath, construíram as três peças do Selo. A cooperação inicial foi desgastada pelos efeitos da Margem e pelas disputas de inspeção. Na última campanha, Avar e Serath voltaram a cooperar, mas a guerra havia comprometido os mecanismos para comunicar e verificar o acordo.



Mesa das Portas



Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções."]], "widths": [1, 3]}



Formação e práticas. Reunia responsáveis pelas disciplinas da associação fundada em Aethravel. A revisão por mais de uma escola procurava impedir que prestígio e linhagem substituíssem demonstrações. Cuidadores de passagens, conservadores de instrumentos e pesquisadores participavam de uma instituição mais ampla que uma força de combate.



Disputas internas. Uma suspensão devia conservar os registros do trabalho e indicar as condições necessárias para retomá-lo. A regra protegia a possibilidade de revisão e também criava disputas sobre quem podia atrasar uma pesquisa. A contenção pública das divergências por Caerion dificultou esse ideal em momentos posteriores.



Na história da era. O conflito do Selo expôs a distância entre exigir interrupção e apresentar uma alternativa praticável para as comunidades dependentes da rede. A destruição de arquivos e instrumentos no fim da era comprometeu parte dos procedimentos que os fundadores haviam procurado preservar.



Aliança da Brasa



Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Período", "I Era"], ["Campo de atuação", "Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices."]], "widths": [1, 3]}



Formação e práticas. A aliança vinculava ensino, proteção e obras materiais. Saelith via nos dragões parceiros para enfrentar a fome e dar estabilidade às cidades. Khorvath oferecia conhecimentos de concentração da mana, especialmente no trabalho de pedra, metal e aerólito.



Disputas internas. Que os pactos locais tinham contrapartidas diferentes: manutenção de santuários, provisões para oficinas e abertura de aprendizagem. A variedade permitia adaptação, mas também favorecia a apresentação de obrigações novas como se sempre tivessem integrado um acordo anterior.



Na história da era. A aproximação de Saelith com Zhaurak tensionou a autonomia das comunidades e dividiu sacerdotes. Sua retirada das bênçãos após Uldar rompeu a associação automática entre proteção dracônica e legitimidade da guerra. A aliança deixou legados técnicos mais duradouros do que sua unidade política.



Selo do Tempo



Sistema Eldenari de três instrumentos e uma rede instalada para compatibilizar fluxos temporais presentes.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Ativação", "c. 6384 da I Era"], ["Componentes", "Relógio, Pergaminho e Gema"], ["Escala", "Rede de instalações preparadas"], ["Limite", "Compatibilização presente; não reescreve o passado"]], "widths": [1, 3]}



Construção e autorização. Os Primeiros Magos construíram o Selo com Khorvath. O Pacto das Três Testemunhas autorizou a operação sob observação de Eldenari, dragões e elfos altos. Caerion exigiu desligamento gradual diante de efeitos inesperados; Zhaurak obteve reconhecimento dos domínios. Avar e patrocinadores abreviaram etapas de verificação diante da fome.



Três funções complementares. O Relógio de Avar comparava ritmos e intervalos; o Pergaminho das Concordâncias estabelecia condições e interrupções; a Gema de Eshara ligava os procedimentos à rede material e distribuía energia. Cada parte limitava abusos que as outras não reconheciam sozinhas. A escala do sistema dependia de instalações preparadas durante décadas.



Estabilidade e custo. Ativado por volta de 6384 no Zigurate das Nove Vigílias, o Selo fez os Descompassos praticamente cessarem durante nove anos. Serath e Maeriel descobriram o desvio de experiências incompatíveis para a Margem. Três tentativas de redução enfrentaram mortes, efeitos de memória e bloqueios de inspeção.



Ruptura e limites. Na campanha final coincidiram o desligamento de Avar e Serath, o ataque de Zhaurak e a intervenção ordenada por Caerion. A unidade se perdeu e as peças foram dispersas. Mesmo reunido, o Selo não permitia voltar ao passado para escolher outro resultado. Encontrar os instrumentos em outra era não reconstrói a antiga rede.



Relógio de Avar



Instrumento que compara ritmos e delimita intervalos dentro do Selo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Tipo", "Artefato do Selo"], ["Estado no fim da I Era", "Disperso após a ruptura"]], "widths": [1, 3]}



Função no conjunto. O Relógio estabelecia a comparação temporal necessária à operação, sem decidir quais mudanças seriam admissíveis. Sua leitura dependia de referências e condições de instalação. Avar permaneceu junto a ele na ruptura.



Uso e limites. Separado do conjunto, podia revelar ou reduzir desajustes locais. Não reescrevia acontecimentos vividos. O instrumento tinha aros de bronze fosco, discos e ponteiros artesanais. Sua operação preservava a diferença entre medir uma relação e governar todo o tempo.



História e referência visual. A ruptura dispersou os instrumentos e alterou suas correspondências com a rede. Fora de uso, o Relógio deixou de emitir um padrão que permitisse encontrá-lo simplesmente buscando mana. Seu destino posterior não é resolvido por este recorte.



Pergaminho das Concordâncias



Registro reativo à mana das condições de operação e interrupção do Selo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Tipo", "Artefato do Selo"], ["Estado no fim da I Era", "Disperso após a ruptura"]], "widths": [1, 3]}



Função no conjunto. O Pergaminho estabelecia limites e procedimentos sem fornecer energia ou executar sozinho as alterações. A escrita reagia à mana e permitia comparar a resposta do sistema com as condições previstas.



Uso e limites. Isolado, ajudava a reconhecer instruções, falhas e condições de dispositivos da mesma tradição. Margens de revisão reservadas a objeções, cuja leitura exigia comparar versões. O valor do objeto dependia da compreensão do procedimento registrado.



História e referência visual. Serath o acionou para impedir a travessia completa do Inconcluso. Após a dispersão, os relatos de aparição tornaram-se contraditórios. O instrumento não permite ordenar qualquer coisa por meio de palavras e não garante reconstruir as instalações perdidas.



Gema de Eshara



Instrumento preparado por Eshara Vel para vincular o Selo à rede material e distribuir mana.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Tipo", "Artefato do Selo"], ["Estado no fim da I Era", "Disperso após a ruptura"]], "widths": [1, 3]}



Função no conjunto. A Gema recebeu o nome da pesquisadora que a preparou. Eshara Vel fora nomeada em homenagem à lua, já chamada Eshara. A peça distribuía energia captada e ligava procedimentos aos pontos preparados em Virtude.



Uso e limites. Utilizava mana acumulada e precisava de reposição. Isolada, podia alimentar e ampliar ligações preparadas, sem conhecer medida ou finalidade. O risco aumentava quando controles ausentes eram substituídos por operadores e seres vivos submetidos à carga.



História e referência visual. A ruptura dispersou a peça com as outras partes do Selo. O relato acompanha sua função e sua história na I Era; os acontecimentos posteriores permanecem nos verbetes e blocos da trama correspondentes. Sua referência visual é uma pedra esmeralda em suporte de metal e cerâmica.



Aerólito



Metal capaz de conservar padrões de mana, ensinado aos construtores Eldenari por Khorvath.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Material", "Metal de retenção de padrões de mana"], ["Tradição técnica", "Oficinas dracônicas e Eldenari"]], "widths": [1, 3]}



Ofício e transmissão. O trabalho do aerólito aproximou Artífices da Brasa, cidades Eldenari e elfos altos. Conservar um padrão exigia material, preparação e técnica. Oficinas e aprendizagem tinham tanta importância quanto a presença do metal.



Ampliação dos usos. Placas de comparação, encaixes de instrumentos e pequenos suportes de repetição eram usados nas oficinas da I Era. Uma peça conserva o padrão que foi preparada para receber; alterações do suporte ou desgaste podem prejudicar a leitura. A manutenção exige reconhecer o trabalho anterior.



Valor e dependência. A distribuição das oficinas criava desigualdades entre centros capazes de fabricar componentes e comunidades dependentes de reparo externo. A Guerra dos Reparos levou esse problema aos canais e às instalações de mana. O domínio do ofício se tornou uma fonte de autoridade e um motivo para defender a abertura de registros.



Eshara, a lua esmeralda



Lua acompanhada pelos Custódios da Esmeralda e sede do refúgio dos dragões sobreviventes.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Tipo", "Lua"], ["Refúgio", "Área preparada com mana; acesso consumido"]], "widths": [1, 3]}



Ciclos e vigílias. Os Custódios acompanhavam os ciclos de Eshara a partir de santuários nas montanhas. O astro oferecia uma referência de longa duração para observações que atravessavam vidas de povos mortais. Sua cor e seu nome integraram tradições e nomes pessoais.



Refúgio preparado. O refúgio de mana foi preparado pelos Custódios antes da retirada final. Após a ruptura do Selo, Vaelthar e Varesh conduziram para lá os dragões sobreviventes que conseguiram atravessar. A passagem consumiu os últimos instrumentos capazes de manter o caminho.



Isolamento e memória. O abrigo reunia terraços de repouso e pontos de distribuição da mana. Essas condições dizem respeito ao abrigo preparado, sem estabelecer que toda a lua possua o mesmo ambiente. O isolamento limitou os contatos com Virtude. Eshara Vel recebeu o nome do astro, e a Gema recebeu o nome da maga.



A Margem



Região de Eomundus sobrecarregada pelo desvio de experiências incompatíveis durante a operação do Selo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Plano", "Eomundus"], ["Condição", "Sobrecarga produzida pelo Selo"]], "widths": [1, 3]}



Acúmulo e reconhecimento. Serath Namar e Maeriel Sorn identificaram que a estabilidade de Virtude transferia experiências incompatíveis para uma região de Eomundus. Fragmentos de acontecimentos, consciências interrompidas e possibilidades acumulavam-se num espaço incapaz de comportar a carga.



O Inconcluso. Respostas persistentes e adaptativas surgiram no acúmulo e receberam o nome de Inconcluso. As hipóteses de presença velária e organização emergente da memória permaneceram em disputa. O reconhecimento de respostas observáveis não resolveu sua origem ou a extensão de sua identidade.



Custo do encerramento. As tentativas de reduzir a carga exigiam coordenar instalações e aceitar efeitos em comunidades diferentes. A guerra destruiu a confiança necessária a essa operação. A ruptura atingiu os Eldenari ligados à rede; cálculos de retorno tardio da energia integram uma das explicações da Grande Punição.



O Inconcluso



Nome dado às respostas adaptativas identificadas na Margem durante a crise do Selo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Natureza", "Identidade e origem não demonstradas"], ["Manifestação", "Respostas persistentes e adaptativas na Margem"]], "widths": [1, 3]}



Uma resposta que persiste. Serath descreveu respostas que se adaptavam às intervenções. Avar recebeu mensagens que pareciam completar seus pensamentos. O comportamento sugeria uma busca de continuidade pela incorporação de experiências ao alcance do acúmulo.



Hipóteses e limites. Caerion considerou uma entidade velária; outros pesquisadores propuseram uma organização emergente de memórias e possibilidades. As hipóteses explicavam aspectos diferentes sem resolver a origem. Os registros conservam observáveis as respostas e em aberto a natureza de quem respondia.



A última campanha. Avar percebeu a ação através dos instrumentos do Selo e preparou o desligamento com Serath. Na ruptura, a pesquisadora usou o Pergaminho para impedir que o Inconcluso atravessasse inteiramente. O episódio relaciona a falha técnica às condições políticas que impediram coordenação e verificação.



Leth Avar



Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Eomundus"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. A perda de estabilidade atingia nomes, formas e a vida em comum. Cidades mudavam segundo os sonhos de seus habitantes, tornando a memória uma condição incerta de orientação. A crise preparou a decisão de procurar corpos e caminhos mais estáveis em Virtude.



Vida e práticas locais. Havia pátios de reconhecimento onde famílias repetiam nomes, vínculos e tarefas antes de uma partida. A prática ajudava a reunir pessoas quando uma casa já não conservava a aparência da véspera. Objetos de uso cotidiano podiam servir como apoio de reconhecimento, sem garantir que uma identidade fosse restaurada.



Memória e situação histórica. A Travessia das Sete Portas reduziu o acesso à região. O temor de Arieth de não encontrar ninguém a quem devolver o caminho expressa a perda envolvida no acolhimento. Leth Avar pertence ao Entrelaço e não recebe coordenadas no mapa material de 788.



Elar-Tao



Localidade fluvial Eldenari atingida pela repetição de uma estação de cheia.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Virtude; geografia antiga"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. A crise comprometeu armazenamento, cultivo e memória. Alimentos apodreceram e tornaram a amadurecer, enquanto crianças preservavam recordações de pais ainda vivos. O fenômeno ampliou a pressão por uma intervenção capaz de proteger comunidades inteiras.



Vida e práticas locais. A ampliação situa a Retirada dos Armazéns em 6337 e o Pacto das Barcas em 6338. Veska Tor organizou transportes e reivindicou lugar para pessoas, sementes e mantimentos nos barcos disputados pelas casas de estudo. As marcas de carga conservaram a diferença entre o que fora prometido e o que efetivamente saiu.



Memória e situação histórica. O exemplo da localidade integrou o debate anterior à organização dos Primeiros Magos. Sua posição exata na geografia anterior à catástrofe não é convertida em coordenadas atuais. O artigo acompanha a relação entre rio, trabalho e pesquisa, preservando os limites da reconstrução.



Vel-Samar



Centro de arquivo cujo incêndio marcou a abertura da Guerra das Nove Vigílias.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Virtude; geografia antiga"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. Após Maeriel retirar Serath da prisão, Zhaurak atacou a escolta e incendiou o Arquivo de Vel-Samar. Emissários protegidos pelo Pacto morreram. O ataque tornou material a ruptura das garantias que sustentavam a observação conjunta do Selo.



Vida e práticas locais. O arquivo mantinha depósitos separados para cópias de pactos e registros de circulação. Essa divisão procurava impedir que a perda de um salão eliminasse todas as versões. O incêndio destruiu pessoas e cadeias de autenticação; documentos preservados fora da cidade passaram a carregar parte de sua memória.



Memória e situação histórica. A reconstrução de rotas e responsabilidades depende de cópias incompletas. A posição de Vel-Samar na geografia antiga continua aproximada e não recebe um marcador atual. O destino do arquivo ajuda a explicar por que versões posteriores da guerra divergem sobre decisões tomadas pelos mesmos aliados.



Uldar



Cidade neutra cuja destruição levou Khorvath a romper com Zhaurak na quinta campanha.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Virtude; geografia antiga"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. As Cinzas de Uldar são situadas aproximadamente em 6397. A destruição atingiu uma cidade que não participava da guerra como combatente. Para Khorvath, a violência tornou insustentável a aliança com Zhaurak.



Vida e práticas locais. Uldar conservava oficinas de manutenção que atendiam a comunidades rivais mediante acordos locais. A neutralidade protegia trabalho, acesso a peças e uma população que dependia da passagem de mercadorias. Esse papel explica sua importância para além do número de combatentes.



Memória e situação histórica. Após o ataque, Saelith retirou sacerdotes da bênção às tropas e perdeu o cargo. A cidade tornou-se referência nos debates sobre a proteção de lugares neutros. Seu traçado e sua posição exata anteriores à catástrofe permanecem fora da precisão do atlas de 788.



Refúgio de Eshara



Abrigo de mana preparado pelos Custódios na lua esmeralda e alcançado pelos dragões após a ruptura.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Lua Eshara"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. A preparação antecedia a retirada final e estava ligada às vigílias dos Custódios da Esmeralda. Vaelthar e Varesh conduziram para lá sobreviventes, enquanto alguns ovos permaneceram ocultos em Virtude. A passagem consumiu os instrumentos que a mantinham aberta.



Vida e práticas locais. O abrigo reunia terraços rochosos de repouso e pequenos reservatórios de distribuição da mana. O abrigo precisava sustentar dragões feridos e longos períodos de torpor. A experiência de cada sobrevivente passou a depender de recursos que já não podiam ser repostos por uma travessia regular.



Memória e situação histórica. O isolamento impede acompanhar sua história com a mesma continuidade dos registros materiais de Virtude. O refúgio é uma localidade lunar, sem marcador no mapa dos reinos de 788. Sua existência histórica no relato da retirada não estabelece uma rota disponível para viajantes posteriores.



Paralisação dos Nove Pátios



Trabalhadores interromperam serviços após a suspensão de pagamentos para financiar pesquisa.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era; anterior ao Selo, ano indeterminado"], ["Precisão", "Indeterminada"]], "widths": [1, 3]}



Contexto. Barqueiros, carpinteiros e responsáveis pela conservação sustentavam os observatórios. Quando a Casa das Medidas suspendeu pagamentos, a pesquisa continuou a consumir trabalho e alimento de equipes sem garantia de manutenção. A paralisação levou essa dependência aos pátios das instituições.



Decisões e consequências. O acordo obrigou os estudiosos a reservar mantimentos para os trabalhadores. Que essas reservas fossem indicadas antes da abertura de novas frentes de serviço, permitindo comparar recursos prometidos e equipes convocadas. A medida criou uma proteção sujeita a disputa e fiscalização.



Memória e continuidade. A organização dos Primeiros Magos herdou instituições que já haviam enfrentado contestação do próprio trabalho de apoio. A conquista raramente recebia o destaque dado a novos encantamentos, embora ajudasse a manter cidades e oficinas funcionando. A data anual permanece indeterminada.



Guerra dos Reparos



Conflito entre cidades Eldenari pelo controle da manutenção dos canais e dos suportes de mana.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "6262–6266 da I Era"], ["Precisão", "Data adotada no Registro 2.7"]], "widths": [1, 3]}



Contexto. Equipes de reparo passaram a ser impedidas de atravessar instalações de cidades rivais. Patrocinadores cobravam exclusividade pelo trabalho em canais e suportes de aerólito, enquanto comunidades a jusante arcavam com interrupções e falta de água. Em 6262, apreensões de ferramentas e comboios deram lugar a escaramuças nas passagens.



Decisões e consequências. A guerra concentrou-se em diques, oficinas e depósitos. Cidades procuravam preservar a irrigação dos próprios campos sem conceder acesso aos rivais. Inspeções técnicas eram tratadas como reconhecimento militar. A Casa das Medidas dividiu-se entre defender a circulação das equipes e proteger contratos de seus membros.



Memória e continuidade. A arbitragem de 6266 previu inspeções acompanhadas por representantes de mais de uma cidade e voz das comunidades afetadas. A solução encerrou as campanhas locais, mas preservou desigualdades de fabricação e acesso. Mais tarde, os impasses de inspeção do Selo retomariam tensões dessa história, em escala muito maior.



Retirada dos Armazéns de Elar-Tao



Evacuação que tornou pública a disputa por barcos entre casas de estudo e famílias atingidas pelos Descompassos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "6337 da I Era"], ["Precisão", "Data adotada no Registro 2.7"]], "widths": [1, 3]}



Contexto. Durante a cheia repetida de Elar-Tao, as condições dos armazéns deixaram de acompanhar uma sucessão previsível. Mantimentos conservados num dia apareciam deteriorados no seguinte, e instrumentos recebiam prioridade de transporte sobre alimentos. Tripulações precisavam decidir o que levar antes que o acesso aos cais mudasse outra vez.



Decisões e consequências. Veska Tor reuniu marcas de carga e testemunhos de famílias impedidas de embarcar. Organizou travessias com pessoas, sementes e provisões, enfrentando ordens de reservar barcos a caixas de pesquisa. O episódio deu visibilidade a uma decisão tratada até então como assunto exclusivo dos proprietários e estudiosos.



Memória e continuidade. O transporte emergencial preservou parte dos recursos da comunidade e deixou conflitos que seriam negociados no Pacto das Barcas. A retirada não encerrou os Descompassos. Sua memória ajudou a explicar tanto a urgência de Avar quanto a resistência a soluções que desconsiderassem quem suportava seus riscos.



Pacto das Barcas



Acordo de Elar-Tao que incluiu tripulações nas decisões de transporte durante emergências.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "6338 da I Era"], ["Precisão", "Data adotada no Registro 2.7"]], "widths": [1, 3]}



Contexto. O pacto foi negociado após a Retirada dos Armazéns. Famílias exigiam conservar espaço para pessoas e alimentos, enquanto casas de estudo argumentavam que a perda de instrumentos comprometeria uma solução duradoura. Os barqueiros contestaram a exigência de executar escolhas das quais não participavam.



Decisões e consequências. Veska Tor defendeu a reserva explícita de capacidade para passageiros, sementes e provisões. O acordo reconheceu representantes das tripulações na distribuição emergencial de cargas e exigiu registrar alterações de prioridade. Propriedade da carga e autoridade sobre a vida dos embarcados passaram a ser discutidas separadamente.



Memória e continuidade. O pacto se aplicava aos serviços negociados em Elar-Tao e não criou uma autoridade universal sobre todos os rios. Sua experiência circulou nas redes de manutenção. Quando a interrupção do Selo voltou a colocar comunidades diante de riscos impostos por outros, esses registros ofereceram linguagem para reivindicar participação.



Batalha das Pontes de Asmarith



Serath impediu uma inundação que atingiria famílias partidárias de Avar durante a segunda campanha.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "c. 6394 da I Era; segunda campanha"], ["Precisão", "Aproximada"]], "widths": [1, 3]}



Contexto. Os aliados podiam abrir comportas para deter uma força inimiga, mas a água atingiria campos habitados por famílias favoráveis a Avar. O controle da passagem militar se confundia com o controle da irrigação. Serath se opôs à abertura, tratando a vida dos moradores como uma responsabilidade anterior à vantagem de campanha.



Decisões e consequências. A decisão preservou agricultores e também permitiu que uma força adversária escapasse e voltasse a combater. Parte dos companheiros criticou Serath. Ela sustentou que a proteção das pessoas não podia depender da previsão do que fariam depois aqueles que fossem poupados.



Memória e continuidade. Relatos das margens conservaram a memória das comportas fechadas ao lado das listas de perdas militares. Essa diferença ajuda a compreender como uma mesma batalha podia ser lembrada como falha estratégica ou salvamento. Sua posição relativa na segunda campanha é mais segura que o ano retrospectivo.



Cinzas de Uldar



Destruição de uma cidade neutra que rompeu alianças entre dragões e sacerdotes.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "c. 6397 da I Era; quinta campanha"], ["Precisão", "Aproximada"]], "widths": [1, 3]}



Contexto. O ataque de Zhaurak atingiu Uldar na quinta campanha. Sua neutralidade era sustentada por acordos locais e pelo serviço de oficinas a comunidades de posições diferentes. A destruição eliminou pessoas, abrigo e parte da capacidade de manutenção que atravessava as frentes da guerra.



Decisões e consequências. Khorvath rompeu com Zhaurak. Saelith Vora retirou sacerdotes da bênção às tropas, perdeu o cargo e passou a conduzir refugiados. As decisões mostram que as antigas alianças se modificaram durante o conflito, sob o peso de consequências que seus participantes haviam ajudado a tornar possíveis.



Memória e continuidade. A tradição conserva Uldar como referência nas reivindicações de proteção de lugares de serviço comum. A história não apaga o apoio anterior de Khorvath ao Selo nem a aproximação de Saelith com o Zênite. A mudança de posição ganha sentido justamente por atravessar responsabilidades anteriores.



Os vinte e três dias de Xeo Taoju



Intervalo de ocupação e socorro entre a ruptura do Selo e a Grande Punição.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "Fim da I Era, após a ruptura do Selo"], ["Precisão", "Aproximada"]], "widths": [1, 3]}



Contexto. Após a perda de unidade do Selo, os vencedores ocuparam Xeo Taoju por vinte e três dias. O desaparecimento de muitos Eldenari, a destruição das instalações e a dispersão de refugiados tornavam incerta a dimensão da vitória. A correspondência entre instrumentos e lugares também havia mudado.



Decisões e consequências. Foram organizados pátios de reunião para procurar parentes e pequenos depósitos de água e grãos sob supervisão local. Listas de sobreviventes circulavam com lacunas, correções e nomes repetidos. O esforço de reconstruir vínculos era acompanhado por disputas sobre quem podia ocupar armazéns e conservar documentos.



Memória e continuidade. No vigésimo quarto dia da ocupação, o céu se incendiou. A Grande Punição atingiu cidades e caminhos, encerrando o horizonte da I Era. A numeração convencional próxima de 6400 não acrescenta um ano inteiro entre ruptura e catástrofe; os vinte e três dias constituem o intervalo narrado.



Guerra das Nove Vigílias



Sete campanhas nas quais a disputa pelo Selo desfez alianças entre cidades Eldenari, elfos altos e dragões.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Campanhas", "Sete, c. 6393–6399"], ["Encerramento da era", "c. 6400; ruptura e Punição separadas pelo intervalo narrado"]], "widths": [1, 3]}



Abertura e coalizões. Por volta de 6393, Maeriel retirou Serath da prisão. Zhaurak atacou a escolta e incendiou Vel-Samar, matando emissários protegidos. A resposta élfica reuniu cidades contrárias ao Selo; outras apoiaram Avar por convicção, dependência ou medo da perda de proteção. As coalizões nunca coincidiram perfeitamente com a origem dos povos.



Guerra sobre a vida comum. Fortalezas e observatórios foram tomados e retomados. A Casa das Medidas dividiu seus mapas entre ofensivas e proteção de localidades. O Círculo das Testemunhas conservou trocas de prisioneiros sob suspeita dos dois lados. Nas Pontes de Asmarith, impedir uma inundação significou renunciar a uma vantagem militar.



Rupturas dentro da guerra. As Cinzas de Uldar afastaram Khorvath de Zhaurak e levaram Saelith a retirar bênçãos. Vaelthar entrou no conflito após sofrer um ataque ao proteger uma delegação. A destruição de ninhos produziu perdas futuras que tornaram a reconciliação especialmente difícil entre os dragões.



A última campanha. No cerco de Xeo Taoju, em torno de 6399, Avar e Serath prepararam um desligamento. A mensagem de Maeriel a Caerion foi retida, e o mago ordenou uma intervenção sem conhecer o novo acordo. O ataque de Zhaurak coincidiu com as outras ações. A ruptura foi seguida por vinte e três dias de ocupação e pela Grande Punição, no limite convencional próximo de 6400.



Damar Esh



Sacerdote Eldenari que defendia a interpretação divina das aparições antigas.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era; antes da chegada dos elfos altos"], ["Povo", "Eldenari"], ["Atuação", "Sacerdócio e interpretação das manifestações"], ["Traço distintivo", "Barba branca curta e faixa azul profunda"], ["Vestimenta", "Linho marfim"], ["Posição", "Defesa do caráter divino das aparições"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



A autoridade das maravilhas. Damar Esh construiu uma escola influente ao tratar as manifestações e aparições como divinas. O crescimento dos relatos de Descompassos abriu espaço para sua interpretação. Sua posição oferecia uma explicação que comunidades e sacerdotes podiam incorporar à vida ritual.



A disputa com Nimea. Nimea Aral sustentava que produzir maravilhas não impedia uma entidade de mentir. O desacordo envolvia a maneira de recolher depoimentos e reconhecer autoridade. A influência de Damar não torna seus seguidores um grupo uniforme: havia pessoas em busca de proteção e dirigentes interessados em validar decisões.



Referência individual. Pele castanha escura, cabeça alongada, barba branca muito curta, olhos escuros e lábios cheios. Usava túnica de linho marfim com faixa azul profunda e uma placa de cerâmica ritual. A data anual de sua atuação continua indeterminada, anterior à chegada dos elfos altos nos relatos utilizados.



Hared Sen



Príncipe que procurou apoiar seu governo de Xeo Taoju no prestígio de uma criança oracular.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "c. 3400 da I Era; data disputada"], ["Povo", "Eldenari"], ["Atuação", "Príncipe de Xeo Taoju"], ["Traço distintivo", "Sinal escuro ao lado da boca"], ["Vestimenta", "Linho azul escuro; placas douradas"], ["Legado", "Disputa política pelo reconhecimento oracular"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Governo e oráculo. Apoiado por sacerdotes, Hared tentou transformar a criança em fundamento de autoridade política. O caso é situado por alguns estudiosos perto de 3400 da I Era, com diferenças de gerações entre cópias. O recorte conserva essa aproximação.



A mudança de acusação. Quando a criança contrariou o príncipe, o santuário foi fechado sob suspeita de influência velária. Documentos posteriores apontaram fraude dos tutores sem resolver a origem das visões. Uma tradição afirma que a criança sobreviveu com outro nome, mas seu destino permanece desconhecido.



Aparência e memória. Hared tinha rosto cheio, olhos pequenos muito próximos, cabelo preto liso penteado para trás e um sinal escuro ao lado da boca. Vestia linho azul escuro e colar de pequenas placas douradas. Seu caso reforçou entre comunidades cautelosas a preocupação de proteger a pessoa antes de reconhecer um título religioso.



Doutrina dos Sinais Cruzados



Práticas de confronto de testemunhos destinadas a dificultar fraudes no reconhecimento de Arautos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era e recepção posterior"], ["Tipo", "Prática de avaliação de reconhecimento"]], "widths": [1, 3]}



Testemunhos e biografia. Templos reuniam depoimentos independentes, previsões registradas antes dos resultados e informações da vida anterior ao reconhecimento. Uma cura, uma visão ou a capacidade de ouvir mortos exigiam interpretação em conjunto com a trajetória da pessoa.



Limites da verificação. A prática reduzia facilidades para fraude sem produzir uma certificação absoluta. Responsáveis podiam ser corrompidos, pressionados ou enganados. O reconhecimento de Ilyra e Oren teve formas de sustentação diferentes, enquanto a condição reivindicada por Avar permaneceu disputada.



Proteção e poder. O caso de Hared Sen expôs o uso político do título e da acusação de falsidade. Recomendava-se preservar depoimentos contrários no mesmo conjunto dos favoráveis. Essa defesa da comparação aproximava a doutrina dos métodos do Círculo das Testemunhas, sem fundir suas instituições.



Pacto das Três Testemunhas



Acordo de observação entre Eldenari, dragões e elfos altos para autorizar o experimento do Selo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Partes", "Eldenari, dragões e elfos altos"], ["Objeto", "Observação e condições da operação do Selo"]], "widths": [1, 3]}



Autorização e contrapartidas. O pacto reuniu observação de três tradições e exigiu medições independentes e intervalos para verificar a resposta das regiões. Caerion pediu um desligamento gradual diante de efeitos inesperados. Zhaurak condicionou sua adesão ao reconhecimento de seus domínios, enquanto Vaelthar permaneceu contrário à tentativa.



A pressa da operação. Avar e patrocinadores abreviaram etapas diante da fome. A decisão foi registrada em ata, inclusive com apoio de estudiosos que depois afirmariam tê-la combatido. A ampliação distingue a preservação de uma ata da capacidade real de suas testemunhas de suspender o trabalho.



Garantias destruídas. O ataque de Zhaurak matou emissários protegidos em Vel-Samar. Durante a guerra, os mecanismos de verificação foram desfeitos por suspeitas, bloqueios e violência. A demora da mensagem levada por Naeris Ul no final do conflito expõe a perda das condições que antes permitiam um acordo comum.



Incidente de Thar-Sen



Passagem de quarenta peregrinos que regressaram dezessete anos depois de viverem uma única noite.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era, antes da chegada dos elfos altos; ano indeterminado"], ["Intervalo relatado", "Uma noite para os peregrinos; dezessete anos fora"]], "widths": [1, 3]}



A procissão. Uma procissão seguiu luzes até um templo ausente na véspera. Quarenta peregrinos retornaram dezessete anos depois, afirmando ter vivido uma noite. Os efeitos foram diferentes: alguns trouxeram ensinamentos úteis e outros regressaram aterrorizados.



Vidas desencontradas. Os relatos acompanham o problema das obrigações interrompidas: famílias haviam reorganizado moradia e trabalho, enquanto os retornados ainda se orientavam pela noite da partida. O reconhecimento de uma pessoa não recompunha automaticamente o lugar que ela ocupara dezessete anos antes.



O nome de Veyr. Veyr foi associado ao episódio sem conclusão segura. A comparação de testemunhos integrou disputas sobre a autoridade das manifestações. O incidente antecede a chegada dos elfos altos nos relatos preservados, mas não recebe um ano inventado para preencher a cronologia.



Noite dos Dois Amanheceres



Descompasso observado por trabalhadores que passaram a discordar sobre os sete dias anteriores.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era, antes da chegada dos elfos altos; ano indeterminado"], ["Efeito relatado", "Divergências sobre sete dias de experiência"]], "widths": [1, 3]}



Dois sóis por um instante. Trabalhadores do Observatório relataram dois sóis surgindo brevemente. Depois, suas lembranças dos sete dias anteriores deixaram de concordar. O episódio afetou tanto o reconhecimento de experiências quanto a confiança nos registros usados para ordenar a vida do trabalho.



Registros e cobrança. A comparação de marcas de serviço, entregas e relatos domésticos como parte da investigação. A disputa sobre qual semana fora vivida também se tornava disputa sobre serviços e pagamentos. A conservação de versões diferentes permitia estudar o fenômeno sem exigir que todos aceitassem uma lembrança única.



Interpretações. O episódio pertence aos relatos anteriores à chegada dos elfos altos. Damar Esh e a tradição crítica ligada a Nimea oferecem formas diferentes de pensar as manifestações. A data anual e a causa exata continuam abertas; a aparição não estabelece a existência permanente de um segundo sol.



Primeira Era



Dragões, eldenari, elfos altos e os conflitos em torno da criação e da magia.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Duração estimada", "Cerca de 6.400 anos, com margem de incerteza"], ["Referência temporal", "I Era; limite convencional c. 6400"]], "widths": [1, 3]}



Um horizonte de longa duração. A Primeira Era reúne cerca de 6.400 anos na cronologia retrospectiva, com margem de incerteza. Seu início convencional acompanha a memória dos primeiros dragões. A criação dos planos pertence a um horizonte anterior à contagem, enquanto a formação de cidades, instituições e conflitos compõe a história da era.



Dragões e cidades Eldenari. Assentamentos Eldenari aparecem por volta de 2100 nos vales do Taoju e Asmarith. Xeo Taoju se consolida aproximadamente em 2550. Ilyra Seneth e Oren Namar ligam astronomia e memória a instituições duradouras. As relações com dragões variavam entre aprendizado, proteção e tributo; Conclaves e alianças não formavam um governo único.



Pesquisa e disputa social. Talena Ors e Edris Vaun investigaram transmissão e permanência material. A Casa das Medidas disputava calendários e cobrança, enquanto o Círculo das Testemunhas conservava relatos divergentes. A Paralisação dos Nove Pátios e, mais tarde, a Guerra dos Reparos mostram a importância política do trabalho que sustentava as pesquisas.



Chegada dos elfos altos. A Travessia das Sete Portas, por volta de 5990, trouxe Aelthir de Leth Avar. Arieth Ilvar conduziu refugiados que assumiram corpos materiais e se tornaram elfos altos. Caerion fundou a Ordem em Aethravel aproximadamente em 6035. O intercâmbio com os Eldenari aproximou técnicas e expôs divergências sobre intervenção nos planos.



A aposta no Selo. A crise de Elar-Tao ampliou a urgência de uma solução. Por volta de 6360, os Primeiros Magos organizaram sua disciplina comum. O Selo foi ativado em torno de 6384 e trouxe nove anos de estabilidade. O desvio para a Margem tornou essa conquista uma questão de responsabilidade diante de experiências e comunidades que suportavam seu custo.



Guerra, ruptura e catástrofe. As sete campanhas das Nove Vigílias são colocadas em torno de 6393–6399. A ruptura dispersou as peças do Selo, atingiu os Eldenari ligados à rede e foi seguida pela retirada dos dragões para Eshara. Após vinte e três dias de ocupação de Xeo Taoju, veio a Grande Punição. Suas causas permanecem discutidas, incluindo hipóteses sobre energia acumulada, Velários e tradições setentrionais.



Grande Punição



O acontecimento enigmático que encerra a Primeira Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Período", "Fim da Primeira Era"], ["Certeza", "Causas e extensão discutidas"], ["Referência temporal", "Fim da I Era, c. 6400"], ["Intervalo", "Após vinte e três dias de ocupação de Xeo Taoju"]], "widths": [1, 3]}



O fim de uma sequência. A Grande Punição veio após a ruptura do Selo e os vinte e três dias de ocupação de Xeo Taoju. No vigésimo quarto dia, o céu se incendiou. Fogo atingiu cidades, cinzas cobriram os céus e caminhos entre os planos foram rompidos. Caerion morreu protegendo refugiados que seguiam para o norte.



Hipóteses preservadas. Os cálculos de Serath apontavam um retorno tardio de energia acumulada na Margem. Relatos de luzes organizadas sugeriam intervenção velária; sacerdotes transmitiram proibições divinas de reabrir passagens. A tradição de Bergen associaria os Thul Verenari ao acontecimento, mas os fragmentos da I Era não demonstram essa participação ou a identidade do povo mencionado.



Terras e sobreviventes. Nenhum mapa confiável preservou todo o mundo anterior. Mudanças de costas, altitude e passagem entre terras são discutidas com evidências fragmentárias. Muitos Eldenari já haviam sido atingidos pela ruptura; sobrevivências dispersas e misturas posteriores tornam inadequada a ideia de desaparecimento absoluto do povo.



Um limite histórico. O fim da era é arredondado para cerca de 6400. A reconstrução conserva a ordem entre ruptura, ocupação e catástrofe sem introduzir um ano adicional entre elas. A ampliação do Registro permite detalhar consequências e experiências sem encerrar as hipóteses de causa numa explicação única.



Thul Verenari



Lenda setentrional de um povo antigo cuja existência permanece controversa.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Estado", "Existência não confirmada"], ["Região atribuída", "Extremo norte"], ["Referência temporal", "Tradição posterior sobre a I Era; relatos até a III Era"]], "widths": [1, 3]}



Uma tradição do extremo norte. Os Thul Verenari são descritos em relatos setentrionais como seres de cerca de um metro a um metro e vinte, pele clara azulada e grandes olhos negros amendoados. Atribuem-lhes afinidade com magia e tecnologia. Sua existência permanece controversa e sua localização é colocada além da região da Ordem.



A relação atribuída à I Era. A tradição de Bergen os aproxima da Grande Punição. As fontes antigas não demonstram se o nome correspondia a um povo existente, a uma classificação posterior de aparições ou à reunião de relatos distintos. O vínculo com a catástrofe pertence à história dessa atribuição.



Ampliação das leituras. Este recorte distingue uma leitura de intervenção, que procura ação organizada nas luzes, e uma leitura de transmissão, que investiga quando o nome passou a acompanhar o relato. São linhas de investigação dentro do universo, não descobertas de identidade. Elas permitem novas expedições e disputas sem transformar uma imagem em prova.



Aparência nos relatos. A ilustração representa a tradição descritiva: figura pequena, pele azulada e grandes olhos negros. Vestimentas e objeto geométrico são recursos interpretativos, sem confirmar material, função ou participação na Punição. A convicção de um viajante integra seu testemunho, com o valor e os limites desse contexto.



Ordem dos Magos



Instituição setentrional de estudo, proteção e disputa pelo controle do conhecimento.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Centro", "Aethravel"], ["Leitura", "Anais da Ordem dos Magos"]], "widths": [1, 3]}



Responsabilidades pelo isolamento. A abertura da Ordem a pesquisadores de diferentes povos convive com disputas de acesso e autoridade. O isolamento de 731 exige distinguir autorização, execução, alteração de registros, conhecimento posterior e contestação.



Na história política de Vaelen Endor. Selvar II é imperador entre 2078 e 2149 da II Era. A correspondência de Tessia com a Mesa dos Instrumentos Reservados é datada em 2093, sem fixar a descoberta da Agulha. O processo de Leva Senn na Controvérsia do Espelho é situado em 2101. Aren Voss recusa condenação por possibilidade futura.



A fundação e seus dilemas. Caerion Thalas fundou a Ordem por volta de 6035 em Aethravel, sob proteção de Arieth Ilvar. A Mesa das Portas podia suspender trabalhos e exigir registros. Maeriel Sorn sustentou o intercâmbio com os Eldenari. A crise do Selo expôs o limite de procedimentos que dependiam de confiança entre comunidades em guerra.



Aethravel



Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Reino / estado", "Reino de Aelvar"], ["Instituição", "Ordem dos Magos"], ["Acesso", "Controlado"]], "widths": [1, 3]}



Descrição. Aethravel reúne sede e instalações de estudo da Ordem dos Magos. Situa-se no extremo norte do circuito de Aelvar, mas não deve ser tratada como outra denominação da corte de Emvale.



Descrição. O caminho de abastecimento atravessa setor chamado Serra das Duas Vigílias. Frio, queda de pedra e condição dos animais afetam o percurso, mesmo quando um mapa geral não desenha cada curva.



Descrição. A Ordem admite não elfos como membros plenos desde a Carta das Mãos Abertas de 326. Isso não converte laboratórios e arquivos reservados em visitas públicas; referência, formação e autorização continuam relevantes.



Aethravel na I Era. A fortaleza recebeu a associação fundada por Caerion Thalas. Seus trabalhos reuniam cuidadores de passagens, conservadores de instrumentos e estudiosos. A Mesa das Portas examinava intervenções e podia exigir suspensão. O fim da era destruiu parte dos registros e dos instrumentos que sustentavam esses procedimentos.



Xeo Taoju



Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Reino / estado", "Quinder"], ["Função", "Capital"], ["Rio", "Taoju"], ["Patrimônio", "Zigurate, observatório, Pátio das Nove Sombras"], ["Irrigação", "Conselho das Duas Margens, 734"]], "widths": [1, 3]}



Capital junto ao Taoju. Xeo Taoju é a capital de Quinder e sede de Selyra Naereth. Bairros, hortas e oficinas se articulam com a irrigação do Taoju. Essa faixa cultivada pertence a uma região que passa de campos verdes a terrenos mais secos: água, sombra e áreas expostas fazem parte da paisagem da capital.



Patrimônio e restauro. O Zigurate das Nove Vigílias, o Observatório de Ilyra, o Pátio das Nove Sombras e os Arcos de Saelith marcam a visita. Construções Eldenari receberam reparos e usos posteriores. A Oficina dos Arcos, reconhecida em 758, protege fragmentos inscritos e disputa contratos de conservação. Humanos e elfos negros colaboram e concorrem pelas encomendas.



A cidade em 788. O Conselho das Duas Margens recebe pedidos de irrigação, mas seus assentos favorecem grandes propriedades, santuários e corporações. Moradores e trabalhadores mantêm a cidade além do circuito monumental. Nerion Fales divulga seus atrativos no Guia dos Viajantes de 788; o elogio à sua beleza é opinião de viajante. A tradição da décima sombra no Pátio permanece não confirmada.



Cotidiano. Nas margens do Taoju, o restauro do patrimônio Eldenari convive com a circulação diária. Oficinas e trabalhos de conservação ocupam a mesma cidade por onde passam moradores, cargas e viajantes.



Patrimônio em uso. A Oficina dos Arcos, reconhecida em 758 da III Era, denuncia a incorporação de fragmentos inscritos em casas privadas. Seus membros também disputam contratos de restauro, num debate em que conservação e remuneração se cruzam.



A cidade antes da Grande Punição. A consolidação urbana é situada por volta de 2550 da I Era. Calendários, irrigação e oficinas sustentavam a vida Eldenari. O Zigurate recebeu o Selo em torno de 6384 e tornou-se centro da guerra final. Após a ruptura, a cidade viveu vinte e três dias de ocupação e socorro antes da Grande Punição.



Samarith



Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Reino", "Quinder"], ["Instituição", "Torre do Grande Pombo"], ["Rio", "Asmarith"], ["Marco histórico", "Acordo das Lâmpadas, 2429 da II Era"], ["Grande Pombo", "Calven IX"]], "widths": [1, 3]}



A cidade e o Asmarith. Samarith ocupa o corredor do Asmarith, em Quinder. Cais, hospedarias e mercados acompanham barcas e peregrinos. A água sustenta trechos cultivados num reino que passa de campos verdes a áreas mais secas. A Torre Sagrada é sua grande referência religiosa; moradores humanos e élficos negros compartilham trabalho, vizinhança e cerimônias.



A sede do Grande Pombo. Em 1398 da II Era, o Concílio das Sete Portas estabeleceu a comunhão dos Sete. Após a conquista, o Acordo das Lâmpadas de 2429 preservou o Grande Pombo, arquivos, santuários e peregrinação. A Torre conservou competências religiosas e privilégios dentro da soberania de Quinder, reunindo interesses de culto, comércio e reconhecimento político.



Samarith no início de 788. Calven IX ocupa o posto de Grande Pombo, enquanto Selyra Naereth mantém a autoridade civil. Procissões, taxas e escoltas exigem negociação. Ayak oferece conexão com o norte pela navegação e pelas estradas. Fora do recinto principal, O Pombo Torto, de Lethra Noll, recebe peregrinos em quartos comuns e cubículos familiares, com refeições, notícias e regras próprias.



Cotidiano. Viajantes que chegam pelos caminhos de Quinder encontram pouso no Pombo Torto, a estalagem de Lethra Noll. A Torre do Grande Pombo dá outra referência a quem circula pela cidade.



A cidade em dia de cerimônia. O movimento da Torre muda a circulação no bairro. Perto dali, o Pombo Torto oferece quartos comuns e cubículos para famílias. O Guia registra caldo de grãos com cebola tostada e pão achatado nos dias de maior movimento.



Memória e estudos da I Era. A Casa dos Nomes fundada por Oren Namar e as galerias da futura Torre Sagrada vinculavam Samarith ao cuidado da memória. Na Câmara do Limiar, observar os mortos não autorizava retê-los. Cópias dos Cadernos de Permanência de Talena Ors circularam na cidade e conservaram diferenças entre observação e comentário.



Ilyra Seneth



Astrônoma Eldenari da I Era, associada ao primeiro calendário celeste preservado em Xeo Taoju.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Nome", "Ilyra Seneth"], ["Povo", "Eldenari"], ["Período", "I Era"], ["Atuação", "Astronomia e calendário celeste"], ["Marco documentado", "c. 2700 da I Era"], ["Lugar associado", "Xeo Taoju; Observatório de Ilyra"], ["Referência temporal", "I Era"]], "widths": [1, 3]}



Astronomia em Xeo Taoju. Por volta de 2700 da I Era, Ilyra Seneth estabeleceu em Xeo Taoju o primeiro calendário celeste preservado. Seus registros reuniam previsões corretas, erros e correções. O Observatório de Ilyra conserva sua tradição de tornar o céu compreensível pela observação e pelo cálculo.



O reconhecimento de Asterion. Entre os Eldenari, Ilyra foi reconhecida como a primeira Arauto de Asterion. Seus seguidores atribuíram a muitos cálculos uma infalibilidade que ela própria contestava. A avaliação desse reconhecimento variou entre escolas e tradições.



Traços e temperamento. Tinha cabelos muito claros, olhos de cores ligeiramente diferentes e o hábito de bater três vezes na mesa antes de aceitar um cálculo. Sua curiosidade vinha acompanhada de impaciência com ritmos de trabalho mais lentos. Avar Seneth, especialista em tempo entre os Primeiros Magos, era seu descendente.



Um legado disputado. Avar Seneth, seu descendente, procurou dar ao mundo um calendário que jamais falhasse. Sua ambição retomou a autoridade do conhecimento celeste, mas também expôs os riscos de transformar a correção de um cálculo numa missão exclusiva. A pesquisa de Ilyra havia preservado erros e revisões que seguidores por vezes apagavam ao tratá-la como profetisa infalível.



Oren Namar



Sacerdote Eldenari da I Era e fundador da Casa dos Nomes, em Samarith.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Nome", "Oren Namar"], ["Povo", "Eldenari"], ["Período", "I Era"], ["Atuação", "Sacerdócio e preservação dos nomes"], ["Marco documentado", "c. 2760 da I Era"], ["Lugar associado", "Casa dos Nomes, em Samarith"], ["Referência temporal", "I Era"]], "widths": [1, 3]}



A Casa dos Nomes. Oren Namar fundou por volta de 2760 da I Era a Casa dos Nomes, em Samarith. Ali se registravam os mortos para conservar seus nomes na memória coletiva. A guarda dos arquivos tornou-se parte de seu compromisso religioso e público.



Memória e autoridade. Reconhecido como Arauto de Nereth, Oren recusou a ordem de um rei para apagar dos registros os nomes de uma cidade rebelada. Morreu defendendo seus arquivos. Documentos de cidades rivais preservaram relatos sobre experiências associadas a ele.



Traços e temperamento. Era largo de ombros e usava uma túnica remendada mesmo quando passou a administrar recursos. Guardava pequenas placas com os nomes que receava esquecer. Afável nas conversas privadas, tornava-se inflexível diante de pedidos de exceção aos registros.



A continuidade dos nomes. A defesa dos arquivos confrontou a ordem de apagar uma cidade rebelada. Oren morreu protegendo os registros. A Casa dos Nomes permaneceu ligada ao princípio de que poder político não concede direito de eliminar uma vida da memória.

## 40. Implantação da Primeira Era e manutenção da base



Wikia 0.32: 615 artigos, 182 marcos e 83 vínculos. O lote acrescenta 55 artigos, amplia os artigos centrais e conecta os dez marcos já existentes da I Era. O recorte tem entrada própria e referências ao Registro.



Lugares de Eomundus, localidades de posição antiga incerta e o refúgio lunar não recebem coordenadas no mapa material de 788. Retratos e composições são referências em fantasia estilizada, com diferenças individuais. A representação dos Thul Verenari ilustra a tradição, sem confirmar sua existência.

## 41. Thul Verenari: verdade do cenário e limites do conhecimento

Decisão autoral vigente e precedência

Esta decisão substitui o limite de confirmação de RC-P08 e a parte correspondente de RC-IE00. Os capítulos anteriores são conservados como histórico de edição. Afirmações de desconhecimento nos relatos históricos passam a descrever o conhecimento dos habitantes, sem negar os fatos autorais definidos aqui.

### RC-TV01 — Existência real e conhecimento dos povos

Os Thul Verenari existem. Os habitantes de Virtude, em geral, conhecem apenas lendas e testemunhos ocasionais ou rejeitam sua existência. O conhecimento de personagens não deve ser confundido com a verdade autoral do cenário.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV02 — Aparência vigente

Anatomia semelhante a um gray, com pele azulada, cabeça lisa sem cabelo, sem orelhas e sem nariz, boca pequena e olhos grandes, negros e amendoados. Preserva-se o porte de cerca de um metro a um metro e vinte. A imagem é substituída para retirar os traços élficos anteriores.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV03 — Origem, tecnologia e telepatia

Origem desconhecida, possivelmente exterior ao planeta de Virtude; a procedência extraplanetária não é confirmada como fato. Tecnologia extremamente avançada e comunicação telepática são fatos. Tecnologia, tempo e mente são interesses centrais.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV04 — Autoria e motivação da Grande Punição

A Grande Punição foi um ataque nuclear dos Thul Verenari contra Virtude. Eles avaliaram que o caos do planeta chamava a atenção de inteligências extraterrestres ameaçadoras e decidiram intervir. Essa avaliação é a motivação deles; identidade das inteligências e ameaça iminente não ficam automaticamente comprovadas. A população de Virtude desconhece a natureza nuclear, a autoria e a intenção do ataque. Não se alteram a ruptura anterior do Selo e o intervalo de vinte e três dias de ocupação.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV05 — Vigilância setentrional

Após a intervenção, os Thul se ocultaram no extremo norte do planeta para vigiar sua evolução, os Descompassos e os temas tecnológicos, temporais e mentais. São pragmáticos e discretos. Sua presença real não atribui automaticamente a eles todos os fenômenos do norte.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV06 — Bergen, rumores e acesso à informação

Luzes e aparições ocasionais sustentam relatos em Bergen. Os habitantes não conhecem realmente esse povo. A localização precisa das instalações não é publicada no atlas como conhecimento corrente. Os artigos distinguem informações públicas no mundo e verdade reservada do cenário.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.



Thul Verenari — dossiê vigente



Existência e conhecimento. Os Thul Verenari existem no universo de Virtude. Para os habitantes do planeta, porém, seu nome pertence sobretudo às lendas do extremo norte. Há quem o associe a aparições e luzes, quem rejeite sua existência e quem reúna relatos sem conseguir identificar com segurança os observados. A verdade do cenário e o conhecimento de suas sociedades são distintos.



Aparência. São pequenos e esguios, com cabeça relativamente grande, pele azulada e superfície craniana lisa. Não possuem cabelo, orelhas ou nariz. A boca é pequena e os olhos negros são grandes e amendoados.



Relatos do norte. Em Bergen, observadores ocasionalmente veem luzes ou encontram uma figura que não sabem explicar. Aparições isoladas podem se transformar em histórias contraditórias ao circular entre postos, viajantes e comunidades. Esses testemunhos compõem o conhecimento local; não fornecem aos reinos uma compreensão da organização, dos recursos ou dos propósitos desse povo.



Origem e comunicação. A origem dos Thul Verenari permanece desconhecida. A possibilidade de terem vindo de fora do planeta de Virtude integra o cânone como hipótese, sem planeta natal ou percurso de chegada estabelecidos. Possuem tecnologia extremamente avançada e comunicam-se por telepatia. Seu interesse se concentra especialmente em tecnologia, tempo e mente.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.



Vigilância no extremo norte. Depois da intervenção, os Thul Verenari se ocultaram no extremo norte do planeta para acompanhar o andamento de Virtude, os Descompassos e as transformações tecnológicas, temporais e mentais. São extremamente discretos e pragmáticos. Luzes e aparições ocasionais em Bergen podem decorrer dessa presença, sem que todo incidente setentrional seja automaticamente atribuído a eles. A localização precisa de suas instalações não é conhecida pelos povos do cenário.



Grande Punição — dossiê vigente



O fim de uma sequência. A Grande Punição veio após a ruptura do Selo e os vinte e três dias de ocupação de Xeo Taoju. No vigésimo quarto dia, o céu se incendiou. Fogo atingiu cidades, cinzas cobriram os céus e caminhos entre os planos foram rompidos. Caerion morreu protegendo refugiados que seguiam para o norte.



Interpretações dos sobreviventes. Os cálculos de Serath apontavam um retorno tardio de energia acumulada na Margem. Relatos de luzes organizadas sugeriam intervenção velária; sacerdotes transmitiram proibições divinas de reabrir passagens. A tradição de Bergen associaria os Thul Verenari ao acontecimento. Essas interpretações integram a história dos povos de Virtude, que desconhecem a natureza e os responsáveis pela catástrofe.



Terras e sobreviventes. Nenhum mapa confiável preservou todo o mundo anterior. Mudanças de costas, altitude e passagem entre terras são discutidas com evidências fragmentárias. Muitos Eldenari já haviam sido atingidos pela ruptura; sobrevivências dispersas e misturas posteriores tornam inadequada a ideia de desaparecimento absoluto do povo.



O limite entre as eras. O fim da era é arredondado para cerca de 6400. A sequência conserva a ruptura do Selo, os vinte e três dias de ocupação de Xeo Taoju e, no vigésimo quarto dia, a Grande Punição. O desconhecimento dos sobreviventes sobre a catástrofe não significa ausência de uma causa definida na verdade do cenário.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.

## 42. Aelthir: aparência, vínculos e travessia

Continuidade de aparência

Os Aelthir possuem aparência idêntica à dos elfos altos, apenas mais etérea em Eomundus. Esta definição orienta toda descrição e ilustração atual ou futura, preservando traços pessoais antes e depois da Travessia.

### RC-AT01 — Aparência dos Aelthir

Mesma anatomia, fisionomia, proporções, orelhas e diversidade individual dos elfos altos. Em Eomundus, apenas presença mais etérea por luz e contornos. A Travessia não troca os traços da pessoa. Não inventar órgãos, mudar cor de pele ou cabelo na Travessia, impor transparência ou deformar a anatomia para marcar a diferença.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT02 — Reconhecimento e vida comunitária

Casas de Reconhecimento conservam relações, objetos e testemunhos, sem impor uma identidade por versão única. As práticas e os conflitos descritos nos dossiês são adotados.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT03 — Guardiões das Soleiras

Cuidadores de passagens, buscas e condições de retorno; função comunitária que não equivale a comando automático da futura Ordem.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT04 — Ilenya Saar

Nova personagem Aelthir, depois elfa alta, com a mesma fisionomia nos dois planos. Cuida de vínculos, participa da Travessia e das negociações de acolhimento. Traços, roupas e trajetória do dossiê são vigentes.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT05 — Acordo das Soleiras

Novo marco situado em c. 6002 da I Era, entre postos de Aston e Emvale, com participação de Arieth e Ilenya. Organiza mantimentos, turnos e transmissão de informações sem condicionar ajuda a obediência presumida.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT06 — Adaptação material

A mudança é ontológica e envolve perda de capacidades e adaptação à vida material, preservando a aparência de elfo alto. Práticas de passagem, acolhimento e consentimento contribuem para o ambiente de formação da Ordem sem fundir todas as instituições.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.



Aelthir e a chegada dos elfos altos



Comunidades de Eomundus com a mesma aparência dos elfos altos, envoltas em uma presença mais etérea; sua travessia para Virtude marcou a origem material desse povo.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Origem", "Eomundus"], ["Travessia", "c. 5990 da I Era"], ["Transformação", "Corpos materiais; origem dos elfos altos"], ["Longevidade material", "Muitos séculos; raramente mais de um milênio"], ["Aparência", "Idêntica à dos elfos altos; presença mais etérea em Eomundus"], ["Travessia e fisionomia", "Mesmos traços individuais antes e depois"], ["Comunidades", "Casas de Reconhecimento e redes de passagem"]], "widths": [1, 3]}



Aparência e presença. Os Aelthir têm a mesma aparência dos elfos altos: rostos, corpos, proporções e orelhas pontudas seguem a mesma anatomia. Conservam diferenças individuais de pele, olhos, cabelo, idade e constituição. Em Eomundus, sua presença é mais etérea, percebida na luz suave e na menor firmeza dos contornos. Ao atravessar, a pessoa conserva sua fisionomia; a materialidade se torna mais estável.



Comunidades de Leth Avar. A vida em Leth Avar se organizava em torno de vínculos reconhecidos por outras pessoas. Casas, jardins e oficinas podiam mudar de acesso quando a memória de seus habitantes se alterava. As Casas de Reconhecimento conservavam objetos de uso, relatos de convivência e tarefas compartilhadas. O valor de um objeto estava na relação que ajudava a recordar: uma peça modesta podia sustentar mais reconhecimento que uma joia sem história.



Nomes e responsabilidade. Um nome era acompanhado por relações: quem o utilizava, quem o havia recebido e quais compromissos lembrava. Em períodos de instabilidade, os Aelthir evitavam decidir uma identidade por um único testemunho. Quem não reconhecia a própria casa podia ser acolhido sem precisar aceitar imediatamente a versão dos demais. Essa cautela protegia pessoas e também produzia disputas quando famílias reivindicavam vínculos incompatíveis.



Guardiões e caminhos. Os Guardiões das Soleiras cuidavam das condições de passagem. Reuniam relatos sobre acessos, procuravam viajantes e mantinham contato entre comunidades. Seu conhecimento dependia de observar mudanças e escutar quem atravessara. Um caminho conhecido podia deixar de servir à mesma família, tornando a promessa de retorno uma responsabilidade difícil de garantir.



A crise e a Travessia. Quando Leth Avar perdeu estabilidade, nomes e cidades deixaram de conservar relações suficientes para uma vida comum. Arieth Ilvar manteve postos de acolhimento e conduziu refugiados durante a Travessia das Sete Portas, situada por volta de 5990 da I Era. Ilenya Saar acompanhou famílias e conservou objetos de reconhecimento. A chegada a Virtude exigiu aprender a conviver com corpos e recursos de duração mais estável.



A vida material. Alimento, abrigo e conservação de ferramentas passaram a exigir estoques, trabalho e acordos que continuavam válidos mesmo quando alguém esquecia sua origem. O Acordo das Soleiras, por volta de 6002, organizou práticas de acolhimento entre postos de Aston e Emvale. O cuidado deixou de depender apenas da lembrança pessoal de um protetor. Algumas famílias receavam que registrar vínculos em nome do acolhimento também permitisse controlar seus movimentos.



O que atravessou com eles. A transformação em elfos altos preservou pessoas, divergências e parte das práticas das comunidades anteriores. Cuidar de passagens, conservar testemunhos e perguntar quem podia consentir numa intervenção contribuíram para o ambiente em que Caerion Thalas fundou a Ordem. A experiência do exílio continuou a ser lembrada de modos diferentes: como sobrevivência, perda de capacidades ou aceitação de uma existência menos vulnerável às mudanças do Entrelaço.



Leth Avar



Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Localização histórica", "Eomundus"], ["Tipo", "Localidade histórica da I Era"], ["Precisão cartográfica", "Sem posição no atlas material de 788"]], "widths": [1, 3]}



Paisagem e função. A perda de estabilidade atingia nomes, formas e a vida em comum. Cidades mudavam segundo os sonhos de seus habitantes, tornando a memória uma condição incerta de orientação. A crise preparou a decisão de procurar corpos e caminhos mais estáveis em Virtude.



Vida e práticas locais. Havia pátios de reconhecimento onde famílias repetiam nomes, vínculos e tarefas antes de uma partida. A prática ajudava a reunir pessoas quando uma casa já não conservava a aparência da véspera. Objetos de uso cotidiano podiam servir como apoio de reconhecimento, sem garantir que uma identidade fosse restaurada.



Memória e situação histórica. A Travessia das Sete Portas reduziu o acesso à região. O temor de Arieth de não encontrar ninguém a quem devolver o caminho expressa a perda envolvida no acolhimento. Leth Avar pertence ao Entrelaço e não recebe coordenadas no mapa material de 788.



Continuidade das pessoas. As mudanças de Leth Avar atingiam vínculos, acessos e reconhecimento. Os Aelthir conservavam a aparência de elfos altos, com presença mais etérea no Entrelaço. A perda de estabilidade do lugar não estabelece uma anatomia diferente para seus habitantes.



Pátios e cuidado. As Casas de Reconhecimento e os Guardiões das Soleiras mantinham formas complementares de cuidado. Nos pátios, conservavam-se objetos e relatos de convivência; nos caminhos, comparavam-se condições de acesso e retorno. Durante a crise, a decisão de abandonar uma rota podia separar famílias e dividir responsáveis pelo mesmo abrigo.



Arieth Ilvar



Regente da Travessia na história da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Aelthir; depois elfa alta"], ["Atuação", "Regente da Travessia"], ["Sinais distintivos", "Rosto longo, pele escura e mecha branca trançada junto à têmpora."], ["Período", "I Era"], ["Vínculos principais", "Aelthir e a chegada dos elfos altos; Leth Avar"], ["Condição histórica", "Figura histórica da I Era"]], "widths": [1, 3]}



Trajetória e escolhas. Conduziu famílias de Leth Avar durante a Travessia das Sete Portas. Sua autoridade era marcada pela responsabilidade diante das pessoas que aceitara guiar. Manteve postos de acolhimento quando parte do conselho defendia fechar a passagem.



Vínculos e conflitos. A chegada exigiu organizar abrigo e recursos para corpos sujeitos a novas condições materiais. A regente protegeu a associação de estudiosos que Caerion transformaria na Ordem dos Magos. O consentimento nas intervenções e a conservação de conhecimentos de passagem pertencem a esse contexto.



Legado e limites do registro. Temia receber uma delegação que exigisse o retorno e descobrir que não restara ninguém a quem devolver o caminho. As fontes não estabelecem aqui uma data de morte ou uma sucessão completa de sua regência.



Aparência e presença. Arieth conservou rosto longo, pele escura e mecha branca trançada junto à têmpora antes e depois da Travessia. Em Eomundus, sua presença era mais etérea; em Virtude, seus traços de elfa alta adquiriram a firmeza da condição material.



Casas de Reconhecimento



Redes comunitárias de Leth Avar dedicadas ao acolhimento e à continuidade de vínculos.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Origem", "Leth Avar, em Eomundus"], ["Atividade", "Acolhimento e conservação de vínculos"]], "widths": [1, 3]}



Casas e convivência. Uma Casa de Reconhecimento reunia pessoas que se responsabilizavam por recordar umas às outras. Podia ocupar um pátio, uma oficina ou mais de uma residência. Ferramentas, tecidos reparados e refeições compartilhadas ajudavam a reconhecer uma história de convivência, mesmo quando o acesso a uma casa havia mudado.



Conservar sem impor. As Casas comparavam testemunhos e admitiam que um vínculo permanecesse em dúvida. Ilenya Saar defendia acolher a pessoa antes de resolver todas as versões sobre sua identidade. Essa prática enfrentava resistência de famílias que temiam perder autoridade ou responsabilidades antigas. A lembrança de um compromisso podia sustentar auxílio e também servir para exigir obediência.



Depois da partida. Na Travessia, pequenos conjuntos de objetos acompanharam famílias e grupos de cuidado. A perda de uma caixa podia significar a perda de uma forma de provar reconhecimento, sem apagar automaticamente a pessoa. Em Virtude, práticas das Casas foram adaptadas a listas, estoques e turnos de acolhimento. A solidariedade precisava funcionar entre pessoas que ainda não possuíam lembranças comuns.



Guardiões das Soleiras



Cuidadores Aelthir dos caminhos, encontros e condições de retorno entre comunidades.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Origem", "Comunidades Aelthir"], ["Atividade", "Passagens, buscas e retorno"]], "widths": [1, 3]}



Um trabalho de passagem. Os Guardiões das Soleiras observavam como acessos respondiam a nomes, compromissos e mudanças da paisagem de Eomundus. Acompanhavam viajantes e recolhiam descrições de encontros. Sua atividade exigia conhecer pessoas e relações de vizinhança, além de reconhecer arcos e caminhos.



Dever e conflito. Um guardião podia manter uma rota aberta para receber alguém atrasado e, com isso, expor outras famílias a uma passagem instável. Durante a crise de Leth Avar, grupos discordaram sobre quando interromper buscas e concentrar recursos na saída. Arieth Ilvar apoiou a continuidade dos postos de acolhimento diante de pressões para fechá-los.



Memória em Virtude. Alguns cuidadores continuaram a trabalhar nos postos da chegada, onde uma soleira passou a designar também a entrada de um abrigo. Seus conhecimentos sobre passagens contribuíram para práticas de conservação adotadas mais tarde por estudiosos da Ordem. A antiga função não conferia automaticamente cargo ou autoridade na nova instituição.



Ilenya Saar



Cuidadora Aelthir das Casas de Reconhecimento, participante da Travessia e do acolhimento nas comunidades setentrionais.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era"], ["Povo", "Aelthir; depois elfa alta"], ["Atuação", "Acolhimento e memória comunitária"], ["Marco", "Travessia; acordo de c. 6002 da I Era"], ["Sinais distintivos", "Cabelo negro encaracolado; olhos castanhos caídos"], ["Vestimenta", "Linho verde-musgo; cordão de objetos familiares"], ["Aparência", "Mesma anatomia e fisionomia de elfa alta; presença etérea em Eomundus"]], "widths": [1, 3]}



Um rosto a reconhecer. Ilenya tinha pele castanha acobreada, rosto oval de queixo arredondado, nariz curto e olhos castanhos ligeiramente caídos. Prendia os cabelos negros muito encaracolados com uma tira de tecido. Usava linho verde-musgo e um cordão com pequenos objetos de família. Em Eomundus, a luz de seus contornos era mais etérea; depois da Travessia, sua fisionomia permaneceu a mesma.



As caixas de convivência. Trabalhou nas Casas de Reconhecimento conservando pequenos conjuntos de utensílios e relatos familiares. Sua paciência tinha um limite claro: contrariava dirigentes que tratavam uma versão discordante como prova de que o acolhido perdera o direito de falar por si. A convicção lhe custou apoio de algumas famílias que antes lhe confiavam objetos e crianças.



A Travessia e os postos. Acompanhou refugiados de Leth Avar e colaborou com o acolhimento protegido por Arieth. Em Virtude, precisou aceitar que objetos preservados já não resolviam falta de comida ou abrigo. Defendeu turnos de cuidado e reservas identificadas antes de novas promessas de acolhimento. Participou das negociações do Acordo das Soleiras por volta de 6002 da I Era.



Uma memória em disputa. Ilenya procurou conservar relatos de quem desejara atravessar e de quem partira por não ter outra saída. A diferença incomodava narrativas que apresentavam a mudança como escolha unânime. Seus registros transmitiram perdas e ressentimentos junto aos exemplos de cooperação, deixando a história da chegada aberta à experiência de pessoas diferentes.



Acordo das Soleiras



Acordo de acolhimento das comunidades da chegada, situado por volta de 6002 da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "c. 6002 da I Era"], ["Precisão", "Aproximada"], ["Tipo", "Acolhimento e acordo comunitário"]], "widths": [1, 3]}



Depois da saída. As comunidades que receberam os Aelthir em Aston e Emvale enfrentaram demandas de abrigo e alimento que se prolongavam além de promessas pessoais. Famílias reconhecidas numa rota podiam chegar a um posto onde ninguém conhecia seus vínculos. O cuidado precisava acompanhar pessoas através de uma rede de abrigos.



O que foi acordado. O Acordo das Soleiras articulou reservas de mantimentos, turnos de cuidado e transmissão de informações entre postos. Ilenya Saar participou das negociações sob a proteção política de Arieth Ilvar. O acesso ao auxílio não dependia de o acolhido aceitar imediatamente uma genealogia ou um compromisso alegado por outros.



Os limites do registro. Listas facilitavam o trabalho, mas criavam poder sobre a circulação e as obrigações dos refugiados. Parte dos negociadores receava que a hospitalidade se transformasse numa dívida permanente. O acordo procurou manter separadas a responsabilidade de alimentar alguém e a decisão sobre a quem essa pessoa devia obediência. Suas práticas influenciaram debates posteriores sobre consentimento e conservação de testemunhos.



Eomundus



O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Natureza do registro", "Definição do cenário"], ["Referência temporal", "Antes da contagem das eras"]], "widths": [1, 3]}



O Entrelaço. Eomundus aproxima possibilidades e vidas delimitadas. Seus caminhos respondem a expectativas, lembranças e vínculos, de modo que duas viagens pelo mesmo arco podem levar a encontros diferentes. Orientar-se envolve compreender relações de acesso, além de reconhecer formas da paisagem.



Povos e presenças. Os Aelthir, ancestrais dos elfos, os Namar que acompanham consciências após a morte e os Velários pertencem às descrições do Entrelaço. Ishrael, Oruven e Veyr, o Cortês, aparecem em narrativas de transformação, passagem e hospitalidade. A identidade por trás desses nomes varia entre os relatos.



Lugares e compromissos. A Enseada das Promessas e o Patamar dos Ecos exemplificam lugares cuja travessia depende da história do viajante. Seus mapas registram condições de encontro e retorno. Um compromisso reconhecido por outros pode orientar o caminho por mais tempo que uma intenção passageira, e a entrada em Eomundus nunca equivale a controle completo sobre sua paisagem.



Os Aelthir do Entrelaço. Os Aelthir possuíam os mesmos traços físicos dos elfos altos, com uma presença mais etérea em Eomundus. A ligação entre identidade e paisagem atravessava sua vida comunitária, sem eliminar diferenças pessoais. As Casas de Reconhecimento de Leth Avar e os Guardiões das Soleiras cuidavam de relações que a instabilidade tornaria difíceis de conservar.



Travessia das Sete Portas



Os Aelthir chegaram de Eomundus durante a Travessia das Sete Portas, situada por aproximação em 5990 da I Era.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Data", "c. 5990 da I Era"], ["Era", "I Era"], ["Tipo", "História e sociedade"], ["Precisão", "Aproximada"], ["Natureza da evidência", "Reconstrução aproximada"], ["Referência temporal", "c. 5990 da I Era"]], "widths": [1, 3]}



Data e natureza do registro. Concordância de relatos élficos. A indicação “c.” conserva uma datação aproximada; ela não deve ser convertida em aniversário ou dia exato.



Relato e contexto. Os Aelthir chegaram de Eomundus durante a Travessia das Sete Portas, situada por aproximação em 5990 da I Era. Uma região do Entrelaço, chamada Leth Avar, vinha perdendo estabilidade: pessoas esqueciam o próprio nome e cidades inteiras mudavam de forma conforme os sonhos de quem dormia nelas. A regente Arieth Ilvar conduziu os refugiados até Virtude. Ao aceitarem corpos materiais, perderam parte de suas antigas capacidades e tornaram-se os elfos altos.



Percursos e consequências. Este marco se relaciona a Aelthir e a chegada dos elfos altos, Arieth Ilvar, Leth Avar. Os artigos associados apresentam as trajetórias, decisões e efeitos locais do acontecimento.



A fisionomia na Travessia. A passagem para Virtude preservou rostos, proporções e traços individuais dos Aelthir. A aparência era a dos elfos altos; a condição mais etérea de Eomundus cedeu lugar à estabilidade material. O acolhimento posterior é tratado no Acordo das Soleiras.

## 43. Thul Verenari: vigilância, telepatia e registros



As decisões RC-TV01–06 permanecem vigentes. Existência, aparência azulada sem nariz ou orelhas, tecnologia avançada, telepatia, ataque nuclear e vigilância não são revogados. Origem possivelmente extraplanetária e avaliação de ameaça continuam com os limites já definidos.

### RC-TV07 — Organização da Vigília e discrição

Vigília Setentrional e Ecos Silenciosos passam a designar a organização de observação e seus procedimentos. Há funções diferentes, registros de responsabilidade e divergências sobre intervenção. Não se fixa capital, governo completo ou origem exterior ao planeta.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV08 — Telepatia e individualidade

Comunicação telepática permite compartilhar impressões, intenções e imagens em graus distintos, sem estabelecer mente coletiva única ou controle automático dos habitantes. Os observadores conservam interpretações próprias.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV09 — Janelas de Escuta

Instrumentos comparam registros de Descompassos, mana, artefatos e instalações. Tecnologia avançada não elimina a necessidade de interpretar contexto e diferenciar perda de observação de ausência do fenômeno.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV10 — Causa reservada do episódio de 785

O campo sem gelo e o ruído sob a neve registrados por Haldren Vesk em 785 da III Era decorreram da retirada de um captador Thul. Não houve reconhecimento de sua natureza pelo capitão; a inspeção posterior continuou sem objeto ou prova disponível a Bergen. Não se generaliza essa causa a todo incidente setentrional.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.



Thul Verenari



Povo de tecnologia extremamente avançada, associado às lendas do extremo norte e às luzes observadas em Bergen.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Existência", "Confirmada no cânone do cenário"], ["Conhecimento dos habitantes", "Lenda, relatos fragmentários ou descrença"], ["Aparência", "Pele azulada; sem cabelo, orelhas ou nariz; boca pequena; olhos grandes amendoados"], ["Porte", "Cerca de um metro a um metro e vinte"], ["Região dos relatos", "Extremo norte de Virtude"], ["Referência temporal", "I Era à III Era"]], "widths": [1, 3]}



Origem e comunicação. A origem dos Thul Verenari permanece desconhecida. A possibilidade de terem vindo de fora do planeta de Virtude integra o cânone como hipótese, sem planeta natal ou percurso de chegada estabelecidos. Possuem tecnologia extremamente avançada e comunicam-se por telepatia. Seu interesse se concentra especialmente em tecnologia, tempo e mente.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.



Vigilância no extremo norte. Depois da intervenção, os Thul Verenari se ocultaram no extremo norte do planeta para acompanhar o andamento de Virtude, os Descompassos e as transformações tecnológicas, temporais e mentais. São extremamente discretos e pragmáticos. Luzes e aparições ocasionais em Bergen podem decorrer dessa presença, sem que todo incidente setentrional seja automaticamente atribuído a eles. A localização precisa de suas instalações não é conhecida pelos povos do cenário.



Comunicar sem formar uma mente única. A telepatia dos Thul permite transmitir intenções, imagens e impressões com níveis diferentes de detalhe. Ela não apaga a experiência individual: uma observação partilhada pode produzir conclusões incompatíveis. A Vigília registra quem percebeu uma variação, quem a comparou com os arquivos e quem propôs agir. Assim, a interpretação de um observador continua identificável mesmo depois de partilhada com os demais.



A vida nos postos. A Vigília Setentrional mantém postos pequenos e especializados, associados à conservação das Janelas de Escuta. A rocha e as condições do extremo norte ajudam a ocultar instalações, sem que haja um reino conhecido ou uma capital divulgada. Manutenção, comparação de registros e períodos de recolhimento alternam-se no trabalho. Os nomes das funções usados neste artigo traduzem seu papel; não estabelecem uma língua falada pelos Thul.



Decisões depois da Punição. As consequências da intervenção acompanham as discussões entre observadores. Alguns veem sinais de risco que exigiriam contenção antecipada; outros receiam transformar toda mudança de Virtude numa repetição da crise antiga. Ecos Silenciosos procura conservar nos registros os efeitos das atividades Thul. A hipótese de origem exterior ao planeta permanece aberta, e a avaliação de ameaças extraterrestres continua sendo uma motivação deles, sem confirmar uma inteligência específica.



Vigília Setentrional



A organização da observação Thul, descrita nas informações reservadas do cenário.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era à III Era"], ["Conhecimento dos povos", "Estas informações não são conhecidas em Virtude"], ["Natureza", "Organização ou prática Thul de observação"]], "widths": [1, 3]}



Postos e responsabilidades. A Vigília Setentrional reúne postos de observação, conservação de instrumentos e comparação de registros dos Thul Verenari. A designação identifica o trabalho mantido no extremo norte após a Grande Punição; não define o governo completo do povo ou seu lugar de origem. Equipes mantêm funções distintas para observação, interpretação e preservação dos dados.



Discordar em silêncio. A comunicação telepática permite partilhar observações e intenções sem fala, mas não elimina interpretações individuais. Observadores divergem sobre o peso de uma anomalia e sobre o custo de uma intervenção. A Vigília conserva essas diferenças em seus registros. Uma lembrança compartilhada pode transmitir a urgência sentida por alguém sem obrigar os demais a adotar sua conclusão.



Proteção e responsabilidade. Alguns defendem contenção antecipada diante de sinais que consideram semelhantes aos do fim da I Era. Outros sustentam que a presença dos próprios Thul precisa entrar no cálculo das perturbações observadas. A memória da Grande Punição é tratada como decisão cujas consequências continuam exigindo vigilância. O pragmatismo não torna suas avaliações infalíveis nem suas prioridades idênticas.



Janelas de Escuta



Instrumentos de observação dos Thul, conhecidos apenas nas informações reservadas do cenário.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era à III Era"], ["Conhecimento dos povos", "Estas informações não são conhecidas em Virtude"], ["Natureza", "Organização ou prática Thul de observação"]], "widths": [1, 3]}



O que os postos acompanham. Os Thul chamam de Janelas de Escuta os conjuntos de instrumentos que comparam sinais de diferentes regiões e momentos. Acompanham Descompassos, alterações na circulação da mana e a atividade de artefatos e instalações. O registro de uma variação indica algo a investigar; a interpretação depende da comparação com outras observações.



Registros e ausência. A tecnologia avançada conserva sequências de sinais que os calendários locais não descrevem da mesma maneira. Uma janela pode mostrar continuidade onde um observador relata interrupção, ou recolher sinais cujo contexto cultural lhe escapa. A Vigília diferencia perda de observação, silêncio de uma região e ausência efetiva de um fenômeno. Os Thul continuam interessados no que os habitantes percebem, mesmo quando não tornam sua presença conhecida.



O episódio de 785. O campo sem gelo e o ruído sob a neve registrados por Haldren Vesk em 785 da III Era corresponderam à retirada de um captador Thul. A atividade deixou vestígios breves antes de o posto remover o equipamento. O capitão não reconheceu sua causa, e a inspeção posterior não encontrou objeto. O episódio permanece um relato inconclusivo para Bergen, embora sua causa seja definida no cânone reservado.



Ecos Silenciosos



Práticas de discrição e avaliação de contato adotadas pela vigilância Thul.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Referência temporal", "I Era à III Era"], ["Conhecimento dos povos", "Estas informações não são conhecidas em Virtude"], ["Natureza", "Organização ou prática Thul de observação"]], "widths": [1, 3]}



A observação também modifica. Ecos Silenciosos é a designação dos procedimentos pelos quais a Vigília procura distinguir um fenômeno acompanhado dos efeitos da própria presença. Instrumentos, deslocamentos e contatos podem deixar vestígios que os povos de Virtude interpretarão por suas tradições. Um observador deve registrar quando sua atividade passou a integrar aquilo que está estudando.



Telepatia e encontro. Nos encontros entre Thul, impressões e intenções podem ser partilhadas sem palavras, com diferentes graus de detalhe. Essa comunicação sustenta cooperação e desacordo. O uso de telepatia não torna todos os indivíduos uma consciência única e não estabelece controle automático da mente de quem vive em Virtude. Contatos deliberados exigem uma decisão que os observadores não tratam como simples extensão de uma conversa entre si.



O custo de intervir. A discrição é uma prioridade, mas não uma promessa de nunca agir. A Grande Punição demonstra o alcance de uma decisão que os Thul consideraram necessária. Debates atuais examinam quando interromper uma observação, recolher equipamento ou propor uma medida de contenção. A origem dos observadores e a identidade das inteligências que temem continuam em aberto.



Incidente registrado no posto de Haldren



O capitão Haldren Vesk, humano largo de rosto e quase sem sobrancelhas depois de uma queimadura, patrulha um posto antigo e chama os Thul Verenari de histórias para assustar recrutas.

{"type": "table", "heads": ["Campo", "Definição"], "rows": [["Data", "785 da III Era"], ["Era", "III Era"], ["Tipo", "História e sociedade"], ["Precisão", "Datada"], ["Natureza da evidência", "Registro histórico adotado"], ["Referência temporal", "785 da III Era"]], "widths": [1, 3]}



O captador retirado. Em 785 da III Era, a retirada de um captador de uma Janela de Escuta deixou o campo sem gelo e o som sob a neve anotados por Haldren Vesk. Os Thul recolheram o equipamento antes da inspeção seguinte. A definição da causa no cânone reservado não transforma o relato do capitão em prova disponível aos reinos nem estabelece contato dele com a Vigília.

## 44. Implantação dos dossiês Aelthir e Thul Verenari



Wikia 0.34: 622 artigos, 183 marcos e 84 vínculos. Sete artigos novos, cinco ilustrações e ampliação dos dossiês centrais. Referências e ligações entre artigos conservam a distinção entre história conhecida e informações reservadas.



A regra de aparência dos Aelthir foi consolidada em política visual e aplicada às cenas da Travessia, de Leth Avar, aos grupos e à nova personagem. As imagens antigas permanecem apenas como histórico de arquivo quando substituídas nos artigos atuais.

## 45. Aelthir — aparência astral e continuidade visual

Referência visual vigente

Pele clara e cabelos loiros são a referência dos Aelthir, com anatomia de elfos altos e presença mais astral e etérea. Este capítulo prevalece sobre as descrições anteriores de suas cores de pele e cabelo. Os capítulos anteriores ficam preservados como histórico editorial.

### RC-AT07 — Aelthir e a aparência astral

Mesma anatomia, proporções e orelhas pontudas dos elfos altos, com pele clara e cabelos loiros em tons de mel, ouro pálido e platinado. A presença Aelthir em Eomundus é astral e etérea: luminosidade perolada, reflexos de estrelas e contornos envolvidos por luz prateada. Rostos permanecem legíveis e individualizados. A Travessia estabiliza a materialidade sem mudar pele, cabelo ou fisionomia.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.

### RC-AT08 — Arieth e Ilenya

Arieth Ilvar: pele clara, rosto longo, cabelos loiro-pálidos e mecha branca trançada à têmpora. Ilenya Saar: pele clara, cabelos loiro-mel muito encaracolados, rosto oval, queixo arredondado, nariz curto e olhos castanhos ligeiramente caídos. Vestimentas, trajetórias e vínculos permanecem. As descrições anteriores de pele escura ou castanha e cabelo negro dessas duas personagens são substituídas por esta decisão.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.

### RC-AT09 — Continuidade entre cenas

A anatomia e os traços individuais se mantêm antes e depois da Travessia. Eomundus acentua luminosidade perolada e presença astral; Virtude estabiliza os corpos materiais. A direção de arte continua fantasia estilizada, com rostos, penteados, expressões e gestos variados. Cinco imagens foram revistas: comunidade Aelthir, Leth Avar, Travessia das Sete Portas, Ilenya Saar e Arieth Ilvar.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.
