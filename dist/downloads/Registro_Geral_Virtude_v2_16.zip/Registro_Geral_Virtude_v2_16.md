# Registro Geral de Virtude 2.16

Finalidade: consolidar o cânone autoral e orientar a wikia. Decisões posteriores prevalecem; capítulos anteriores são preservados como histórico. Contém spoilers e conhecimentos reservados.

## 1. Finalidade, autoridade e uso

Edição 2.5 - organização e referências

A presente edição acrescenta a cronologia geral e o índice de vínculos dos capítulos 30 a 33. As decisões substantivas anteriores permanecem, com sua numeração e procedência. Estados antigos de implantação são históricos; os índices novos apresentam sua própria cobertura e fontes.

A regra de consulta

Em caso de conflito entre uma obra e uma definição normativa vigente deste Registro, vale a definição do Registro. Uma decisão posterior expressa de Tiago Luis Custódio prevalece e deve ser incorporada à próxima versão. Questões marcadas EM ABERTO não são decisões e não autorizam preencher lacunas como fatos.

O que muda nesta edição

A edição 2.4 incorpora a história política de Vaelen Endor a partir de VE, publicado pelo autor em 5 de novembro de 2026. A base 2.3 permanece preservada como referência histórica. Novos reinados, datas, pessoas e instituições passam a referência operacional nos registros RC-VE desta edição.



Este é o documento editorial de continuidade do universo de Virtude. Sua finalidade é conservar decisões, estabilizar nomes e relações, distinguir conhecimento de hipótese e orientar a criação de novos materiais. Não é uma crônica escrita por alguém de Virtude: contém informações de bastidores e desfechos que personagens e leitores de introdução podem desconhecer. A autoria do universo e a autoridade final pertencem a Tiago Luis Custódio.



O Registro não exige que cada livro antigo seja refeito imediatamente. Uma definição pode estar vigente aqui enquanto uma edição anterior ainda conserva outra versão. Por isso, a regra oficial e o estado de implantação são campos distintos. Uma ocorrência só é marcada como corrigida depois de se conferir o material alterado; encontrar a forma correta em um trecho não certifica todo o livro.



A base documental original consolidou as decisões explícitas desta conversa, o inventário da wikia 0.9 e a consulta temática aos onze PDFs nela disponíveis. Reúne um núcleo normativo, uma cronologia de referência, fichas de continuidade de lugares e personagens, um índice natural e um relatório de divergências. O alcance é a base identificada nesta edição, não todo arquivo ou rascunho que possa existir fora dela.



Quatro formas de informação

| Marca | Significado e efeito |
| --- | --- |
| AUTORAL | Decisão explicitamente confirmada pelo autor nesta conversa. É normativa. |
| CONSOLIDADO | Síntese das fontes identificadas, adotada como referência nesta edição. A atribuição ou incerteza faz parte da definição. |
| EDITORIAL ADOTADO | Escolha de continuidade feita nesta edição para resolver um conflito, com justificativa e localização. É a referência operacional até decisão autoral posterior. |
| EM ABERTO | Pergunta ou incompatibilidade ainda sem solução. Não adquire autoridade apenas por estar registrada. |



Os dossiês e os índices dos capítulos finais reproduzem a base de consulta identificada. Não acrescentam confirmação autoral independente a cada frase da wikia. Quando um dossiê conflitar com um registro normativo específico, este prevalece; quando aparecer um conflito novo não resolvido, conserve a dúvida e abra uma ocorrência.



Ordem de precedência



Primeiro, uma decisão autoral expressa mais recente; em seguida, o registro normativo específico vigente; depois, as fontes indicadas para aquele assunto. Para acontecimentos dramatizados, a cena do romance fornece a referência mais direta. Para regras de jogo, vale a versão mecânica identificada. Uma ilustração interpretativa não supera uma descrição física explícita, e uma data recente de arquivo não transforma automaticamente um testemunho ficcional em verdade absoluta.



A wikia deve acompanhar as decisões vigentes, mas não precisa carregar toda a discussão editorial. Os livros podem receber lotes de correções em revisões futuras. Este PDF congela a versão 2.2; o arquivo editável é a matriz para uma nova edição. Nenhuma atualização é automática: modificar a wikia ou um livro exige uma ação posterior.

Aviso de leitura

Este volume contém spoilers integrais dos dois romances e informações destinadas à criação e revisão do universo. Não deve ser usado como apresentação inicial para jogadores que desejam descobrir a trama.

## 2. Fontes, versões e método



A base W09 desta matriz corresponde à wikia 0.9, inventariada em 3 de novembro de 2026, com 220 verbetes, 75 personagens ilustrados, 70 lugares e onze PDFs. Esse retrato é histórico. A edição 2.4 acrescenta a obra VE e não revalida, por esse acréscimo, os inventários ou estados de implantação posteriores da wikia.



A base documental anterior é preservada para rastreabilidade. A edição 2.0 acrescentou decisões autorais desta conversa, identificadas por DA2, e detalhamento criativo autorizado. O número de verbetes ou imagens da wikia não muda por causa deste documento. As páginas das fontes continuam referindo-se às edições inventariadas, não às futuras reescritas.

| Código | Material consultado | Páginas |
| --- | --- | --- |
| AN | Anais da Ordem dos Magos | 34 |
| BA | Bichos e Assombros dos Caminhos | 37 |
| C1 | As Guias Partidas | 156 |
| C2 | As Quatro Hostes | 154 |
| FA | As Formas da Ausência | 48 |
| FR | Entre Feras e Raízes | 73 |
| GJ | Crônicas de Virtude — Guia do Jogador | 58 |
| GV | Guia dos Viajantes de 788 | 43 |
| HG | História Geral de Virtude | 147 |
| LR | Crônicas de Virtude — Livro de Regras | 64 |
| ME | O Mar das Espadas na Época de Selvar II | 41 |
| VE | Vaelen Endor — A construção e a queda do Império | 66 |



As páginas citadas são posições de página no PDF, contando a capa como página 1. Os arquivos foram identificados por conteúdo e resumo SHA-256, reproduzido no apêndice. W09 designa os verbetes da wikia 0.9; DA designa as decisões autorais expressas nesta conversa, sem numeração fictícia de página.



O que foi conferido



A conferência combinou extração textual dos onze PDFs, busca de nomes e variantes, leitura dirigida de passagens geográficas, cronológicas, narrativas e mecânicas e comparação com os verbetes. O relatório localiza ocorrências efetivamente verificadas e separa erros confirmados de dúvidas. Não constitui uma certificação de revisão linha a linha de todas as páginas, de cada viagem ou de todos os detalhes visuais.



A criação de uma concordância não apaga a perspectiva das fontes: Aveline compila história, Nerion recomenda viagens, Maelis descreve observações naturais, Odran relata experiências e Edrien escreve de dentro da Ordem. A verdade editorial pode ser mais precisa que o conhecimento disponível a esses autores.

| Obra interna | Data e posição do relato |
| --- | --- |
| História Geral / Aveline Sarven | Publicação no Quinto Dia da Vigília de 788; conhece o encerramento do ano. |
| Anais / Edrien Vaust | Aethravel, 787; exemplar interno com folhas reservadas. |
| Bichos e Assombros / Odran Velis | Morvek, 2386 da II Era; não é um viajante contemporâneo de 788. |
| As Formas da Ausência / Ishara Vel-Sen | Samarith, 780 da II Era; possui nota posterior de Aveline. |
| Mar das Espadas / Teren Vassel | Morvek, 664 da III Era; trata de 2078-2149 da II Era e possui nota de 788. |
| Entre Feras e Raízes / Maelis Varen | Ihfarilse, último mês de 787; ampliação editorial real não antecipa o futuro ficcional. |
| Guia dos Viajantes / Nerion Fales | Edição para 788; distingue visitas, pousos e itinerários de uma história completa. |

## 3. Decisões estruturantes da edição 2.0



O autor aprovou o aprofundamento conjunto dos cinco eixos, a mudança de romance, a relação discreta entre NPCs, a traição entre coroas, o sistema monetário e cenas de cotidiano. Também autorizou detalhamento social e visual e personagens adjacentes. As definições abaixo já são vigentes; sua implantação nos livros é uma etapa posterior.

### RC-A01 — Marevim: da reparação à apropriação

Após 731, Marevim procura testemunhos e responsabilização. Passa da preservação de memórias à tentativa de obter respostas delas e, por fim, à sustentação de consciências sem consentimento. Os estágios são distintos; não recebem anos novos sem necessidade. A injustiça sofrida não lhe concede autoridade sobre mortos e sobreviventes. Eline defendia consentimento.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Acrescentar a transição por cenas, documentos e decisões; não apresentar toda pesquisa de memória como necromancia desde o começo.

### RC-A02 — Responsabilidades na Ordem

Distinguir autorização, execução, alteração de relatório, conhecimento posterior e contestação. Ivela apoiou revisão limitada e aceitou um resultado insuficiente; Rul preservou provas e demorou a romper o silêncio institucional. As responsabilidades são próprias e desiguais. Há opositores de Marevim que também reconhecem o crime de 731.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Distribuir informação e poder; os novos NPCs da Ordem individualizam funções sem substituir Ivela ou Rul.

### RC-A03 — Quatro hostes e cooperação condicionada

Aelvar busca conter a ruptura e conservar controle técnico; Quinder defende habitantes e soberania; os contingentes centrais possuem comandos e financiadores divergentes; o exército de Marevim inclui mortos, consciências retidas e aliados com diferentes margens de escolha. Provas técnicas, dissidentes e garantias tornam possível uma cooperação parcial.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Manter sinais acordados, tratamento de prisioneiros e corredores verificáveis. Unidades não recebem todas as ordens ao mesmo tempo; continuam existindo perdas após o primeiro entendimento.

### RC-A04 — Os seis permanecem por motivos próprios

Liana responde por caminhos e pessoas sem decidir por elas; Demer protege quem não consegue partir; Le Rink enfrenta o uso da autoridade paterna; Nyssara precisa renunciar ao controle sobre Narel; Kharug distingue negociação de perdão; Sera divide autoria e responsabilidade.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: A separação temporária do grupo tem efeitos reais sobre competências, informação e decisões. Nenhum protagonista substitui todos os demais.

### RC-A05 — Liana e Rul

A amizade vem de 778; a aproximação amorosa começa pouco antes da abertura de C2. São adultas, com interesses próprios. Liana conduz Rul a Aethravel após uma inspeção por trabalho combinado: o afeto não é remuneração. Encontram-se de tempos em tempos, trocam cartas irregulares e não assumem coabitação ou disponibilidade permanente.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Reescrever a abertura, reencontros e epílogo. O desacordo sobre proteção e autonomia permanece; a relação não depende apenas da ferida de Rul.

### RC-A06 — Rul não é destinatária passiva

Rul escolhe tarefas, recusa decisões tomadas em seu nome e possui contatos, obrigações e capacidade técnica independentes. Liana pode partir sem abandono automático; Rul pode ficar sem que isso signifique recusa do vínculo.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Não transformar a goblin em prêmio, mascote, paciente permanente ou motivação para apagar as escolhas de Liana.

### RC-A07 — Elthara e Tavian

Elthara Sorn e Tavian Ordel tiveram aproximação afetiva em negociações militares anteriores e retomam encontros ocasionais. Ambos são adultos. Omitem o vínculo de parte dos subordinados; isso cria conflito de confiança entre comandos de interesses distintos.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Mostrar intimidade por gestos, cartas e conhecimento de hábitos. Não usar o vínculo como explicação automática da aliança, de uma traição ou de acesso irrestrito a segredos.

### RC-A08 — Limites operacionais da magia

Conhecer uma técnica não fornece materiais ou condições. Transmitir informação não comprova autoria ou integridade. Interferências possuem condições identificáveis e preparação narrativa. Cura e comunicação não restituem automaticamente membros, memória, consentimento ou confiança.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Evitar bloqueios inventados apenas para uma cena. Preservar função de pilotos, mensageiros, curadores, técnicos e arquivos; quantidades pertencem ao sistema de RPG.

### RC-A09 — Consequências de Samarith

O pós-guerra acompanha apuração de 731, assistência a sobreviventes dos diferentes exércitos e cobrança das garantias financeiras da campanha. Revelação não produz reparação instantânea. Demer participa do cuidado sem precisar fundar uma ordem excepcional.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Definir quem assume custos e quem continua esperando. Processos podem permanecer abertos depois de 788.

### RC-A10 — Cenas de mundo vivido

Distribuir cenas breves de trabalho, costumes, humor, beleza e conflito. Algumas retornam à investigação; outras concluem uma pequena história no próprio encontro. Nem toda cena contém uma pista ou objeto secreto.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Usar a matriz de cenas desta edição, preservando a causalidade e o conhecimento de cada personagem.

## 4. Traição de Sar-Nobil e sucessão de Nobilith

### RC-S01 — Promessa e acordo secreto

Maressa II promete a Osric Dalm respeitar a condução da sucessão e garantir abastecimento. Negocia secretamente com Martan Edris reconhecimento e crédito em troca de garantias sobre receitas e postos de Sar-Nobil. É compromisso político limitado: não transfere automaticamente a soberania de Nobilith.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Introduzir a promessa antes de mostrar sua violação; distinguir receita empenhada, administração de posto e anexação.

### RC-S02 — O custo da decisão

Durante a guerra, Maressa autoriza desviar parte de recursos prometidos a Nobilith apesar de avisos de escassez. Martan ajuda a ocultar o acordo. O socorro parte tarde; comunidades ficam expostas, e casas perdem pessoas e animais de serviço.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Mostrar ordens, transportes, testemunhas e efeitos. Não culpar uma magia secreta nem tornar Maressa responsável por todo atraso da guerra.

### RC-S03 — Osric e a coroação

Osric morre de sua condição já existente no décimo mês de 788, depois da batalha. Não se introduz envenenamento. Martan obtém coroação com apoio de parte da casta dos cavaleiros; as concessões vêm à tona e sua legitimidade é contestada. O dia preciso não é fixado.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Substituir o encerramento anterior que mantinha Osric vivo e a sucessão apenas em expectativa. No início de 788, ele continua vivo e reinante.

### RC-S04 — Helena e a contestação

Helena reúne casas prejudicadas, administradores e credores para contestar concessões e procedimento sucessório. Não recebe automaticamente a coroa. Promete reformas enquanto tenta proteger rendas próprias. Ao fechar 788 há um rei coroado e postos que não obedecem às mesmas ordens.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Evitar reduzir Martan a fantoche e Helena a solução moral. A sucessão contestada é política, sem comprovação sobrenatural.



A sequência deve mostrar: promessa pública; negociação reservada; aviso de escassez; decisão de desvio; perdas e registros; morte de Osric; coroação; revelação; recusa de parte dos postos. Esses acontecimentos não precisam ocupar cenas consecutivas. A autenticidade do acordo depende de vias independentes, testemunhos e atos efetivos, não de uma carta encontrada que explique tudo.

| Pessoa | Responsabilidade e limite |
| --- | --- |
| Maressa II | Escolhe priorizar sua campanha e ampliar influência; conhece os avisos e não pode alegar ignorância total. Perde confiança diplomática. |
| Martan Edris | Aceita e ajuda a ocultar o compromisso; também possui partidários e programa próprios. Sua coroa não encerra a disputa. |
| Helena Dalm | Organiza contestação com interesses próprios. A denúncia não a torna herdeira indiscutível. |
| Osric Dalm | Governa no início de 788 e sofre limitações já existentes. Sua morte posterior não é assassinato introduzido por esta revisão. |
| Cavaleiros e moradores | Escolhem entre juramentos, serviço, terra e subsistência; comunidades sofrem cobranças duplicadas e perda de proteção. |



As disputas resultantes continuam além de 788. Esta edição não decreta uma guerra continental, não escolhe o vencedor final da contestação nem atribui parentesco novo aos candidatos. O parentesco anterior é preservado: Martan é sobrinho de Osric; Helena é sua neta.

## 5. Moedas, emissão e circulação

### RC-M01 — Ráculo e nordum preservados

Ráculo e nordum permanecem com sua história e circulação anteriores. Os sete Reinos Centrais são Valerith, Nobilith, Sokeria, Heria, Rácia, Cávia e Milles. Bergen não ganha uma moeda substituta. Milles mantém a convivência de nordum e ráculo.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Conservar diferenças de cunhagem, peso, desgaste e os conflitos de ensaio já descritos.

### RC-M02 — Novas definições monetárias

O quadro desta edição estabelece as moedas dos demais estados e os lugares sem cunhagem soberana comum. Nome de moeda não implica exclusividade de circulação. Dorgal, como moeda, é distinguido da cidade pelo contexto.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Implantar nas descrições econômicas, contratos, mercados e cenas; não renomear preços de toda obra sem conferir contexto.

| Território | Nome / padrão | Definição vigente |
| --- | --- | --- |
| Aelvar | Ilvar | Prata régia; emissões antigas continuam circulando. |
| Iltharion | Vaess | Prata fiscalizada pela coroa e casas autorizadas. |
| Naerath | Nareth | Prata; emissões dinásticas com diferenças de teor. |
| Quinder | Lâmpada | Prata; cobre e crédito em compras pequenas. |
| Thaelorien | Folha | Prata para mercados e pagamentos públicos; prestações locais também existem. |
| Dorgamar | Dorgal | Prata; barras ensaiadas e documentos de depósito em grandes operações. |
| Nogard | Escama | Prata imperial; emissões de ouro em grandes pagamentos. |
| Sularien | Âncora | Prata de circulação portuária. |
| Jacomb | Maré | Prata de contratos e comércio costeiro. |
| Vardessa | Vardo | Prata imperial, de circulação desigual fora dos centros. |
| Pellanor | Ponte | Padrão de prata reconhecido por casas emissoras; não pressupõe coroa confederativa. |
| Oleakia | Sem moeda soberana comum | Moedas externas, crédito e vales de depósitos identificados. |
| Confederação Orc | Sem cunhagem confederativa única | Moedas externas, metal pesado e convenções de comunidades. |
| Ayak | Circulação múltipla | Ráculos, norduns e moedas marítimas; sem moeda própria definida. |
| Chisiague | Circulação múltipla | Moedas vizinhas e pagamentos locais; sem cunhagem comum à Liga. |
| Povos Livres | Práticas por comunidade | Sem moeda universal atribuída a todos. |



Não há câmbio universal e perpétuo. Teor, peso, desgaste, procedência e confiança afetam aceitação; a Liga das Balanças mantém função técnica e interesses próprios. Um vale de depósito identifica emissor e obrigação: não pode ser gasto em toda Virtude como se fosse prata. Sem moeda própria não significa sem comércio, riqueza ou crédito.



Valores pequenos podem usar cobre, frações reconhecidas e crédito local. Esta edição não fixa uma relação universal entre ouro, prata e cobre, nem uma série de denominações por reino. No RPG, os preços continuam em prata de referência; o câmbio entra quando acrescenta uma escolha relevante. Não se obriga a mesa a recalcular toda compra.



Para diferenciar imagens, o ilvar apresenta um ramo estreito; o vaess, um arco aberto; o nareth, duas incisões paralelas; a lâmpada, uma chama estilizada; a folha, uma nervura central; o dorgal, uma comporta; a escama, três placas sobrepostas; a âncora, uma haste bifurcada; a maré, duas ondas; o vardo, um marco de estrada; a ponte, três vãos baixos. Esses motivos são complementos visuais novos, não prova de símbolo religioso universal. Perfis de soberanos e marcas de casa variam entre emissões.

## 6. Reinos e localidades: diferenças sociais e visuais



Cada ficha estabelece composição de cena, grupos sociais e conflito, sem transformar população em bloco uniforme. Os topônimos e governantes anteriores são preservados. Os complementos de materiais e usos são novos detalhes de continuidade; não implicam clima único para um reino inteiro. Para os Povos Livres, a ficha não cria um estado soberano.



Valerith



<b>Localidades e paisagem:</b> Vaelen Endor, arquivos, pátios de carga e edifícios imperiais adaptados; Nerevala é uma fronteira portuária disputada, não uma segunda capital.



<b>Grupos e disputa:</b> Corte, administração urbana, credores e associações de moradores disputam precedência e receita. Maressa empenha rendas; Lethia negocia autonomia urbana; Alessa depende de abastecimento externo.



<b>Direção visual:</b> Cantaria reparada com tijolo, roupa de audiência bem cortada e trajes de trabalho variados; nenhum padrão obrigatório para todo morador.



Reino de Nobilith



<b>Localidades e paisagem:</b> Cidade de casas antigas e acessos de serra; postos e hospedarias de Sar-Nobil têm espaços para animais, arreios e reparos.



<b>Grupos e disputa:</b> Casta dos cavaleiros, proprietários, administradores, transportadores e dependentes disputam obrigações. Casas apoiam Martan ou Helena por combinações de juramento, crédito e serviço; a coroação posterior divide postos.



<b>Direção visual:</b> Brasões gastos, ferro mantido por oficina e mantos de viagem pesados; distinguir riqueza herdada de equipamento realmente disponível.



Sokeria



<b>Localidades e paisagem:</b> Isnymelha militar e marítima; Vaelora combina floresta trabalhada, cultivo, coleta e direitos de acesso.



<b>Grupos e disputa:</b> Senhores, aldeias endividadas, trabalhadores móveis, clero e guarnições competem por braços e reservas. A Questão dos Celeiros contrapõe alívio prometido, exceções senhoriais e petições camponesas.



<b>Direção visual:</b> Celeiros, pátios de serviço, remendos de lona e ferramentas agrícolas; evitar tornar todo o reino um castelo.



Reino de Heria



<b>Localidades e paisagem:</b> Corte e casas de cavaleiros convivem com abrigos, propriedades e caminhos de serviço.



<b>Grupos e disputa:</b> Nobreza militar, dependentes, escrivães e membros dos Heróis disputam manutenção e isenções. Livro das Esporas: pagamentos indevidos e amparo real coexistem; uma apuração pode retirar alimento de quem não cometeu fraude.



<b>Direção visual:</b> Armaduras antigas restauradas, cavalos de condições diversas e arquivos modestos; pompa não é prosperidade geral.



Reino da Rácia



<b>Localidades e paisagem:</b> Ihfarilse combina oficinas, biblioteca e instalações do Circuito; Valada é corredor de autos e transporte; Atlante articula saída costeira.



<b>Grupos e disputa:</b> Patrocinadores, inventores, operários, aprendizes, corporações e redes clandestinas competem por acesso e autoria. Prestígio do Circuito sustenta a coroa e favorece patrocinados; reparadores sem nome cobram crédito e segurança.



<b>Direção visual:</b> Metais manchados, peças etiquetadas, proteção de oficina e roupa de corte contrastante; evitar vapor ou máquinas sem base no lore.



Reino da Cávia



<b>Localidades e paisagem:</b> Trogu tem docas e estaleiros; Juu Daixo, combustível e metal; galerias possuem moradores e direitos próprios.



<b>Grupos e disputa:</b> Concessionários, cooperativas mineiras, armadores, pilotos e comunidades subterrâneas negociam risco e acesso. A coroa adia conflitos de concessão; trabalhadores exigem participação em achados e condições de segurança.



<b>Direção visual:</b> Poeira e sal em zonas diferentes, suportes de carga e oficinas; não colocar toda cidade dentro de uma mina.



Reino de Milles



<b>Localidades e paisagem:</b> Cidade capital, floresta, localidades frias e passagens do Estreito do Norte compõem percursos distintos.



<b>Grupos e disputa:</b> Corte, casas de ensaio, comerciantes, condutores e comunidades de manutenção disputam câmbio e auxílio. Rovena negocia nordum e ráculo; crise de receitas pode virar acusação contra estrangeiros.



<b>Direção visual:</b> Tecidos sobrepostos, depósitos secos e madeira de manutenção; neve e gelo dependem de estação e altitude.



Reino de Bergen



<b>Localidades e paisagem:</b> Muralha de Hravn, postos e povoados do norte, com gelo e abastecimento condicionando serviço.



<b>Grupos e disputa:</b> Guarnições, comunidades tributadas, corte, mercadores e autoridades de Auvren disputam proteção e informação. Relatos do norte sustentam gastos e suspeitas, sem confirmar um exército oculto ou os Thul Verenari.



<b>Direção visual:</b> Pedra escurecida, madeira protegida do tempo, lã e sinais de reparo; evitar neve uniforme em qualquer mês.



Reino de Aelvar



<b>Localidades e paisagem:</b> Emvale é capital; Aston tem pomares e residência de Le Rink; Aethravel possui instalações e autonomia pactuada. Let-Thalara é bosque.



<b>Grupos e disputa:</b> Coroa, casas antigas, famílias de cultivo, ofícios e setores da Ordem negociam obrigações. Arriot busca controle sem possuir todos os arquivos; os direitos dos Pomares mantêm dependências.



<b>Direção visual:</b> Pomares manejados, alvenaria sóbria e circulação de mantimentos; vestes cerimoniais diferem da roupa de campo.



Reino de Iltharion



<b>Localidades e paisagem:</b> Nerathiel e seus acessos orientais relacionam serra, costa e interior; não repetir a imagem de Emvale.



<b>Grupos e disputa:</b> Casas portuárias, guardiões do interior, corte e pilotos disputam inspeções e autonomia. Elyndra sustenta acordo entre interesses distintos; sinais costeiros também podem servir à vigilância comercial.



<b>Direção visual:</b> Pedra clara de tons variados, estruturas de sinal e tecido bem preso ao vento em ambientes costeiros, sem arquitetura universal obrigatória.



Domínio de Naerath



<b>Localidades e paisagem:</b> Vel-Narim e Floresta Negra incluem terrenos manejados, assentamentos e estradas, não escuridão sobrenatural contínua.



<b>Grupos e disputa:</b> Grandes casas, cultivadores, dependentes, comerciantes e comunidades humanas negociam terra e renda. Zeryssa e conselho das casas enfrentam disputas herdadas da relação com Quinder.



<b>Direção visual:</b> Folhagem fechada e clareiras de trabalho, tons escuros usados de maneiras variadas; povo e moralidade não se confundem.



Quinder



<b>Localidades e paisagem:</b> Xeo Taoju tem monumentos, água e corte; Samarith, santuários e serviços. Campos irrigados passam a áreas mais secas.



<b>Grupos e disputa:</b> Corte, santuários, irrigantes, famílias humanas com reivindicações e proprietários de origens diversas disputam água e restituição. Selyra oferece abrigo e mantém controle dos caminhos; o Conselho das Duas Margens administra parte da irrigação.



<b>Direção visual:</b> Canais úteis, sombra localizada e superfícies de solo diferentes; evitar deserto total ou jardim contínuo.



Reino de Thaelorien



<b>Localidades e paisagem:</b> Nael-Sul cidade é distinta da Grande Floresta; Vradrath e as vertentes condicionam caminhos; Orvalda e Edramil possuem circuitos próprios.



<b>Grupos e disputa:</b> Coroa, pactos de bosques, comunidades urbanas, extratores e responsáveis por viveiros disputam uso. Conservação pode proteger comunidades ou legitimar cobrança e exclusão; Ariessa não é dona de cada bosque.



<b>Direção visual:</b> Madeira trabalhada e pedra adaptadas ao lugar, áreas cultivadas e usos cotidianos; não uniformizar tudo em casas nas árvores.



Império de Dorgamar



<b>Localidades e paisagem:</b> Dorgal é centro político; Morvek é portuária; cidades, minas e canais desativados têm economias diferentes.



<b>Grupos e disputa:</b> Coroa, assembleias urbanas, casas de canal, mineiros, credores e técnicos migrantes disputam investimento. Brunna quer recuperar parte da rede; algumas casas preferem manter taxas ou abandonar obras.



<b>Direção visual:</b> Marcas de nível de água, comportas mantidas e setores abandonados; evitar montanhas de ouro como paisagem nacional.



Império de Nogard



<b>Localidades e paisagem:</b> Corte do Estreito é insular; ancoradouros, depósitos e fiscalização distinguem o núcleo imperial.



<b>Grupos e disputa:</b> Dinastia, comandos navais, armadores, seguradores e comunidades de meio-dragões possuem interesses diversos. Cobranças sobre Oleakia e a Mesa do Lastro não são uma só autoridade nem uma única política.



<b>Direção visual:</b> Escamas e cristas individuais variadas, cabos e pedra portuária; não colocar asas ou chifres iguais em todos.



Reino de Sularien



<b>Localidades e paisagem:</b> Nhal-Sular articula portos e relações costeiras com Nogard e Jacomb.



<b>Grupos e disputa:</b> Coroa, pilotos, casas mercantis, abastecedores e vítimas de apresamentos disputam intermediação. Tharven financia ações contra rivais; a Querela das Âncoras conserva compensações contestadas.



<b>Direção visual:</b> Cais de condições distintas, armazéns apertados e roupa prática de bordo; origem élfica negra não replica Naerath.



Reino de Jacomb



<b>Localidades e paisagem:</b> Portos, pontos de aviso e oficinas de navegação ligam o reino aos circuitos orientais.



<b>Grupos e disputa:</b> Corte de Celvar, casas de contrato, pilotos e guardiões costeiros disputam risco e informação. O Ofício das Marés cobra prudência onde agentes comerciais vendem promessas de acesso.



<b>Direção visual:</b> Instrumentos reparados, marcas de maré e mapas anotados; não apresentar Lombonia como passeio regular.



Vardessa — Império Ocidental



<b>Localidades e paisagem:</b> Império Ocidental conhecido por tratados e relatos; centros e estradas não recebem aqui um mapa urbano completo inventado.



<b>Grupos e disputa:</b> Corte apresentada por Ilaris, representantes comerciais, cobradores e autoridades locais aparecem como interlocutores, sem uma constituição exaustiva. A distância entre pretensão imperial e cobrança efetiva admite disputa; detalhes não documentados ficam limitados aos novos contatos definidos.



<b>Direção visual:</b> Usar selos, marcos e peças de vestuário de emissários; não fixar clima, capital ou monumentalidade não descritos.



Confederação Halfling de Pellanor



<b>Localidades e paisagem:</b> Vales ocidentais além de Welkar / Velkar, com pontes, correios e pequenas soberanias; sem capital confederativa única.



<b>Grupos e disputa:</b> Pequenas cortes, comunidades, hospedeiros, reparadores e comerciantes negociam pesos e isenções. A Mesa das Sete Panelas coordena sem abolir governos locais; privilégio de parentes pode distorcer manutenção.



<b>Direção visual:</b> Escalas de mobiliário variadas, despensas e pontes ajustadas a usos reais; halflings não são apenas uma estética de festa.



União das Tocas de Oleakia



<b>Localidades e paisagem:</b> Terras baixas úmidas, Aurenval, túneis e depósitos dispersos relacionados a comunidades.



<b>Grupos e disputa:</b> Tocas, assembleias, matriarcas, cultivadores, pescadores e gente de vigília disputam reservas e acesso costeiro. Ima coordena; cobrança nogard permanece contestada; interesses de famílias não são idênticos.



<b>Direção visual:</b> Entradas protegidas de água, ferramentas de portes diversos e sinais discretos; oleakes possuem feições e pelagens individuais.



Confederação Orc



<b>Localidades e paisagem:</b> Comunidades e rotas ocidentais com assembleias locais; não há capital nacional única definida aqui.



<b>Grupos e disputa:</b> Chefias, famílias deslocadas, negociantes, criadores e trabalhadores divergem sobre terra e tratados. Indenização parcial pode ser reparação para uns e renúncia inaceitável para outros, como no conflito de Kharug e Druvak.



<b>Direção visual:</b> Equipamento mantido, materiais de origem diversa e registros de pacto; não reduzir assentamentos a acampamentos de guerra.



Cidade-Estado de Ayak



<b>Localidades e paisagem:</b> Cais, balsas, depósitos e desembocaduras ligam circulação fluvial e costeira.



<b>Grupos e disputa:</b> Conselho, síndica, carregadores, barqueiros e comerciantes disputam armazenagem e prioridade. Autonomia do porto não resolve o acesso igual aos serviços ou o preço da espera.



<b>Direção visual:</b> Madeira molhada, marcas de carga e passagens estreitas; embarcações e níveis de água orientam a composição.



Liga dos Passos de Chisiague



<b>Localidades e paisagem:</b> Coroa montanhosa e entrada de mar aberta a leste; passos, cidade e acessos de água precisam aparecer distintos.



<b>Grupos e disputa:</b> Liga, guardiões de passo, transportadores, moradores de encosta e comunidades das margens disputam manutenção. Taxas de travessia e direitos de água podem divergir mesmo entre aliados de Halessa Norn.



<b>Direção visual:</b> Rocha estratificada, espaços de abrigo e vegetação conforme encosta ou margem; não fechar o acesso oriental.



Terras dos Povos Livres



<b>Localidades e paisagem:</b> Territórios amplos do nordeste com comunidades distintas; não existe paisagem política única.



<b>Grupos e disputa:</b> Assembleias e autoridades locais, rotas sazonais e visitantes negociam condições próprias. Tratados de uma comunidade não obrigam todas as demais; um porta-voz precisa de mandato delimitado.



<b>Direção visual:</b> Distinguir assentamento e estação na futura cena; não inventar uma roupa tribal universal.

### RC-L01 — Distinguir localidades dentro do mesmo reino

Uma ilustração deve escolher localidade, estação, função do espaço e presença social. Não usar o mesmo perfil de torres, praça, rio e montanha em todas as cidades. Sem descrição suficiente, omitir o detalhe em vez de converter uma hipótese em geografia.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Aplicar as 24 fichas territoriais às 70 localidades inventariadas. Relações espaciais anteriores permanecem prioritárias.



Ficha de imagem de local: nome e época; água e acesso; relevo; vegetação e manejo; materiais e escala; trabalho visível; grupos presentes; ponto de vista; elementos que não podem mudar. Uma imagem da capital não representa automaticamente todo o reino.

## 7. Personagens adjacentes: novas fichas



As 25 pessoas seguintes são criações novas vigentes desta edição, sob autorização do autor. Não são apresentadas como personagens já existentes nos romances. Todos os vínculos de serviço são delimitados. Semelhança de sobrenome não cria genealogia; nenhuma ficha escolhe automaticamente uma lealdade para um povo inteiro.



Aparência, vestimenta e objeto de trabalho servem de base a futuras imagens. Arma não é obrigatória: um funcionário pode portar ferramentas e uma pessoa armada não precisa posar em combate. Nenhuma imagem nova é criada por esta atualização do Registro.



PN-01 | Sovel Aneth



<b>Elfo alto · Ordem / Aelvar · Custódio de autorizações.</b> Conhece a circulação de vias de 731, mas não assinou a operação. Teme perder sustento e confunde dever de sigilo com lealdade aos vivos.



<b>Aparência:</b> Face comprida, nariz largo, cabelo cinzento rente à nuca; mãos de dedos grossos.



<b>Vestimenta e equipamento:</b> Túnica de lã azul apagado, mangas curtas sobre camisa clara; estojo de selos e chave de arquivo. Sem arma habitual.



<b>Relação com a trama:</b> Rul compara matrizes sob sua guarda; Ivela precisa reconhecer o alcance das negativas anteriores.



PN-02 | Brena Uld



<b>Humana · Ordem / sobreviventes de 731 · Curadora e testemunha.</b> Sobreviveu ao isolamento já adulta; esta edição a apresenta idosa em 788, sem fixar nascimento. Recusa virar apenas prova da dor de Marevim.



<b>Aparência:</b> Rosto quadrado, cabelo crespo muito curto, sobrancelhas baixas; movimento deliberado do ombro direito.



<b>Vestimenta e equipamento:</b> Casaco castanho com fechos de osso e bolsa de curativos; faca de trabalho, sem uso marcial habitual.



<b>Relação com a trama:</b> Demer a escuta; documentos da Ordem precisam distinguir seu testemunho das interpretações do pesquisador.



PN-03 | Nereth Cal



<b>Humano · Valerith / crédito de campanha · Escrivão de garantias.</b> Registra a garantia de Sar-Nobil sem conhecer de início todas as promessas feitas a Osric. Deseja preservar o posto e não aceita assumir sozinho a decisão régia.



<b>Aparência:</b> Rosto oval, nariz curto, entradas pronunciadas e cabelo castanho liso; fala devagar.



<b>Vestimenta e equipamento:</b> Colete cinzento sem bordado, bolsa plana e caneta curta; sem arma de serviço.



<b>Relação com a trama:</b> Lethia administra sua circulação; vias independentes podem confirmar partes do acordo.



PN-04 | Varda En



<b>Humana · Nobilith / Sar-Nobil · Administradora de um posto de muda.</b> Conhece a diferença entre suprimentos prometidos e entregues. Protege moradores e depende de renda de passagem que também os onera.



<b>Aparência:</b> Face larga, olhos pequenos, cabelo escuro trançado baixo; antebraços fortes.



<b>Vestimenta e equipamento:</b> Sobretúnica verde gasta, botas altas reparadas, chaves e cordel de contas; lança curta guardada para defesa do posto.



<b>Relação com a trama:</b> Kharug confere cargas com ela; Helena procura seu apoio e não recebe obediência gratuita.



PN-05 | Ceris Dalmere



<b>Humano · Nobilith / cavalaria · Cavaleiro de uma casa de renda curta.</b> Apoia Martan por juramento e receia uma concessão que entregue o sustento do posto a credores. Não é parente dos Dalm por semelhança de nome.



<b>Aparência:</b> Rosto estreito, olhos fundos, nariz convexo e cabelo preto comprido preso; barba rala.



<b>Vestimenta e equipamento:</b> Cota antiga com reparos visíveis, manto bege e escudo com pintura renovada; lança e espada curta.



<b>Relação com a trama:</b> Sua dúvida materializa a divisão da casta; não comanda todos os cavaleiros.



PN-06 | Dena Arl



<b>Humana · Sokeria / aldeias · Organizadora de armazenamento.</b> Negocia reservas entre famílias e discorda de Yarine sobre quanto entregar à campanha. Não substitui Marta Eren.



<b>Aparência:</b> Rosto triangular, olhos afastados, cabelo castanho em duas tranças curtas.



<b>Vestimenta e equipamento:</b> Saia de trabalho sobre calças estreitas, avental de fibra grossa e medidas de madeira; foice de trabalho, não arma obrigatória.



<b>Relação com a trama:</b> Atrasos de socorro a afetam; sua petição acompanha sementes e trabalho, não só números da corte.



PN-07 | Orel Vennas



<b>Anão · Heria / dependentes · Responsável por uma casa de veteranos.</b> Recebe recursos de uma casa investigada por Isembra. Quer apuração e teme que o corte abrupto de verbas abandone os dependentes.



<b>Aparência:</b> Nariz largo, barba ruiva curta com fios brancos, olhos claros profundos; porte robusto.



<b>Vestimenta e equipamento:</b> Casaco remendado nos cotovelos, livro de refeições e bengala; sem arma cotidiana.



<b>Relação com a trama:</b> Ysenda precisa negociar continuidade do cuidado sem preservar a fraude.



PN-08 | Terenna Vos



<b>Humana · Rácia / oficinas · Representante de reparadores.</b> Exige que nomes de quem ajusta as peças constem dos registros. Pode atrasar serviço ao recusar trabalho inseguro.



<b>Aparência:</b> Rosto retangular, maxilar forte, cabelo liso preto preso em rabo curto; sorriso raro.



<b>Vestimenta e equipamento:</b> Colete de lona ferrugem, mangas presas e caixa de gabaritos; martelo de trabalho, sem arma pessoal definida.



<b>Relação com a trama:</b> Contesta Sera e os patrocinadores de Loria; sua competência não se resume a ajudá-las.



PN-09 | Borrin Tas



<b>Anão · Cávia / carregadores · Conferente de doca.</b> Defende equipes que pagam pelo tempo de espera imposto por inspeções. Também favorece conhecidos quando escolhe um turno.



<b>Aparência:</b> Rosto redondo, barba cinzenta dividida em duas pontas, um dente frontal ausente.



<b>Vestimenta e equipamento:</b> Capa curta impermeabilizada, calças folgadas presas na canela e placa de contagem; faca de corda.



<b>Relação com a trama:</b> Vessa precisa de sua equipe para uma operação; Dorna contesta que risco de mina seja tratado como peso de carga.



PN-10 | Edda Fenn



<b>Humana · Milles / abastecimento · Condutora de comboios.</b> Aceita moedas diferentes conforme destino e recusa lotes sem ensaio. Cobra adiantamento porque uma rota interrompida pode arruinar a equipe.



<b>Aparência:</b> Face longa, nariz arrebitado, cabelo castanho cortado rente às orelhas; bochechas marcadas pelo frio.



<b>Vestimenta e equipamento:</b> Lã em camadas, luvas de palmas reforçadas e lista de provisões; machadinha de serviço, sem papel militar fixo.



<b>Relação com a trama:</b> Rovena enfrenta as consequências de decisões monetárias nas entregas de Edda.



PN-11 | Haldis Ruun



<b>Humana · Bergen / muralha · Responsável por mantimentos de um posto.</b> Registra consumo e avisos do norte sem concluir que toda falta é sabotagem ou toda aparição é mentira.



<b>Aparência:</b> Rosto largo, queixo curto, cabelo muito claro em trança apertada; voz rouca.



<b>Vestimenta e equipamento:</b> Manto de lã cinzenta, botas de solado renovado e medidas de ração; lança de posto, usada em serviço.



<b>Relação com a trama:</b> Seus pedidos mostram o custo da proteção e o limite das notícias vendidas a viajantes.



PN-12 | Irenel Avar



<b>Elfa alta · Iltharion / sinalização · Guardiã de um farol.</b> Recusa registrar carga privada como se fosse segurança de navegação. Não fala em nome de toda a rainha Elyndra.



<b>Aparência:</b> Face pequena, nariz comprido, cabelo castanho escuro em trança lateral; olhos de pálpebras pesadas.



<b>Vestimenta e equipamento:</b> Casaco curto fechado alto, tecido preso ao vento e lente de inspeção; bastão de caminhada.



<b>Relação com a trama:</b> Oferece um contraste entre aviso público e espionagem comercial nos circuitos de Jacomb.



PN-13 | Vael Ner



<b>Elfo negro · Naerath / propriedades · Administrador de arrendamentos.</b> Conhece limites antigos de terrenos e lucra com mediações. Pode provar uma reivindicação e discordar da restituição proposta.



<b>Aparência:</b> Rosto oval largo, olhos quase redondos, cabelo branco curto penteado para trás.



<b>Vestimenta e equipamento:</b> Túnica marrom-escura de bainha clara e pasta de cordões; sem arma habitual.



<b>Relação com a trama:</b> Nyssara enfrenta o uso seletivo de sua própria pesquisa sem receber uma solução simples de arquivo.



PN-14 | Mira Saven



<b>Humana · Quinder / irrigação · Medidora ligada a comunidades irrigantes.</b> Disputa prioridades entre hortas e propriedades maiores. Depende de autorizações e não possui poder sobre todo o Conselho das Duas Margens.



<b>Aparência:</b> Face quadrada, nariz fino, cabelo preto com fios brancos preso baixo; unhas curtas.



<b>Vestimenta e equipamento:</b> Camisa clara, faixa azul desbotada e vara graduada; faca pequena de serviço.



<b>Relação com a trama:</b> Liana atravessa um desvio que ela mandou fechar; Selyra precisa responder à petição dos prejudicados.



PN-15 | Aelra Tis



<b>Elfa da floresta · Thaelorien / viveiros · Responsável por um viveiro comunitário.</b> Protege mudas e cobra limites de coleta, mas os direitos de acesso não são igualmente fáceis para todos.



<b>Aparência:</b> Face longa, maçãs baixas, cabelo castanho acinzentado preso em laço simples.



<b>Vestimenta e equipamento:</b> Tecido verde desbotado com bainha reforçada, avental e faca de enxertia; arco de caça somente em saídas combinadas.



<b>Relação com a trama:</b> Elenva negocia com seu grupo; Liana não pode aceitar compromissos por serem do mesmo povo.



PN-16 | Dovra Kelun



<b>Anã · Dorgamar / canais · Inspetora de uma associação de manutenção.</b> Defende recuperação de trechos úteis e rejeita reabrir uma rede inteira por prestígio. A nova cicatriz é detalhe criado nesta edição, não inferido de imagem.



<b>Aparência:</b> Face larga, nariz quebrado antigo já cicatrizado, cabelo preto raspado nas laterais; barba não definida nesta ficha.



<b>Vestimenta e equipamento:</b> Casaco de tecido ocre, botas com polainas, régua e instrumento de nível; sem arma de rotina.



<b>Relação com a trama:</b> Sera encontra seu critério de segurança; a corte de Brunna precisa escolher obras com efeitos desiguais.



PN-17 | Kesh Aruv



<b>Nogard · Nogard / ancoradouros · Piloto de serviço costeiro.</b> Vive de serviços autorizados pela fiscalização e perde clientes com taxas que considera abusivas.



<b>Aparência:</b> Focinho curto, escamas cinza-azuladas, crista baixa e chifres curtos voltados para trás; sem asas definidas.



<b>Vestimenta e equipamento:</b> Colete de couro flexível com aberturas adaptadas, corda de sondagem e faca de bordo.



<b>Relação com a trama:</b> Pode negociar com pescadores oleakes sem representar Azhvar ou a Mesa do Lastro.



PN-18 | Sareth Vin



<b>Elfa negra · Sularien / abastecimento · Representante de carregadores.</b> Busca compensação por alimento apresado; discorda de armadores e também de colegas que lucram com o contrabando.



<b>Aparência:</b> Rosto de queixo largo, cabelo preto muito curto, olhos estreitos; mãos grandes.



<b>Vestimenta e equipamento:</b> Jaqueta de linho grosso azul-escuro, cinto de bolsas e gancho de carga; sem arma marcial obrigatória.



<b>Relação com a trama:</b> Sua reclamação dá consequência concreta à política de Tharven e aos contratos com Jacomb.



PN-19 | Neral Doss



<b>Humano · Jacomb / navegação · Piloto do Ofício das Marés.</b> Não vende certeza sobre Lombonia. Sua prudência custa um contrato e pode salvar uma tripulação.



<b>Aparência:</b> Face triangular, nariz curto torto, cabelo grisalho crespo, barba curta desigual.



<b>Vestimenta e equipamento:</b> Capa de tecido encerado, mapa dobrado e linha de sondagem; faca de bordo.



<b>Relação com a trama:</b> Cruza notícias com Vessa e enfrenta agentes que prometem passagem segura sem base.



PN-20 | Pella Vintor



<b>Halfling · Pellanor / pontes · Responsável por inspeção de passagem.</b> Aplica tabelas por peso e enfrenta isenções de famílias influentes. Não é parente de Lessa Vint por semelhança nominal.



<b>Aparência:</b> Rosto oval, nariz arredondado, cabelo castanho em coque baixo, sobrancelhas muito retas.



<b>Vestimenta e equipamento:</b> Colete de lã curta, calças de trabalho e gabarito de roda; sem arma de ofício.



<b>Relação com a trama:</b> Sua cena mostra por que pontes custam trabalho; não confundir com a ancestral Pella Três-Pontes.



PN-21 | Tima Oren



<b>Oleake · Oleakia / reservas · Conferente de um depósito comunitário.</b> Discorda da localização de uma reserva nova e precisa ouvir famílias que querem guardar comida perto de casa.



<b>Aparência:</b> Focinho curto, face larga, pelagem bege-clara com orelhas de pontas castanhas; porte pequeno.



<b>Vestimenta e equipamento:</b> Sobretúnica curta verde-musgo, bolsos de tecido cru e contas de estoque; bastão de vigília, sem armamento universal do povo.



<b>Relação com a trama:</b> Ima coordena sem impor propriedade; Rima e a observação de cultivo ajudam a mostrar as diferenças de trabalho.



PN-22 | Rughen Tal



<b>Orc · Confederação Orc / terra · Delegado de duas comunidades.</b> Pode negociar por duas comunidades, não por toda a Confederação. Aceita compensação que alguns parentes recusam.



<b>Aparência:</b> Mandíbula estreita para seu povo, nariz largo, pele castanho-oliva, cabelo em duas tranças; presas inteiras.



<b>Vestimenta e equipamento:</b> Casaco de tecidos de origens diferentes, cordão de mandatos e escudo reparado; lança quando viaja em escolta.



<b>Relação com a trama:</b> Dialoga com Kharug e dissidentes sem substituir Rugha Sen ou Druvak.



PN-23 | Lenna Uss



<b>Goblin · Ayak / balsas · Organizadora de turnos de carregamento.</b> Distribui trabalhos escassos e é cobrada por favorecimento. Sua rede é local e não uma representação de todos os goblins.



<b>Aparência:</b> Face triangular, nariz largo curto, cabelo preto rente à cabeça, orelhas compridas estreitas sem as queimaduras de Rul.



<b>Vestimenta e equipamento:</b> Colete cinza de bolsos externos, lenço amarelo e tabuinhas de turno; faca de corda.



<b>Relação com a trama:</b> A missão precisa aguardar equipe e maré; a autonomia de Ilyne Tess não elimina disputas no cais.



PN-24 | Darel Nornas



<b>Humano · Chisiague / passos · Administrador de abrigo de encosta.</b> Quer manutenção de uma rota que recebe menos mercadorias, mas serve moradores. Não possui parentesco automático com Halessa Norn ou Darel Oss.



<b>Aparência:</b> Face comprida, nariz fino, cabelo castanho ondulado sobre a nuca; olhos claros fundos.



<b>Vestimenta e equipamento:</b> Capa de duas camadas, botas de sola grossa e chave de depósito; bastão de caminho.



<b>Relação com a trama:</b> Seu conflito conecta direitos de água e passagem sem fechar a abertura marítima oriental.



PN-25 | Siva Orlen



<b>Humana · Vardessa / contatos comerciais · Agente de contratos de uma casa ocidental.</b> Afirma um mandato comercial verificável, não intimidade com toda a corte imperial. Defende cláusulas que favorecem sua casa.



<b>Aparência:</b> Rosto redondo, queixo pronunciado, cabelo preto em trança única enrolada; olhos pequenos atentos.



<b>Vestimenta e equipamento:</b> Casaco bege de fechos escuros, carteira de selos e pequena balança; sem arma definida.



<b>Relação com a trama:</b> Seu vardo e suas cartas apresentam Vardessa sem inventar um domínio completo de geografia ainda pouco descrita.

## 8. Fichas visuais dos personagens já existentes



As 75 fichas desta seção complementam o inventário W09. Os sinais distintivos anteriores continuam prioritários e são reproduzidos no dossiê de consulta. As formulações abaixo são detalhamento novo autorizado; não são descrições extraídas de imagens. Para personagens cujo povo ou idade não foi explicitado, a incerteza permanece: um formato facial não define espécie, idade exata ou genealogia.

### RC-V05 — Contrato visual de personagem

Preservar povo confirmado, idade contextual, marcas físicas, cabelo e limitações; acrescentar silhueta, fisionomia, roupa, instrumento e gesto. A ficha textual prevalece sobre uma imagem incompatível. Suplementos novos desta edição são canônicos no alcance indicado.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Comparar personagens lado a lado antes de gerar retratos. Detalhes não descritos continuam interpretação; variantes de roupa e posição são possíveis.

### RC-V06 — Armas e ofícios

Nem todo personagem possui arma pessoal habitual. Diferenciar arma de serviço, ferramenta cortante, equipamento cerimonial e objeto mágico vinculado a um evento. Não inventar encantamento para dar destaque visual.

Base: DA2: propostas aprovadas pelo autor e detalhamento autorizado nesta edição 2.0.

Aplicação: Usar equipamento em tarefas naturais e respeitar mãos, próteses, ferimentos e época da cena.



Ansa Mer



<b>Fisionomia:</b> Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Aren Varn



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Arriot Ilvar



<b>Fisionomia:</b> Rosto muito magro, nariz comprido, cabelos cinzentos presos; luvas conservam função cerimonial e ocultamento da queimadura.



<b>Vestimenta:</b> Casaco verde-escuro de tecido fino e bordado contido; roupas de audiência diferentes das de viagem. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Selo e documentos; espada cerimonial apenas em contexto apropriado, sem torná-la arma constante. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Avren Dal



<b>Fisionomia:</b> Preservar: rosto largo, postura firme. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Beral Oss



<b>Fisionomia:</b> Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Calven IX



<b>Fisionomia:</b> Face longa, testa alta e nariz pronunciado; altura, cabelo ralo e sobrancelhas espessas preservados.



<b>Vestimenta:</b> Vestes claras com faixa escura, bem conservadas; mudança de tecido em funções públicas e privadas. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Selo e livro de audiências; não portar cajado mágico por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Darel Oss



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Demer Vault



<b>Fisionomia:</b> Rosto retangular, nariz de ponte larga, barba curta; a queimadura no antebraço permanece.



<b>Vestimenta:</b> Camisa clara, proteção de malha e placas mantidas, manto vinho gasto; símbolo de Ardanus. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Espada e escudo para serviço; em atendimento pode estar desarmado. Após a batalha perde insígnia de função, não o símbolo de fé. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Dorna Kel



<b>Fisionomia:</b> Preservar: sobrancelhas claras, ombro esquerdo mais baixo. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Druvak



<b>Fisionomia:</b> Preservar: mais novo que Kharug, tranças curtas, cicatriz junto ao queixo. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Dália Ress



<b>Fisionomia:</b> Preservar: ombros largos, cabelo preto preso num pano. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Edranna Halven



<b>Fisionomia:</b> Preservar: postura ereta, cabelo castanho com branco, sorriso preciso. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Edren Sol



<b>Fisionomia:</b> Preservar: tornozelo deformado, barba irregular. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Elenva Tair



<b>Fisionomia:</b> Preservar: ruivo muito escuro, dois dedos unidos por cicatriz. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Eline



<b>Fisionomia:</b> Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Elthara Sorn



<b>Fisionomia:</b> Preservar: Rosto largo, cabelo preso junto à cabeça, dois dedos substituídos por prótese simples. Complemento de olhar: sobrancelhas móveis e atenção lateral.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Eran Pel



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Form



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem cinza-clara, face triangular e nariz pequeno. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Forty



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem ruiva apagada, maxilar largo e orelhas ligeiramente desiguais. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Hadrik Vel



<b>Fisionomia:</b> Preservar: pescoço grosso, pequena cicatriz sobre o nariz. Complemento de olhar: atenção aos gestos do interlocutor.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Happidoh



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem areia escura, focinho alongado e orelhas de pontas escuras. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Ilven Sar



<b>Fisionomia:</b> Preservar: pequena joia no fecho do casaco, apresentação impecável. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Ima Olek



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanha dourada, face estreita e olhos de pálpebras baixas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Ima Teren



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanha, face arredondada; pelo castanho nas mãos preservado. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Irena Sol



<b>Fisionomia:</b> Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Istren Vaul



<b>Fisionomia:</b> Preservar: marcas de varíola, expressão cautelosa. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Ivela Dorn



<b>Fisionomia:</b> Preservar: 67 anos, cabelo branco preso por fita, dedos com artrite. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Jassa



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Kharug Venn



<b>Fisionomia:</b> Maxilar largo, nariz achatado, presa inferior quebrada, cabelo raspado e mãos com marcas de corda.



<b>Vestimenta:</b> Casaco de tecidos reparados em tons terrosos, botas firmes e bolsas de contrato. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança curta, faca utilitária e equipamento de animais; não posar sempre com a arma erguida. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Khoram Tesh



<b>Fisionomia:</b> Rosto largo, arcadas fortes e olhar preciso; pele verde acinzentada, presa com capa, lentes e nós no cabelo.



<b>Vestimenta:</b> Mangas claras protegidas por colete escuro, tecido gasto na borda da mesa. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Apoios de leitura e instrumentos de conservação, sem arma de rotina. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Le Rink



<b>Fisionomia:</b> Rosto comprido, queixo fino, sobrancelhas retas; olhos cinzentos e marca no pescoço preservados.



<b>Vestimenta:</b> Casaco azul-escuro de acabamento fino, luvas e camisa clara; traje de estrada mais cuidado que luxuoso. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Espada de esgrima e instrumento de proteção; luvas não ocultam automaticamente todos os gestos. Ferida de braço só depois do evento. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Lethia Arven



<b>Fisionomia:</b> Preservar: rosto pequeno, expressão contida. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Lethra Noll



<b>Fisionomia:</b> Preservar: cabelo muito curto, um olho com película leitosa. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Liana Meywood



<b>Fisionomia:</b> Face estreita de maçãs altas, sobrancelhas de alturas discretamente diferentes; cabelo irregular na altura dos ombros preserva a mecha branca.



<b>Vestimenta:</b> Túnica de viagem verde apagado, camisa clara, calças castanhas e botas reparadas; sem ornamento régio. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Arco de madeira sem decoração ostensiva, aljava e faca de campo. Pose atenta com opção real de retirada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Loria Halven



<b>Fisionomia:</b> Preservar: jovem adulta, roupa de manutenção. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Maela Dorn



<b>Fisionomia:</b> Preservar: magra, cabelo castanho preso, tinta no polegar. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Marevim



<b>Fisionomia:</b> Face angulosa, olhos fundos e olheiras discretas, cabelo quase branco; dois dedos pouco móveis. Maturidade e cansaço sem aparência adolescente.



<b>Vestimenta:</b> Tecido cinza-esverdeado e manto escuro com reparos cuidadosos; sem armadura decorativa de vilão. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Instrumentos e superfícies de pesquisa. Agulha e Gema aparecem somente quando a época e a cena permitirem. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Mavra Senn



<b>Fisionomia:</b> Preservar: rosto redondo, parte de uma orelha perdida. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Meral



<b>Fisionomia:</b> Preservar: rosto mais velho, nariz largo, cabelo claro. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Meren Voss



<b>Fisionomia:</b> Preservar: queixo largo, um olho esbranquiçado. Complemento de olhar: canto da boca discretamente assimétrico.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Mereth Sal



<b>Fisionomia:</b> Preservar: gestos precisos. Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Mina



<b>Fisionomia:</b> Preservar: cabelo preso de modo informal, tinta seca no punho. Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Mira Olek



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanho-acinzentada, focinho curto e face larga. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Narel



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Neris



<b>Fisionomia:</b> Preservar: manto áspero, recipiente de água vazio, rosto comum. Complemento de olhar: expressão contida e queixo levemente recolhido.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Nima Tel



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem creme, face pequena e orelhas de bases largas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Nyssara Veyl



<b>Fisionomia:</b> Maçãs salientes, nariz suavemente convexo e olhar medido; preservar tranças brancas e mínimo direito parcialmente perdido.



<b>Vestimenta:</b> Casaco vinho-escuro de mangas amplas, faixa de cintura e bolsa de cadernos; roupa prática bem apresentada. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Instrumentos de leitura, luz de trabalho e faca de viagem; magia de sombras não exige arma inventada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Odran Fess



<b>Fisionomia:</b> Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Olen Des



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Orelna Voss



<b>Fisionomia:</b> Preservar: cabelos brancos, voz baixa. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Oren Val



<b>Fisionomia:</b> Preservar: cabeça raspada, olhos lacrimejantes ao vento. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Orven Tal



<b>Fisionomia:</b> Preservar: mão deformada por acidente antigo, roupas austeras. Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Oth Salven



<b>Fisionomia:</b> Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Ressa Til



<b>Fisionomia:</b> Preservar: cicatriz antiga na bochecha, unhas roídas. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Rima Vel



<b>Fisionomia:</b> Traços leporinos e orelhas longas; complemento individual: pelagem castanho-escura, focinho estreito e maçãs marcadas. Sem altura ou idade numérica nova.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Rovan Ess



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Rul Aven



<b>Fisionomia:</b> Rosto de queixo curto e maçãs largas, nariz arredondado, sobrancelhas baixas; orelhas largas com queimaduras antigas preservadas.



<b>Vestimenta:</b> Sobretúnica vinho apagado, camisa de gola simples e bolsos internos; fechos acessíveis ao próprio porte. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lentes de inspeção, caderno e estojo acolchoado; faca utilitária pequena, sem arma marcial habitual. Não replicar a silhueta de Sera. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Saeren Il



<b>Fisionomia:</b> Preservar: cabelo escuro, marca clara na base da orelha. Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Seldo Mer



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Seli Ar



<b>Fisionomia:</b> Preservar: ferimento no pé na cena de encontro. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Selk Arven



<b>Fisionomia:</b> Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de ocre apagado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Selyra Naereth



<b>Fisionomia:</b> Face triangular madura, olhos de pálpebras baixas e lábios finos; nó branco único e rigidez para poupar o joelho.



<b>Vestimenta:</b> Veste violeta apagada de corte amplo e faixas claras; sem decoração que transforme toda cena em cerimônia. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Documentos e apoio de assento conforme necessidade. Nenhuma arma pessoal obrigatória definida. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Sera Vennor



<b>Fisionomia:</b> Rosto arredondado, nariz curto, olhos vivos; cabelo preto, sardas claras e lente esquerda preservados.



<b>Vestimenta:</b> Camisa clara de mangas presas, colete castanho de oficina, calças resistentes e avental conforme tarefa. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Estojo de ferramentas e peças de mana; martelo de trabalho não equivale a arma de guerra. Posição concentrada na peça. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Sirr-Vek



<b>Fisionomia:</b> Preservar: Escamas quase negras; pequena argola de cobre na mandíbula. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: caminhando com material preso ao corpo, adaptada à atividade, à época e às limitações do personagem.



Tavian Ordel



<b>Fisionomia:</b> Preservar: rosto marcado, barriga saliente, cansaço visível. Complemento de olhar: sobrancelhas móveis e atenção lateral.



<b>Vestimenta:</b> Roupa de marcha sob proteção mantida, manto de tecido pesado e calçado de serviço. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Lança ou espada de serviço como complemento novo; não fixar arma mágica. Conservar equipamentos explícitos anteriores. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Tavin Orr



<b>Fisionomia:</b> Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Roupa de estudo de mangas presas, casaco de tecido opaco e estojo separado de materiais. Para detalhes não fixados anteriormente: acento de cinza azulado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Caderno e instrumentos adequados ao ofício; sem arma marcial habitual nova. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Tessa Mal



<b>Fisionomia:</b> Preservar: cabelo curto, cicatriz no queixo. Complemento de olhar: olhar direto sem sorriso permanente.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de terra clara, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Tessa Varn



<b>Fisionomia:</b> Preservar: alta, cabelo cortado à altura do maxilar. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Roupa de viagem reparada, cinto simples e calçado ajustado ao trabalho; não usar uniforme genérico de aventureiro. Para detalhes não fixados anteriormente: acento de verde acinzentado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Correias, recipientes ou instrumentos de carga; faca utilitária apenas quando a tarefa a justificar. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.



Toren Kel



<b>Fisionomia:</b> Complemento de olhar: atenção aos gestos do interlocutor. Fisionomia complementar: rosto triangular, nariz largo e sobrancelhas espessas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de azul de tecido desbotado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: em pé, peso apoiado numa perna, ouvindo, adaptada à atividade, à época e às limitações do personagem.



Varek Oss



<b>Fisionomia:</b> Complemento de olhar: testa relaxada e olhos atentos. Fisionomia complementar: face larga, maxilar firme e olhar de pálpebras pesadas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de cinza quente, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: inclinando-se sobre a tarefa sem encarar o observador, adaptada à atividade, à época e às limitações do personagem.



Varesh Khor



<b>Fisionomia:</b> Preservar: escamas cor de cobre, crista serrada. Complemento de olhar: concentração com boca relaxada. Fisionomia complementar: face estreita, nariz convexo e olhos fundos.



<b>Vestimenta:</b> Casaco ou sobretúnica de tecido opaco com acabamento coerente ao ofício; evitar repetir a mesma combinação de camisa branca e colete marrom em todos. Para detalhes não fixados anteriormente: acento de verde de baixa saturação, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Objeto de função descrito na ficha; sem arma pessoal nova por padrão. Composição preferencial: fazendo uma pausa com mãos relaxadas, adaptada à atividade, à época e às limitações do personagem.



Varna Il



<b>Fisionomia:</b> Complemento de olhar: sobrancelhas móveis e atenção lateral. Fisionomia complementar: rosto quadrado, nariz arredondado e sobrancelhas retas.



<b>Vestimenta:</b> Camisa de mangas presas, colete resistente e reforços nos pontos de trabalho; sem luxo de corte obrigatório. Para detalhes não fixados anteriormente: acento de vinho escurecido, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Ferramentas do ofício, sem arma marcial habitual; instrumentos não devem aparecer como decoração sem uso. Composição preferencial: voltando o rosto para alguém fora do quadro, adaptada à atividade, à época e às limitações do personagem.



Vessa Cor



<b>Fisionomia:</b> Preservar: baixa, ombros fortes, mãos enfaixadas. Complemento de olhar: expressão contida e queixo levemente recolhido. Fisionomia complementar: face redonda, queixo curto e olhos afastados.



<b>Vestimenta:</b> Camisa de tecido grosso, casaco curto e botas de convés; fechos sem pontas soltas. Para detalhes não fixados anteriormente: acento de creme cru, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Faca de bordo e cordas; arma de combate somente se já definida ou exigida pela cena. Composição preferencial: ajustando o equipamento antes do trabalho, adaptada à atividade, à época e às limitações do personagem.



Yarine Vel



<b>Fisionomia:</b> Preservar: Robusta, cabelo ruivo desbotado, movimentos rápidos. Complemento de olhar: olhar direto sem sorriso permanente. Fisionomia complementar: rosto oval, nariz fino e sobrancelhas arqueadas.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de castanho avermelhado, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: apoiando material numa superfície de altura adequada, adaptada à atividade, à época e às limitações do personagem.



Ysenda Corval



<b>Fisionomia:</b> Preservar: cabelo grisalho raspado de um lado, uma perna rígida. Complemento de olhar: canto da boca discretamente assimétrico. Fisionomia complementar: face retangular, maçãs baixas e olhos pequenos.



<b>Vestimenta:</b> Tecido lavável em camadas simples, bolsa ou avental conforme tarefa e calçado de uso diário. Para detalhes não fixados anteriormente: acento de azul quase negro, em faixa, forro ou pequeno reparo; não substituir as cores explicitamente definidas.



<b>Arma, instrumento e pose:</b> Utensílios de cuidado, serviço ou estoque; sem arma marcial habitual acrescentada. Composição preferencial: sentado de lado conferindo um objeto, adaptada à atividade, à época e às limitações do personagem.

## 9. Matriz de cenas e implantação nas obras



As cenas são diretrizes de composição aprovadas, não trechos já escritos nem uma sequência rígida. Distribuir por rotas e competências reais. Para os novos NPCs, marcar estreia e conhecimento disponível antes de usá-los como testemunhas. Evitar um encontro obrigatório com cada personagem novo no mesmo romance.



Renda de um morto



Uma viúva tenta manter um pagamento no Livro das Esporas. <b>Conexão:</b> Heria: fraude, dependentes e proteção. <b>Participantes possíveis:</b> Demer ou Kharug. Uma conversa encerra a cena; a questão pode voltar com Isembra.



Prata recusada



Um vendedor recusa moeda vistosa e aceita outra gasta depois de ensaio. <b>Conexão:</b> Moedas e confiança, Liga das Balanças. <b>Participantes possíveis:</b> Kharug. Preparar um contrato, sem transformar toda moeda em cifra secreta.



A peça da balsa



Trabalhadores suspendem passagem para trocar uma peça pequena. <b>Conexão:</b> Trabalho, atraso e manutenção em Ayak. <b>Participantes possíveis:</b> Liana e Lenna. Perder tempo tem efeito; a peça não precisa ser sabotada.



Brinquedo antigo



Uma criança brinca com réplica de objeto Eldenari. <b>Conexão:</b> Memória cotidiana e diferença de olhar. <b>Participantes possíveis:</b> Nyssara. Não tornar o brinquedo artefato mágico.



A cadeira de Rul



Ajuste de móvel exige orçamento, prazo e escolhas de quem o usa. <b>Conexão:</b> Porte, ofício e autonomia. <b>Participantes possíveis:</b> Rul e Liana. Liana precisa ouvir em vez de decidir pelo conforto da outra.



Proteção e cobrança



Um cavaleiro afasta um cobrador e exige serviço gratuito. <b>Conexão:</b> Casta de Nobilith e dependência. <b>Participantes possíveis:</b> Kharug ou Demer. Antecipar divisão de juramentos sem revelar o acordo secreto.



Reserva nova



Famílias discutem a localização de um depósito oleake. <b>Conexão:</b> Defesa dispersa e trabalho doméstico. <b>Participantes possíveis:</b> Tima Oren. Pequena história com decisão comunitária própria.



Partida suspensa



Piloto muda horário por sinais costeiros que outros não percebem. <b>Conexão:</b> Conhecimento local e economia do risco. <b>Participantes possíveis:</b> Neral Doss ou Vessa. Não confirmar explicação sobrenatural obrigatória.



Carta atrasada



Uma carta chega depois de ambas terem mudado os planos. <b>Conexão:</b> Intimidade, correios e vida profissional. <b>Participantes possíveis:</b> Liana e Rul. Não criar abandono onde houve desencontro de informação.



Duas medidas de água



Um desvio beneficia uma propriedade e prejudica hortas. <b>Conexão:</b> Quinder: irrigação e representação. <b>Participantes possíveis:</b> Mira Saven. A missão atravessa um conflito que não pode resolver numa tarde.



Comporta silenciosa



Uma instalação parada continua exigindo manutenção mínima. <b>Conexão:</b> Dorgamar: custo do abandono e decisão de investimento. <b>Participantes possíveis:</b> Dovra e Sera. Conhecimento técnico tem história social e prioridade política.



O turno disputado



Uma equipe perde o trabalho após horas esperando inspeção. <b>Conexão:</b> Cávia: trabalho portuário e quem paga a espera. <b>Participantes possíveis:</b> Borrin e Vessa. Concluir a reclamação local sem exigir grande conspiração.

| Material | Implantação necessária |
| --- | --- |
| Registro 2.0 | Vigente nesta entrega: substituir decisões superadas e conservar pendências de implantação. |
| C1 e C2 em conjunto | Retirar romance Liana-Demer; preparar Liana-Rul; incorporar responsabilidades da Ordem, negociação militar, custos e cenas adequadas. Rever epílogos e cronologia de Nobilith. |
| História Geral | Alinhar relações, sucessão, moedas, grupos sociais e cronologia. A publicação ao fechar 788 pode conhecer a morte de Osric e a coroação contestada. |
| Anais | Conhecimento até 787: aprofundar antecedentes e responsabilidade, sem narrar como passado a batalha ou a sucessão de 788. Um adendo futuro precisa de data e autor. |
| Guias e obras temáticas | Aplicar moedas e descrições dentro da época de cada autor. ME trata do passado e não recebe moedas modernas como se fossem universais no reinado de Selvar. BA, publicado em 2386 da II Era, não recebe pessoas novas de 788. |
| Manuais de RPG | Preservar início de 788; não apresentar a morte de Osric ou desfechos como situação inicial. Moedas entram como ambientação sem substituir preços de referência. |
| Wikia | Atualizar textos, perfis, relações, filtros e imagens em tarefa própria; W09 continua sendo versão anterior até publicação efetiva. |



A cada atualização, conferir impacto no Registro na mesma tarefa. Alteração factual, cronológica, física, relacional ou mecânica pede anotação; estilo e layout isolados não exigem decisão canônica. Acompanhamento é procedimento de trabalho, sem sincronização automática em segundo plano.

## 10. Fichas de composição das localidades



Complementos para as 70 entradas de lugar já inventariadas. As vistas de reinos ou estados são recortes representativos e devem nomear a localidade escolhida. O objetivo é diferenciar função, materiais, trabalho e composição sem inventar relevo ou edifícios incompatíveis com o mapa. A estação permanece uma escolha explicitada na encomenda de imagem.



356 Milles



<b>Base preservada:</b> Povoação de Milles cujo nome se associa a um antigo marco de levantamento imperial.



<b>Composição e peculiaridade:</b> Pátio de parada, volumes de carga e abrigo de manutenção: mostrar circulação e trabalho em vez de uma segunda capital monumental.



Aethravel



<b>Base preservada:</b> Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.



<b>Composição e peculiaridade:</b> Recintos de estudo, corredores de serviço e pátio de abastecimento; equipamentos em manutenção e móveis de portes diversos. A Ordem não é só uma torre isolada.



Aston



<b>Base preservada:</b> Cidade do circuito meridional de Aelvar, entre as relações de Emvale e Thalendriel.



<b>Composição e peculiaridade:</b> Pomares manejados, acesso de propriedades e edifícios de residência; deixar visível o trabalho que sustenta a aparência ordenada.



Atlante



<b>Base preservada:</b> Cidade costeira da Rácia articulada às relações de rio e aos trajetos do Mar das Espadas.



<b>Composição e peculiaridade:</b> Margem de desembocadura e transição entre transporte fluvial e saída costeira; distinguir equipamentos de rio e de mar.



Bosque de Aurenval



<b>Base preservada:</b> Bosque de Oleakia ligado a coleta, abrigo e negociação dos caminhos.



<b>Composição e peculiaridade:</b> Áreas de bosque, cultivo, caminhos e cercados; mostrar o manejo humano e oleake sem transformar toda árvore em moradia.



Bosque de Let-Thalara



<b>Base preservada:</b> Bosque de Aelvar entre os acessos de Emvale e Aston.



<b>Composição e peculiaridade:</b> Bosque de Aelvar e acessos entre Emvale e Aston; clareiras e árvores de portes diferentes, sem sede de coroa florestal.



Bosque de Leth-Auren



<b>Base preservada:</b> Área de manejo, coleta e acordos na Grande Floresta de Nael-Sul.



<b>Composição e peculiaridade:</b> Postos e áreas de uso da comunidade, com sinais de acordos de coleta; não repetir a cena urbana de Nael-Sul.



Cidade de Bergen



<b>Base preservada:</b> Centro urbano setentrional ligado a abastecimento, rotas e tradições locais de Bergen.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Cidade de Chisiague



<b>Base preservada:</b> Núcleo de conselho, desembarque e armazenagem na porção interior da entrada marítima.



<b>Composição e peculiaridade:</b> A cidade integra os acessos de passos e margens; rocha, abrigo e circulação são prioritários. Respeitar a abertura marítima a leste.



Cidade de Heria



<b>Base preservada:</b> Centro urbano do reino de Heria e de suas relações de corte, serviço e cavalaria.



<b>Composição e peculiaridade:</b> Audiência, serviço de cavalaria e vida de trabalhadores em espaços distintos; contrastar manutenção real e apresentação nobre.



Cidade de Jacomb



<b>Base preservada:</b> Centro urbano de Jacomb ligado às atividades de porto e às referências de pilotos.



<b>Composição e peculiaridade:</b> Ponto de contratação e circulação de notícias marítimas, com mapas de trabalho e referências de pilotos; não representar Lombonia como parte urbana.



Cidade de Milles



<b>Base preservada:</b> Capital do Reino de Milles, ao sul da grande área florestal.



<b>Composição e peculiaridade:</b> Capital com administração e depósitos ligados a percursos frios; serviços e moradores distinguem a cena de uma simples parada de comboios.



Cidade de Nobilith



<b>Base preservada:</b> Centro urbano de Nobilith, com casas antigas, ofícios e relações de apresentação.



<b>Composição e peculiaridade:</b> Casas antigas e administração de rendas; cavaleiros, servidores e proprietários usam os mesmos acessos com posições sociais diferentes.



Cidade-Estado de Ayak



<b>Base preservada:</b> Governo dos cais nas desembocaduras ao norte de Quinder.



<b>Composição e peculiaridade:</b> Conselho e turnos de cais coexistem com balsas, correntes e depósitos; a margem condiciona os movimentos.



Cidadela do Norte



<b>Base preservada:</b> Posto e cidade na margem ocidental do Estreito do Norte.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Confederação Halfling de Pellanor



<b>Base preservada:</b> Rede de pequenos estados e comunidades halflings sem capital soberana única.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Confederação Orc



<b>Base preservada:</b> Pacto entre comunidades orcs que conservam autonomia e decisões em assembleia.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Corte do Estreito



<b>Base preservada:</b> Centro político insular de Nogard, articulado às casas e comandos de frota dos meio-dragões.



<b>Composição e peculiaridade:</b> Núcleo insular de governo e fiscalização nogard; pessoas de feições dracônicas variadas, embarcações e acesso controlado.



Domínio de Naerath



<b>Base preservada:</b> Casas de elfos negros e caminhos junto à Floresta Negra.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Dorgal



<b>Base preservada:</b> Centro político de Dorgamar, ligado a assembleias, casas e saberes de trabalho com pedra e água.



<b>Composição e peculiaridade:</b> Audiência de governo, contas e interlocutores de cidades e canais; pedra trabalhada e instrumentos de obra, sem tesouro espalhado como mobiliário.



Emvale



<b>Base preservada:</b> Capital de Aelvar, ligada à corte de Arriot Ilvar e aos circuitos de Aston e Thalendriel.



<b>Composição e peculiaridade:</b> Capital de Aelvar: funções de corte e de abastecimento convivem; roupa de cerimônia contrasta com carregadores e artífices.



Grande Floresta de Nael-Sul



<b>Base preservada:</b> Grande região florestal em torno do relevo central de Vradrath.



<b>Composição e peculiaridade:</b> Distinguir áreas manejadas, usos e caminhos de comunidades da vegetação menos alterada; não repetir a floresta de outro reino como imagem intercambiável.



Grande Muralha de Hravn



<b>Base preservada:</b> Fortificações de Bergen sustentadas por postos, trabalho e abastecimento.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Ihfarilse



<b>Base preservada:</b> Centro urbano da Rácia associado a oficinas, biblioteca e aos trabalhos do Circuito do Vento Arcano.



<b>Composição e peculiaridade:</b> Oficinas, biblioteca e Circuito em espaços com funções diferentes; equipamentos não ocupam cada praça como cenário de exposição.



Império de Dorgamar



<b>Base preservada:</b> O império anão, suas cidades e a infraestrutura que atravessa a pedra.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Império de Nogard



<b>Base preservada:</b> Terra dos meio-dragões, cujo império insular controla passagens orientais do Mar das Espadas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Isnymelha



<b>Base preservada:</b> Capital da Sokeria, conhecida pela presença da pedra e pelas relações entre costa e interior.



<b>Composição e peculiaridade:</b> Cidade militar marítima: armazenamento e manutenção de defesa convivem com vida de mercado e dependência dos campos.



Juu Daixo



<b>Base preservada:</b> Cidade de trabalho mineral, carvão e transporte nos acessos montanhosos da Cávia.



<b>Composição e peculiaridade:</b> Carvão, metal, combustível e transporte; madeira, fuligem e ferramentas de trabalho sem transformar toda pessoa em mineiro.



Leopoldina



<b>Base preservada:</b> Localidade de Milles entre os itinerários que articulam povoações e bordas florestais.



<b>Composição e peculiaridade:</b> Circulação do Estreito e apoio a viajantes; mostrar carga e acesso por embarcação, sem inventar ponte marítima contínua.



Liga dos Passos de Chisiague



<b>Base preservada:</b> Liga em torno de uma entrada marítima alongada, aberta a leste entre faixas montanhosas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Lombonia Ghostland



<b>Base preservada:</b> Ilhas cercadas por relatos inquietantes e investigações incompletas.



<b>Composição e peculiaridade:</b> Ilhas e vestígios sob condições de risco; preservar incerteza e a época da cena. Não antecipar a ocupação de Marevim em imagens da II Era.



Mar das Espadas



<b>Base preservada:</b> Águas que ligam reinos, cidades portuárias e memórias do comércio imperial.



<b>Composição e peculiaridade:</b> Água entre circuitos costeiros com navegação e esperas reais; não desenhar uma estrada sobre o mar.



Mar de Lombonia



<b>Base preservada:</b> Mar dos circuitos orientais, associado às ilhas de Lombonia e a portos de diferentes estados.



<b>Composição e peculiaridade:</b> Respeitar a posição cartográfica e acessos costeiros. A existência de relatos ameaçadores não exige uma tempestade eterna.



Morvek



<b>Base preservada:</b> Cidade portuária de Dorgamar, com oficinas, depósitos, moradias e serviços de navegação.



<b>Composição e peculiaridade:</b> Porto e circulação comercial de Dorgamar; diferenciar da sede política e dos canais interiores.



Nael-Sul



<b>Base preservada:</b> Capital de Thaelorien, nos acessos da Grande Floresta de Nael-Sul e dos relevos de Vradrath.



<b>Composição e peculiaridade:</b> Cidade de governo e santuários nos acessos da floresta; edifícios, caminhos e moradores, sem fundir a cidade inteira na formação florestal.



Nerathiel



<b>Base preservada:</b> Capital de Iltharion e centro da corte de Elyndra Vaess.



<b>Composição e peculiaridade:</b> Corte e acessos orientais; mostrar trabalho e circulação próprios de Iltharion, sem copiar Emvale ou apresentar todos os habitantes em visita cerimonial.



Nerevala



<b>Base preservada:</b> Cidade meridional de Valerith, disputada por reivindicações da Sokeria e da Rácia.



<b>Composição e peculiaridade:</b> Cais e entradas fiscalizadas por interesses rivais; recibos, mantimentos e guarda pequena, sem três coroas reinando simultaneamente na cidade.



Nhal-Sular



<b>Base preservada:</b> Capital de Sularien, ligada à vida política e às relações costeiras de seu reino.



<b>Composição e peculiaridade:</b> Contratação marítima e disputa por intermediação; armazéns e pontos de cobrança em vez de monumentalidade genérica de reino élfico.



Nova Milles



<b>Base preservada:</b> Cidade de Milles nos circuitos de campos, pousos e floresta do interior.



<b>Composição e peculiaridade:</b> Etapa do circuito do norte com abastecimento, espera e manutenção; escala de serviço distinta da capital.



Orvalda



<b>Base preservada:</b> Cidade de Thaelorien ligada aos acessos costeiros e aos caminhos florestais.



<b>Composição e peculiaridade:</b> Circuito costeiro de Thaelorien: roupa e ferramentas de transporte podem conviver com materiais de floresta sem transformar o porto em bosque fechado.



Passagem de Sar-Nobil



<b>Base preservada:</b> Rota de travessia associada à Serra de Sar-Nobil.



<b>Composição e peculiaridade:</b> Mostrar a rota praticável, curvas, espera, animais e manutenção; não confundir o trajeto com a totalidade da serra.



Pombo Torto



<b>Base preservada:</b> A estalagem de Lethra Noll em Samarith.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Quinder



<b>Base preservada:</b> Reino entre campos verdes e terras mais secas, com cultivo sustentado pelo Taoju e pelo Asmarith.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Rada de Vau-Cinzento



<b>Base preservada:</b> Ancoragem e pequenos acessos de cabotagem da costa meridional de Quinder.



<b>Composição e peculiaridade:</b> Margens e acessos de desembarque devem deixar legível o trecho terrestre posterior; não transportar Samarith até a praia.



Reino da Cávia



<b>Base preservada:</b> Reino de portos, mineração e transporte entre Trogu e as subidas de Juu Daixo.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino da Rácia



<b>Base preservada:</b> Oficinas, arquivos e circulação de técnicas nos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Aelvar



<b>Base preservada:</b> O reino setentrional dos elfos altos, entre cidades antigas e a influência da Ordem.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Bergen



<b>Base preservada:</b> Reino setentrional de rotas frias, fortificações e tradições religiosas próprias.



<b>Composição e peculiaridade:</b> Pedra e serviços ligados à corte e às rotas do norte; conservar circulação de moradores e mantimentos, sem transformar toda cena em muralha.



Reino de Heria



<b>Base preservada:</b> Tradições de cavalaria e tensões sobre serviço, rendas e privilégios num dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Iltharion



<b>Base preservada:</b> Reino oriental de elfos altos, independente da corte de Emvale.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Jacomb



<b>Base preservada:</b> Reino oriental ligado à navegação, aos pilotos e à circulação de notícias entre costas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Milles



<b>Base preservada:</b> Rotas setentrionais, floresta e relações de câmbio entre o Estreito e as cidades do interior.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Nobilith



<b>Base preservada:</b> Casas antigas, direitos de propriedade e disputas de sucessão num dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Sularien



<b>Base preservada:</b> Estado élfico negro do sudeste, com centro em Nhal-Sular e relações de costa próprias.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Reino de Thaelorien



<b>Base preservada:</b> O reino florestal ao sul dos Reinos Centrais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Roial



<b>Base preservada:</b> Centro comercial e contábil de Milles, com funções próprias na rede de cidades do reino.



<b>Composição e peculiaridade:</b> Parada de circulação no reino de Milles; carga, abrigo e trabalho sazonal distinguem a vista de floresta ou palácio.



Samarith



<b>Base preservada:</b> Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.



<b>Composição e peculiaridade:</b> Santuários, hospedarias, petições e assistência em uma cidade habitada; a Torre não deve apagar o restante da vida urbana.



Serra de Sar-Nobil



<b>Base preservada:</b> Conjunto montanhoso que atravessa predominantemente Nobilith de norte a sul.



<b>Composição e peculiaridade:</b> Eixo montanhoso predominantemente norte-sul; trilhas de serviço e áreas de abrigo não são uma estrada sobre toda a crista.



Sokeria



<b>Base preservada:</b> Reino central ligado às margens do Mar das Espadas.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Terras dos Povos Livres



<b>Base preservada:</b> Região de comunidades e autoridades distintas, sem soberano comum.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Thalendriel



<b>Base preservada:</b> Cidade de Aelvar nas rotas que descem rumo à Cidadela do Norte.



<b>Composição e peculiaridade:</b> Tomar a função de referência e os acessos descritos como eixo da composição. Diferenciar material, escala, atividade e ponto de vista; não acrescentar porto, torre ou montanha sem apoio no verbete ou mapa.



Trogu



<b>Base preservada:</b> Capital e cidade portuária da Cávia, ligada ao comércio marítimo e às remessas do interior.



<b>Composição e peculiaridade:</b> Docas, concessões, estaleiros e equipes de carga em condições diferentes; mostrar o trabalho que sustenta o porto.



União das Tocas de Oleakia



<b>Base preservada:</b> Comunidades oleakes, refúgios e depósitos dispersos numa união de tribos e assembleias.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vaelen Endor



<b>Base preservada:</b> Capital de Valerith e antiga capital imperial, com edifícios, mercados e arquivos de usos sucessivos.



<b>Composição e peculiaridade:</b> Antiga capital e corte atual de Valerith: cantaria histórica adaptada, arquivo, crédito e trabalho urbano em vez de ruína desabitada.



Valada



<b>Base preservada:</b> Cidade do corredor entre Ihfarilse, as passagens interiores e os acessos do Caminho Alto.



<b>Composição e peculiaridade:</b> Registros, audiência e trânsito de trabalhadores; água e corredor terrestre fazem parte da composição sem reduzir a cidade a tribunal.



Valerith



<b>Base preservada:</b> Reino central que conserva em Vaelen Endor uma herança imperial.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vardessa — Império Ocidental



<b>Base preservada:</b> Estado ocidental conhecido por contatos diplomáticos e comerciais.



<b>Composição e peculiaridade:</b> Aplicar a ficha territorial específica desta edição. Escolher uma localidade e seus grupos sociais, sem converter capital, povo e estado na mesma entidade.



Vel-Narim



<b>Base preservada:</b> Centro político de Naerath, ligado aos acessos orientais da Floresta Negra.



<b>Composição e peculiaridade:</b> Corte e circulação no Domínio, em relação com a Floresta Negra; edifícios e clareiras trabalhadas, sem noite sobrenatural permanente.



Wegas



<b>Base preservada:</b> Cidade dos percursos interiores de Milles, ligada à região da floresta e suas estradas.



<b>Composição e peculiaridade:</b> Travessia, cargas e aproximações do relevo; desenhar o acesso praticável em vez de carroças sobre uma crista aleatória.



Xeo Taoju



<b>Base preservada:</b> Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.



<b>Composição e peculiaridade:</b> Capital de Quinder com monumentos Eldenari, corte, canais e tarefas de manutenção; combinar solo seco e áreas irrigadas de maneira localizada.

## 11. Decisões geográficas vigentes

### RC-G01 — Let-Thalara

Let-Thalara designa somente o bosque de Aelvar, entre os acessos de Emvale e Aston. Não é a capital de Thaelorien.

Base: DA; HG pp. 5 e 78; GV pp. 28 e 32.

Aplicação: Corrigir menções de capital, ligações de verbetes e mapas derivados. Preservar o bosque.

### RC-G02 — Nael-Sul

Nael-Sul é a cidade capital de Thaelorien. A Grande Floresta de Nael-Sul existe normalmente como entidade geográfica distinta e homônima.

Base: DA; HG pp. 58 e 64; GJ p. 18.

Aplicação: Manter fichas e referências separadas para cidade e floresta; não apagar uma para resolver a ambiguidade.

### RC-G03 — Chisiague

O mapa de referência está correto: a entrada de água marítima abre-se a leste. Textos e imagens devem respeitar essa abertura.

Base: DA; HG p. 5; GV p. 4; FR caderno ambiental.

Aplicação: Não fechar a extremidade oriental nem deslocar a abertura para oeste. O mapa não determina sozinho a navegabilidade de cada trecho.

### RC-G04 — Mar de Lombonia

Mar de Lombonia é o nome oficial. Mar das Tormentas deixa de ser o nome canônico dessa água.

Base: DA; W09 mar-lombonia.

Aplicação: Substituir o antigo topônimo onde designar esse mar. A palavra tormentas, como fenômeno meteorológico, continua válida.

### RC-G05 — Nerevala

A grafia oficial é Nerevala, conforme o mapa. Neravala é variante legada para pesquisa e correção, sem constituir outra cidade.

Base: DA; HG pp. 5 e 73; GV p. 19.

Aplicação: Normalizar títulos e nomes visíveis. Um redirecionamento de endereço antigo pode ser preservado.

### RC-G06 — Reino e cidade de Milles

O reino de Milles e a cidade de Milles existem; a cidade é a capital do reino.

Base: DA; HG p. 5; W09 milles e cidade-milles.

Aplicação: Não fundir os dois verbetes. Em tabelas, explicitar se o campo trata da unidade política ou do centro urbano.

### RC-G07 — Serra de Sar-Nobil

A Serra de Sar-Nobil atravessa predominantemente Nobilith de norte a sul. É o conjunto montanhoso associado ao corredor.

Base: DA; HG pp. 60 e 81; GV p. 11.

Aplicação: Rever descrições de relevo e de orientação; não tratar a serra inteira como estrada.

### RC-G08 — Passagem de Sar-Nobil

A Passagem de Sar-Nobil é a rota de travessia associada ao corredor. Articula os acessos de Quinder e de Vaelen Endor com a descida por Nobilith rumo à Sokeria, e o percurso inverso.

Base: DA; HG pp. 81 e 110; GJ p. 12.

Aplicação: Preservar as ligações laterais e os acessos utilizáveis; não redesenhar um caminho reto sobre qualquer ponto da crista.

### RC-G09 — Cavaleiros de Nobilith

Os cavaleiros de Nobilith constituem uma casta importante da nobreza. Linhagem, patrimônio, formação e obrigações de serviço ajudam a organizar seu poder.

Base: DA; HG p. 60; W09 nobilith.

Aplicação: Desenvolver privilégios, dependências e serviço sem reduzir todos os cavaleiros a guardas de estrada.

### RC-G10 — Confederação Halfling

A Confederação Halfling de Pellanor fica a oeste, além da Cordilheira de Welkar. A folha cartográfica e a HG consultadas grafam Velkar. A posição ocidental está confirmada.

Base: DA; HG pp. 58 e 81; W09 pellanor.

Aplicação: Preservar a localização. Usar remissão Welkar / Velkar; a escolha de uma grafia única para todas as fontes permanece aberta.

### RC-G11 — Quinder

Quinder apresenta campos verdes em transição para terras mais secas, com agricultura dependente da água. Não é integralmente desértico.

Base: W09 quinder; HG seção de Quinder; GV capítulos de Quinder.

Aplicação: Variar imagens de campos, canais, solo seco e povoamento. Evitar dunas universais ou vegetação uniforme.

### RC-G12 — Nogard

Nogard é terra de meio-dragões. O nome pode designar o povo e o estado, conforme o contexto. A dinastia imperial não representa todos os indivíduos.

Base: DA sobre as imagens; LR p. 9; W09 nogard.

Aplicação: Incluir habitantes meio-dragões quando apropriado às cenas; não transformar toda a população em dragões de outra escala.

### RC-G13 — Nerevala e soberania

Nerevala pertence a Valerith no marco de referência, apesar de pretensões de Sokeria e Rácia. A Trégua das Três Portas não equivale a transferência de soberania.

Base: HG pp. 73 e 145; GV p. 19.

Aplicação: Distinguir administração, influência, pretensão e soberania.

### RC-G14 — Reino, capital e povo

Uma predominância de povo não torna um reino etnicamente uniforme. Capital, sede rotativa, corte insular e coordenação confederativa são categorias diferentes.

Base: HG pp. 45 e 49; LR pp. 8-9; W09.

Aplicação: Não inventar capital única para Pellanor, nem monarquia uniforme para toda confederação.

## 12. Tempo, eras e acesso à informação

Complemento vigente da cronologia imperial

Os registros RC-VE e as tabelas dos capítulos de integração imperial desta edição completam as datas anteriores. As marcas base e ampliação indicam a procedência no livro VE. Ambas são adotadas nesta edição, preservadas as incertezas e questões abertas expressas.

### RC-T01 — O marco comum

O estado padrão para RPG e apresentação sem spoilers é o início de 788 da III Era, antes dos acontecimentos posteriores da crise.

Base: DA; HG p. 8; GJ capa; W09 terceira-era.

Aplicação: Não apresentar mortos, ferimentos futuros ou mudanças de função como situação inicial.

### RC-T02 — Calendário da Concordância

O ano comum possui doze meses de trinta dias e cinco Dias da Vigília após o décimo segundo mês. Não há ano zero entre eras.

Base: HG p. 8.

Aplicação: Escrever era junto de datas antigas e distinguir calendário de data editorial real.

### RC-T03 — Precisão do passado

A I Era tem duração estimada em cerca de 6.400 anos, com incerteza aproximada de seis séculos. A II Era tem 2.431 anos registrados. A formação dos planos não recebe duração material demonstrada.

Base: HG p. 8.

Aplicação: Não transformar 9.619 anos, resultado de uma soma convencional até 788, numa idade exata do mundo.

### RC-T04 — Primeiro encontro dos seis

As Guias Partidas se passam entre 785 e 787. A Audiência das Guias em Valada, no décimo mês de 787, é o primeiro encontro documentado dos seis reunidos. Ainda não constitui companhia permanente.

Base: HG p. 145; C1; W09 liana e le-rink.

Aplicação: Preservar encontros parciais anteriores; não afirmar que seis viajavam sempre juntos desde 785.

### RC-T05 — Idade de Marevim

Marevim Aethros nasceu em 462 da III Era. Em 788 a diferença entre os anos é de 326; sem data de aniversário, não se fixa a idade completada em um dia. Pode ser relativamente jovem para um elfo alto e apresentar maturidade e cansaço.

Base: HG p. 102; AN p. 24; DA sobre maturidade visual.

Aplicação: Não ilustrá-lo automaticamente como adolescente, nem converter idade élfica em idade humana precisa.



Concordância anterior a 788

| Data / era | Evento e cuidado de continuidade |
| --- | --- |
| c. 1 / I | Horizonte convencional dos primeiros dragões. |
| c. 2100 / I | Primeiros assentamentos identificados como Eldenari. |
| c. 2550 / I | Consolidação urbana de Xeo Taoju. |
| c. 5990 / I | Travessia das Sete Portas. |
| c. 6035 / I | Fundação da Ordem em Aethravel. |
| c. 6384 / I | Ativação do Selo. |
| c. 6393-6399 / I | Sete campanhas da Guerra das Nove Vigílias. |
| Fim da I Era | Ruptura do Selo e Grande Punição, separadas por vinte e três dias, segundo a sequência adotada. |
| 1-40 / II | Período mais intenso de escuridão e destruição. |
| 1-c. 1000 / II | Milênio das Trevas; reconstruções regionais desiguais. |
| 612 / II | Desastre de Lombonia. |
| 1084 / II | Paz de Dorgal. |
| 1261 / II | Tratado das Três Margens. |
| 1368 / II | Fundação convencional do Império de Dorgamar. |
| 1398 / II | Concílio das Sete Portas. |
| 1517-1546 / II | Guerra dos Diques em Quinder; anterior ao império de Vaelen Endor e aos canais orientais. |
| 1896 / II | Proclamação imperial de Vaela. |
| 2032; 2039; 2058 / II | Tratado das Águas, início das obras e primeiro conjunto oriental de canais em serviço: marcos diferentes. |
| 2078-2149 / II | Reinado de Selvar II. |
| 2386 / II | Publicação de Bichos e Assombros dos Caminhos. |
| 2424-2428 / II | Campanhas de conquista de Quinder. |
| 2429 / II | Acordo das Lâmpadas. |
| 2431 / II | Concordata de Vaelen e fim da II Era. |
| 1 / III | Primeiro ano posterior à dissolução reconhecida, sem ano zero. |
| 61-74 / III | Guerra das Duas Cortes e independência de Quinder. |
| 98 / III | Reconhecimento da autonomia de Ayak; porto e nome são anteriores. |
| 147 / III | Fundação da Guilda dos Heróis. |
| 208 / III | Reunião inaugural da Mesa das Sete Panelas. |
| 219 / III | Programa da muralha de pedra de Bergen; não é o começo de todos os postos do norte. |
| 286 / III | Organização da Guilda dos Magos. |
| 318 / III | Desastre das Galerias de Anver. |
| 326 / III | Carta das Mãos Abertas: membros plenos não elfos na Ordem. |
| 412; 438 / III | Circuito precursor e carta da Guilda do Vento Arcano: marcos distintos. |
| 462 / III | Nascimento de Marevim Aethros. |
| 588 / III | Início do reinado de Ariessa em Thaelorien. |
| 622 / III | Início do reinado de Arriot em Aelvar. |
| 731 / III | Isolamento da aldeia e morte de Eline. |
| 734 / III | Autorização do Conselho das Duas Margens. |
| 741 / III | Ascensão de Elyndra em Iltharion. |
| 754 / III | Coroação de Brunna IV em Dorgamar. |
| 755 / III | Revisão limitada apoiada por Ivela. |
| 759 / III | Marevim alcança a Gema em Lombonia; dado posterior de reconstrução. |
| 763-770 / III | Querela de Terval e disputas ligadas às famílias de Kharug e Druvak. |
| 772 / III | Disputa das Pontes Baixas em Pellanor. |
| 778 / III | Trabalho de campo do qual vem a amizade de Liana e Rul, conforme W09; não confundir com o Apresamento das Três Bandeiras do mesmo ano. |
| 779-783 / III | Disputas das obras de irrigação de Quinder. |
| 785-787 / III | Caso das Guias Partidas. |
| 786 / III | Tensão naval entre Nogard e Oleakia; acordo provisório. |
| 10º mês de 787 | Audiência em Valada; seis reunidos. |
| Último mês de 787 | Publicação ficcional de Entre Feras e Raízes. |



Fontes: HG pp. 141-145; capas de BA e FR; W09 liana. A lista seleciona marcos úteis à revisão e preserva aproximações. Eventos do mesmo ano não são automaticamente causa uns dos outros.

## 13. A crise de 788 e seus desfechos

Referência de autor e revisão

O conteúdo deste capítulo é canônico de bastidores e inclui o encerramento dos romances. Não deve entrar integralmente em páginas de introdução ou fichas de campanha no início de 788.

| Data em 788 | Sequência de referência |
| --- | --- |
| 11 / 2º mês | Golpe de Marevim e roubo da Agulha. |
| 19 / 4º mês | Primeira chegada da missão a Samarith pelo eixo Aelvar-Naerath-Quinder. |
| 27 / 4º mês | Partida para diligência documental na Rácia, por Nobilith, Valerith e corredor de Valada. |
| 5 / 5º mês | Chegada de Rul a Samarith, enquanto a missão está ausente. |
| 27 / 5º mês | Passagem da missão por Ihfarilse. |
| 28 / 6º mês | Inspeção da urna na costa de Trogu; reencontro com Rul. |
| 26 / 7º mês | Retorno a Samarith pelo Mar das Espadas, desembarque perto de Vau-Cinzento e trecho terrestre. |
| 7º e 8º meses | Testes, ruptura temporária e negociações; oficina de campanha de Sera em Xeo Taoju. |
| Início do 9º mês | Desembarque do exército principal de Marevim em Vau-Cinzento. |
| 18-23 / 9º mês | Batalha de Samarith. |
| 23 / 9º mês | Operação da Câmara e morte de Marevim. |
| 3 e 27 / 10º mês | Termos provisórios e pacto mais amplo; ratificações ainda parcialmente pendentes. |
| 12 / 12º mês | Recebimento da resposta de Arriot. |
| 28 / 12º mês | Encerramento da coleta de testemunhos da História Geral. |
| 2º Dia da Vigília | Sinos pelos mortos dos quatro exércitos. |
| 5º Dia da Vigília | Publicação ficcional da História Geral consultada. |



Fonte da sequência datada: HG pp. 145-146. As datas são marcos da concordância histórica; a presença de uma data nessa tabela não elimina conflitos pontuais com cenas ou colofões. O desfecho afetivo abaixo é uma correção editorial expressamente localizada.

### RC-N01 — Liana e Demer: amizade, sem romance

O romance entre Liana Meywood e Demer Vault é retirado da continuidade. Eles conservam amizade, confiança, cuidado e conflitos de valores. Cenas de beijo, desejo romântico, formação de casal ou separação amorosa devem ser removidas ou reescritas. O vínculo amoroso de Liana passa a ser com Rul Aven.

Base: DA2: decisão autoral posterior à edição 1.0; substitui RC-N01 / 1.0.

Aplicação: Revisar C1 e C2, HG, wikia e resumos. O antigo desfecho de separação também deixa de valer; nenhuma das duas versões anteriores é o novo cânone.

### RC-N02 — Demer e sua fé

Demer deixa a função institucional após a batalha, mas conserva sua fé e o símbolo de Ardanus. Não é automaticamente Arauto.

Base: C2 pp. 144-145; W09 demer.

Aplicação: Distinguir afastamento de função, perda de fé e condição divina.

### RC-N03 — Consequências persistentes

Le Rink conserva perda de sensibilidade em parte do braço e mão; a recuperação não é imediata. O protótipo de Sera é consumido na operação. Registros técnicos não equivalem a possuir novamente o exemplar.

Base: C2 pp. 143 e 149; W09 le-rink e sera.

Aplicação: Em cenas posteriores, manter limitações, adaptação e perda material; em retratos anteriores, não antecipá-las.

### RC-N04 — Narel e Druvak

O encontro ligado à consciência de Narel não devolve um corpo ao irmão de Nyssara. Druvak rompe com Marevim e morre protegendo uma retirada, segundo o desfecho adotado.

Base: C2; W09 nyssara, kharug, narel e druvak.

Aplicação: Não restituir personagens ou corpos por simplificação de resumo; um novo retorno exigiria decisão e explicação próprias.

### RC-N05 — Marevim e a responsabilidade

O crime institucional de 731 e o ocultamento do custo humano permanecem verdadeiros. As injustiças sofridas não absolvem Marevim de seus próprios atos. Sua morte na Câmara não apaga a necessidade de apuração.

Base: HG pp. 102 e 138-140; AN folhas reservadas; C2 pp. 138-141.

Aplicação: Preservar responsabilidades múltiplas e evitar uma versão na qual toda violência provém de um único culpado.



Coerência dos deslocamentos



A missão chega primeiro a Samarith, parte para a investigação na Rácia e depois retorna. Não se trata de uma caminhada linear única do norte até o clímax. Rul possui deslocamentos próprios. A rota de regresso e a rota do exército de Marevim não devem ser fundidas apenas porque ambas envolvem o Mar das Espadas e Vau-Cinzento.



Uma passagem de costa exige desembarque e acesso terrestre quando a cidade não está sobre a água. Um passo montanhoso exige uma rota utilizável, não apenas proximidade em linha reta. Uma mudança de mês não prova que todo o intervalo foi gasto em caminhada: controles, trabalho, reparos e espera também consomem tempo. Tempos de viagem do lore podem continuar existindo mesmo que a mecânica do RPG dispense metros e quilômetros obrigatórios.

## 14. Povos, instituições e mistérios

### RC-P01 — Oleakes e Oleakia

Oleakes são um povo de pequeno porte e traços leporinos, com orelhas longas. Há referência explícita a pelo castanho nas mãos de Ima Teren. Oleakia é a União das Tocas; pessoa, povo e estado não são sinônimos.

Base: HG p. 27; BA relato de Ima Teren; LR p. 9; W09 oleakes.

Aplicação: Não fixar altura ou pelagem única a todos. Não reduzir pessoas pequenas a encantamentos, mascotes ou uma profissão universal.

### RC-P02 — Identidades oleakes

Mira Olek pertence às tradições de origem e reservas. Ima Olek coordena a União das Tocas no presente. Ima Teren aparece no relato publicado em 2386 da II Era. Rima Vel é interlocutora de Maelis no caderno de 785. Nima Tel é exemplo de ficha de RPG.

Base: HG pp. 27 e 86; BA; FR; GJ; W09 perfis correspondentes.

Aplicação: Não fundir nomes semelhantes nem transplantar a anfitriã da II Era para o presente sem uma decisão explícita.

### RC-P03 — Defesa comunitária

Happidoh reconhece acessos; Form verifica relatos; Forty organiza defesa sem ataques autorizados a pescadores na tensão de 786. A coordenação não transforma Ima Olek em proprietária de todas as tocas.

Base: HG pp. 67 e 86; W09.

Aplicação: Preservar papéis distintos e a autonomia das comunidades.

### RC-P04 — Povos não fixam personalidade

Povo, cultura, cidadania, classe, culto e lealdade são campos distintos. As dez opções mortais de criação não esgotam todos os seres existentes no universo.

Base: LR pp. 8-10; GJ; HG quadro político.

Aplicação: Não converter bônus de ficha em temperamento obrigatório nem um governo em representante de todo o povo.

### RC-P05 — Kobolds

Kobolds foram retirados do catálogo comum de criação solicitado pelo autor. Isso não apaga Sirr-Vek ou os Tessik do Veio Frio da narrativa.

Base: DA sobre regras; LR pp. 8-10; C2; W09 sirr-vek e tessik-veio-frio.

Aplicação: Manter separadas disponibilidade mecânica e existência no mundo.

### RC-P06 — Ordem e Guilda dos Magos

Ordem dos Magos e Guilda dos Magos são instituições distintas. A Carta das Mãos Abertas de 326 da III Era trata de membros plenos não elfos na Ordem; a Guilda tem marco de organização em 286.

Base: HG p. 143; AN; W09 ordem.

Aplicação: Não fundir instituições por uma função mágica comum; não atribuir a Le Rink comando automático sobre a Ordem.

### RC-P07 — Planos e Arautos

Os planos são Noérion, Eomundus e Virtude. Arauto é uma encarnação divina excepcional, cujo chamado e reconhecimento podem ser incompletos ou disputados. Receber auxílio divino não basta para provar essa condição.

Base: W09 planos, arautos e demer; HG cosmologia.

Aplicação: Distinguir tradição cosmológica, reconhecimento institucional e confirmação narrativa.

### RC-P08 — Grande Punição e Thul Verenari

Causas e extensão da Grande Punição permanecem discutidas. A existência dos Thul Verenari e sua eventual relação com o acontecimento não estão demonstradas. A convicção de Odran integra o relato, não uma prova editorial conclusiva.

Base: FA; BA; HG; W09 thul e punicao.

Aplicação: Não preencher os mistérios com uma explicação única apresentada como descoberta já confirmada.

### RC-P09 — Neris

Neris não deve ser apresentada como manifestação divina confirmada. Relatos e interpretações sobre sua identidade permanecem abertos.

Base: HG p. 140; C2; W09 neris.

Aplicação: Conservar os depoimentos incompatíveis sem transformar uma imagem ou ficha em revelação definitiva.

### RC-P10 — História natural

Os sessenta registros de Maelis formam o catálogo de FR desta edição. Indivíduos acrescentados à categoria Natureza da wikia, como Avô Gotejo, não aumentam retroativamente o catálogo da autora.

Base: FR; W09 natureza e avo-gotejo.

Aplicação: Separar espécie, nome popular, classificação provisória e indivíduo. Não converter lenda local em propriedade universal de um organismo.



Narradores podem discordar



Uma diferença é preservável quando tem função clara: observação limitada, relato de época, interpretação religiosa, propaganda institucional ou hipótese. Para mantê-la, o texto deve dizer quem afirma, quando afirma e com que alcance. A explicação local do Sino Sem Badalo não encerra todas as versões da lenda. A discordância não precisa ser apagada para manter continuidade.



Não usar um narrador pouco confiável como desculpa automática para qualquer erro. Afirmar que uma capital está em outro continente, sem intenção narrativa nem atribuição, normalmente pede correção factual. Já uma cerimônia ou uma classificação natural pode variar entre comunidades sem contradição.

## 15. Aparência e continuidade visual

### RC-V01 — Estilo padrão

A arte padrão de Virtude usa fantasia estilizada. As figuras devem conservar posturas variadas e naturais; a composição de Liana pode ser mantida quando solicitado.

Base: DA sobre o estilo e as imagens.

Aplicação: Aplicar em novas encomendas e revisões. Uma exploração artística anterior não substitui a diretriz vigente.

### RC-V02 — Descrição antes de interpretação

Traços explicitamente descritos nos materiais orientam as imagens. Escolhas visuais não descritas, como pormenores de um rosto, não se tornam fatos canônicos automaticamente.

Base: Critério de continuidade adotado; legendas interpretativas de W09.

Aplicação: Se uma descrição física ainda não estiver ancorada em fonte ou decisão, registrar como interpretação visual, não como nova biografia.

### RC-V03 — Rostos distintos

Personagens não devem ter feições praticamente idênticas. Variar discretamente formatos de rosto, nariz, maxilar, olhos, sobrancelhas e expressão, respeitando os traços fixados no lore.

Base: DA da edição 0.9.

Aplicação: Não inventar cicatrizes, amputações, parentescos ou idade precisa apenas para diferenciar rostos.

### RC-V04 — Miniaturas e lugares

Miniaturas devem preservar rosto, cabelo e orelhas. Imagens de localidades devem acompanhar relevo, água, vegetação e povoamento descritos, com personalidade própria.

Base: DA sobre recortes e localidades.

Aplicação: Ajustar enquadramento e contenção sem alterar a anatomia. Evitar repetir uma cidade genérica para todo reino.



Fichas físicas de referência



<b>Liana Meywood.</b> Pele acobreada; mecha branca na têmpora; cicatriz no lábio inferior. Fonte de consulta: W09 / liana.



<b>Demer Vault.</b> Barba curta; cabelos pretos; queimadura no antebraço. Fonte de consulta: W09 / demer.



<b>Le Rink.</b> Olhos cinzentos; cabelo claro preso; marca no pescoço. Fonte de consulta: W09 / le-rink.



<b>Nyssara Veyl.</b> Tranças brancas finas; olhos castanhos; perda parcial do mínimo direito. Fonte de consulta: W09 / nyssara.



<b>Kharug Venn.</b> Presa inferior quebrada; cabelo raspado; marcas de corda nas mãos. Fonte de consulta: W09 / kharug.



<b>Sera Vennor.</b> Cabelo preto; sardas claras; lente no olho esquerdo. Fonte de consulta: W09 / sera.



<b>Marevim.</b> Cabelos quase brancos; olhos fundos; dois dedos pouco móveis. Fonte de consulta: W09 / marevim; conferir a passagem literária antes de acrescentar pormenores. Para Marevim, juventude relativa é compatível com cansaço e traços maduros; não há conversão numérica automática para um humano.



A ficha física descreve o corpo no momento apropriado. Um ferimento obtido em 788 não deve aparecer automaticamente em um retrato de 787. A presença de uma arma numa pintura não prova que seja o único equipamento usado pelo personagem. Sem descrição de vestuário exclusivo, variações coerentes de roupa são possíveis.

Aparência: escopo resolvido nesta edição

O autor solicitou aprofundamento de aparência, vestuário, armas e diferenças entre personagens e localidades. A edição 2.0 estabelece fichas visuais textuais, preservando marcas anteriores e identificando os complementos novos. As imagens existentes não foram regeneradas nesta tarefa.

## 16. Regras do RPG e cânone do mundo



A referência mecânica é o Livro de Regras 0.3, com Guia do Jogador 0.2 compatível. Regras de teste continuam sujeitas a partidas e revisão; a versão deve ser indicada quando houver mudança. Uma mecânica de campanha não precisa descrever literalmente cada fenômeno narrativo do mundo.

### RC-R01 — Atributos

FOR, DEX, CON, INT, VON e CAR variam de 2 a 18. MOD: 2-3 = -3; 4-5 = -2; 6-7 = -1; 8-12 = 0; 13-14 = +1; 15-16 = +2; 17-18 = +3.

Base: DA; LR p. 6.

Aplicação: Não voltar à faixa antiga de 3-18 nem substituir CON por Saúde nos campos da edição vigente.

### RC-R02 — Teste sem perícia

Uma tentativa permitida sem perícia treinada usa exatamente o atributo em porcentagem. Não recebe multiplicador, MOD, bônus circunstancial ou piso de 5%. Tarefas rotineiras podem dispensar teste; técnicas especializadas podem exigir treino.

Base: DA; LR p. 5.

Aplicação: FOR 14 significa 14%. A regra não concede conjuração ou fabricação especializada sem treinamento.

### RC-R03 — Leitura do d100

Dois dados de dez faces: um para dezena e outro para unidade, definidos antes. Os dois zeros representam 100.

Base: DA; LR p. 5.

Aplicação: Não interpretar 00 como sucesso zero.

### RC-R04 — Perícia treinada

Na regra 0.3, a fórmula é 35% + 5 × MOD + pontos investidos + bônus permanentes, respeitando os tetos da versão. A frase que manda multiplicar o atributo por cinco na mesma página é um erro editorial.

Base: LR p. 12, fórmula e frase em conflito.

Aplicação: Na revisão, escrever que entra cinco vezes o modificador do atributo. Não aplicar cinco vezes o valor bruto.

### RC-R05 — Criação

Nível 1: até três perícias treinadas e 40 pontos, no máximo 20 em uma; teto final inicial de 55%. PV máximos = CON. PM máximos = VON + MOD de INT, mínimo 6.

Base: LR p. 7.

Aplicação: Distinguir PV iniciais do ganho por avanço; não somar os 40 pontos em cada perícia.

### RC-R06 — Progressão

Um nível a cada três sessões concluídas, grupo no mesmo nível. Do 2 ao 30: +1d6 + MOD de CON PV máximos, mínimo 1; +2 PM e +5 pontos de perícia por avanço. Há marcos de aprimoramento e treinamento na tabela própria.

Base: DA sobre simplificação; LR pp. 16-18.

Aplicação: Não misturar XP antigo com sessões nem conceder o ganho por sessão individualmente.

### RC-R07 — Após o nível 30

A cada três sessões, um grau de legado: +1 PV máximo, +1 PM máximo e +5 pontos, seguindo os limites e opções de LR p. 19.

Base: LR p. 19.

Aplicação: Registrar nível 30, legado N; não extrapolar automaticamente o ganho de 1d6 para o nível 31.

### RC-R08 — Magia

Seis caminhos: Fogo, Água, Terra, Ar, Luz e Trevas. Técnicas exigem treinamento, magia conhecida e requisitos de círculo. Classe não é proibição absoluta de aprender magia.

Base: LR pp. 7, 11-12 e catálogo de magia.

Aplicação: Não trocar silenciosamente por escolas de outro sistema; mudanças exigem nova versão mecânica.

### RC-R09 — Distâncias e viagens

Posição, deslocamento e viagem são resolvidos pela cena, recursos e bom senso, sem metros ou quilômetros obrigatórios.

Base: DA; LR pp. 2 e 6.

Aplicação: Isso simplifica a mesa; não apaga geografia, obstáculos ou duração das viagens no lore.

### RC-R10 — Dano e proteção

O pedido base estabelece dano desarmado 1d3 + MOD e armas simples 1d6 + MOD. A aplicação final de tipo, mãos, FOR mínima e redução de dano segue o catálogo e o combate da versão 0.3.

Base: DA; LR catálogo de armas e combate.

Aplicação: Não transformar todo equipamento em um único dado nem somar duas proteções quando a regra manda usar o maior valor.



Limite entre sistemas e mundo



Os dez povos mortais comuns são humano, elfo alto, elfo da floresta, elfo negro, anão, orc, goblin, halfling, oleake e nogard. Eldenari é origem excepcional condicionada ao período ou à premissa. Dragões e Arautos não são pacotes comuns de criação. Elfos altos do norte e do leste são formações regionais, não um quarto pacote élfico automático (LR pp. 8-10).



As oito classes são Guerreiro, Guardião, Batedor, Ladino, Mago, Devoto, Artífice e Diplomata (LR p. 11). Títulos narrativos, como ranger ou paladino, não exigem uma classe adicional de mesmo nome. Uma ficha usada como exemplo não transforma a pessoa em participante obrigatório dos romances.

## 17. Divergências e fila de correções

Situação após a decisão autoral

DV-01 recebeu nova definição: todo romance Liana-Demer é retirado, incluindo o desfecho de separação escolhido na 1.0. DV-02 e DV-03 continuam pendentes; DV-04 e DV-05 permanecem abertos. As decisões 2.0 criam novas pendências de implantação, descritas na matriz, e não tornam corrigidos os PDFs antigos.



Os itens abaixo distinguem conflitos atuais confirmados, divergências históricas já harmonizadas nos trechos consultados e dúvidas novas. Nenhuma obra foi alterada pela produção deste Registro. A lista é uma fila de trabalho; não uma alegação de que cada ocorrência foi corrigida.

Desfecho de Liana e Demer

{"type": "audit", "id": "DV-01", "status": "IMPLANTADO NOS ROMANCES E NA HISTÓRIA GERAL / WIKIA PENDENTE", "title": "Desfecho de Liana e Demer", "evidence": "HG p. 140 mantinha o casal; C2 pp. 146-148 encerrava o romance; W09 reproduzia a separação. As três apresentações dependiam de um romance agora retirado pelo autor.", "rule": "Vale RC-N01 / 2.0: Liana e Demer não constituem casal. Liana e Rul desenvolvem relação amorosa.", "action": "Os dois romances revistos e a História Geral atualizada incorporam Liana e Rul e a amizade de Liana com Demer. Revisar a wikia, inclusive resumos, fichas e ligações entre verbetes."}

Fórmula de perícia treinada

{"type": "audit", "id": "DV-02", "status": "ALTA · CORREÇÃO PENDENTE", "title": "Fórmula de perícia treinada", "evidence": "LR p. 12 apresenta 35% + 5 × MOD + pontos; mais abaixo diz que o atributo entra multiplicado por cinco.", "rule": "Vale RC-R04: o termo é 5 × MOD. O atributo bruto não é multiplicado por cinco nessa fórmula.", "action": "Corrigir a frase e conferir exemplos e ficha de consulta numa revisão de LR. Testes sem treino permanecem atributo puro em porcentagem."}

Estado do sistema no verbete Magia

{"type": "audit", "id": "DV-03", "status": "MÉDIA · CORREÇÃO PENDENTE", "title": "Estado do sistema no verbete Magia", "evidence": "W09 / magia afirma que os caminhos poderão orientar o futuro sistema e que a conversão ainda exige definir aprendizagem e recursos. LR 0.3 já define essas regras.", "rule": "O sistema existe em versão de teste; não está ausente.", "action": "Na próxima atualização da wikia, reescrever o trecho para remeter ao sistema 0.3 e indicar que balanceamento e revisões continuam. Nenhuma publicação do site foi feita nesta tarefa."}

Welkar e Velkar

{"type": "audit", "id": "DV-04", "status": "ABERTO · PADRONIZAÇÃO", "title": "Welkar e Velkar", "evidence": "A instrução autoral mais recente usa Welkar; o mapa de referência e HG p. 81 usam Velkar. A localização além da barreira ocidental está confirmada.", "rule": "Usar remissão entre as grafias; não tratar como duas cordilheiras.", "action": "O autor poderá escolher uma grafia única em revisão futura. Até lá, não redesenhar o mapa ou substituir todas as ocorrências como se a escolha já tivesse sido explicitada."}

Nyssara e o filtro de reino

{"type": "audit", "id": "DV-05", "status": "ABERTO · VÍNCULO GEOGRÁFICO", "title": "Nyssara e o filtro de reino", "evidence": "W09 / nyssara descreve serviço da corte de Quinder, mas o campo kingdomIds aponta a Naerath. Um vínculo de origem poderia justificar o filtro, porém essa função não está explicada na ficha.", "rule": "Não é prova de contradição biográfica; a semântica do filtro precisa ser esclarecida.", "action": "Conferir origem, residência e vínculo de serviço nas fontes; depois nomear o campo e ajustar o filtro. Não atribuir lealdade por mera localização."}

Capital, bosque e floresta

{"type": "audit", "id": "DV-06", "status": "HARMONIZADO NOS TRECHOS CONSULTADOS", "title": "Capital, bosque e floresta", "evidence": "HG pp. 5, 58, 64 e 78; ME pp. 18 e 39; GV pp. 4 e 32; GJ p. 18; FR p. 12 usam a separação correta.", "rule": "Valem RC-G01 e RC-G02.", "action": "Manter o controle para PDFs anteriores e novas menções. Não afirmar que essas edições atuais ainda conservam o erro antigo com base apenas na conversa histórica."}

Nerevala e Sar-Nobil

{"type": "audit", "id": "DV-07", "status": "HARMONIZADO NOS TRECHOS CONSULTADOS", "title": "Nerevala e Sar-Nobil", "evidence": "HG pp. 73 e 81; GV pp. 11 e 19; GJ p. 12 registram grafia e distinção de serra/passagem compatíveis.", "rule": "Valem RC-G05, RC-G07 e RC-G08.", "action": "Revisar versões legadas quando forem republicadas. Preservar aliases úteis de busca."}

Tormentas como estação

{"type": "audit", "id": "DV-08", "status": "DIVERGÊNCIA APARENTE · SEM CORREÇÃO", "title": "Tormentas como estação", "evidence": "BA p. 30 e FR p. 27 usam tormentas para fenômenos e episódios de tempo, sem nomear o antigo Mar das Tormentas.", "rule": "RC-G04 elimina o topônimo antigo, não a palavra meteorológica.", "action": "Não fazer substituição global de tormentas por Lombonia."}

Datas de publicação e conhecimento

{"type": "audit", "id": "DV-09", "status": "ABERTO · CONFERÊNCIA NARRATIVA", "title": "Datas de publicação e conhecimento", "evidence": "AN é datado de 787 e contém folhas reservadas; FA possui nota posterior; HG conhece o encerramento de 788.", "rule": "Distinguir corpo original, adendo e conhecimento posterior.", "action": "Se uma passagem datada de 787 revelar um evento de 788, localizar o trecho e conferir se pertence ao adendo antes de corrigir. Esta edição não afirma ter encontrado anacronismo específico nesses casos."}

Feições e marcas físicas

{"type": "audit", "id": "DV-10", "status": "ABERTO · CONTINUIDADE VISUAL", "title": "Feições e marcas físicas", "evidence": "As imagens são interpretativas. A revisão 0.9 diferenciou retratos, mas isso não certifica a visibilidade de cada marca em toda miniatura ou cena.", "rule": "Valem RC-V02 e RC-V03.", "action": "Quando uma imagem for revista, conferir povo, cabelo, cicatrizes documentadas, equipamento, época e enquadramento; registrar a validação do arquivo exato."}



Não são erros por si só



Marevim ser relativamente jovem e parecer cansado; dois lugares compartilharem um nome quando são entidades distintas; um povo existir sem ser opção comum de RPG; um autor interno acreditar em um fenômeno que outro não confirma; a wikia reunir mais indivíduos na categoria Natureza que o número de entradas de Maelis. Cada comparação precisa preservar contexto e escala.

## 18. Lugares e relações territoriais

Inventário anterior com referência temporal

As fichas abaixo registram a base W09 no início de 788. As novas definições sociais e visuais estão no capítulo territorial desta edição; os acontecimentos posteriores de Nobilith prevalecem quando o período retratado for o encerramento do ano.



Inventário dos 70 lugares de W09, em ordem alfabética. Estas fichas conservam a referência territorial já publicada; não criam capital, fronteira ou data adicional. Os registros RC-G prevalecem sobre qualquer formulação genérica. Os vínculos abaixo indicam contexto, não necessariamente soberania ou posição atual.

356 Milles

Povoação de Milles cujo nome se associa a um antigo marco de levantamento imperial.

Aethravel

Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.

Aston

Cidade do circuito meridional de Aelvar, entre as relações de Emvale e Thalendriel.

Atlante

Cidade costeira da Rácia articulada às relações de rio e aos trajetos do Mar das Espadas.

Bosque de Aurenval

Bosque de Oleakia ligado a coleta, abrigo e negociação dos caminhos.

Bosque de Let-Thalara

Bosque de Aelvar entre os acessos de Emvale e Aston.

Bosque de Leth-Auren

Área de manejo, coleta e acordos na Grande Floresta de Nael-Sul.

Cidade de Bergen

Centro urbano setentrional ligado a abastecimento, rotas e tradições locais de Bergen.

Cidade de Chisiague

Núcleo de conselho, desembarque e armazenagem na porção interior da entrada marítima.

Cidade de Heria

Centro urbano do reino de Heria e de suas relações de corte, serviço e cavalaria.

Cidade de Jacomb

Centro urbano de Jacomb ligado às atividades de porto e às referências de pilotos.

Cidade de Milles

Capital do Reino de Milles, ao sul da grande área florestal.

Cidade de Nobilith

Centro urbano de Nobilith, com casas antigas, ofícios e relações de apresentação.

Cidade-Estado de Ayak

Governo dos cais nas desembocaduras ao norte de Quinder.

Cidadela do Norte

Posto e cidade na margem ocidental do Estreito do Norte.

Confederação Halfling de Pellanor

Rede de pequenos estados e comunidades halflings sem capital soberana única.

Confederação Orc

Pacto entre comunidades orcs que conservam autonomia e decisões em assembleia.

Corte do Estreito

Centro político insular de Nogard, articulado às casas e comandos de frota dos meio-dragões.

Domínio de Naerath

Casas de elfos negros e caminhos junto à Floresta Negra.

Dorgal

Centro político de Dorgamar, ligado a assembleias, casas e saberes de trabalho com pedra e água.

Emvale

Capital de Aelvar, ligada à corte de Arriot Ilvar e aos circuitos de Aston e Thalendriel.

Grande Floresta de Nael-Sul

Grande região florestal em torno do relevo central de Vradrath.

Grande Muralha de Hravn

Fortificações de Bergen sustentadas por postos, trabalho e abastecimento.

Ihfarilse

Centro urbano da Rácia associado a oficinas, biblioteca e aos trabalhos do Circuito do Vento Arcano.

Império de Dorgamar

O império anão, suas cidades e a infraestrutura que atravessa a pedra.

Império de Nogard

Terra dos meio-dragões, cujo império insular controla passagens orientais do Mar das Espadas.

Isnymelha

Capital da Sokeria, conhecida pela presença da pedra e pelas relações entre costa e interior.

Juu Daixo

Cidade de trabalho mineral, carvão e transporte nos acessos montanhosos da Cávia.

Leopoldina

Localidade de Milles entre os itinerários que articulam povoações e bordas florestais.

Liga dos Passos de Chisiague

Liga em torno de uma entrada marítima alongada, aberta a leste entre faixas montanhosas.

Lombonia Ghostland

Ilhas cercadas por relatos inquietantes e investigações incompletas.

Mar das Espadas

Águas que ligam reinos, cidades portuárias e memórias do comércio imperial.

Mar de Lombonia

Mar dos circuitos orientais, associado às ilhas de Lombonia e a portos de diferentes estados.

Morvek

Cidade portuária de Dorgamar, com oficinas, depósitos, moradias e serviços de navegação.

Nael-Sul

Capital de Thaelorien, nos acessos da Grande Floresta de Nael-Sul e dos relevos de Vradrath.

Nerathiel

Capital de Iltharion e centro da corte de Elyndra Vaess.

Nerevala

Cidade meridional de Valerith, disputada por reivindicações da Sokeria e da Rácia.

Nhal-Sular

Capital de Sularien, ligada à vida política e às relações costeiras de seu reino.

Nova Milles

Cidade de Milles nos circuitos de campos, pousos e floresta do interior.

Orvalda

Cidade de Thaelorien ligada aos acessos costeiros e aos caminhos florestais.

Passagem de Sar-Nobil

Rota de travessia associada à Serra de Sar-Nobil.

Pombo Torto

A estalagem de Lethra Noll em Samarith.

Quinder

Reino entre campos verdes e terras mais secas, com cultivo sustentado pelo Taoju e pelo Asmarith.

Rada de Vau-Cinzento

Ancoragem e pequenos acessos de cabotagem da costa meridional de Quinder.

Reino da Cávia

Reino de portos, mineração e transporte entre Trogu e as subidas de Juu Daixo.

Reino da Rácia

Oficinas, arquivos e circulação de técnicas nos Reinos Centrais.

Reino de Aelvar

O reino setentrional dos elfos altos, entre cidades antigas e a influência da Ordem.

Reino de Bergen

Reino setentrional de rotas frias, fortificações e tradições religiosas próprias.

Reino de Heria

Tradições de cavalaria e tensões sobre serviço, rendas e privilégios num dos Reinos Centrais.

Reino de Iltharion

Reino oriental de elfos altos, independente da corte de Emvale.

Reino de Jacomb

Reino oriental ligado à navegação, aos pilotos e à circulação de notícias entre costas.

Reino de Milles

Rotas setentrionais, floresta e relações de câmbio entre o Estreito e as cidades do interior.

Reino de Nobilith

Casas antigas, direitos de propriedade e disputas de sucessão num dos Reinos Centrais.

Reino de Sularien

Estado élfico negro do sudeste, com centro em Nhal-Sular e relações de costa próprias.

Reino de Thaelorien

O reino florestal ao sul dos Reinos Centrais.

Roial

Centro comercial e contábil de Milles, com funções próprias na rede de cidades do reino.

Samarith

Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.

Serra de Sar-Nobil

Conjunto montanhoso que atravessa predominantemente Nobilith de norte a sul.

Sokeria

Reino central ligado às margens do Mar das Espadas.

Terras dos Povos Livres

Região de comunidades e autoridades distintas, sem soberano comum.

Thalendriel

Cidade de Aelvar nas rotas que descem rumo à Cidadela do Norte.

Trogu

Capital e cidade portuária da Cávia, ligada ao comércio marítimo e às remessas do interior.

União das Tocas de Oleakia

Comunidades oleakes, refúgios e depósitos dispersos numa união de tribos e assembleias.

Vaelen Endor

Capital de Valerith e antiga capital imperial, com edifícios, mercados e arquivos de usos sucessivos.

Valada

Cidade do corredor entre Ihfarilse, as passagens interiores e os acessos do Caminho Alto.

Valerith

Reino central que conserva em Vaelen Endor uma herança imperial.

Vardessa — Império Ocidental

Estado ocidental conhecido por contatos diplomáticos e comerciais.

Vel-Narim

Centro político de Naerath, ligado aos acessos orientais da Floresta Negra.

Wegas

Cidade dos percursos interiores de Milles, ligada à região da floresta e suas estradas.

Xeo Taoju

Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.

## 19. Personagens e suas condições

Base anterior, vínculos já harmonizados

Os 75 perfis de W09 são conservados como índice de consulta, com Liana, Demer e Rul harmonizados ao novo vínculo. Os 25 novos personagens ficam no capítulo próprio. A descrição visual suplementar desta edição deve acompanhar futuras imagens.



Inventário dos 75 personagens de W09. O campo não explicitado é preservado; ausência de idade não autoriza estimá-la a partir de uma pintura. O perfil pertence ao contexto de referência indicado, e o campo posterior contém spoilers. Exemplos de RPG e pessoas de épocas antigas continuam identificados como tais. As informações de fichas não substituem a leitura de uma cena quando se revisam gestos, motivações e conhecimento disponível.

Ansa Mer

Trabalha com ajudantes, água aquecida e panos separados para atender pessoas que chegam da operação.

Aren Varn

Irmão de Tessa Varn, integra os registros de trabalhadores da caravana investigada em As Guias Partidas.

Arriot Ilvar

Rei de Aelvar e pai de Le Rink, acostumado à política da longa memória.

Avren Dal

Comanda os procedimentos de circulação na Cidadela do Norte.

Beral Oss

Contramestre ligado à tripulação de Vessa Cor.

Calven IX

O Grande Pombo de Samarith, guardião de uma instituição influente.

Darel Oss

Marinheiro ligado à operação de uma embarcação examinada em Trogu.

Demer Vault

Paladino de Ardanus, dividido entre o dever institucional e as pessoas diante dele.

Dorna Kel

Ligada à Cooperativa do Terceiro Veio, trata achados de galeria como questão de trabalho, registro e segurança.

Druvak

Irmão mais novo de Kharug Venn.

Dália Ress

Mantém a Roda Partida junto de oficinas de Ihfarilse.

Edranna Halven

Depende da receita e do prestígio do Circuito.

Edren Sol

Sua situação é discutida no caso de contratos e trabalho forçado.

Elenva Tair

Representa interesses de manejo, comunidades e concessões de madeira.

Eline

Filha de Marevim, atuou como curadora e morreu em 731, numa aldeia atingida por um Descompasso.

Elthara Sorn

Marechal a serviço de Arriot Ilvar, valoriza o cumprimento de ordens sob pressão.

Eran Pel

Conhece o acesso à casa de trabalho junto de uma pedreira desativada, a uma jornada de Valada.

Form

Ajuda a examinar relatos de infiltração nas relações costeiras de Oleakia.

Forty

Participa da defesa de Oleakia nas disputas com Nogard.

Hadrik Vel

Capataz conhecido por Kharug a partir de cobranças anteriores.

Happidoh

Participa da defesa de Oleakia pelo conhecimento dos acessos discretos e pela troca de informações com pescadores.

Ilven Sar

Agente em Vaelen Endor, apresenta relações de negócio e recibos organizados.

Ima Olek

Coordena relações entre tribos e assembleias de Oleakia, sem possuir autoridade uniforme sobre cada toca.

Ima Teren

Anfitriã oleake no relato de Odran Velis, o Três-Botas.

Irena Sol

Maga formada fora de Aethravel.

Istren Vaul

Conhece Marevim e o agravo ligado aos acontecimentos de 731.

Ivela Dorn

Conselheira ligada às reformas da Ordem.

Jassa

Nome preservado na relação de trabalhadores que Kharug leva consigo.

Kharug Venn

Orc negociador, comerciante e combatente que conhece o peso de um acordo.

Khoram Tesh

Bibliotecário orc de Ihfarilse, atento à conservação e ao acesso aos registros.

Le Rink

Príncipe de Aelvar, diplomata e mago de proteção.

Lethia Arven

Chanceler de Maressa II Veldan.

Lethra Noll

Administra uma hospedaria fora do recinto principal da Torre de Samarith.

Liana Meywood

Ranger elfa das florestas, observadora e pouco disposta a transformar afeto em permanência.

Loria Halven

Filha de Edranna Halven e piloto conhecida no Circuito do Vento Arcano.

Maela Dorn

Trabalha com registros de passagem em Valada.

Marevim

Mago elfo alto, ligado a uma história de perda e ocultação institucional.

Mavra Senn

Combina cortesia, ameaça, negócios e um fundo de auxílio às famílias dos agentes.

Meral

Pessoa encontrada por Kharug durante a operação das galerias.

Meren Voss

Comanda a Viúva de Sal e calcula o uso de pessoas, papéis e mercadorias como fontes de resgate e receita.

Mereth Sal

Mantém a hospedaria As Duas Chaves numa etapa mercantil de Naerath.

Mina

Filha adotiva de Khoram Tesh, trabalha com encadernação.

Mira Olek

Matriarca lembrada pela organização de depósitos dispersos de alimento.

Narel

Irmão de Nyssara Veyl, conhece o reconhecimento de objetos e mercadorias e procura escolher seu próprio caminho.

Neris

Nome usado por uma mulher associada à cisterna nos relatos das Crônicas.

Nima Tel

Personagem oleake de demonstração do Guia do Jogador.

Nyssara Veyl

Estudiosa elfa negra, atenta ao que inscrições e versões oficiais deixam de dizer.

Odran Fess

Nome associado a contratos de transporte e dívida.

Olen Des

Trabalha com acessos subterrâneos e retirada de materiais.

Orelna Voss

Conduz a audiência do caso das Guias Partidas.

Oren Val

Chamado de Irmão Oren Val, é uma referência institucional para Demer.

Orven Tal

Proprietário de oficinas, financia escavações associadas às chamadas Casas de Passagem.

Oth Salven

Moleiro associado ao Moinho de Salven, num circuito entre os acessos de Vel-Narim e Quinder.

Ressa Til

Participa das negociações e verificações do caso de transporte em Valada.

Rima Vel

Anfitriã oleake de Aurenval, interlocutora de Maelis Varen em observações de campo.

Rovan Ess

Participa dos procedimentos de busca e das condições de segurança do caso em Valada.

Rul Aven

Pesquisadora goblin da Ordem e amiga de Liana.

Saeren Il

Responsável pelo atendimento e encaminhamento em Thalendriel.

Seldo Mer

Seu nome aparece na relação de trabalhadores conservada por Kharug.

Seli Ar

Encontrada com o pé ferido e febre, recebe cuidados de Demer.

Selk Arven

Nome associado a uma entrega na trama de Ihfarilse.

Selyra Naereth

Rainha de Quinder, entre o dever de oferecer abrigo e o hábito de controlar os caminhos.

Sera Vennor

Inventora anã, ambiciosa e direta, que conhece a distância entre o desenho e a peça.

Sirr-Vek

Porta-voz de uma comunidade instalada em túneis ligados a antigas galerias.

Tavian Ordel

Militar experiente em articular interesses de contingentes distintos.

Tavin Orr

Aprendiz num ambiente de trabalho de Ihfarilse.

Tessa Mal

Conhece caminhos de serviço usados para distribuir alimento.

Tessa Varn

Irmã de Aren Varn e dona da mula Palha.

Toren Kel

Conhece o primeiro acesso utilizado na descida às ruínas de As Guias Partidas.

Varek Oss

Integra o ambiente de oficinas que Sera frequenta em Ihfarilse.

Varesh Khor

Atua num consórcio de armadores e agentes de seguro.

Varna Il

Participa de trabalho de escavação e segurança de acesso, em colaboração com Olen Des.

Vessa Cor

Comanda embarcações e mantém relações com o Ofício das Marés.

Yarine Vel

Sustenta uma rede de celeiros entre aldeias da Sokeria e Isnymelha.

Ysenda Corval

Mantém um abrigo na fronteira de Heria.

## 20. Catálogo natural e temas do universo



O catálogo abaixo inventaria a história natural já publicada. Códigos e classificações da autora são preservados quando disponíveis. Um nome popular não demonstra espécie biológica única. Uma alegação de observador e sua incerteza não podem ser removidas durante a adaptação para a wikia.



Fauna

| Registro | Ambiente / contexto | Estatuto |
| --- | --- | --- |
| Abelha rasa | Campos e florestas | Observação registrada |
| Andorinha das escarpas | Montanhas | Observação registrada |
| Ave dos troncos ocos | Campos e florestas | Observação registrada |
| Avô do Gotejo | Cavernas e galerias | Relato narrativo |
| Besouro dos arreios | Cidades e trabalho | Correspondência e fontes |
| Bode coroado | Montanhas | Observação registrada |
| Caracol de vidro fosco | Campos e florestas | Observação registrada |
| Caranguejo de margem escura | Mar e litoral | Correspondência e fontes |
| Caranguejo de sino | Rios e áreas úmidas | Observação registrada |
| Coruja contadora | Campos e florestas | Observação registrada |
| Enguia de vidro | Rios e áreas úmidas | Correspondência e fontes |
| Garça de cobre | Rios e áreas úmidas | Correspondência e fontes |
| Ladrão de cascas | Campos e florestas | Observação registrada |
| Lagartixa dos muros quentes | Cidades e trabalho | Observação registrada |
| Lagarto de rocha | Campos e florestas | Observação registrada |
| Lobo de cinza | Campos e florestas | Observação registrada |
| Lontra dos cais | Rios e áreas úmidas | Correspondência e fontes |
| Mariposa de folha seca | Campos e florestas | Observação registrada |
| Morcego de galeria | Cidades e trabalho | Observação registrada |
| Peixe de barba curta | Rios e áreas úmidas | Observação registrada |
| Porco de raiz | Campos e florestas | Observação registrada |
| Pássaro do poente | Mar e litoral | Correspondência e fontes |
| Rato dos celeiros | Cidades e trabalho | Observação registrada |
| Recife que respira | Mar e litoral | Observação registrada |
| Saltador de névoa | Campos e florestas | Observação registrada |
| Traça de couro úmido | Cidades e trabalho | Observação registrada |
| Veado de espelho | Campos e florestas | Correspondência e fontes |
| Verme de ferro | Cidades e trabalho | Observação registrada |
| Vespa de pote | Cidades e trabalho | Observação registrada |



Flora

| Registro | Ambiente / contexto | Estatuto |
| --- | --- | --- |
| Alga de fita parda | Mar e litoral | Observação registrada |
| Arroz de várzea | Rios e áreas úmidas | Observação registrada |
| Casca-mansa | Campos e florestas | Correspondência e fontes |
| Castanheira mansa | Campos e florestas | Correspondência e fontes |
| Centeio de inverno | Campos e florestas | Observação registrada |
| Erva de margem salobra | Mar e litoral | Observação registrada |
| Erva-de-chuva | Campos e florestas | Observação registrada |
| Flor do último frio | Campos e florestas | Observação registrada |
| Folha-de-costura | Campos e florestas | Observação registrada |
| Freixo dos pátios | Cidades e trabalho | Observação registrada |
| Junco de enseada | Mar e litoral | Correspondência e fontes |
| Junco-de-fita | Rios e áreas úmidas | Observação registrada |
| Lentilha de remanso | Rios e áreas úmidas | Correspondência e fontes |
| Linho dos cais | Cidades e trabalho | Observação registrada |
| Musgo de roldana | Campos e florestas | Observação registrada |
| Pereira dos pomares de Aston | Campos e florestas | Observação registrada |
| Pinheiro de casca escura | Campos e florestas | Observação registrada |
| Raiz-âncora | Rios e áreas úmidas | Observação registrada |
| Resineira negra | Campos e florestas | Observação registrada |
| Sal-de-vidro | Rios e áreas úmidas | Observação registrada |
| Salgueiro das duas margens | Rios e áreas úmidas | Observação registrada |
| Trigo dos campos centrais | Campos e florestas | Observação registrada |
| Urtiga de prata | Campos e florestas | Observação registrada |
| Zimbro de passo | Montanhas | Correspondência e fontes |



Fungos e afins

| Registro | Ambiente / contexto | Estatuto |
| --- | --- | --- |
| Barba de pedra | Campos e florestas | Classificação em aberto |
| Bolor de corda salgada | Mar e litoral | Classificação em aberto |
| Bolor do saco quente | Cidades e trabalho | Observação registrada |
| Crosta de vento | Montanhas | Classificação em aberto |
| Orelha de tronco | Campos e florestas | Observação registrada |
| Sino de casca | Campos e florestas | Classificação em aberto |
| Vigia vermelho | Campos e florestas | Correspondência e fontes |
| Véu das raízes | Campos e florestas | Classificação em aberto |



História, cosmologia, povos e organizações



<b>Ordem dos Magos.</b> Instituição setentrional de estudo, proteção e disputa pelo controle do conhecimento. Referência: W09 / ordem.



<b>Orcs e a Confederação.</b> Comunidades, pactos e experiências que não cabem numa única vontade política. Referência: W09 / orcs.



<b>Goblins.</b> Populações minoritárias espalhadas por muitas regiões de Virtude. Referência: W09 / goblins.



<b>Arautos.</b> Encarnações divinas que nascem sem conhecer necessariamente sua missão. Referência: W09 / arautos.



<b>Os três planos.</b> Virtude, Eomundus e Noérion na compreensão da criação. Referência: W09 / planos.



<b>Magia.</b> Estudo, prática e relações entre vontade, conhecimento e as condições do mundo. Referência: W09 / magia.



<b>Thul Verenari.</b> Lenda setentrional de um povo antigo cuja existência permanece controversa. Referência: W09 / thul.



<b>Grande Punição.</b> O acontecimento enigmático que encerra a Primeira Era. Referência: W09 / punicao.



<b>Primeira Era.</b> Dragões, eldenari, elfos altos e os conflitos em torno da criação e da magia. Referência: W09 / primeira-era.



<b>Segunda Era.</b> Reorganização dos povos, expansão imperial e fragmentação. Referência: W09 / segunda-era.



<b>Terceira Era.</b> Reinos fragmentados, antigas instituições e novas disputas. Referência: W09 / terceira-era.



<b>Caso das Guias Partidas.</b> A investigação que aproxima os futuros companheiros entre 785 e 787. Referência: W09 / guias-partidas.



<b>Oleakes.</b> Povo de pequeno porte e traços leporinos, associado às comunidades, tocas e redes de abrigo de Oleakia. Referência: W09 / oleakes.



<b>Tessik do Veio Frio.</b> Comunidade kobold ligada a túneis de galerias na região de Juu Daixo. Referência: W09 / tessik-veio-frio.



A categoria Organizações ainda não possui verbete separado para todas as instituições citadas. Isso é uma lacuna de indexação, não prova de que elas não existam. Guilda dos Magos, Heróis, Guerreiros, Vento Arcano, confrarias, cooperativas e redes podem receber dossiês próprios em uma expansão futura, mantendo os nomes e datas das fontes.

## 21. Manutenção, revisões e novas decisões



Este Registro deve ser atualizado quando surgir uma decisão que afete mais de um material, uma contradição relevante, uma mudança de nome, uma data estruturante, uma relação entre personagens ou uma regra mecânica. Pequenos ajustes de estilo não exigem nova decisão canônica. Não é necessário gerar um PDF a cada sessão de trabalho: acumule alterações na matriz editável e publique uma edição consolidada quando fizer sentido.



Como registrar uma alteração



Dê ao assunto um identificador estável. Escreva primeiro a definição vigente, com período e alcance. Depois informe de onde ela veio, qual versão substitui e quais materiais ainda precisam ser corrigidos. Quando a decisão mudar, conserve o histórico: marcar como substituída é mais útil que apagar uma escolha anterior e perder a explicação de sua existência.

| Campo | Conteúdo esperado |
| --- | --- |
| Identificador | RC para definição; DV para divergência; usar numeração nova sem reutilizar código. |
| Assunto e período | Entidade exata, época e alcance. Cidade, floresta, indivíduo e povo têm identidades diferentes. |
| Situação | AUTORAL, CONSOLIDADO, EDITORIAL ADOTADO ou EM ABERTO. |
| Definição vigente | Frase inequívoca que pode orientar a revisão. Se estiver em aberto, formular a pergunta. |
| Fonte e localização | Obra, versão e página ou capítulo; para wikia, identificador do verbete. |
| Versão substituída | Qual informação deixa de valer, se houver. |
| Impacto | Textos, imagens, índices, relações, regras e filtros afetados. |
| Implantação | Pendente, parcial ou conferida, separadamente para cada material. |
| Validação | Data real da revisão e responsável; não inventar uma data de aprovação autoral. |



Fluxo de revisão de uma obra



Antes de editar, selecione as ocorrências abertas relativas àquela obra e consulte os registros normativos. Corrija o texto, confira referências cruzadas e reveja imagens, mapas, tabelas, sumário e notas quando afetados. Depois identifique a nova edição e marque apenas as ocorrências efetivamente verificadas como implantadas. Um arquivo com título novo e conteúdo antigo não encerra uma correção.



Atualizar o Registro não publica automaticamente alterações em outros materiais. A wikia pode ser alinhada em uma tarefa breve; PDFs maiores podem esperar uma revisão conjunta. A decisão canônica permanece disponível nesse intervalo, e o leitor editorial consegue saber por que uma versão antiga diverge.



Controle de versões



A versão 1.0 foi a primeira consolidação. A versão 2.0 incorpora mudanças estruturantes aprovadas em 3 de novembro de 2026, incluindo a retirada de um romance, novos vínculos, sucessão e moedas. Uma revisão 2.1 pode reunir ajustes pontuais; uma edição 3.0 poderá acompanhar outra mudança estrutural. A numeração é editorial real e não substitui o ano ficcional. A versão mecânica do RPG continua tendo numeração independente.

| Versão | Data real | Conteúdo |
| --- | --- | --- |
| 1.0 | 03/11/2026 | Primeira consolidação: núcleo normativo, concordância, dossiês da base 0.9 e relatório DV-01 a DV-10. |
| 2.0 | 03/11/2026 | Revisão estrutural aprovada: vínculos, política, sucessão, magia, moedas, grupos, 25 novos personagens e fichas visuais. |
| 2.1 | 03/11/2026 | Implantação no Volume I: 58 capítulos, seis novos NPCs em cena e preparação do vínculo Liana-Rul. Cânone 2.0 preservado. |
| 2.2 | 03/11/2026 | Implantação no Volume II: 74 capítulos, vínculo Liana-Rul, responsabilidade da Ordem, cooperação condicionada e crise sucessória de Nobilith. |
| 2.3 | 03/11/2026 | Consolidação das quatro obras complementares e fila da wikia. |



Modelo para a próxima ocorrência



DV-[novo número] | Assunto: [...] | Material e versão: [...] | Localização: [...] | Trecho ou descrição do conflito: [...] | Registro normativo aplicável: [...] | Decisão: [...] | Pendências por material: [...] | Conferência final: [...]. Este é um modelo de trabalho, não uma ocorrência já encontrada.

Prioridade para a próxima rodada

Aplicar a matriz de implantação 2.0: revisar os romances em conjunto, depois a História Geral e obras temáticas; atualizar a wikia conforme os textos assentados. DV-02 e DV-03 continuam pendentes. Não corrigir o romance retirado para outro desfecho também superado.

| Versão | Data real | Conteúdo |
| --- | --- | --- |
| 2.4 | 5 de novembro de 2026 | Incorporação da história política imperial VE; sucessão, cronologia, pessoas, instituições, lugares e limites documentais. |

## 22. Identificação das fontes e limites desta edição



Os resumos abaixo identificam os arquivos efetivamente consultados, para distinguir uma nova edição de um PDF homônimo antigo. SHA-256 é uma impressão digital dos bytes: mudar o arquivo muda o resumo. Não é uma classificação de qualidade nem uma aprovação autoral.



AN | Anais da Ordem dos Magos



34 páginas. Arquivo: Anais_da_Ordem_dos_Magos.pdf.



2c83376306e05d3610e9efd3abd29ad001cf06dccb11062aa483edd91f7106a3



BA | Bichos e Assombros dos Caminhos



37 páginas. Arquivo: Bichos_e_Assombros_dos_Caminhos.pdf.



c0da601c6a2596337038af7d8bd22895a19227fc3ba2c1f89e55ed0a42c371ca



C1 | As Guias Partidas



156 páginas. Arquivo: Cronicas_de_Virtude_I_As_Guias_Partidas.pdf.



02e87438b9cdd53523d16c2e83485eb487056fa13bb782ae6f72002d7d30d793



C2 | As Quatro Hostes



154 páginas. Arquivo: Cronicas_de_Virtude_II_As_Quatro_Hostes.pdf.



cf0df17aeb189c758bc72cc3a829c56c95a49005e5823209e2fad1bcee6098d1



FA | As Formas da Ausência



48 páginas. Arquivo: As_Formas_da_Ausencia.pdf.



4f661d535a9760973c6204dd39fa14348c6c7e8a2c415210182a8f1dc0fdb9dd



FR | Entre Feras e Raízes



73 páginas. Arquivo: Entre_Feras_e_Raizes_Edicao_Revista.pdf.



e25fbec7cdba9d97dc11da4d492b4f060f64013b7c5548e03db1f6a2950c1db6



GJ | Crônicas de Virtude — Guia do Jogador



58 páginas. Arquivo: Cronicas_de_Virtude_Guia_do_Jogador_Edicao_Revista.pdf.



1cce349444a8e3820a89ba34e5ab8c946524b41e6b6d5583d7666e6a7a71fd04



GV | Guia dos Viajantes de 788



43 páginas. Arquivo: Guia_dos_Viajantes_de_788.pdf.



d3ea0fa8719a581bc3e6a97e9b5abdc94a4a2b06cf1a1617c4a20d12b28f71b6



HG | História Geral de Virtude



147 páginas. Arquivo: Historia_Geral_de_Virtude.pdf.



3b19cd8d8a01e3f80d6bc8dda035f8ce81e7a492ed375920cab0e67a0d5a6c34



LR | Crônicas de Virtude — Livro de Regras



64 páginas. Arquivo: Cronicas_de_Virtude_Livro_de_Regras_v03.pdf.



0a97805b467b027733905bcccb37401e3594f7ddea795b7136f2fd32aa2d6bc4



ME | O Mar das Espadas na Época de Selvar II



41 páginas. Arquivo: Mar_das_Espadas_na_Epoca_de_Selvar_II.pdf.



314efd8edd170984efee8b2170da2106aece1f5e69428a31a9a33f47d8ffd2da



W09 e mapa



W09: Wiki e Biblioteca de Virtude, edição 0.9, fonte d9ae6b9d2843978ec59b34e401ad906efc014759. O inventário compreende 220 verbetes: 75 personagens, 70 lugares, 61 registros de Natureza e 14 outros temas. A imagem cartográfica preservada na base é a referência espacial usada nas decisões geográficas desta conversa; o mapa geral não fixa sozinho escala, estrada ou condição de acesso.



Este Registro não corrige silenciosamente arquivos anteriores. O relatório documenta o que foi encontrado, a regra adotada e o que permanece pendente. Não se afirma que todas as possíveis contradições foram eliminadas, nem se transforma uma questão sem resposta em certeza apenas para completar uma ficha.



O arquivo editável que acompanha o PDF conserva a mesma estrutura e pode receber novas decisões. A cópia em PDF é a edição de consulta correspondente à versão indicada na capa. Havendo divergência futura entre uma matriz alterada e este PDF congelado, identifique a versão vigente e gere nova edição, em vez de manter dois documentos contraditórios sob o mesmo número.



As impressões digitais acima continuam identificando as fontes anteriores à revisão 2.0. DA2 é a fonte das novas decisões, não uma suposta edição já publicada dos romances. A próxima conferência deverá atualizar esse inventário somente depois que os arquivos das obras forem efetivamente revisados.

## 23. Implantação no Volume I e concordância de capítulos



Implantação realizada no Volume I, edição 2.0. Foram preservados os 54 capítulos anteriores em sua ordem e acrescentados quatro capítulos, resultando em 58. Não houve participação de Rul no resgate ou na audiência de Valada. O primeiro encontro dos seis continua ocorrendo na audiência de 787.

| Assunto | Situação após esta edição |
| --- | --- |
| Liana e Demer | Preparação romântica retirada; amizade e assistência preservadas. |
| Liana e Rul | Amizade desde 778 e correspondência aprofundadas. Aproximação amorosa formal permanece perto da abertura de C2. |
| Novos personagens | Terenna Vos, Sovel Aneth, Brena Uld, Varda En, Ceris Dalmere e Nereth Cal introduzidos em cenas. Os outros 19 continuam disponíveis para obras posteriores. |
| Sar-Nobil | Antecedentes sociais e disputa sucessória apresentados em 787; traição, morte de Osric e coroação pertencem a 788 e não ocorrem neste volume. |
| Moedas | Ilvar e lâmpada entram em circulação cotidiana, ao lado de ráculos e crédito. Não foram estabelecidas taxas universais. |
| Ordem | Cenas de arquivo, revisão insuficiente e testemunho preparam as responsabilidades. Os atos posteriores de Marevim não são antecipados como conhecidos. |
| Cenas cotidianas | Vale de depósito, trabalho de oficina, espera de viagem, manutenção de posto e responsabilidade por garantias integrados à narrativa. |



Arquivo: Cronicas_de_Virtude_Volume_I_Edicao_2.pdf. 136 páginas. SHA-256: 209a60c18529ae32f5f3df3ed2dc6b72a078d83f3dc71397dc0fccd90dea970b. O manuscrito editável conserva o texto integral da edição. Os localizadores antigos C1 continuam identificando a fonte anterior; para esta edição, usar a concordância de capítulos abaixo.

| Capítulo anterior | Capítulo atual | Título |
| --- | --- | --- |
| 1 | 1 | O animal que voltou |
| 2 | 2 | A margem inferior |
| 3 | 3 | Um reparo fora do lugar |
| 4 | 4 | A tigela de sal |
| 5 | 5 | Quem conhece o portão |
| 6 | 6 | Sete lugares para dormir |
| 7 | 7 | O peso do guincho |
| 8 | 8 | As coisas que se recuperam |
| 9 | 9 | O sinal de Ressa |
| 10 | 10 | A data da renovação |
| 11 | 11 | O serviço de Ardanus |
| 12 | 12 | Uma tarde na Roda Partida |
| 13 | 14 | A mão de Orven Tal |
| 14 | 15 | O menino da ponte |
| 15 | 16 | O que se promete em voz alta |
| 16 | 17 | A laje e a visita |
| 17 | 18 | Uma sala sem janela |
| 18 | 19 | A mesa de Orven |
| 19 | 20 | O lugar da cadeira |
| 20 | 22 | A sombra na travessa |
| 21 | 23 | A casa vazia |
| 22 | 24 | Debaixo do alpendre |
| 23 | 25 | O nome do vazamento |
| 24 | 26 | O homem do avental limpo |
| 25 | 27 | As contas abertas |
| 26 | 28 | O pão de ninguém |
| 27 | 29 | A chuva entre os anos |
| 28 | 31 | A cuba rachada |
| 29 | 32 | A laje em pé |
| 30 | 33 | Um caminho de serviço |
| 31 | 34 | A leitura de um medo |
| 32 | 35 | As ferramentas de uma noite |
| 33 | 36 | A escolha de Orven |
| 34 | 37 | A autorização cabe num bolso |
| 35 | 38 | O círculo incompleto |
| 36 | 39 | Nove nomes na escuridão |
| 37 | 40 | A sala de cima |
| 38 | 41 | O que a pedra aceita |
| 39 | 42 | A tira azul |
| 40 | 43 | A parte que ficou com eles |
| 41 | 44 | A ausência de uma resposta |
| 42 | 45 | A água depois do calor |
| 43 | 46 | Um selo fora de estação |
| 44 | 47 | O preço de uma palavra |
| 45 | 49 | O forno de Ressa |
| 46 | 50 | Os seis na mesma sala |
| 47 | 51 | O que uma testemunha reconhece |
| 48 | 52 | O primeiro erro |
| 49 | 53 | A parte do desenho que tem nome |
| 50 | 54 | A cópia que pode sair |
| 51 | 55 | Uma mesa sem ata |
| 52 | 56 | As coisas que não entram na sentença |
| 53 | 57 | O que cabe numa despedida |
| 54 | 58 | O lugar dos nomes |



Capítulos novos: O nome na bancada; A via que permanecia; A largura de uma roda; A assinatura de baixo. A nova edição não implanta os acontecimentos futuros de Samarith, o vínculo de Elthara e Tavian ou toda a expansão monetária em cenas que não comportam esses assuntos.

## 24. Implantação no Volume II e concordância de capítulos



Implantação no Volume II, edição 2.0. Os 67 capítulos anteriores permanecem em sua ordem, com revisão de 22 deles e sete capítulos acrescentados, totalizando 74. As cenas de aproximação e separação amorosa entre Liana e Demer foram substituídas; o vínculo romântico vigente é Liana-Rul. A cronologia da investigação, as subtramas independentes e os custos físicos do desfecho foram preservados.

| Assunto | Implantação e limite |
| --- | --- |
| Liana e Rul | Aproximação já existente pouco antes de 11/2/788; trabalho de escolta independente do afeto; reencontro em Trogu, cotidiano em Samarith e partida com correspondência irregular, sem coabitação prometida. |
| Liana e Demer | Amizade, colaboração e cuidado mútuo. Não houve romance ou separação amorosa nesta continuidade. |
| Ordem e 731 | Sovel distingue matrizes e autorizações; Ivela responde pela revisão insuficiente; Rul declara a demora institucional; Brena presta testemunho próprio. A apuração não termina em 788. |
| Marevim | Etapas de preservação, resposta e retenção sem consentimento; reconhecimento do crime original não absolve novos atos. Morre na Câmara em 23/9; corpo recuperado e identificado. |
| Quatro hostes | Demonstração técnica com erros expostos; recusa de promessa universal; oficiais de ligação, rendição e inspeção, sem confiança instantânea ou fim imediato da violência. |
| Elthara e Tavian | Intimidade anterior retomada; omissão causa conflito com subordinada e revisão das comunicações. Não determina automaticamente aliança nem prova troca de favores. |
| Sar-Nobil | Orientação norte-sul e casta dos cavaleiros em cena; promessa a Osric, acordo reservado Maressa-Martan e desvio consciente do socorro. Morte pela doença existente no mês 10, coroação de Martan e contestação de Helena, sem vencedor definitivo. |
| Consequências | Le Rink conserva perda de sensibilidade; Sera perde o protótipo; Narel não recebe corpo; Druvak morre sem corpo recuperado; Demer deixa a função, conserva a fé e participa da assistência. |
| Mundo cotidiano | Oficinas, abastecimento, caução em moedas distintas e manejo da água em Quinder. Não se criaram câmbio universal nem conhecimento onisciente. |
| Personagens adjacentes | Sovel, Brena, Nereth, Varda, Ceris, Terenna e Mira são mobilizados conforme funções aprovadas. Nem todos os novos personagens do Registro precisam aparecer neste romance. |
| Materiais pendentes | História Geral, wikia e demais PDFs não foram atualizados por esta entrega. Manter o Registro como referência nas divergências restantes. |



Arquivo: Cronicas_de_Virtude_Volume_II_Edicao_2.pdf. 159 páginas. SHA-256: 175f8835f78f54eabcb2f495d92933c8dcc59ad90a2c4b112c86e72f6a68ef17. O manuscrito editável conserva o texto integral. Concordância: os localizadores C2 antigos continuam apontando para a edição anterior; usar os capítulos abaixo para a edição 2.0.

| Capítulo anterior | Capítulo atual | Título |
| --- | --- | --- |
| 1 | 2 | A marca que não podia estar ali |
| 2 | 3 | A porta de abastecimento |
| 3 | 5 | A filha no vidro |
| 4 | 6 | Emvale ainda dormia |
| 5 | 7 | Uma luva para a estrada |
| 6 | 8 | O Vau das Corças |
| 7 | 9 | As portas de Thalendriel |
| 8 | 10 | A cidade junto ao Estreito |
| 9 | 11 | Os dois livros de Mereth |
| 10 | 12 | O que o preço não compra |
| 11 | 13 | Farinha no sangue |
| 12 | 14 | Um quarto fora da Torre |
| 13 | 15 | O tempo de Calven IX |
| 14 | 16 | O joelho da rainha |
| 15 | 17 | O direito de continuar |
| 16 | 18 | A voz que discordava |
| 17 | 19 | A estrada não esqueceu |
| 18 | 21 | O preço do aviso |
| 19 | 22 | O pano azul |
| 20 | 23 | A peça da qual Sera sabia |
| 21 | 24 | As páginas de Mina |
| 22 | 25 | A oferta de Mavra |
| 23 | 26 | O óleo que não era entrega |
| 24 | 27 | A primeira regra |
| 25 | 28 | Os que ficavam na oficina |
| 26 | 29 | A filha da rainha |
| 27 | 31 | A água que mudou de dono |
| 28 | 32 | Avô do Gotejo |
| 29 | 33 | Os olhos no metal |
| 30 | 34 | A amiga na porta |
| 31 | 35 | As raízes chegam ao porto |
| 32 | 36 | A urna no porão |
| 33 | 37 | A culpa tem uma cadeira |
| 34 | 38 | A pedra e o corrimão |
| 35 | 39 | A caução do Estreito |
| 36 | 40 | A Viúva de Sal |
| 37 | 41 | O nome que não era de guerra |
| 38 | 42 | Os cais de Vau-Cinzento |
| 39 | 43 | Os nomes nos receptáculos |
| 40 | 44 | Uma palavra introduzida |
| 41 | 46 | A mulher da cisterna |
| 42 | 47 | O Poço das Três Lajes |
| 43 | 48 | O papel que Le Rink guardou |
| 44 | 49 | Aqueles que esperavam a estrada |
| 45 | 50 | O trabalho que pode ser dividido |
| 46 | 51 | A carta de Druvak |
| 47 | 52 | Uma mesa com espaço para a recusa |
| 48 | 53 | A descarga |
| 49 | 55 | Antes da névoa |
| 50 | 56 | O caminho que a rainha abriu |
| 51 | 57 | Três comandos e uma cidade |
| 52 | 58 | A mulher que sabia o nome |
| 53 | 59 | A passagem do irmão |
| 54 | 60 | As Pontes das Lâmpadas |
| 55 | 61 | O caminho melhor |
| 56 | 62 | A Câmara não estava vazia |
| 57 | 63 | O nome que ele escolheu |
| 58 | 64 | O que não cabia no caderno |
| 59 | 65 | O intervalo |
| 60 | 66 | O homem diante da porta |
| 61 | 67 | O que a justiça faria |
| 62 | 68 | Eline não concordava |
| 63 | 69 | Os que saíram |
| 64 | 70 | A conta dos vivos |
| 65 | 71 | O endereço de uma carta |
| 66 | 72 | Seis caminhos |
| 67 | 74 | As últimas badaladas |



Capítulos acrescentados: Antes da volta; As vias separadas; O posto da crista; A segunda garantia; A altura da água; O quarto sem mapa; A coroa e os postos. O endereço de uma carta substitui o antigo capítulo de separação amorosa. A pedra e o corrimão reescreve a antiga cena do cais como amizade e decisão pessoal de Demer.

## 25. Consolidação das edições e atualização da wikia

Recorte histórico da edição 2.3

Este quadro conserva a situação de implantação em 3 de novembro de 2026. A incorporação de VE na edição 2.4 é registrada nos capítulos seguintes. Uma pendência antiga não comprova que a mesma pendência exista hoje.



Inventário vigente em 3 de novembro de 2026. Os volumes I e II, edição 2.0, têm concordância nos dois capítulos anteriores. A linha de materiais pendentes do Volume II descreve a situação daquela entrega. O quadro abaixo registra as revisões que vieram depois.

| Edição atualizada | Páginas | Escopo incorporado |
| --- | --- | --- |
| Historia Geral de Virtude Edicao Atualizada.pdf | 148 | Liana e Rul, apuração de 731, moedas, sucessão de Nobilith e cronologia. |
| Mar das Espadas Selvar II Edicao Atualizada.pdf | 43 | Postos, pagamentos e abastecimento no recorte 2078–2149 da II Era. Nota editorial situa as referências de 788. |
| Guia dos Viajantes de 788 Edicao Atualizada.pdf | 45 | Caderno final com moedas e avisos de viagem posteriores à batalha. Texto de Nerion fechado na Vigília de 787. |
| Entre Feras e Raizes Edicao Atualizada.pdf | 76 | Caderno editorial sobre observações, amostras e rotas de 788. Tratado de Maelis datado do fim de 787. |



Verbetes e pontos de conferência

| Área da wikia | Revisão a aplicar |
| --- | --- |
| Liana, Rul e Demer | Atualizar fichas, relações e resumos dos romances. Liana e Rul têm vínculo amoroso. Demer e Liana mantêm amizade e colaboração. |
| Ordem, Marevim e Eline | Distinguir autorização, execução, alteração de registros e apuração do isolamento de 731. Registrar Brena, Sovel, Ivela e Rul pelas funções demonstradas. |
| Nobilith, Sar-Nobil, Maressa, Martan e Helena | Distinguir serra e rota de travessia. Situar Osric vivo no começo de 788. Após a batalha, registrar morte pela doença, coroação de Martan e contestação em curso. |
| Quinder e Samarith | Distinguir a situação do início de 788, a batalha de 18 a 23/9 e o atendimento, as dívidas e a apuração no pós-guerra. |
| Moedas e comércio | Registrar emissões nas fichas territoriais e ligar ao verbete geral. Preservar as práticas locais de Oleakia, Pellanor e comunidades sem cunhagem comum. |
| Geografia e filtros | Conferir Nael-Sul, Let-Thalara, abertura leste de Chisiague, Nerevala, Milles e Pellanor além da Cordilheira de Welkar. Aplicar filtros a verbetes com localização pertinente. |
| Obras e downloads | Vincular as quatro edições atualizadas nas respectivas fichas. Identificar o recorte imperial de Selvar II e os cadernos editoriais posteriores aos textos de Nerion e Maelis. |



Os manuais de RPG permanecem em etapa própria. Este quadro serve de base para revisar a wikia e conferir suas referências, textos, tabelas, filtros e downloads antes da publicação.

## 26. Vaelen Endor: incorporação política e histórica

Incorporação vigente

As ampliações de VE são adotadas nesta edição por autorização do criador do universo. A origem de cada dado é conservada. Questões explicitamente abertas continuam sem solução.

### RC-VE01 — Incorporação e autoridade de VE

As ampliações de VE são incorporadas como continuidade editorial adotada. A autorização desta atualização é do criador de Virtude. A origem nova de um dado continua registrada para rastreabilidade. Interpretações de Iria, falas de personagens e documentos internos não se transformam em verdade absoluta por serem citados.

Base: VE pp. 4, 51–65; solicitação de incorporação do autor.

Aplicação: Usar esta edição como referência operacional para novos materiais. Conservar a marca de incerteza onde a fonte a contém.

### RC-VE02 — Recorte e alcance do Império

A crise de 1872–1880 antecede a Guerra das Correntes de 1881–1895. Vaela é proclamada em 1896. A Concordata de 2431 encerra a II Era. A diferença entre as datas da proclamação e da dissolução é 535. O núcleo corresponde às regiões dos futuros sete Reinos Centrais, Quinder e domínio variável sobre partes de Bergen. Dorgamar e as outras potências externas mantêm soberania própria.

Base: VE caps. 1–6, pp. 7–18; caderno V.

Aplicação: Evitar projetar fronteiras e monarquias de 788 sobre toda a II Era.

### RC-VE03 — Sucessão imperial ampliada

Adota-se a sequência de 14 governantes apresentada na tabela desta edição. Vaela, Selvar II e Odravel IV eram figuras anteriores; os demais reinados completam intervalos. As datas são de reconhecimento político e não definem nascimento, morte ou parentesco de primeiro grau entre sucessores.

Base: VE cap. 7, pp. 19–20; caderno II, pp. 55–56.

Aplicação: Usar os intervalos completos ao criar fichas. Não inferir genealogia sem nova definição.

### RC-VE04 — Liga, Bar-Terval e Carta das Nove Estradas

O Pacto dos Celeiros de Reth é datado em 1876; o Acordo das Contas de Madeira, em 1892. A repressão de Bar-Terval e a ruptura de Rughan ficam situadas em 1904. A versão organizada da Carta das Nove Estradas utilizada por VE é datada em 1908. As nove estradas são corredores com ramais, sem desenho exato fixado.

Base: VE caps. 3–6; cronologia pp. 51–54.

Aplicação: Distinguir data de organização da versão de uma carta e data de fundação do direito nela reunido.

### RC-VE05 — Moeda e o norte

Ráculo e nordum permanecem distintos. A revisão monetária de Selvar I, em 2021 da II Era, admite certas obrigações em nordum mediante aferição de peso. A Petição dos Sacos Fechados, de 2024, trata de cobrança que desconsiderava entrega já realizada em grão. Não há câmbio universal permanente definido.

Base: VE cap. 8, pp. 21–22.

Aplicação: Descrever conversão em seu contexto de posto, ano e serviço.

### RC-VE06 — Dorgamar e a rede de águas

Mantêm-se 1368 da II Era para a fundação convencional de Dorgamar, 2032 para o Tratado das Águas de Morvek, 2039 para o início das obras, 2058 para a primeira operação e 2116 para as ligações principais. O Aditamento dos Quatro Dias é de 2063. A rede anã combina eclusas, transbordos e tração, com saída marítima por Morvek.

Base: VE cap. 9, pp. 23–24.

Aplicação: Distinguir Companhia das Eclusas Orientais, Vedores da Água Fundida e Vedores das Três Lanternas.

### RC-VE07 — Selvar II, Tessia e a sentença do Espelho

Selvar II é imperador entre 2078 e 2149 da II Era. A correspondência de Tessia com a Mesa dos Instrumentos Reservados é datada em 2093, sem fixar a descoberta da Agulha. O processo de Leva Senn na Controvérsia do Espelho é situado em 2101. Aren Voss recusa condenação por possibilidade futura.

Base: VE caps. 10–11, pp. 25–28.

Aplicação: Conservar a separação entre consciência, memória em mana e previsão. Não substituir prova de ação por visão futura.

### RC-VE08 — Cheia e reparações

A Cheia das Sete Comportas é de 2127 da II Era. Sella Dorn atua nos socorros e tem despesas discutidas em 2128. O Inventário das Tigelas é situado em 2129. A vedora Nerra Keld participa da escolha de reparos. A recuperação comercial não equivale à indenização de todas as famílias.

Base: VE cap. 12, pp. 29–30.

Aplicação: Distinguir o evento antigo das novas pessoas e contas que o livro acrescenta.

### RC-VE09 — Heranças, portos e repressão

Preserva-se o litígio de Celandra Vey entre 2258 e 2274 e a Carta das Viúvas e Tutores de 2274. Roda de Sarnel é o moinho local nomeado por VE. O acordo estável da Liga dos Portos fica em 2312; o Acordo dos Lastros, em 2315; a revolta de Sarn, em 2337; a arbitragem, em 2339. Sarn é distrito portuário da região de Trogu.

Base: VE caps. 14–15, pp. 33–36.

Aplicação: Não tratar Sarn como reino separado nem a Carta regional como igualdade jurídica geral.

### RC-VE10 — Bergen e Segundo Amanhecer

Guerra dos Postos do Norte nomeia em VE a fase de 2376–2388 da II Era. A ascensão de Odravel IV fica em 2394; o orçamento do Segundo Amanhecer, em 2402; uma previsão vendida, em 2407; e a Conferência dos Cadernos Vazios, em 2412. O projeto busca o Relógio de Avar, encontra instrumentos menores e envolve fraude.

Base: VE caps. 16–17, pp. 37–40.

Aplicação: Não atribuir ao projeto a recuperação comprovada do Relógio. Não confundir os postos da II Era com episódios de Hravn na III Era.

### RC-VE11 — Os três pretendentes de 2418

Após a morte de Odravel IV em 2418, Maeressa Endorin, sobrinha do imperador, reivindica continuidade da casa; Aldren Veyr se apoia em parentesco matrimonial, credores e concessões; Soren Talv invoca a emergência e seu comando militar. Nenhum obtém reconhecimento comum como imperador do conjunto.

Base: VE cap. 18, pp. 41–42; caderno II p. 56.

Aplicação: Usar os três nomes como referência da crise sem inventar coroação universal posterior a 2418.

### RC-VE12 — Crise final, Quinder e Concordata

Dupla chancelaria em 2419, Cerco das Casas de Grão em 2420 e abertura da Porta de Cal em 2421 integram a crise. Vaeliss Sareth conquista Quinder em campanhas de 2424–2428. Calven III permanece em Samarith; o Acordo das Lâmpadas é de 2429. A Concordata de 2431 reconhece os sucessores. Enna Vossel, Maela Torr e Dorven Keld são negociadores nomeados nesta ampliação.

Base: VE caps. 18–21, pp. 41–48.

Aplicação: Separar paz institucional, posse e restituição de patrimônio. Preservar a mudança de era sem ano zero.

### RC-VE13 — Iria Veldar e a data do relato

Iria Veldar nasce em 704 da III Era e publica VE pela Oficina da Folha Cinzenta, em Vaelen Endor, em 784. Teren Vassel publica em 664 e morre em 676, antes do nascimento de Iria. Ela o conhece por leitura. O Guia dos Viajantes de 788 é controle editorial posterior, inacessível à autora interna de 784.

Base: VE pp. 5–6, 63–66.

Aplicação: Não escrever Iria como testemunha direta da II Era nem como aluna presencial de Vassel. A idade em dia específico depende do aniversário.

### RC-VE14 — Locais novos e limites cartográficos

Reth, Vau das Cestas, Três Argolas, Posto da Cal, Porta de Cal, Pátio do Lastro, Roda de Sarnel e Sala das Nove Chaves são lugares de escala local. A posição de cada construção não está fixada em coordenadas. Não constituem novos reinos.

Base: VE caderno IV, p. 61; capítulos correspondentes.

Aplicação: Adicionar referências locais sem redesenhar fronteiras ou estabelecer uma capital independente.

### RC-VE15 — Documentos ficcionais e resolução aberta

Folha de Dena Ors, carta de Rughan, traslado do Espelho, memorial de Ilyra e cláusula de remessas são textos ficcionais compostos em VE. Seu conteúdo estabelece o que a obra atribui a essas vozes; não implica reprodução de documento real ou infalibilidade das testemunhas.

Base: VE pp. 10, 16, 28, 40, 48; caderno VI.

Aplicação: Preservar a atribuição e não transformar cada frase de uma personagem em norma universal.

## 27. Cronologia imperial e sucessão vigente



As expressões Base e Ampliação reproduzem a procedência indicada em VE. Nesta edição, ambas integram a continuidade adotada. Os limites explicitados em RC-VE03, RC-VE07 e RC-VE15 permanecem aplicáveis.

| Data | Acontecimento | Condição |
| --- | --- | --- |
| 893 da II Era | Acordo das Três Lanternas | Base |
| 1368 da II Era | Fundação imperial convencional de Dorgamar | Base |
| 1398 da II Era | Concílio das Sete Portas | Base |
| 1517–1546 da II Era | Guerra dos Diques na bacia de Taoju e Asmarith | Base |
| 1872–1880 da II Era | Crises de abastecimento que precedem a unificação | Base |
| 1876 da II Era | Pacto dos Celeiros de Reth | Ampliação |
| 1878 da II Era | Folha de Dena Ors sobre reconhecimento de recibos | Ampliação |
| 1881–1895 da II Era | Guerra das Correntes | Base |
| 1887; 1889 da II Era | Tomada das Três Argolas; compensações | Ampliação |
| 1892 da II Era | Acordo das Contas de Madeira | Ampliação |
| 1896 da II Era | Proclamação de Vaela e afirmação de Vaelen Endor como capital | Base |
| 1904 da II Era | Data atribuída à repressão de Bar-Terval e à ruptura de Rughan | Ampliação da data; episódio é base |
| 1908 da II Era | Organização da versão da Carta das Nove Estradas aqui utilizada | Ampliação da data; carta é base |
| 1940 da II Era | Acordo das Chaves | Ampliação |
| 1946–1948 da II Era | Petição de Ilma Tessik | Ampliação |
| 1951 da II Era | Conferência dos contratos de cavalos | Ampliação |
| 1991 da II Era | Conservação de cópias locais das contas | Ampliação |
| 2021; 2024 da II Era | Revisão monetária; Petição dos Sacos Fechados | Ampliação |
| 2032; 2039 da II Era | Tratado das Águas de Morvek; início das obras | Base |
| 2058 da II Era | Primeiro conjunto da rede anã entra em serviço | Base |
| 2063 da II Era | Aditamento dos Quatro Dias de manutenção | Ampliação |
| 2078–2149 da II Era | Reinado de Selvar II | Base |
| 2093 da II Era | Correspondência sobre os estudos de Tessia | Ampliação |
| 2101 da II Era | Julgamento de Leva Senn na Controvérsia do Espelho | Ampliação da data e da acusada; controvérsia é base |
| 2108 da II Era | Reclamação dos estaleiros de Trogu | Base |
| 2110 da II Era | Conferência atribuída a Nera Talven | Ampliação |
| 2116 da II Era | Conclusão das principais ligações dos canais | Base |
| 2127 da II Era | Cheia das Sete Comportas | Base |
| 2128–2129 da II Era | Contas de socorro e Inventário das Tigelas | Ampliação |
| 2190 da II Era | Garantias sobre depósitos a credores da capital | Ampliação |
| 2223 da II Era | Conferência dos Selos de Pedra | Ampliação |
| 2258–2274 da II Era | Litígio de Celandra Vey; Carta das Viúvas e Tutores | Base |
| 2312; 2315 da II Era | Acordo estável da Liga dos Portos; Acordo dos Lastros | Ampliação das datas; liga é base |
| 2337; 2339 da II Era | Revolta de Sarn; arbitragem | Ampliação das datas; revolta é base |
| 2376–2388 da II Era | Fase chamada Guerra dos Postos do Norte | Ampliação das datas e nome; guerra dispendiosa com Bergen é base |
| 2394 da II Era | Ascensão atribuída a Odravel IV | Ampliação |
| 2402; 2407; 2412 da II Era | Orçamento do Segundo Amanhecer; previsão vendida; conferência | Ampliação das datas; projeto e fraude são base |
| 2418 da II Era | Morte de Odravel IV e sucessão disputada | Base |
| 2419; 2420; 2421 da II Era | Duas Chancelarias; Casas de Grão; Porta de Cal | Ampliação |
| 2422; 2425; 2426 da II Era | Guarda de receitas; Assembleia dos Ferros; contratos de revisão local | Ampliação |
| 2424–2428 da II Era | Campanhas de Vaeliss Sareth e conquista de Quinder | Base |
| 2429 da II Era | Acordo das Lâmpadas | Base |
| 2431 da II Era | Concordata de Vaelen e fim da II Era | Base |
| 1 da III Era | Primeiro ano da nova contagem | Base |
| 18 da III Era | Inverno das Docas Vazias | Base |
| 61–74 da III Era | Guerra das Duas Cortes e independência de Quinder | Base |
| 67 da III Era | Concordata das Comportas em Dorgamar | Base |
| 784 da III Era | Publicação deste livro por Iria Veldar | Ampliação |



Sucessão de reconhecimento político

| Governante | Reinado na II Era | Ponto de referência |
| --- | --- | --- |
| Vaela Endorin | 1896–1938 | Proclamação em 1896 é base; término ampliado |
| Teren I Endorin | 1938–1979 | Confirmação das garantias e Acordo das Chaves |
| Isera I | 1979–2018 | Depósitos e conservação de cópias locais |
| Selvar I | 2018–2050 | Revisão monetária e Tratado de Morvek |
| Maereth I | 2050–2078 | Primeira operação da rede anã e manutenção |
| Selvar II | 2078–2149 | Reinado integral já estabelecido |
| Isera II | 2149–2182 | Continuidade de contratos e revisão de obras |
| Odravel I | 2182–2216 | Concessões de cobrança e crédito sobre depósitos |
| Vaela II | 2216–2253 | Revisão de concessões provinciais |
| Teren II | 2253–2294 | Período do litígio de Celandra Vey |
| Odravel II | 2294–2330 | Negociações com a Liga dos Portos |
| Selvar III | 2330–2361 | Período aqui atribuído à revolta de Sarn |
| Odravel III | 2361–2394 | Campanhas dos Postos do Norte |
| Odravel IV | 2394–2418 | Início ampliado; morte em 2418 é base |
| Reconhecimento fragmentado | 2418–2431 | Três pretendentes, receitas provinciais e Concordata |



Após 2418 há reconhecimento fragmentado até 2431. A tabela não cria uma linha genealógica completa nem fixa a idade ou a data de morte de cada governante.



Reinos sucessores e herança

| Reino sucessor | O que a fragmentação preservou ou fortaleceu |
| --- | --- |
| Valerith | A antiga capital, arquivos e pretensão de precedência diplomática |
| Nobilith | Casas de terra, direitos patrimoniais e serviço da nobreza de cavaleiros |
| Heria | Relações entre rendas senhoriais, manutenção de cavalaria e obrigações pessoais |
| Sokeria | Fortificações e autoridade de senhores que condicionam o alcance da coroa |
| Milles | Redes de cidades e recomposição das relações com Bergen e o Estreito |
| Cávia | Receitas portuárias e articulação de Trogu com o trabalho mineral do interior |
| Rácia | Oficinas, circulação de técnicas e desenvolvimento urbano posterior |

## 28. Pessoas, instituições e locais da história imperial



A lista combina pessoas já estabelecidas e novas figuras de VE. A procedência detalhada consta da matriz imperial editável. Os governantes intermediários têm registro na tabela de sucessão. Homonímia não fixa parentesco.

| Pessoa | Lugar na narrativa |
| --- | --- |
| Vaela Endorin | Governante da liga e primeira imperatriz; capacidade de coordenação e concentração de comando |
| Dorrik Venn | Estrategista anão, aliado de Vaela; objeções privadas à extensão de poderes |
| Rughan das Duas Margens | Negociador orc; limites dos acordos comunitários e ruptura após Bar-Terval |
| Maressa de Merovél | Sacerdotisa e organizadora de abastecimento; mediação por contratos e hospitalidade |
| Dena Ors | Nova escriba da liga, ativa em registros de 1878–1883 |
| Orma Tessik | Nova delegada de fornecedores; confirmação local dos cobradores |
| Sorenna Vale | Nova capitã do episódio das Três Argolas |
| Selvar II | Imperador de 2078 a 2149; auge, obras e limites da administração |
| Tessia Orven | Arqueóloga que recuperou a Agulha de Namar e fez circular estudos |
| Aren Voss | Magistrado que recusou a condenação por uma possibilidade futura |
| Leva Senn | Nova acusada da reconstrução do processo do Espelho |
| Nera Talven | Nova comissária da conferência posterior à reclamação de Trogu |
| Sella Dorn | Nova barqueira nos socorros após a cheia |
| Nerra Keld | Nova vedora ligada à prioridade de reparos |
| Celandra Vey | Viúva que disputou a administração de uma propriedade em Nobilith |
| Rovald Vey | Primo adversário de Celandra; disputa de costume e rendas |
| Ossa Merev | Nova moradora que conserva um compromisso de alívio de serviço |
| Mira Tovel | Nova estivadora da revolta de Sarn |
| Sora Hald | Nova negociadora de Bergen durante as campanhas do norte |
| Odravel IV | Último grande imperador; patrocinador do Segundo Amanhecer |
| Ilyra Tessan | Nova pesquisadora que distingue vestígios e previsão |
| Orel Veyr | Novo agente financeiro que transforma incerteza em promessa |
| Sera Namar | Nova conferente das despesas do Segundo Amanhecer |
| Maeressa, Aldren e Soren | Novos nomes dos três pretendentes da sucessão de 2418 |
| Aressa Tonn | Nova mediadora que registra famílias deslocadas em Quinder |
| Ilvess Nor | Nova comandante de Naerath na campanha de Quinder |
| Vaeliss Sareth | Rainha de Naerath, responsável pelas campanhas de 2424–2428 |
| Calven III | Grande Pombo que permaneceu em Samarith e negociou em 2429 |
| Enna Vossel, Maela Torr e Dorven Keld | Novos negociadores da conferência de 2431 |
| Nerissa Sareth | Sucessora de Vaeliss; independência de Quinder após a Guerra das Duas Cortes |
| Iria Veldar | Nova autora interna, nascida em 704 e publicando em 784 da III Era |



Outras pessoas nomeadas nos capítulos

| Pessoa | Função e limite |
| --- | --- |
| Ilma Tessik | Peticionária por animais requisitados; ativa no processo de 1946–1948 da II Era. |
| Salenna Oss | Governadora urbana que denuncia preferências nos contratos de cavalos em 1951. |
| Bren Ossel | Ensaiador anão, ligado à revisão monetária e às tabelas de aferição do norte em 2021. |
| Ina Vel | Escrivã humana da cobrança em duplicidade discutida em 2024. |
| Tessa Varnel | Negociadora imperial de garantias de cargas em 2034. |
| Maevra Doss | Vedora que defende janela de manutenção no Aditamento de 2063. |
| Ilven Tor | Secretário da Mesa dos Instrumentos Reservados na correspondência de 2093. |
| Maren Tel | Escrivão do traslado da Controvérsia do Espelho. |
| Berna Oss | Curadora de mesa da celebração de 2116; reivindica refeições para os carregadores. |
| Ivera Veyr | Negociadora provincial que defende preservação de sementes no contexto de 2190. |
| Dela Reth | Comerciante humana entre os representantes da Liga dos Portos. |
| Ors Namar | Armador anão interessado em garantias de depósitos. |
| Taeren Ilvar | Delegado élfico interessado no reconhecimento de contratos com portos externos. |
| Aven Doss | Comandante da repressão na revolta de Sarn. |
| Halven Reth | Comissário imperial na fase dos Postos do Norte. |
| Rovan Sel | Guardião que abre a Porta de Cal às tropas de Aldren em 2421 após obter salvo-conduto para parentes. |
| Nessa Veld | Chefe de depósito que negocia alimento durante o Cerco das Casas de Grão em 2420. |
| Tem Oss | Tabelião goblin que usa a fórmula até revisão das partes em contratos de 2426. |
| Maela Torr | Governadora ligada ao Termo de Guarda das Receitas de Trogu em 2422; representante de depósitos na conferência final. |
| Edran Voss | Comandante que autoriza destruição de cercas para uma faixa de passagem na repressão de Bar-Terval. |



Instituições

| Instituição | Atuação e instrumento de poder |
| --- | --- |
| Conselho do Abastecimento | Reunião da liga anterior à coroa; reservas, comboios e reconhecimento de contribuições |
| Comando de guerra da liga | Poder emergencial cuja renovação ajudou a concentrar a autoridade de Vaela |
| Corte imperial | Nomeações, arbitragem e coordenação de recursos sob o selo comum |
| Governadores provinciais | Arrecadação, tropas e execução local; confirmação progressivamente ligada a casas |
| Assembleias urbanas | Negociação de obras, receitas e prerrogativas das cidades |
| Colégio das Contas | Fiscalização de receita e posterior validação de obrigações e títulos |
| Mesa dos Percursos | Nome criado neste volume para os serviços de correio, postos e cópias |
| Mesa dos Instrumentos Reservados | Repartição nova para pedidos de acesso a estudos e instrumentos de mana |
| Companhia das Eclusas Orientais | Administração por concessão de parte da rede anã independente |
| Vedores da Água Fundida | Fiscalização da operação e das obras da rede de águas |
| Vedores das Três Lanternas | Segurança de escavações; tradição do acordo de 893 |
| Liga dos Portos | Coordenação de cidades e interesses marítimos; suspensão de remessas como pressão |
| Casa de Conta de Namar-Tel | Associação de credores criada neste volume; garantias sobre receita e depósitos |
| Grande Pombo e santuários dos Sete | Autoridade religiosa, acolhimento, patrimônio e negociação em Samarith |
| Ordem dos Magos | Pesquisa, guarda de instrumentos e regulação de acesso a conhecimentos |
| Equipes do Segundo Amanhecer | Pesquisa patrocinada pela última corte, atravessada por promessas e fraude |



Locais e escalas

| Local | Definição |
| --- | --- |
| Reth | Distrito de armazenagem do entroncamento anterior à capital; contexto do pacto de 1876. |
| Vau das Cestas | Pouso e aferição na região da futura Valerith; não recebe coordenadas. |
| Três Argolas | Posto de pedágio na região da futura Heria, tomado em 1887. |
| Posto da Cal | Fiscalização de recibos nos acessos da capital. |
| Porta de Cal | Posição defensiva da capital aberta em 2421. Não presumir identidade com o posto. |
| Pátio do Lastro | Setor de Morvek ligado aos socorros da cheia. |
| Roda de Sarnel | Moinho da propriedade em disputa no litígio de Celandra. |
| Sarn | Distrito portuário da região de Trogu; episódio anterior recebe desenvolvimento e datas em VE. |
| Sala das Nove Chaves | Dependência da antiga administração de Vaelen Endor onde VE situa a conferência final. |
| Ponte Seca | Nome do protocolo de 2388 e referência local do conflito do norte, sem localização cartográfica precisa. |

## 29. Conferência de compatibilidade e implantação de VE



A conferência entre a base 2.3 e VE não identificou incompatibilidade nos marcos principais da unificação, do reinado de Selvar II, da dissolução ou da mudança de era. As novas precisões se somam ao núcleo anterior, com os limites registrados em RC-VE.

### RC-VE16 — Alegações de documentos e acontecimentos

A cronologia conserva datas de atos, conflitos e pessoas. Expressões de memória, reputação e interpretação presentes no livro são atribuídas aos seus participantes. Não se presume que todas as autoridades adotavam o mesmo calendário no momento do ato.

Base: VE caps. 1 e 21; caderno VI.

Aplicação: Manter era e origem ao transportar datas para resumos.



Questões em aberto

### RC-VEA01 — Lacuna preservada 1

Genealogia completa dos Endorin e das casas ligadas à coroa. Parentescos de primeiro grau não se deduzem da sequência de reinados.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA02 — Lacuna preservada 2

Nascimento, morte e idade dos governantes e pessoas sem datas expressas. Uma troca de governante não equivale automaticamente à morte do anterior.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA03 — Lacuna preservada 3

Traçado exato das Nove Estradas, ramais de canais e posição dos distritos locais.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA04 — Lacuna preservada 4

Extensão do domínio imperial em Bergen em cada fase. A presença de tropas e a cobrança variavam.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA05 — Lacuna preservada 5

Texto integral da Concordata de 2431 e datas diárias de seus atos. As cláusulas literárias de VE não constituem uma edição diplomática completa.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA06 — Lacuna preservada 6

Data exata da recuperação da Agulha de Namar. A carta de 2093 atesta correspondência, sem datar por si a descoberta.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.

### RC-VEA07 — Lacuna preservada 7

Data do aniversário de Iria Veldar. A diferença entre 704 e 784 é de oitenta anos, sem fixar a idade completada em um dia.

Base: VE caderno VI, pp. 63–65.

Aplicação: Exige nova definição antes de ser tratada como fato.



Implantação nas obras

| Material | Situação após a edição 2.4 |
| --- | --- |
| VE | Fonte incorporada; 66 páginas; nomes e datas ampliados adotados com os limites desta edição. |
| Registro de Continuidade | Atualização efetuada nesta edição 2.4 em PDF e matriz editável. |
| História Geral de Virtude | Usar RC-VE ao revisar a síntese imperial e sua cronologia; reescrita e novo PDF não fazem parte desta atualização. |
| O Mar das Espadas na Época de Selvar II | Preservar o recorte de 2078–2149 e a data de Vassel em 664; detalhes adicionais só devem entrar conforme o acesso do autor interno. |
| Wikia | Fila de incorporação de governantes, personagens, instituições, pactos e marcos. Este Registro não atesta a implantação desses itens no site. |
| Crônicas e manuais | Aplicar como antecedente histórico em futuras revisões quando pertinente. Evitar acesso de personagens a obras ainda não publicadas em sua época. |

## 30. Organização geral: tempo, vínculos e referências

Finalidade da atualização

Esta edição conserva o corpo de definições 2.4 e acrescenta índices de consulta usados também pela wikia. Não substitui os livros por resumos nem cria relações para preencher lacunas. O Registro continua sendo a referência normativa em caso de divergência.

### RC-O01 — Cronologia única e identificável

Os índices da wikia e desta matriz compartilham os mesmos identificadores de acontecimentos e vínculos. Cada item conserva referência, precisão e limites. A organização não cria novas datas ou relações por inferência.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O02 — Precisão temporal preservada

Datas aproximadas continuam aproximadas; intervalos, anos agrupados e datas sem dia não se tornam datas completas. Os anos são comparados dentro de cada era. A ausência de ano zero é preservada. A formação dos planos não recebe duração material demonstrada.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O03 — Encontro, parentesco e sucessão

Sobrenome comum, presença numa cena e sequência de governantes não demonstram parentesco. Um encontro documentado não é automaticamente amizade, aliança ou cooperação permanente. A filiação explícita de Isera a Teren I permanece uma relação específica, sem preencher toda a cadeia genealógica.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O04 — Fonte e atribuição

Cada acontecimento e vínculo apresenta arquivo e página, ou registro normativo identificável. A interpretação de uma autora interna conserva atribuição. A fonte usada pelos novos índices é identificada por arquivo, páginas e impressão digital nesta matriz.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O05 — Spoilers e início de 788

A wikia usa o início de 788 como marco público. Acontecimentos posteriores e vínculos que revelam seus resultados são ocultados pelo controle de spoilers, inclusive na busca e nos filtros. O acesso a um PDF integral não elimina seus spoilers. Este Registro é referência autoral integral e contém os desfechos.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O06 — Escalas e cobertura

Regiões de referência orientam a consulta sem fixar as mesmas fronteiras em todas as eras. O índice de vínculos é uma seleção confirmada, não um cadastro exaustivo de toda relação possível. Nomes citados podem participar da rede antes de possuírem artigo próprio.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O07 — Manutenção conjunta

Uma decisão que modifique data, identidade, vínculo ou condição de conhecimento exige conferir o Registro, o índice da cronologia, a rede de vínculos e os verbetes afetados. As obras completas podem ser atualizadas em edições programadas. Nenhuma divergência em aberto recebe solução automática.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

### RC-O08 — Continuidade visual

Retratos continuam subordinados às descrições canônicas. Feições, roupas e idades aparentes não especificadas são interpretação visual e não estabelecem novos fatos biográficos. Os retratos imperiais da wikia 0.24 não suprem lacunas genealógicas ou cronológicas.

Base: Consolidação das fontes existentes e solicitação autoral de organização em 7 de novembro de 2026.

Aplicação: Aplicar na wikia, na matriz editável e nas revisões futuras.

## 31. Cronologia geral com referências



O índice contém 148 marcos selecionados. As referências HG e VE desta seção apontam aos arquivos identificados no quadro de fontes do índice. R24 aponta à edição 2.4 como origem documental de definições aqui preservadas. Eventos do mesmo ano não são automaticamente causas uns dos outros.

| Código | Fonte do índice / arquivo | Páginas / SHA-256 |
| --- | --- | --- |
| HG | História Geral de Virtude / Historia_Geral_de_Virtude.pdf | 148 pp. / e48a8453cfcc8e62b26e88eed94c07366bb099ef5007750eab7cfb81207d45a8 |
| VE | Vaelen Endor — A construção e a queda do Império / Vaelen_Endor_A_Construcao_e_a_Queda_do_Imperio.pdf | 66 pp. / d14fe79da436dd65fa4853c5bf07417c6e01a3d64c55518da95a533468f5bfcc |
| R24 | Registro de Continuidade 2.4 — fonte das definições preservadas / Registro_de_Continuidade_Virtude_v2_4.pdf | 138 pp. / 9c97328532251bc4c546c5ed767efb5333f28ca994e6990fb01d6759c3d2b3b0 |



Antes da contagem

| ID / data | Acontecimento e limite | Fonte |
| --- | --- | --- |
| EV-001 / Antes da contagem | Formação dos planos segundo as tradições da Consciência Una. Cosmologia; duração indeterminável. / Precisão: Indeterminada | HG p. 142 |



I Era

| ID / data | Acontecimento e limite | Fonte |
| --- | --- | --- |
| EV-002 / c. 1 da I Era | Horizonte convencional dos primeiros dragões. Marco retrospectivo, não uma data de nascimento demonstrada. / Precisão: Aproximada | HG p. 142 |
| EV-003 / c. 2100 da I Era | Primeiros assentamentos identificados como Eldenari. Datação aproximada de vestígios. / Precisão: Aproximada | HG p. 142 |
| EV-004 / c. 2550 da I Era | Consolidação urbana de Xeo Taoju. Reconstrução arqueológica e textual. / Precisão: Aproximada | HG p. 142 |
| EV-005 / c. 2700-2760 da I Era | Trabalhos de Ilyra e fundação da Casa dos Nomes de Oren. Tradições e cópias de registros. / Precisão: Aproximada | HG p. 142 |
| EV-006 / c. 5990 da I Era | Travessia das Sete Portas. Concordância de relatos élficos. / Precisão: Aproximada | HG p. 142 |
| EV-007 / c. 6035 da I Era | Fundação da Ordem em Aethravel. Data relativa à Travessia. / Precisão: Aproximada | HG p. 142 |
| EV-008 / c. 6360 da I Era | Organização do círculo dos Primeiros Magos. Fragmentos das casas de pesquisa. / Precisão: Aproximada | HG p. 142 |
| EV-009 / c. 6384 da I Era | Ativação do Selo. Nove anos antes da abertura da guerra, segundo a sequência adotada. / Precisão: Aproximada | HG p. 142 |
| EV-010 / c. 6393-6399 da I Era | Sete campanhas da Guerra das Nove Vigílias. Sequência relativa melhor conhecida que a numeração. / Precisão: Aproximada | HG p. 142 |
| EV-011 / Fim da I Era, c. 6400 | Ruptura do Selo e Grande Punição, separadas por vinte e três dias. Limite convencional da era. / Precisão: Aproximada | HG p. 142 |



II Era

| ID / data | Acontecimento e limite | Fonte |
| --- | --- | --- |
| EV-012 / 1-40 da II Era | Período mais intenso de escuridão e destruição. Datas regionais convertidas. / Precisão: Intervalo | HG p. 142 |
| EV-013 / 1-c. 1000 da II Era | Milênio das Trevas; migrações e reconstruções desiguais. Período histórico amplo. / Precisão: Aproximada | HG p. 142 |
| EV-014 / 173 da II Era | União dos celeiros associada a Nara. Tradição datada em cópias posteriores. / Precisão: Datada | HG p. 142 |
| EV-015 / c. 462 da II Era | Paliçadas e postos setentrionais ligados ao Ano do Brilho Imóvel. Tradição de Bergen preservada em cópias posteriores; não comprova Thul Verenari. / Precisão: Aproximada | HG p. 142 |
| EV-016 / 612 da II Era | Desastre de Lombonia. Registros costeiros e documentos recuperados. / Precisão: Datada | HG p. 142 |
| EV-017 / 893 da II Era | Cópia mais antiga do Acordo das Três Lanternas. Testemunho documental preservado. / Precisão: Datada | HG p. 143 |
| EV-018 / 1084 da II Era | Paz de Dorgal. Tratado em cópias concordantes. / Precisão: Datada | HG p. 143 |
| EV-019 / 1261 da II Era | Tratado das Três Margens. Documento de irrigação e paz. / Precisão: Datada | HG p. 143 |
| EV-020 / 1368 da II Era | Fundação convencional do Império de Dorgamar. Reconhecimento da chefia comum entre cidades e casas. / Precisão: Datada | HG p. 143 |
| EV-021 / 1398 da II Era | Concílio das Sete Portas. Contagem reconhecida nos santuários de Samarith. / Precisão: Datada | HG p. 143 |
| EV-022 / 1517-1546 da II Era | Guerra dos Diques em Quinder, na bacia de Taoju e Asmarith. Conflito anterior ao império de Vaelen Endor e aos canais orientais de Dorgamar. / Precisão: Intervalo | HG p. 143 |
| EV-023 / 1872-1880 da II Era | Crise de abastecimento e formação da liga de Vaela. Registros de cidades e comboios. / Precisão: Intervalo | HG p. 143 |
| EV-105 / 1876 da II Era | Pacto dos Celeiros de Reth. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-106 / 1878 da II Era | Folha de Dena Ors sobre reconhecimento de recibos. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-024 / 1881-1895 da II Era | Campanhas da Guerra das Correntes. Concordância militar das cidades da liga. / Precisão: Intervalo | HG p. 143 |
| EV-107 / 1887; 1889 da II Era | Tomada das Três Argolas; compensações. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-108 / 1892 da II Era | Acordo das Contas de Madeira. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-025 / 1896 da II Era | Proclamação imperial de Vaela. Marco oficial de fundação. / Precisão: Datada | HG p. 143 |
| EV-130 / 1896–1938 da II Era | Governo de Vaela Endorin. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-109 / 1904 da II Era | Data atribuída à repressão de Bar-Terval e à ruptura de Rughan. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-110 / 1908 da II Era | Organização da versão da Carta das Nove Estradas aqui utilizada. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-131 / 1938–1979 da II Era | Governo de Teren I Endorin. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-111 / 1940 da II Era | Acordo das Chaves. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-112 / 1946–1948 da II Era | Petição de Ilma Tessik. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo | VE p. 51–54 |
| EV-113 / 1951 da II Era | Conferência dos contratos de cavalos. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-132 / 1979–2018 da II Era | Governo de Isera I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-114 / 1991 da II Era | Conservação de cópias locais das contas. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-133 / 2018–2050 da II Era | Governo de Selvar I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-115 / 2021; 2024 da II Era | Revisão monetária; Petição dos Sacos Fechados. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-026 / 2032, 2039 e 2058 da II Era | Tratado das Águas, começo das obras e primeiro conjunto de canais em serviço. Marcos distintos da rede oriental de Dorgamar. / Precisão: Datada | HG p. 143 |
| EV-134 / 2050–2078 da II Era | Governo de Maereth I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-116 / 2063 da II Era | Aditamento dos Quatro Dias de manutenção. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-027 / 2078-2149 da II Era | Reinado de Selvar II e auge da Paz das Estradas. Contagem de reinado. / Precisão: Intervalo | HG p. 143 |
| EV-117 / 2093 da II Era | Correspondência sobre os estudos de Tessia. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-118 / 2101 da II Era | Julgamento de Leva Senn na Controvérsia do Espelho. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-119 / 2110 da II Era | Conferência atribuída a Nera Talven. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-028 / 2116 e 2127 da II Era | Conclusão das principais ligações e Cheia das Sete Comportas. Ampliações e conflito de operação. / Precisão: Datada | HG p. 143 |
| EV-120 / 2128–2129 da II Era | Contas de socorro e Inventário das Tigelas. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo | VE p. 51–54 |
| EV-135 / 2149–2182 da II Era | Governo de Isera II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-136 / 2182–2216 da II Era | Governo de Odravel I. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-121 / 2190 da II Era | Garantias sobre depósitos a credores da capital. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-137 / 2216–2253 da II Era | Governo de Vaela II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-122 / 2223 da II Era | Conferência dos Selos de Pedra. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-138 / 2253–2294 da II Era | Governo de Teren II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-029 / 2258-2274 da II Era | Litígio de Celandra e Carta das Viúvas e Tutores. Processo e carta regional. / Precisão: Intervalo | HG p. 143 |
| EV-139 / 2294–2330 da II Era | Governo de Odravel II. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 55 |
| EV-123 / 2312; 2315 da II Era | Acordo estável da Liga dos Portos; Acordo dos Lastros. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-140 / 2330–2361 da II Era | Governo de Selvar III. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 56 |
| EV-124 / 2337; 2339 da II Era | Revolta de Sarn; arbitragem. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-141 / 2361–2394 da II Era | Governo de Odravel III. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 56 |
| EV-125 / 2376–2388 da II Era | Fase chamada Guerra dos Postos do Norte. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Intervalo | VE p. 51–54 |
| EV-145 / 2386 da II Era | Publicação de Bichos e Assombros dos Caminhos. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada | R24 p. 8 / Cap. 12, concordância anterior a 788 |
| EV-142 / 2394–2418 da II Era | Governo de Odravel IV. Período de reconhecimento político; não informa nascimento, morte ou parentesco automático. / Precisão: Intervalo | VE p. 56 |
| EV-126 / 2402; 2407; 2412 da II Era | Orçamento do Segundo Amanhecer; previsão vendida; conferência. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-030 / 2418 da II Era | Morte de Odravel IV e abertura da disputa sucessória. Registros da corte. / Precisão: Datada | HG p. 143 |
| EV-127 / 2419; 2420; 2421 da II Era | Duas Chancelarias; Casas de Grão; Porta de Cal. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-128 / 2422; 2425; 2426 da II Era | Guarda de receitas; Assembleia dos Ferros; contratos de revisão local. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-031 / 2424-2428 da II Era | Campanhas de conquista de Quinder. Fontes rivais concordam sobre o intervalo geral. / Precisão: Intervalo | HG p. 143 |
| EV-032 / 2429 da II Era | Acordo das Lâmpadas. Instrumento preservado em Samarith. / Precisão: Datada | HG p. 143 |
| EV-033 / 2431 da II Era | Concordata de Vaelen e fim da era. Marco utilizado nesta edição. / Precisão: Datada | HG p. 143 |



III Era

| ID / data | Acontecimento e limite | Fonte |
| --- | --- | --- |
| EV-034 / 1 da III Era | Primeiro ano posterior à dissolução reconhecida. Sem ano zero. / Precisão: Datada | HG p. 143 |
| EV-035 / 18 da III Era | Inverno das Docas Vazias em Dorgamar. Crise comercial, dívidas e conflitos. / Precisão: Datada | HG p. 143 |
| EV-036 / 27-46 da III Era | Formação da rede reconhecida como Guilda dos Guerreiros. Casas locais anteriores ao acordo geral. / Precisão: Intervalo | HG p. 143 |
| EV-037 / 61-74 da III Era | Guerra das Duas Cortes e independência de Quinder. Acordos, remessas e crônicas. / Precisão: Intervalo | HG p. 143 |
| EV-038 / 67 da III Era | Concordata das Comportas. Reorganização e suspensão parcial de ramais em Dorgamar. / Precisão: Datada | HG p. 144 |
| EV-039 / 98 da III Era | Pacto das Duas Fozes e reconhecimento da autonomia de Ayak. A ocupação e o nome do porto são anteriores. / Precisão: Datada | HG p. 144 |
| EV-040 / 147 da III Era | Fundação da Guilda dos Heróis. Registros da Heria. / Precisão: Datada | HG p. 144 |
| EV-041 / 150-200 da III Era | Auge inicial dos Heróis. Periodização aproximada. / Precisão: Aproximada | HG p. 144 |
| EV-042 / 164 da III Era | Pacto dos Ancoradouros. Consolidação política associada a Sularien. / Precisão: Datada | HG p. 144 |
| EV-043 / 208 da III Era | Reunião inaugural da Mesa das Sete Panelas. Tradição documental halfling. / Precisão: Datada | HG p. 144 |
| EV-044 / 219 da III Era | Programa de construção da muralha de pedra de Bergen. Posterior a postos e paliçadas da II Era. / Precisão: Datada | HG p. 144 |
| EV-045 / 286 da III Era | Organização da Guilda dos Magos. Estatutos e cartas de adesão. / Precisão: Datada | HG p. 144 |
| EV-046 / 318 da III Era | Desastre das Galerias de Anver. Registros da Ordem e dos mineiros. / Precisão: Datada | HG p. 144 |
| EV-047 / 326 da III Era | Carta das Mãos Abertas. Admissão de não elfos como membros plenos da Ordem. / Precisão: Datada | HG p. 144 |
| EV-048 / 412 e 438 da III Era | Circuito precursor e carta da Guilda do Vento Arcano. Marcos distintos, frequentemente confundidos. / Precisão: Datada | HG p. 144 |
| EV-143 / 462 da III Era | Nascimento de Marevim Aethros. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada | R24 p. 65 / RC-T05 |
| EV-049 / 521 da III Era | Expansão naval documentada da dinastia Khor-Azhar. Início documental, não origem de Nogard. / Precisão: Datada | HG p. 144 |
| EV-050 / 548 da III Era | Fundação dos Irmãos da Ponte Fria. Acordos de transporte do norte. / Precisão: Datada | HG p. 144 |
| EV-051 / 563 e 571 da III Era | Inverno dos Sem-Rosto e ampliação da muralha. Incidentes e obras não são o mesmo evento. / Precisão: Datada | HG p. 144 |
| EV-052 / 588 da III Era | Início do reinado de Ariessa em Thaelorien. Registros de corte. / Precisão: Datada | HG p. 144 |
| EV-053 / 602 da III Era | Acordo inicial da Liga das Balanças. Cartas comerciais. / Precisão: Datada | HG p. 144 |
| EV-054 / 622 e 631 da III Era | Início do reinado de Arriot e Acordo dos Pomares de Aston. Governo de Aelvar e direitos de cultivo. / Precisão: Datada | HG p. 144 |
| EV-055 / 654 da III Era | Acordo dos Viveiros. Conservação, acesso e cobranças em Thaelorien. / Precisão: Datada | HG p. 144 |
| EV-146 / 664 da III Era | Publicação do estudo de Teren Vassel sobre o Mar das Espadas. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada | VE p. 5 |
| EV-147 / 676 da III Era | Morte de Teren Vassel. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada | VE p. 5 |
| EV-056 / 681 da III Era | Organização da Confraria do Carvão e do Ferro. Registros de Juu Daixo. / Precisão: Datada | HG p. 144 |
| EV-057 / 689 da III Era | Organização da Rede das Chaves Pequenas. Apoio a viajantes e famílias, sem território soberano goblin. / Precisão: Datada | HG p. 144 |
| EV-058 / c. 697-713 da III Era | Consolidação da aliança dos Ladrões. Intervalo inferido; ausência de estatuto verificável. / Precisão: Aproximada | HG p. 144 |
| EV-059 / 703 e 716-722 da III Era | Ascensão de Zeryssa e disputa das rendas entre Naerath e Quinder. Boicotes, processos e Acordo de Vel-Narim. / Precisão: Intervalo | HG p. 145 |
| EV-148 / 704 da III Era | Nascimento de Iria Veldar. Iria conhece Vassel por leitura; ele morreu antes de seu nascimento. / Precisão: Datada | VE p. 5 |
| EV-060 / 731 da III Era | Isolamento da aldeia e morte de Eline. Investigação iniciada e documentos posteriormente abertos. / Precisão: Datada | HG p. 145 |
| EV-061 / 734 da III Era | Autorização do Conselho das Duas Margens. Carta de Quinder. / Precisão: Datada | HG p. 145 |
| EV-062 / 739 e 741 da III Era | Petição dos Filhos Sem Lote e ascensão de Elyndra em Iltharion. Eventos distintos de migração e governo. / Precisão: Datada | HG p. 145 |
| EV-063 / 742 da III Era | Acordo das Raízes Baixas. Direitos de uso de Leth-Auren. / Precisão: Datada | HG p. 145 |
| EV-064 / 752-758 da III Era | Disputa dos Faróis. Iltharion, Aelvar e fiscalização de sinais. / Precisão: Intervalo | HG p. 145 |
| EV-065 / 754 da III Era | Coroação de Brunna IV em Dorgamar. Registros da corte anã. / Precisão: Datada | HG p. 145 |
| EV-066 / 755 da III Era | Revisão limitada apoiada por Ivela. Procedimento da Ordem. / Precisão: Datada | HG p. 145 |
| EV-067 / 758 e 759 da III Era | Reconhecimento da Oficina dos Arcos e fundação da Casa do Tipo Azul. Ofícios e publicação em Samarith. / Precisão: Datada | HG p. 145 |
| EV-068 / 759 da III Era | Marevim alcança a Gema em Lombonia. Data reconstruída de seus registros e deslocamentos. [SPOILER] / Precisão: Datada | HG p. 145 |
| EV-069 / 763-770 da III Era | Querela de Terval. Terras, passagem e indenizações ligadas às famílias de Kharug e Druvak. / Precisão: Intervalo | HG p. 145 |
| EV-070 / 769 da III Era | Abertura do Livro das Esporas. Revisão de rendas da Heria. / Precisão: Datada | HG p. 145 |
| EV-071 / 770 da III Era | Início da compilação da História Geral de Virtude. Cadernos de trabalho da autora da História Geral. / Precisão: Datada | HG p. 145 |
| EV-072 / 772 da III Era | Disputa das Pontes Baixas. Pesos, taxas e passagens em Pellanor. / Precisão: Datada | HG p. 145 |
| EV-073 / 774-777 da III Era | Disputa de ensaios monetários entre a Liga e Milles. Contas e decisões comerciais. / Precisão: Intervalo | HG p. 145 |
| EV-074 / 778 da III Era | Apresamento das Três Bandeiras. Pirataria, documentos e seguros. / Precisão: Datada | HG p. 145 |
| EV-144 / 778 da III Era | Trabalho de campo do qual vem a amizade de Liana e Rul. Sem aniversário ou dia acrescentado à informação da fonte. / Precisão: Datada | R24 p. 10 / RC-A05 |
| EV-075 / 779-783 da III Era | Disputa das obras de irrigação em Quinder. Conselho, medições e petições. / Precisão: Intervalo | HG p. 145 |
| EV-076 / 781 da III Era | Abertura da Questão dos Celeiros na Sokeria. Petições de aldeias. / Precisão: Datada | HG p. 145 |
| EV-077 / 781 e 783 da III Era | Querela das Âncoras e Petição das Margens Vazias. Conflitos distintos em Sularien e Dorgamar. / Precisão: Datada | HG p. 145 |
| EV-078 / 782 da III Era | Mandato de coordenação de Rugha Sen. Não constitui uma monarquia sobre a Confederação Orc. / Precisão: Datada | HG p. 145 |
| EV-079 / 784 da III Era | Acordo dos Sacos de Sal. Convenções aduaneiras. / Precisão: Datada | HG p. 145 |
| EV-080 / 784 da III Era | Incidente das Talhas e início do mandato de Ilyne Tess. Eventos distintos em Nerevala e Ayak. / Precisão: Datada | HG p. 146 |
| EV-129 / 784 da III Era | Publicação de Vaelen Endor — A construção e a queda do Império por Iria Veldar. Ampliação histórica adotada no Registro 2.4; não aumenta a precisão além da fonte. / Precisão: Datada | VE p. 51–54 |
| EV-081 / 785 da III Era | Incidente registrado no posto de Haldren. Observação sem prova da existência dos Thul Verenari. / Precisão: Datada | HG p. 146 |
| EV-082 / 785 da III Era | Exigências dos Jurados do Caminho Alto. Tabelas e termos de transporte. / Precisão: Datada | HG p. 146 |
| EV-086 / 785-787 da III Era | Caso das Guias Partidas; vínculos entre os futuros companheiros. Depoimentos, contratos e autos de Valada. / Precisão: Intervalo | HG p. 146 |
| EV-083 / 786 da III Era | Acordo parcial de Leth-Auren e crise naval entre Nogard e Oleakia. Conflitos distintos. / Precisão: Datada | HG p. 146 |
| EV-084 / 787 da III Era | Debate das Duas Portas. Disputa religiosa e contratual em Valerith. / Precisão: Datada | HG p. 146 |
| EV-085 / 787 da III Era | Trégua das Três Portas. Acordo provisório sem transferência da soberania valerithiana sobre Nerevala. / Precisão: Datada | HG p. 146 |
| EV-087 / Décimo mês de 787 | Audiência das Guias, em Valada; primeiro encontro documentado dos seis reunidos. Atas e credenciais diplomáticas; ainda não constituíam companhia permanente. / Precisão: Datada | HG p. 146 |
| EV-088 / 11 do segundo mês de 788 | Golpe de Marevim e roubo da Agulha. Registros e testemunhos cruzados. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-089 / 19 do quarto mês de 788 | Primeira chegada da missão a Samarith pelo eixo Aelvar-Naerath-Quinder. Entrega inicial do alerta, antes das diligências na Rácia. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-090 / 27 do quarto mês de 788 | Partida da diligência documental para a Rácia. Trajeto por Nobilith, Valerith e o corredor de Valada. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-091 / 5 do quinto mês de 788 | Chegada de Rul a Samarith. Via Aelvar e Naerath; trabalho de arquivos durante a ausência da missão. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-092 / 27 do quinto mês de 788 | Passagem registrada por Ihfarilse. Um mês após a partida; inclui estrada, controles e verificação em Vaelen Endor e Valada. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-093 / 28 do sexto mês de 788 | Inspeção da urna na costa de Trogu. Reencontro com Rul depois do Caminho Alto e da descida de Juu Daixo. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-094 / 26 do sétimo mês de 788 | Retorno da missão a Samarith. Regresso pelo Mar das Espadas, desembarque perto de Vau-Cinzento e marcha terrestre. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-095 / Sétimo e oitavo meses de 788 | Testes em Quinder, ruptura temporária e negociações. Deslocamentos locais; oficina de campanha de Sera em Xeo Taoju. [SPOILER] / Precisão: Datada | HG p. 146 |
| EV-096 / Início do nono mês de 788 | Desembarque do exército principal de Marevim em Vau-Cinzento. De Lombonia ao Mar das Espadas, seguido da aproximação terrestre de Samarith. [SPOILER] / Precisão: Aproximada | HG p. 146 |
| EV-097 / 18-23 do nono mês de 788 | Batalha de Samarith. Convergência dos registros das forças envolvidas. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-098 / 23 do nono mês de 788 | Operação da Câmara e morte de Marevim. Testemunhos independentes e registros técnicos. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-099 / 3 e 27 do décimo mês de 788 | Termos provisórios e assinatura do pacto mais amplo. Ratificações ainda parcialmente pendentes. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-100 / Décimo mês de 788, após a batalha | Morte de Osric, coroação de Martan e contestação das concessões. Dia exato não estabelecido. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-101 / 12 do décimo segundo mês de 788 | Recebimento da resposta de Arriot. Registro da mensagem. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-102 / 28 do décimo segundo mês de 788 | Encerramento da coleta de testemunhos desta edição. Corte editorial, não fim das investigações. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-103 / Segundo Dia da Vigília de 788 | Sinos pelos mortos dos quatro exércitos. Cerimônia em Samarith. [SPOILER] / Precisão: Datada | HG p. 147 |
| EV-104 / Quinto Dia da Vigília de 788 | Publicação desta edição revista. Data do colofão. [SPOILER] / Precisão: Datada | HG p. 147 |

## 32. Vínculos confirmados entre personagens



O índice reúne 65 vínculos confirmados. A direção dos campos de cadastro não altera o sentido da descrição: quem é pai, filha, sobrinho ou sucessor é indicado por escrito. Um vínculo institucional não equivale a concordância com todos os atos da instituição. Os encontros dos seis em Valada são registrados como encontros, não como prova de amizade entre todos os pares.

| ID / pessoas | Tipo e descrição | Período / fonte |
| --- | --- | --- |
| VL-001 / Liana Meywood / Rul Aven | Afeto. Amizade desde 778; aproximação amorosa pouco antes da abertura do Volume II. Mantêm autonomia e encontros ocasionais. | 778 em diante; aproximação amorosa antes da abertura de C2 / R24 p. 10 / RC-A05 |
| VL-002 / Liana Meywood / Demer Vault | Amizade e cooperação. Conservam amizade, confiança e cuidado; não constituem casal. | Guias Partidas e crise de 788 / R24 p. 68 / RC-N01 |
| VL-003 / Elthara Sorn / Tavian Ordel | Afeto. Aproximação afetiva em negociações militares anteriores e encontros ocasionais. O vínculo é reservado e não explica automaticamente uma aliança. | Período não delimitado / R24 p. 10 / RC-A07 |
| VL-004 / Arriot Ilvar / Le Rink | Parentesco. Arriot Ilvar é pai de Le Rink. A filiação não fornece comando automático sobre a Ordem. | Período não delimitado / HG p. 105 |
| VL-005 / Nyssara Veyl / Narel | Parentesco. Nyssara e Narel são irmãos. O desaparecimento de Narel não concede a Nyssara autoridade para decidir por ele. | Período não delimitado / R24 p. 69 / RC-N04 |
| VL-006 / Kharug Venn / Druvak | Parentesco. Kharug é o irmão mais velho de Druvak. Respondem de modos diferentes à perda de terras e à indenização parcial. | Período não delimitado / HG p. 106 |
| VL-007 / Marevim / Eline | Parentesco. Marevim é pai de Eline, curadora morta no isolamento de 731. Ela defendia o consentimento nos tratamentos. | Até 731 da III Era / R24 p. 9 / RC-A01 |
| VL-008 / Osric Dalm / Martan Edris | Parentesco. Martan é sobrinho de Osric; isso não lhe confere legitimidade sucessória indiscutível. | Período não delimitado / R24 p. 12 / cap. 4, parentesco anterior preservado |
| VL-009 / Osric Dalm / Helena Dalm | Parentesco. Helena é neta de Osric. A contestação posterior não a torna automaticamente rainha. | Período não delimitado / R24 p. 12 / cap. 4, parentesco anterior preservado |
| VL-010 / Maressa II Veldan / Osric Dalm | Compromisso político. Maressa promete abastecimento e respeito à condução da sucessão de Nobilith. [SPOILER] | Crise de 788 / R24 p. 12 / RC-S01 |
| VL-011 / Maressa II Veldan / Martan Edris | Acordo reservado. Negociam reconhecimento, crédito e garantias sobre receitas e postos de Sar-Nobil; não se trata de anexação automática. [SPOILER] | Crise de 788 / R24 p. 12 / RC-S01 |
| VL-012 / Martan Edris / Helena Dalm | Contestação política. Após a coroação de Martan, Helena organiza contestação das concessões e do procedimento sucessório. [SPOILER] | Após a batalha, 788 / R24 p. 12 / RC-S04 |
| VL-013 / Ivela Dorn / Ordem dos Magos | Vínculo institucional. Ivela apoia uma revisão limitada e aceita resultado insuficiente; sua responsabilidade deve ser distinguida das demais. | Revisão de 755 e consequências / R24 p. 9 / RC-A02 |
| VL-014 / Rul Aven / Ordem dos Magos | Vínculo institucional. Rul trabalha com conservação de instrumentos, preserva provas e possui responsabilidades próprias. | Período não delimitado / R24 p. 9 / RC-A02 |
| VL-015 / Marevim / Ordem dos Magos | Vínculo institucional. Pesquisador ligado à Ordem antes da ruptura; a apuração de 731 não elimina sua responsabilidade por atos posteriores. | Período não delimitado / R24 p. 69 / RC-N05 |
| VL-016 / Liana Meywood / Le Rink | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-017 / Liana Meywood / Nyssara Veyl | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-018 / Liana Meywood / Kharug Venn | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-019 / Liana Meywood / Sera Vennor | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-020 / Demer Vault / Le Rink | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-021 / Demer Vault / Nyssara Veyl | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-022 / Demer Vault / Kharug Venn | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-023 / Demer Vault / Sera Vennor | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-024 / Le Rink / Nyssara Veyl | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-025 / Le Rink / Kharug Venn | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-026 / Le Rink / Sera Vennor | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-027 / Nyssara Veyl / Kharug Venn | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-028 / Nyssara Veyl / Sera Vennor | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-029 / Kharug Venn / Sera Vennor | Encontro documentado. Reuniram-se na Audiência das Guias, em Valada, no décimo mês de 787. Isso não prova companhia permanente desde 785. | Décimo mês de 787 / R24 p. 64 / RC-T04 |
| VL-030 / Maressa II Veldan / Lethia Arven | Governo e serviço. Maressa governa Valerith com a chanceler Lethia Arven. | Período não delimitado / HG p. 72 |
| VL-031 / Vaela Endorin / Teren I Endorin | Sucessão política. Teren I Endorin sucede a Vaela Endorin no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 1938–1979 da II Era / VE p. 55 |
| VL-032 / Teren I Endorin / Isera I | Sucessão política. Isera I sucede a Teren I Endorin no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 1979–2018 da II Era / VE p. 55 |
| VL-033 / Isera I / Selvar I | Sucessão política. Selvar I sucede a Isera I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2018–2050 da II Era / VE p. 55 |
| VL-034 / Selvar I / Maereth I | Sucessão política. Maereth I sucede a Selvar I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2050–2078 da II Era / VE p. 55 |
| VL-035 / Maereth I / Selvar II | Sucessão política. Selvar II sucede a Maereth I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2078–2149 da II Era / VE p. 55 |
| VL-036 / Selvar II / Isera II | Sucessão política. Isera II sucede a Selvar II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2149–2182 da II Era / VE p. 55 |
| VL-037 / Isera II / Odravel I | Sucessão política. Odravel I sucede a Isera II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2182–2216 da II Era / VE p. 55 |
| VL-038 / Odravel I / Vaela II | Sucessão política. Vaela II sucede a Odravel I no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2216–2253 da II Era / VE p. 55 |
| VL-039 / Vaela II / Teren II | Sucessão política. Teren II sucede a Vaela II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2253–2294 da II Era / VE p. 55 |
| VL-040 / Teren II / Odravel II | Sucessão política. Odravel II sucede a Teren II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2294–2330 da II Era / VE p. 55 |
| VL-041 / Odravel II / Selvar III | Sucessão política. Selvar III sucede a Odravel II no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2330–2361 da II Era / VE p. 56 |
| VL-042 / Selvar III / Odravel III | Sucessão política. Odravel III sucede a Selvar III no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2361–2394 da II Era / VE p. 56 |
| VL-043 / Odravel III / Odravel IV | Sucessão política. Odravel IV sucede a Odravel III no reconhecimento do governo. Esta sequência não estabelece, por si só, parentesco. | 2394–2418 da II Era / VE p. 56 |
| VL-044 / Teren I Endorin / Isera I | Parentesco. Isera é filha de Teren I, que negociou seu casamento com um membro da casa Veyr. | II Era / VE p. 19 |
| VL-045 / Odravel IV / Maeressa Endorin | Parentesco. Maeressa Endorin é sobrinha de Odravel IV; reivindica a continuidade da casa após a morte dele. | Crise de 2418 / VE p. 41 |
| VL-046 / Maeressa Endorin / Aldren Veyr | Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto. | 2418–2431 da II Era / VE p. 41 |
| VL-047 / Maeressa Endorin / Soren Talv | Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto. | 2418–2431 da II Era / VE p. 41 |
| VL-048 / Aldren Veyr / Soren Talv | Disputa política. Disputam o poder após a morte de Odravel IV; nenhum obtém reconhecimento comum como imperador do conjunto. | 2418–2431 da II Era / VE p. 41 |
| VL-049 / Vaela Endorin / Dorrik Venn | Aliança e negociação. Dorrik organiza escoltas e postos; sua aliança com Vaela não representa submissão de Dorgamar. | Formação e consolidação imperial / VE p. 11 |
| VL-050 / Vaela Endorin / Rughan das Duas Margens | Aliança e negociação. Rughan negocia contribuições comunitárias, mas rompe com Vaela após a repressão de Bar-Terval, em 1904. | Formação e consolidação imperial / VE p. 15 |
| VL-051 / Vaela Endorin / Maressa de Merovél | Aliança e negociação. Maressa organiza abastecimento, contratos e mediação; permanece junto à corte e obtém socorro a deslocados. | Formação e consolidação imperial / VE p. 11 |
| VL-052 / Celandra Vey / Rovald Vey | Disputa política. Disputam a administração de uma propriedade em Nobilith. Rovald é primo do marido falecido de Celandra; não se afirma parentesco entre ela e Rovald. | 2258–2274 da II Era / VE p. 33 |
| VL-053 / Celandra Vey / Ossa Merev | Propriedade e obrigações. Ossa conserva prova de alívio de jornadas. Celandra preserva a administração, mas não torna permanente a cobrança suspensa. | Litígio de 2258–2274 / VE p. 33 |
| VL-054 / Aren Voss / Leva Senn | Atuação judicial. Aren recusa condenar Leva por uma possibilidade futura, no processo da Controvérsia do Espelho. | 2101 da II Era / VE p. 27 |
| VL-055 / Tessia Orven / Ilven Tor | Relação institucional. Ilven, secretário da Mesa dos Instrumentos Reservados, contesta a ausência de cópia imperial dos estudos de Tessia. | Correspondência de 2093 / VE p. 27 |
| VL-056 / Ilyra Tessan / Orel Veyr | Pesquisa e financiamento. Ilyra distingue vestígios de previsão; Orel reorganiza os resumos e transforma incerteza técnica em promessa de entrega. | Segundo Amanhecer / VE p. 39 |
| VL-057 / Mira Tovel / Aven Doss | Conflito trabalhista. Mira preserva livros de jornada; Aven comanda a repressão da revolta de Sarn e atribui destruição de cargas aos insurgentes. | 2337–2339 da II Era / VE p. 35 |
| VL-058 / Sora Hald / Halven Reth | Negociação política. Discutem cobrança sobre rebanhos e garantias das receitas do norte. | 2376–2388 da II Era / VE p. 37 |
| VL-059 / Rovan Sel / Aldren Veyr | Acordo militar. Rovan abre a Porta de Cal às tropas de Aldren após obter salvo-conduto para parentes. | 2421 da II Era / VE p. 42 |
| VL-060 / Vaeliss Sareth / Calven III | Acordo institucional. O Acordo das Lâmpadas reconhece o novo governo e garante a permanência do Grande Pombo em Samarith. | 2429 da II Era / VE p. 45 |
| VL-061 / Vaeliss Sareth / Nerissa Sareth | Sucessão política. Nerissa sucede Vaeliss em Quinder. O uso do sobrenome não basta para fixar parentesco de primeiro grau. | Primeiras décadas da III Era / VE p. 49 |
| VL-062 / Enna Vossel / Maela Torr | Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação. | 2431 da II Era / VE p. 47 |
| VL-063 / Enna Vossel / Dorven Keld | Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação. | 2431 da II Era / VE p. 47 |
| VL-064 / Maela Torr / Dorven Keld | Negociação política. Participam da conferência da Concordata de Vaelen com funções distintas: direito, depósitos e circulação. | 2431 da II Era / VE p. 47 |
| VL-065 / Iria Veldar / Teren Vassel | Referência intelectual. Iria lê Vassel. Não o conheceu: ele morreu em 676, antes de seu nascimento em 704. | Obra de Iria publicada em 784 da III Era / VE p. 5 |

## 33. Implantação, cobertura e manutenção da base



A base de trabalho desta rodada é a wikia 0.24, commit 475de5ab6e35f6f6523cb9c75c31485c56d47693. A edição 0.25 acrescenta páginas de cronologia e vínculos, referências clicáveis para os PDFs e relações nas fichas. A implementação mantém 351 verbetes e os materiais anteriores. A disponibilização da atualização deve ser verificada pela publicação do site.

| Área | Condição e limite |
| --- | --- |
| Cronologia | 148 marcos selecionados; datas agrupadas preservam seus segmentos. |
| Vínculos | 65 relações confirmadas; inclui o primeiro encontro dos seis, separado de amizade e parentesco. |
| Identidades | Nomes sem artigo próprio continuam consultáveis na rede, sem criar biografias ou retratos por preenchimento automático. |
| Referências | HG do índice é o arquivo de 148 páginas efetivamente incluído na wikia; não é a antiga identificação de HG preservada nos capítulos de auditoria. |
| Fontes anteriores | As auditorias e estados de implantação das edições anteriores são preservados como histórico. Não significam que a wikia continua naquelas versões. |
| Pendências | Continuam abertas as questões RC-VEA da edição 2.4, a cadeia genealógica integral e datas pessoais não especificadas. |
| Visuais | A interpretação artística não modifica o estado documental de uma informação. |

Fila de aprofundamento

Ampliar gradualmente a cobertura de vínculos com fontes verificadas, revisar referências a cada edição e depois desenvolver geografia histórica. Não converter a ausência de um vínculo no índice em prova de ausência da relação. Nenhuma nova guerra, sucessão ou parentesco é decretado nesta rodada.

## 34. Governança atual e consolidação da wikia



O Registro Geral é a referência viva e normativa. Novas informações e decisões entram no Registro e são refletidas na wikia. Os PDFs anteriores conservam sua edição histórica; sua atualização será deliberada quando houver motivo para uma nova edição.



O autor autorizou a criação de acontecimentos, personagens e lugares sobre a base existente. Este recorte amplia a criação do mundo e a história de sua interpretação. Tradições são registradas com sua perspectiva; datas novas de estudiosos pertencem à história da I Era.



A consolidação incorpora a base da wikia 0.30, com seus 536 artigos, 168 marcos e 65 vínculos, incluindo engenharia dos vórtics, navegação entre menções e desenvolvimentos posteriores à edição 2.5. O retrato dessa base acompanha o arquivo editável. Estados de implantação descritos em capítulos anteriores são históricos.

## 35. Criação do mundo: definições vigentes

Leitura de continuidade

Aun integra a tradição da Consciência Una. Os três planos, os seis caminhos da mana e seus limites preservam a base da História Geral. Os relatos primordiais não recebem anos; 2874 e 2896 da I Era são novas datas autorais de história intelectual.

### RC-CM01 — A criação de Virtude

As tradições de origem descrevem a diferenciação da consciência, a formação dos planos e a circulação da mana. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM02 — Aun

Nome dado à consciência primordial na tradição da Consciência Una. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM03 — Noérion

O Mar das Formas: plano de pensamentos, afetos e possibilidades, com ritmos próprios de existência. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM04 — Eomundus

O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM05 — Virtude — Mundo do Devir

O plano material, onde ações se encadeiam e as vidas particulares enfrentam consequências duradouras. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM06 — Adunevar

Consciências de Noérion associadas a afinidades fundamentais e reconhecidas de maneiras distintas pelos cultos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM07 — Mana

Fluxo entre os três planos, trabalhado pelas práticas mágicas por meio de seis caminhos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM08 — Descompassos

Irregularidades no contato entre os planos que alteram experiência, passagem e sucessão dos acontecimentos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM09 — Mnêmides

Presenças de Noérion que conservam experiências sem lhes atribuir necessariamente um proprietário. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM10 — Anônimos

Presenças de Noérion com dificuldade para manter identidade, capazes de reproduzir vozes e rostos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM11 — Velários

Presenças de Eomundus que assumem formas ligadas à imaginação de quem as encontra. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM12 — Ishrael

Designação velária associada a transformações de vida em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM13 — Oruven

Designação velária associada a passagens improváveis em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM14 — Veyr, o Cortês

Designação velária associada a hospitalidade e obrigação em Eomundus. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM15 — Primeira Distância

Relato da Consciência Una sobre a diferenciação que torna possível encontrar o outro. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM16 — Confluência das Três Margens

Tradição que apresenta a circulação da mana pelo encontro entre os modos de existência dos três planos. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM17 — Contenda do Primeiro Nome

Tradição de Noérion sobre memória, identidade e os limites de usar uma experiência alheia. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM18 — Enseada das Promessas

Lugar de Eomundus cujas rotas de acesso e retorno respondem a compromissos reconhecidos. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM19 — Patamar dos Ecos

Limiar de Eomundus em que vozes e gestos preservados despertam reconhecimento nos visitantes. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM20 — Talena Ors

Estudiosa Eldenari da I Era, compiladora dos Cadernos de Permanência e colaboradora de Edris Vaun. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM21 — Edris Vaun

Artífice Eldenari da I Era que conduziu o Ensaio da Pedra Velada em colaboração com Talena Ors. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM22 — Doutrina do Tear

Tradição de origem que descreve a realidade pelo entrelaçamento de experiências e vínculos. A existência e a transmissão da tradição são vigentes; suas imagens conservam atribuição cultural, sem datação literal da origem.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM23 — Cadernos de Permanência

Compilação organizada por Talena Ors em 2874 da I Era sobre observação, transmissão e interpretação. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

### RC-CM24 — Ensaio da Pedra Velada

Investigação de Edris Vaun, registrada com Talena Ors em 2896 da I Era, sobre a permanência material. Descrição, vínculos e características dos dossiês deste recorte são vigentes.

Base: Expansão editorial autorizada pelo autor nesta atualização; base cosmológica: História Geral de Virtude, pp. 10–12.

Aplicação: Registro Geral, wikia e futuras obras que abordem este assunto.

## 36. Dossiês da criação e tradições



A criação de Virtude



As tradições de origem descrevem a diferenciação da consciência, a formação dos planos e a circulação da mana.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



Uma realidade que ganha diferenças. A doutrina da Consciência Una associa a origem a Aun. A Primeira Distância nomeia o momento em que conhecer passa a envolver uma posição e um limite: algo pode ser encontrado, desejado ou resistir. A existência concreta dos habitantes de Virtude conserva seu valor e suas consequências dentro dessa interpretação.



Os três planos. Noérion, o Mar das Formas, abriga possibilidades e afinidades anteriores à estabilidade dos corpos. Eomundus, o Entrelaço, dá contorno e duração às identidades. Virtude, o Mundo do Devir, reúne matéria, sucessão causal e vidas particulares. A Confluência das Três Margens apresenta o contato entre esses modos de existência como condição da circulação da mana.



Relatos e investigação. A Contenda do Primeiro Nome trata da posse da lembrança e da responsabilidade de reconhecer o outro. A Doutrina do Tear descreve a criação por fios entrelaçados e recebe leituras diferentes da Consciência Una. Na I Era, Talena Ors e Edris Vaun estudaram os relatos e a permanência material. Seus trabalhos pertencem à história dos intérpretes; os episódios primordiais permanecem anteriores à contagem das eras.



Aun



Nome dado à consciência primordial na tradição da Consciência Una.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



A consciência anterior às formas. Aun designa a origem comum da experiência nas versões da Consciência Una. Seu nome funciona como aproximação de algo anterior a estrelas, corpos e divindades particulares. Os narradores associam essa condição à possibilidade de toda relação, sem lhe atribuir uma residência no mapa ou uma genealogia de soberanos.



A Primeira Distância. A diferenciação permite que uma perspectiva encontre outra. A Primeira Distância conserva essa ideia por meio de imagens de abertura, intervalo e escuta. Aun permanece ligado à origem comum, enquanto Noérion, Eomundus e Virtude desenvolvem condições próprias de existência.



Leituras entre os habitantes. A Doutrina do Tear dá maior peso ao entrelaçamento de experiências. Talena Ors registrou diferenças entre fórmulas de origem e usos cotidianos das mesmas palavras. O reconhecimento da tradição de Aun integra o cenário; a interpretação de todas as culturas como um culto uniforme reduziria a diversidade de seus relatos.



Noérion



O Mar das Formas: plano de pensamentos, afetos e possibilidades, com ritmos próprios de existência.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Formas e afinidades. Em Noérion, pensamentos e afetos podem adquirir presença antes de dependerem de um corpo estável. As descrições do Mar das Formas recorrem a profundidades, correntes e constelações que se recombinam. Essas imagens expressam relações entre possibilidades; sua leitura como um oceano material perde parte de seu sentido.



Habitantes e memória. Os Adunevar mantêm afinidades fundamentais, como memória, crescimento ou conflito. As Mnêmides preservam experiências e os Anônimos encontram dificuldade para sustentar uma identidade. A Contenda do Primeiro Nome aproxima esses dois últimos modos de existência em um relato sobre lembrança e reconhecimento.



Tempo e contato. A sucessão universal de acontecimentos própria de Virtude não rege Noérion. Seus encontros são narrados por relações e transformações. A mana permite contatos entre os planos; lembranças recebidas por um visitante exigem interpretação, porque a experiência de outra vida pode ser sentida como íntima sem ter pertencido a ele.



Eomundus



O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



O Entrelaço. Eomundus aproxima possibilidades e vidas delimitadas. Seus caminhos respondem a expectativas, lembranças e vínculos, de modo que duas viagens pelo mesmo arco podem levar a encontros diferentes. Orientar-se envolve compreender relações de acesso, além de reconhecer formas da paisagem.



Povos e presenças. Os Aelthir, ancestrais dos elfos, os Namar que acompanham consciências após a morte e os Velários pertencem às descrições do Entrelaço. Ishrael, Oruven e Veyr, o Cortês, aparecem em narrativas de transformação, passagem e hospitalidade. A identidade por trás desses nomes varia entre os relatos.



Lugares e compromissos. A Enseada das Promessas e o Patamar dos Ecos exemplificam lugares cuja travessia depende da história do viajante. Seus mapas registram condições de encontro e retorno. Um compromisso reconhecido por outros pode orientar o caminho por mais tempo que uma intenção passageira, e a entrada em Eomundus nunca equivale a controle completo sobre sua paisagem.



Virtude — Mundo do Devir



O plano material, onde ações se encadeiam e as vidas particulares enfrentam consequências duradouras.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Matéria e sucessão. Virtude abriga corpos, paisagens e sociedades submetidos a uma sucessão causal. Uma ponte construída pode permanecer para quem chega depois; uma colheita consumida exige novo trabalho. A estabilidade dá às escolhas um peso que distingue o Mundo do Devir das transformações descritas em Noérion.



Vida e autonomia. A origem comum proposta pela Consciência Una convive com existências particulares. Pessoas possuem lembranças limitadas, compromissos e desejos próprios. A história das eras acompanha essas vidas e as instituições que constroem, enquanto a criação dos planos pertence a um horizonte anterior à sua contagem.



Fronteiras permeáveis. A mana atravessa relações entre os planos e sustenta práticas mágicas. Os Descompassos revelam que suas fronteiras podem apresentar irregularidades. O Ensaio da Pedra Velada investigou a permanência de objetos em condições controladas no plano material, contribuindo para separar observação, relato de viagem e interpretação cosmológica.



Adunevar



Consciências de Noérion associadas a afinidades fundamentais e reconhecidas de maneiras distintas pelos cultos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Natureza e domínio. Os Adunevar abrangem formas de consciência cuja existência se liga a afinidades como vínculo, ordem, crescimento, memória, transformação e conflito. Sua potência segue a natureza de cada domínio. Os cultos traduzem encontros e efeitos em nomes, histórias e práticas, produzindo reconhecimentos diferentes entre sociedades.



Presença no mundo. Uma intervenção em Virtude depende de âncoras: corpos, santuários, vínculos ou práticas que sustentam o contato. O instrumento e a afinidade da presença influenciam aquilo que ela consegue realizar. Uma âncora submetida a poder concentrado pode se desgastar, ferir um intermediário ou favorecer Descompassos.



Cultos e arautos. Os arautos tornam a relação com uma presença divina especialmente concreta, mas seu reconhecimento também envolve testemunho e disputa. Divergências entre afinidades produzem tensões sem estabelecer uma corte superior obedecida por todos. O auxílio cotidiano dos templos continua ligado a pessoas, alimentos, abrigo e organização.



Mana



Fluxo entre os três planos, trabalhado pelas práticas mágicas por meio de seis caminhos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Circulação entre planos. A mana expressa a permeabilidade entre Noérion, Eomundus e Virtude. A Confluência das Três Margens dá forma narrativa a essa circulação: diferenças permanecem, mas relações atravessam seus limites. O fluxo assume efeitos concretos conforme o meio, a técnica e as condições do contato.



Seis caminhos. Fogo, Água, Terra, Ar, Luz e Trevas organizam os caminhos da mana. Luz se associa a revelar e transmitir; Trevas a ocultar e proteger. O valor ético depende das escolhas de quem atua e de suas consequências. Espaço, Tempo e Mente descrevem condições de operação das práticas e se articulam aos caminhos.



Uso, limite e experiência. O praticante aprende a reconhecer resistência, consumo e risco. A manipulação encontra aplicações em ofícios, cura, investigação e engenhos, incluindo os vórtics. A mana participa da sustentação e do controle desses veículos; as descrições dos modelos distinguem chassi, estabilidade e comportamento na pista. Descompassos exigem atenção quando o contato entre planos se torna irregular.



Descompassos



Irregularidades no contato entre os planos que alteram experiência, passagem e sucessão dos acontecimentos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Sinais de uma fronteira irregular. Relatos de Descompassos incluem dias que parecem repetir-se, vozes de pessoas ainda não nascidas e viajantes que retornam sem envelhecer a comunidades já transformadas. A variedade exige registrar cada ocorrência em seu contexto. Um efeito reconhecível permite comparar testemunhos, mas não fornece sozinho a causa.



Causas e responsabilidade. A separação imperfeita entre os planos admite ocorrências espontâneas. Intervenções de Eomundus e desgaste de âncoras também podem contribuir. A presença de um Descompasso orienta a investigação sobre o contato e seus suportes; atribuir intenção depende de outras evidências.



Memória e cuidado. Talena Ors defendia separar a experiência de quem voltou, os registros preservados por quem ficou e os comentários posteriores. Essa distinção ajuda a compreender mudanças de calendário e perdas de convivência. O Patamar dos Ecos acrescenta outro problema: uma lembrança reconhecida pode emocionar profundamente sem constituir o retorno integral de uma pessoa.



Mnêmides



Presenças de Noérion que conservam experiências sem lhes atribuir necessariamente um proprietário.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Experiência preservada. As Mnêmides guardam experiências cuja continuidade não depende da identificação de um indivíduo. Nas descrições de Noérion, uma lembrança pode manter a textura de um gesto, o medo ou a alegria sem conservar o nome de quem viveu aquilo. Encontrá-la pode provocar reconhecimento e estranhamento ao mesmo tempo.



Encontros e interpretação. Um visitante do plano material pode receber uma impressão intensa como se tivesse vivido outra vida. A intimidade da sensação requer cuidado: a origem da lembrança e a história do visitante permanecem questões distintas. O Patamar dos Ecos aparece em narrativas de contato com vestígios semelhantes, sem estabelecer um arquivo universal de todas as consciências.



O Primeiro Nome. Na Contenda do Primeiro Nome, a preservação das Mnêmides entra em tensão com o uso de rostos e experiências pelos Anônimos. O relato interroga o que significa reconhecer alguém e quais obrigações surgem ao carregar sua lembrança. Cópias Eldenari empregaram essa história em discussões sobre testemunho e responsabilidade.



Anônimos



Presenças de Noérion com dificuldade para manter identidade, capazes de reproduzir vozes e rostos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Identidade instável. Os Anônimos encontram formas de se apresentar nos gestos, rostos e vozes com que entram em contato. Uma aparência tomada de outro pode durar apenas um encontro. A imitação exprime sua dificuldade de sustentar uma identidade própria e produz efeitos que eles nem sempre compreendem.



Reconhecimento e dano. Para habitantes de Virtude, uma voz íntima desperta expectativas e obrigações. Reproduzi-la pode perturbar luto, confiança e memória. O contato exige discernir continuidade pessoal e semelhança. As consequências para quem reconhece o rosto emprestado compõem parte importante dos relatos do Mar das Formas.



A Contenda do Primeiro Nome. A tradição coloca Anônimos e Mnêmides diante da mesma experiência preservada. Enquanto uns procuram nela um modo de existir, outras a conservam sem distribuí-la como propriedade. A narrativa desenvolve limites e reconhecimento mútuo, oferecendo às culturas uma linguagem para discutir o empréstimo de nomes e a responsabilidade por lembranças.



Velários



Presenças de Eomundus que assumem formas ligadas à imaginação de quem as encontra.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



Formas de encontro. Os Velários entram nas narrativas por aparências parcialmente moldadas pelas expectativas do observador. Uma mesma figura pode ser descrita de maneiras diferentes em dois relatos. A forma facilita o encontro, mas também expressa aquilo que o visitante estava preparado para reconhecer.



Vontades e diferenças. Eomundus abriga presenças com comportamentos variados. Ishrael se associa à transformação de vidas; Oruven, a passagens improváveis; Veyr, o Cortês, à hospitalidade e a obrigações. Esses nomes podem designar indivíduos, famílias de manifestações ou papéis conservados pela tradição. A diversidade de relatos permanece parte de sua caracterização.



Hospitalidade e acesso. Na Enseada das Promessas, histórias de encontro com Velários enfatizam a relação entre uma oferta, a aceitação e o retorno. O compromisso reconhecido pode se tornar condição de passagem. Viajantes atentos procuram compreender os termos do encontro antes de tratar uma dádiva como posse sem vínculo.



Ishrael



Designação velária associada a transformações de vida em Eomundus.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |
| Epíteto | Portadora de Rostos |
| Identidade | Indivíduo, conjunto de manifestações ou papel: questão aberta |



Encontros e tradição. Os relatos de Ishrael descrevem encontros após os quais um visitante modifica relações, ofício ou compreensão de si. Rostos distintos acompanham a mesma designação e reforçam a importância de quem observa. O alcance da transformação emerge das escolhas seguintes, das lembranças que persistem e da dificuldade de contar o encontro aos demais.



Nome e reconhecimento. A tradição de Ishrael preserva o epíteto Portadora de Rostos. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Ishrael e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Oruven



Designação velária associada a passagens improváveis em Eomundus.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |
| Epíteto | Pastor das Luzes |
| Identidade | Indivíduo, conjunto de manifestações ou papel: questão aberta |



Encontros e tradição. Luzes guiando um viajante a uma passagem impossível constituem a imagem recorrente de Oruven. Segui-las envolve reconhecer uma rota e aceitar suas condições. Os relatos conservam diferenças sobre a forma do guia e sobre a duração da travessia; chegar ao destino não garante que o tempo da partida continue intacto.



Nome e reconhecimento. A tradição de Oruven preserva o epíteto Pastor das Luzes. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Oruven e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Veyr, o Cortês



Designação velária associada a hospitalidade e obrigação em Eomundus.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |
| Epíteto | o Cortês |
| Identidade | Indivíduo, conjunto de manifestações ou papel: questão aberta |



Encontros e tradição. Veyr recebe viajantes, oferece abrigo e apresenta dádivas cujas obrigações se tornam claras na continuidade do encontro. As histórias valorizam a atenção ao que foi aceito, prometido e lembrado. A cortesia pode sustentar proteção duradoura e também prender o hóspede a compromissos mais amplos do que imaginava.



Nome e reconhecimento. A tradição de Veyr, o Cortês preserva o epíteto o Cortês. O reconhecimento se apoia em ações, situações e modos de tratar o viajante. Os testemunhos permitem acompanhar uma figura recorrente, mantendo em aberto se o nome pertence a um indivíduo, a uma linhagem de manifestações ou a um papel assumido em diferentes encontros.



Presença nas narrativas. Os relatos integram a vida cultural dos que estudam Eomundus. Talena Ors separava a descrição de um encontro da explicação acrescentada por seus copistas. Essa leitura permite comparar versões de Veyr, o Cortês e compreender como expectativas, vínculos e memória participam da experiência do Entrelaço.



Primeira Distância



Relato da Consciência Una sobre a diferenciação que torna possível encontrar o outro.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



O intervalo primordial. Na tradição da Consciência Una, a Primeira Distância é a diferenciação da experiência antes da estabilidade dos mundos. Conhecer passa a envolver posição, alcance e resistência. O relato oferece imagens de escuta e intervalo para expressar a possibilidade de algo existir diante de outra perspectiva.



Consequências da diferenciação. Aun permanece o nome da origem comum nessa doutrina. A distância permite afinidades e limites que serão descritos por meio de Noérion, Eomundus e Virtude. A diferença dá sentido a desejo, reconhecimento e responsabilidade: aquilo que uma consciência encontra possui condições próprias de existência.



Transmissão e tempo. A Primeira Distância pertence a uma ordem explicativa anterior à contagem das eras. Os narradores podem situá-la antes da Confluência das Três Margens dentro de sua versão, mas essa sequência não fornece anos decorridos. Os Cadernos de Permanência ajudam a compreender a separação entre o tempo de um relato e uma data histórica.



Confluência das Três Margens



Tradição que apresenta a circulação da mana pelo encontro entre os modos de existência dos três planos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



Três condições de existência. O relato descreve Noérion como possibilidade, Eomundus como contorno e vínculo, e Virtude como matéria em sucessão. Cada margem representa condições de existência reconhecíveis, e a confluência conserva a diferença entre elas. A imagem oferece uma linguagem para explicar contatos sem reduzir todos os planos à mesma paisagem.



A circulação. A mana atravessa as relações entre as margens. Na tradição, esse fluxo torna possíveis manifestações, práticas e encontros que relacionam pensamento, identidade e matéria. Seus seis caminhos organizam efeitos distintos, enquanto as condições de Espaço, Tempo e Mente influenciam a operação.



Limite e permanência. A circulação convive com fronteiras e resistências. Os Descompassos expressam contatos irregulares, e o trabalho de uma âncora pode exigir cuidado. A confluência é transmitida como episódio primordial, com ordem interna variável entre versões e sem data convertida em ano da I Era.



Contenda do Primeiro Nome



Tradição de Noérion sobre memória, identidade e os limites de usar uma experiência alheia.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



O conflito das lembranças. Na versão adotada nesta edição, Mnêmides conservam uma experiência que Anônimos passam a usar para obter rosto e voz. A lembrança ganha diversas aparências, e aqueles que a encontram reconhecem pessoas diferentes. A contenda surge da dificuldade de distinguir o encontro com alguém do encontro com algo preservado sobre essa pessoa.



O reconhecimento do limite. A resolução transmitida pelo relato se apoia no reconhecimento da origem emprestada de uma forma. As Mnêmides continuam a preservar; os Anônimos aprendem que apresentar uma voz pode criar obrigações diante de quem a escuta. O Primeiro Nome simboliza a responsabilidade de situar a própria presença perante outra.



Leituras posteriores. Copistas Eldenari empregaram a contenda em discussões sobre testemunho, lembrança e autoria. Talena Ors registrou seu valor como tradição interpretativa. O episódio integra a memória cultural de Noérion, e suas versões permitem examinar os efeitos materiais de reconhecer uma voz íntima, inclusive nos relatos do Patamar dos Ecos.



Enseada das Promessas



Lugar de Eomundus cujas rotas de acesso e retorno respondem a compromissos reconhecidos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |
| Plano | Eomundus |
| Tipo | Enseada de acesso relacional |



Paisagem e orientação. A Enseada das Promessas é descrita como água calma entre margens que parecem próximas e caminhos que mudam ao serem retomados. Embarcadouros, passagens rasas e reflexos servem como pontos de reconhecimento. A orientação depende da relação entre o visitante, o destino e compromissos ainda ativos.



Promessas e passagem. Um voto testemunhado pode conservar uma rota por mais tempo que uma intenção de ocasião. Cumprimento, mudança de condições e reconhecimento da outra parte afetam o retorno. A enseada torna visível uma característica de Eomundus: relações possuem peso geográfico e podem sobreviver à lembrança imperfeita de um viajante.



Hospitalidade e relatos. Histórias de Veyr, o Cortês, associam abrigo e dádivas à responsabilidade de compreender aquilo que se aceita. Outros encontros velários variam conforme o visitante. Os registros da enseada descrevem condições de acesso, preservando o lugar fora das fronteiras materiais dos reinos e sem um ponto fixo no atlas de 788.



Patamar dos Ecos



Limiar de Eomundus em que vozes e gestos preservados despertam reconhecimento nos visitantes.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |
| Plano | Eomundus |
| Tipo | Limiar de memória e reconhecimento |



O patamar junto à água. Relatos apresentam degraus gastos, água baixa e galerias cuja extensão muda com a aproximação. Sons voltam em direções diferentes, às vezes com a inflexão de uma voz reconhecida. O lugar recebe o nome de Patamar dos Ecos pela experiência de reencontrar fragmentos que parecem responder ao visitante.



Vestígios e luto. Uma frase, um gesto ou um afeto pode ser reconhecido com grande intensidade. O vestígio conserva uma experiência limitada, e sua presença não equivale ao retorno integral de quem morreu. Narrativas sobre Mnêmides e os acompanhantes Namar oferecem interpretações diferentes para esses encontros, sem resolver todos os testemunhos por uma causa única.



Atravessar e recordar. O caminho pode mudar quando o visitante tenta repetir exatamente um encontro anterior. Os registros valorizam aquilo que foi ouvido e as condições da passagem. Talena Ors incluiu testemunhos de ecos em sua reflexão sobre memória, distinguindo a experiência sentida da conclusão de que uma consciência completa teria sido recuperada.



Talena Ors



Estudiosa Eldenari da I Era, compiladora dos Cadernos de Permanência e colaboradora de Edris Vaun.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atividade | Estudiosa e compiladora |
| Marco documentado | Cadernos de Permanência, 2874 da I Era |
| Colaboração | Edris Vaun |
| Vestimenta | Linho ocre com remendos azul-escuros |
| Traço distintivo | Pálpebra direita ligeiramente caída |



Trabalho e contexto. Talena Ors reuniu relatos cosmológicos e registros de observação na I Era. Seus Cadernos de Permanência foram organizados em 2874 e circularam por cópias em Samarith. Ela separava a experiência relatada, a cadeia de transmissão e o comentário posterior, buscando conservar diferenças entre testemunhos.



Aparência e hábitos. Possuía rosto amplo, cabelos castanhos muito encaracolados cortados na nuca e uma leve queda da pálpebra direita. Tinta costumava marcar seu polegar. Preferia linho ocre com remendos azul-escuros e levava cadernos de folhas de tamanhos diferentes. Sua curiosidade vinha acompanhada de perguntas diretas sobre quem havia presenciado cada afirmação.



Colaboração e legado. Sua colaboração com Edris Vaun relacionou o estudo dos relatos à observação de objetos. Em 2896, acompanhou o registro do Ensaio da Pedra Velada. As distinções de seus cadernos permitem ler a Primeira Distância, a Contenda do Primeiro Nome e a Doutrina do Tear como tradições com contexto, preservando a riqueza de suas versões.



Edris Vaun



Artífice Eldenari da I Era que conduziu o Ensaio da Pedra Velada em colaboração com Talena Ors.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atividade | Artífice e investigador |
| Marco documentado | Ensaio da Pedra Velada, 2896 da I Era |
| Colaboração | Talena Ors |
| Vestimenta | Linho cinzento e avental de couro |
| Traço distintivo | Dois dedos rígidos na mão esquerda |



Ofício e investigação. Edris Vaun trabalhava com medidas, recipientes e pequenas peças de oficina. Sua colaboração com Talena Ors aproximou observação material e leitura crítica dos relatos. A repetição de uma operação interessava-lhe tanto quanto seu resultado: alterações de recipiente, observador e registro precisavam ser anotadas.



Aparência e maneira de trabalhar. Tinha rosto estreito, calvície no alto da cabeça, cabelos escuros nas laterais e barba curta com fios acobreados. Dois dedos da mão esquerda apresentavam rigidez. Usava linho cinzento e avental de couro. Paciente e pouco expansivo, organizava ferramentas pela sequência de uso e preferia demonstrar uma medida a defendê-la por autoridade.



A Pedra Velada. Em 2896 da I Era conduziu comparações de peso e permanência com objetos vedados, alternando observadores e registros. Talena Ors ajudou a documentar o trabalho. O ensaio sustentou conclusões limitadas às condições observadas no plano material, tornando-se uma referência para discutir a diferença entre percepção, permanência e explicação cosmológica.



Doutrina do Tear



Tradição de origem que descreve a realidade pelo entrelaçamento de experiências e vínculos.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Tradição cosmológica |
| Referência temporal | Antes da contagem das eras |



O mundo como trama. A Doutrina do Tear emprega fios, nós e intervalos para explicar a formação de uma realidade compartilhada. A continuidade de um fio depende de encontros com outros, e o desenho emerge dessas relações. Diferentes narradores dão maior peso à primeira trama ou à atividade contínua de tecer.



Relação com a Consciência Una. Os relatos dialogam com a ideia de uma origem comum e também deslocam a atenção para a pluralidade de vínculos. Aun recebe centralidade na Consciência Una; a Doutrina do Tear costuma enfatizar a composição da experiência. As duas linguagens podem se aproximar em uma comunidade e gerar discussão em outra.



Transmissão Eldenari. Talena Ors reuniu versões orais entre os materiais estudados para os Cadernos de Permanência. Ela observava que uma mesma imagem podia servir à explicação da origem, à memória de um grupo e à transmissão de obrigações. Sua compilação tornou essas diferenças parte do estudo histórico das tradições na I Era.



Cadernos de Permanência



Compilação organizada por Talena Ors em 2874 da I Era sobre observação, transmissão e interpretação.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | 2874 da I Era |
| Autoria | Talena Ors |



Organização em 2874. Talena Ors reuniu os Cadernos de Permanência em 2874 da I Era. O conjunto tratava de relatos cosmológicos, experiências de passagem e observações materiais. Cópias circularam em Samarith, acompanhadas de comentários que nem sempre mantinham a separação proposta pela compiladora.



Três camadas de um testemunho. A compilação distinguia o que alguém dizia ter experimentado, como esse relato havia chegado ao copista e qual explicação lhe fora acrescentada. Essa organização permitia conservar versões divergentes sem fundi-las em uma única voz. A Primeira Distância e a Doutrina do Tear integravam a discussão sobre modelos de origem.



Continuidade de uma pesquisa. O trabalho de Talena Ors com Edris Vaun aproximou os cadernos do registro de operações repetíveis. O Ensaio da Pedra Velada, em 2896, aprofundou esse interesse. Os cadernos pertencem à história intelectual Eldenari; seu conteúdo é conhecido no universo por cópias e referências, com lacunas de transmissão.



Ensaio da Pedra Velada



Investigação de Edris Vaun, registrada com Talena Ors em 2896 da I Era, sobre a permanência material.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | 2896 da I Era |
| Responsável | Edris Vaun |



Procedimento e registro. O ensaio comparou objetos pesados antes e depois de permanecerem em recipientes vedados. Edris Vaun alternava observadores, recipientes e a ordem das verificações. Talena Ors registrava condições, diferenças e limites daquilo que os participantes conseguiam afirmar a partir das operações.



Resultados e alcance. As comparações sustentavam a permanência dos objetos nas condições observadas, mesmo durante intervalos sem observação direta. O resultado fortaleceu uma linguagem de medida e repetição no estudo de Virtude. A conclusão conservava seu alcance material: a observação realizada não esgotava as condições de Noérion ou Eomundus.



Uma discussão sobre realidade. O trabalho tornou concreta uma questão presente nos Cadernos de Permanência: distinguir o que se percebe, o que se registra e o que se explica. Para leitores da Consciência Una, a estabilidade material podia coexistir com uma origem comum da experiência. A divergência entre interpretações continuou a alimentar debates Eldenari.

## 37. Implantação do recorte e referências



A wikia 0.31 reúne 560 artigos, 173 marcos e 66 vínculos. O recorte acrescenta 24 artigos, nove ilustrações, três tradições primordiais sem data histórica e dois marcos da I Era. Cinco artigos existentes recebem complementos. Os IDs RC-CM01–24 apontam para as definições deste Registro.



As imagens são interpretações visuais. Paisagens de Eomundus não recebem coordenadas no mapa material. Ishrael, Oruven e Veyr conservam em aberto a natureza de suas identidades; a figura em uma ilustração contextual não determina aparência única.

## 38. Primeira Era: definições e limites vigentes



Este recorte consolida dragões, Eldenari, chegada dos elfos altos, instituições, artefatos, conflitos e Grande Punição. As adições incluem Guerra dos Reparos (6262–6266), Retirada dos Armazéns (6337), Pacto das Barcas (6338), Veska Tor e Naeris Ul. As novas datas são definições autorais desta edição, não citações acrescentadas aos PDFs antigos.

### RC-IE00 — Limites e precedência do recorte

Mantêm-se a cronologia aproximada da I Era, as sete campanhas, o intervalo de vinte e três dias, as funções limitadas das peças e a existência não confirmada dos Thul Verenari. A Grande Punição não recebe causa única demonstrada. A ampliação cria datas e práticas explicitadas nos novos dossiês; não altera os desfechos conservados nas fontes.

Base: Decisão autoral de ampliar a I Era; História Geral de Virtude pp. 13–24; Registro 2.6.

Aplicação: Wikia e futuras obras; PDFs anteriores conservam sua edição.

### RC-IE01 — Dragões

Primeiros habitantes corpóreos duradouros lembrados pelas tradições de Virtude, de grande longevidade e vínculos profundos com a mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE01; História Geral de Virtude · pp. 13–14, 21–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE02 — Eldenari

Povo de vidas seculares, associado às primeiras cidades dos vales do Taoju e do Asmarith e às grandes instituições de pesquisa da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE02; História Geral de Virtude · pp. 14–16, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE03 — Aelthir e a chegada dos elfos altos

Comunidades de Eomundus cuja travessia para Virtude, conduzida por Arieth Ilvar, deu origem aos elfos altos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE03; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE04 — Vaelthar

Ouvinte das Estrelas na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE04; História Geral de Virtude · pp. 13, 18, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE05 — Khorvath

Ferreiro Vivo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE05; História Geral de Virtude · pp. 13–15, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE06 — Zhaurak

Coroa Rubra na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE06; História Geral de Virtude · pp. 13–14, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE07 — Varesh

Asa das Marés na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE07; História Geral de Virtude · pp. 13–14, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE08 — Arieth Ilvar

Regente da Travessia na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE08; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE09 — Caerion Thalas

Fundador da Ordem dos Magos na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE09; História Geral de Virtude · pp. 17–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE10 — Maeriel Sorn

Diplomata dos intercâmbios na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE10; História Geral de Virtude · pp. 17–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE11 — Avar Seneth

Especialista em tempo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE11; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE12 — Serath Namar

Pesquisadora da memória na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE12; História Geral de Virtude · pp. 17–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE13 — Saelith Vora

Sacerdotisa da Aliança da Brasa na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE13; História Geral de Virtude · pp. 15–16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE14 — Nimea Aral

Organizadora do Círculo das Testemunhas na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE14; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE15 — Teren Vos

Construtor dos instrumentos do Selo na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE15; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE16 — Melian Or

Estudioso dos caminhos do espaço na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE16; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE17 — Eshara Vel

Preparadora da Gema na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE17; História Geral de Virtude · pp. 18–19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE18 — Veska Tor

Barqueira de Elar-Tao na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE18

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE19 — Naeris Ul

Mensageira dos salvo-condutos na história da I Era. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE19

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE20 — Conclaves das Asas

Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE20; História Geral de Virtude · pp. 13, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE21 — Custódios da Esmeralda

Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE21; História Geral de Virtude · pp. 13, 21–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE22 — Artífices da Brasa

Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE22; História Geral de Virtude · pp. 14–15, 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE23 — Senhores do Zênite

Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE23; História Geral de Virtude · pp. 14–15, 18–21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE24 — Casa das Medidas

Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE24; História Geral de Virtude · pp. 16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE25 — Círculo das Testemunhas

Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE25; História Geral de Virtude · pp. 16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE26 — Primeiros Magos

Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE26; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE27 — Mesa das Portas

Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE27; História Geral de Virtude · pp. 17, 20–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE28 — Aliança da Brasa

Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE28; História Geral de Virtude · pp. 15–16, 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE29 — Selo do Tempo

Sistema Eldenari de três instrumentos e uma rede instalada para compatibilizar fluxos temporais presentes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE29; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE30 — Relógio de Avar

Instrumento que compara ritmos e delimita intervalos dentro do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE30; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE31 — Pergaminho das Concordâncias

Registro reativo à mana das condições de operação e interrupção do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE31; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE32 — Gema de Eshara

Instrumento preparado por Eshara Vel para vincular o Selo à rede material e distribuir mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE32; História Geral de Virtude · pp. 18–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE33 — Aerólito

Metal capaz de conservar padrões de mana, ensinado aos construtores Eldenari por Khorvath. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE33; História Geral de Virtude · pp. 15, 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE34 — Eshara, a lua esmeralda

Lua acompanhada pelos Custódios da Esmeralda e sede do refúgio dos dragões sobreviventes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE34; História Geral de Virtude · pp. 13, 18, 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE35 — A Margem

Região de Eomundus sobrecarregada pelo desvio de experiências incompatíveis durante a operação do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE35; História Geral de Virtude · pp. 19–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE36 — O Inconcluso

Nome dado às respostas adaptativas identificadas na Margem durante a crise do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE36; História Geral de Virtude · pp. 19–22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE37 — Leth Avar

Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE37; História Geral de Virtude · pp. 17

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE38 — Elar-Tao

Localidade fluvial Eldenari atingida pela repetição de uma estação de cheia. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE38; História Geral de Virtude · pp. 18

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE39 — Vel-Samar

Centro de arquivo cujo incêndio marcou a abertura da Guerra das Nove Vigílias. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE39; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE40 — Uldar

Cidade neutra cuja destruição levou Khorvath a romper com Zhaurak na quinta campanha. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE40; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE41 — Refúgio de Eshara

Abrigo de mana preparado pelos Custódios na lua esmeralda e alcançado pelos dragões após a ruptura. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE41; História Geral de Virtude · pp. 22

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE42 — Paralisação dos Nove Pátios

Trabalhadores interromperam serviços após a suspensão de pagamentos para financiar pesquisa. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE42; História Geral de Virtude · pp. 16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE43 — Guerra dos Reparos

Conflito entre cidades Eldenari pelo controle da manutenção dos canais e dos suportes de mana. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE43

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE44 — Retirada dos Armazéns de Elar-Tao

Evacuação que tornou pública a disputa por barcos entre casas de estudo e famílias atingidas pelos Descompassos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE44

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE45 — Pacto das Barcas

Acordo de Elar-Tao que incluiu tripulações nas decisões de transporte durante emergências. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE45

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE46 — Batalha das Pontes de Asmarith

Serath impediu uma inundação que atingiria famílias partidárias de Avar durante a segunda campanha. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE46; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE47 — Cinzas de Uldar

Destruição de uma cidade neutra que rompeu alianças entre dragões e sacerdotes. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE47; História Geral de Virtude · pp. 21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE48 — Os vinte e três dias de Xeo Taoju

Intervalo de ocupação e socorro entre a ruptura do Selo e a Grande Punição. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE48; História Geral de Virtude · pp. 22–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE49 — Guerra das Nove Vigílias

Sete campanhas nas quais a disputa pelo Selo desfez alianças entre cidades Eldenari, elfos altos e dragões. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE49; História Geral de Virtude · pp. 21–23

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE50 — Damar Esh

Sacerdote Eldenari que defendia a interpretação divina das aparições antigas. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE50; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE51 — Hared Sen

Príncipe que procurou apoiar seu governo de Xeo Taoju no prestígio de uma criança oracular. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE51; História Geral de Virtude · pp. 15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE52 — Doutrina dos Sinais Cruzados

Práticas de confronto de testemunhos destinadas a dificultar fraudes no reconhecimento de Arautos. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE52; História Geral de Virtude · pp. 14–15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE53 — Pacto das Três Testemunhas

Acordo de observação entre Eldenari, dragões e elfos altos para autorizar o experimento do Selo. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE53; História Geral de Virtude · pp. 18–21

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE54 — Incidente de Thar-Sen

Passagem de quarenta peregrinos que regressaram dezessete anos depois de viverem uma única noite. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE54; História Geral de Virtude · pp. 15–16

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

### RC-IE55 — Noite dos Dois Amanheceres

Descompasso observado por trabalhadores que passaram a discordar sobre os sete dias anteriores. Os fatos, práticas, relações e referências visuais do dossiê correspondente são adotados nesta edição. Incertezas expressas no texto continuam vigentes.

Base: Registro Geral de Virtude 2.7 · RC-IE55; História Geral de Virtude · pp. 15

Aplicação: Registro Geral, wikia e futuras edições pertinentes.

## 39. Primeira Era: dossiês de povos, pessoas, lugares e acontecimentos



Dragões



Primeiros habitantes corpóreos duradouros lembrados pelas tradições de Virtude, de grande longevidade e vínculos profundos com a mana.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Longevidade | Sem morte por velhice; vulneráveis a ferimentos e esgotamento |
| Reprodução | Ovos entre os descendentes |
| Horizonte tradicional | c. 1 da I Era |



Origem e duração. As tradições ligam a formação dos primeiros dragões a Azhravyr e Ithélion, em encontros dos caminhos da mana. O ano 1 da I Era é um horizonte convencional dessa memória. Os primeiros teriam se formado diretamente desses encontros; seus descendentes nasceram de ovos. Dragões não morrem de velhice, mas podem morrer por ferimentos, perda de vínculos com a mana e esgotamento de grandes encantamentos.



Paciência, torpor e responsabilidade. Séculos de existência permitem conhecimentos vastos e também criam desencontros com sociedades de vida mais breve. O torpor recupera forças, mas pode deixar lacunas e dificultar o reconhecimento de mudanças políticas. Uma promessa ainda recente para um dragão pode sustentar a vida de muitas gerações Eldenari. Os Conclaves das Asas procuravam arbitrar território, acesso à mana e cuidado dos ovos.



Tradições e dissidências. Os Custódios da Esmeralda, os Artífices da Brasa e os Senhores do Zênite desenvolveram orientações diferentes. Varesh preservou vínculos sem aderir permanentemente a nenhuma delas. A Guerra das Nove Vigílias atravessou essas divisões: Khorvath rompeu com Zhaurak, enquanto Vaelthar abandonou a neutralidade após sofrer um ataque.



Depois da ruptura. Vaelthar e Varesh conduziram sobreviventes ao refúgio de Eshara. O caminho consumiu os instrumentos capazes de mantê-lo, isolando o grupo. Ovos permaneceram em santuários de Virtude. As tradições posteriores de Nogard conservam o culto a figuras dracônicas, distinguindo a vida histórica de Khorvath e Varesh das interpretações religiosas de sua memória.



Eldenari



Povo de vidas seculares, associado às primeiras cidades dos vales do Taoju e do Asmarith e às grandes instituições de pesquisa da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Longevidade | Vários séculos |
| Primeiros assentamentos | c. 2100 da I Era |
| Centros históricos | Vales do Taoju e Asmarith |
| Depois da ruptura | Mortes, deslocamentos e sobrevivências dispersas |



Cidades e gerações. Vestígios situam assentamentos Eldenari por volta de 2100 da I Era. A consolidação urbana de Xeo Taoju é colocada em torno de 2550. Asterion e Nereth aparecem nas tradições de origem de um povo sensível à mana e dedicado a registrar experiências. Vidas de vários séculos permitiam pesquisas prolongadas, mas também concentravam autoridade em famílias e casas de estudo.



Trabalho e conhecimento. Calendários orientavam plantio, cobrança e armazenamento. Ilyra Seneth procurou tornar o céu compreensível; Oren Namar defendeu a permanência dos nomes dos mortos. Talena Ors e Edris Vaun distinguiram relato e observação. A manutenção dos centros dependia de barqueiros, carpinteiros, cuidadores e trabalhadores de oficina, cuja remuneração se tornou uma questão pública na Paralisação dos Nove Pátios.



Cidades em desacordo. A Casa das Medidas e os templos disputavam competências, enquanto alianças com dragões podiam trazer proteção, ensino ou tributo compulsório. A Guerra dos Reparos aprofundou conflitos pelo acesso à manutenção dos canais. Mais tarde, o Selo dividiu comunidades que temiam perder colheitas e outras que denunciavam o custo de sua estabilidade.



Ruptura e sobrevivência. A ligação de corpos e memórias aos instrumentos de pesquisa tornou os centros Eldenari particularmente vulneráveis à ruptura. Muitos morreram, outros foram arrastados à Margem e pequenos grupos sobreviveram longe das instalações. Seus descendentes se misturaram a outros povos. A perda de arquivos e comunidades explica a fragmentação posterior de sua história.



Aelthir e a chegada dos elfos altos



Comunidades de Eomundus cuja travessia para Virtude, conduzida por Arieth Ilvar, deu origem aos elfos altos.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Origem | Eomundus |
| Travessia | c. 5990 da I Era |
| Transformação | Corpos materiais; origem dos elfos altos |
| Longevidade material | Muitos séculos; raramente mais de um milênio |



Leth Avar. Os Aelthir viviam em Eomundus, onde forma, memória e vínculo se relacionavam à paisagem. A região chamada Leth Avar perdeu estabilidade: pessoas esqueciam o próprio nome e cidades mudavam conforme os sonhos de seus habitantes. O problema atingia a possibilidade de conservar uma vida comum, e a travessia tornou-se uma decisão de sobrevivência.



As Sete Portas. Arieth Ilvar conduziu os refugiados durante a Travessia das Sete Portas, situada por volta de 5990. Ao aceitarem corpos materiais, perderam capacidades antigas e passaram a viver como elfos altos. Suas vidas alcançavam muitos séculos, raramente mais de um milênio. A chegada envolveu abrigo, alimento, reconhecimento de parentesco e adaptação às condições de Virtude.



Comunidades e conhecimento. Emvale e Aston pertencem à formação das comunidades setentrionais. Contatos posteriores alcançaram terras orientais. Ithélion ocupava posição religiosa central e Ardanus, chamado Arathiel, era invocado nos juramentos. A fundação da Ordem dos Magos por Caerion Thalas transformou a experiência das passagens em um programa de conservação, exame e responsabilização.



Trocas e tensões. Maeriel Sorn manteve intercâmbios com pesquisadores Eldenari. Técnicas de proteção mental e relatos do Entrelaço circularam junto ao conhecimento do aerólito. A cooperação não eliminou divergências sobre quem podia autorizar intervenções na mana; o conflito em torno do Selo atingiu as comunidades que haviam procurado em Virtude uma existência mais estável.



Vaelthar



Ouvinte das Estrelas na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Dragão |
| Atuação | Ouvinte das Estrelas |
| Sinais distintivos | Escamas verdes opacas, quase negras à sombra; fratura branca no chifre esquerdo. |
| Período | I Era |
| Vínculos principais | Custódios da Esmeralda; Conclaves das Asas |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Escutava por longos períodos e lembrava visitantes de séculos anteriores. Sua prudência podia adiar uma decisão até transformá-la em abandono. Liderava os Custódios da Esmeralda, atentos aos Descompassos e aos ciclos de Eshara.



Vínculos e conflitos. Permanecia contrário ao Selo, mas não impediu a tentativa autorizada pelo Pacto das Três Testemunhas. Na guerra, buscou uma trégua e foi ferido por dragões do Zênite ao proteger uma delegação élfica. Seus Custódios passaram então a combater.



Legado e limites do registro. Com Varesh, conduziu sobreviventes ao refúgio preparado em Eshara. O isolamento posterior limita aquilo que as fontes de Virtude conseguem acompanhar sobre sua vida. A travessia encerra sua participação diretamente narrada na crise.



Aparência e presença. Escamas verdes opacas, quase negras à sombra; fratura branca no chifre esquerdo.



Khorvath



Ferreiro Vivo na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Dragão |
| Atuação | Ferreiro Vivo |
| Sinais distintivos | Peito largo, escamas cor de cobre e uma asa marcada por cicatrizes de metal fundido. |
| Período | I Era |
| Vínculos principais | Artífices da Brasa; Aliança da Brasa |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Trabalhava junto aos aprendizes e ensinou os Eldenari a concentrar mana em pedra e metal. A dedicação ao ofício convivia com dificuldade de aceitar críticas ao que construíra. Os Artífices da Brasa e a Aliança da Brasa expressaram sua confiança no aperfeiçoamento da criação.



Vínculos e conflitos. Ajudou os Primeiros Magos a construir o Selo e apoiou a tentativa de Avar de corrigir os desvios sem desligá-lo. Temia que a interrupção condenasse cidades. Nas Cinzas de Uldar, rompeu com Zhaurak após a destruição da cidade neutra.



Legado e limites do registro. Morreu sustentando as fundações do zigurate durante a ruptura, permitindo uma evacuação. Seu culto posterior em Nogard transformou o artífice histórico em objeto de devoção, questão disputada entre sacerdotes.



Aparência e presença. Peito largo, escamas cor de cobre e uma asa marcada por cicatrizes de metal fundido.



Zhaurak



Coroa Rubra na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Dragão |
| Atuação | Coroa Rubra |
| Sinais distintivos | Escamas vermelhas de bordas douradas; postura elevada e cuidadosamente dominante. |
| Período | I Era |
| Vínculos principais | Senhores do Zênite; Serath Namar |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Os Senhores do Zênite reuniam-se em torno de sua defesa do governo dos primeiros habitantes sobre os povos posteriores. Sua generosidade com protegidos se confundia com a exigência de obediência. Reconhecia a gratidão com mais facilidade do que a dependência criada por sua proteção.



Vínculos e conflitos. Aderiu ao Pacto após obter o reconhecimento dos próprios domínios. Impediu inspeções, perseguiu críticos e atacou a escolta de Serath. O incêndio de Vel-Samar e a destruição de Uldar ampliaram a guerra e romperam alianças.



Legado e limites do registro. Atacou o zigurate para impedir o desligamento do Selo. Maeriel o enfrentou nas galerias superiores; ambos desapareceram na descarga. Os relatos conservam esse desaparecimento sem uma confirmação separada de seus destinos.



Aparência e presença. Escamas vermelhas de bordas douradas; postura elevada e cuidadosamente dominante.



Varesh



Asa das Marés na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Dragão |
| Atuação | Asa das Marés |
| Sinais distintivos | Membranas das asas com cicatrizes de sal; nesta referência visual, escamas cinza-pérola de reflexos marinhos. |
| Período | I Era |
| Vínculos principais | Conclaves das Asas; Vaelthar |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Percorreu oceanos e acolheu exilados sem aderir permanentemente às três tradições dracônicas. Alterava o ritmo da voz ao experimentar idiomas. Sua liberdade encantava viajantes, mas podia deixar desassistidas comunidades que dependiam de sua continuidade.



Vínculos e conflitos. Um santuário fundado para viajantes ficou sem apoio durante uma fome quando ela partiu para investigar uma corrente marítima. Esse episódio ocupa lugar importante nas leituras críticas de sua hospitalidade e da responsabilidade de quem oferece proteção.



Legado e limites do registro. Conduziu com Vaelthar os sobreviventes até Eshara. Sua memória seria cultuada em Nogard ao lado de Azhravyr e Khorvath, embora ela tivesse vivido como criatura de Virtude.



Aparência e presença. Membranas das asas com cicatrizes de sal; nesta referência visual, escamas cinza-pérola de reflexos marinhos.



Arieth Ilvar



Regente da Travessia na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Aelthir; depois elfa alta |
| Atuação | Regente da Travessia |
| Sinais distintivos | Rosto longo, pele escura e mecha branca trançada junto à têmpora. |
| Período | I Era |
| Vínculos principais | Aelthir e a chegada dos elfos altos; Leth Avar |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Conduziu famílias de Leth Avar durante a Travessia das Sete Portas. Sua autoridade era marcada pela responsabilidade diante das pessoas que aceitara guiar. Manteve postos de acolhimento quando parte do conselho defendia fechar a passagem.



Vínculos e conflitos. A chegada exigiu organizar abrigo e recursos para corpos sujeitos a novas condições materiais. A regente protegeu a associação de estudiosos que Caerion transformaria na Ordem dos Magos. O consentimento nas intervenções e a conservação de conhecimentos de passagem pertencem a esse contexto.



Legado e limites do registro. Temia receber uma delegação que exigisse o retorno e descobrir que não restara ninguém a quem devolver o caminho. As fontes não estabelecem aqui uma data de morte ou uma sucessão completa de sua regência.



Aparência e presença. Rosto longo, pele escura e mecha branca trançada junto à têmpora.



Caerion Thalas



Fundador da Ordem dos Magos na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Elfo alto |
| Atuação | Fundador da Ordem dos Magos |
| Sinais distintivos | Mãos finas, com tremor quando cansado; referência visual de rosto retangular, cabelos presos e manto cinza-azulado. |
| Período | I Era |
| Vínculos principais | Ordem dos Magos; Mesa das Portas |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Fundou a Ordem em Aethravel por volta de 6035. Defendia a revisão dos erros e o exame das intervenções por mais de uma escola. A responsabilidade institucional tornou-o progressivamente relutante em expor divergências internas.



Vínculos e conflitos. Enviou Maeriel a Xeo Taoju, negociou intercâmbios e exigiu um desligamento gradual do Selo diante de efeitos inesperados. Sua alternativa distribuía riscos por comunidades que nem sempre haviam consentido em suportá-los. Na crise final, ordenou uma intervenção antes de receber o novo acordo entre Avar e Serath.



Legado e limites do registro. Morreu durante a Grande Punição tentando proteger refugiados que seguiam para o norte. Sua trajetória reúne a criação de procedimentos de cuidado e os limites políticos que impediram seu funcionamento no momento decisivo.



Aparência e presença. Mãos finas, com tremor quando cansado; referência visual de rosto retangular, cabelos presos e manto cinza-azulado.



Maeriel Sorn



Diplomata dos intercâmbios na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Elfa alta |
| Atuação | Diplomata dos intercâmbios |
| Sinais distintivos | Cabelo negro no queixo, sobrancelha atravessada por cicatriz e roupas práticas de viagem. |
| Período | I Era |
| Vínculos principais | Caerion Thalas; Serath Namar |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Enviada por Caerion a Xeo Taoju, aproximou-se de Serath Namar e dos pesquisadores Eldenari. Seu humor seco prejudicava cerimônias, mas sua disposição de conviver com oficinas e estudos abriu vínculos que a diplomacia formal dificilmente sustentaria.



Vínculos e conflitos. Com Serath, identificou o desvio de experiências para a Margem. Retirou a pesquisadora da prisão por volta de 6393, no episódio que antecedeu o ataque de Zhaurak. Na última campanha, procurou informar Caerion da cooperação renovada entre Avar e Serath.



Legado e limites do registro. Enfrentou Zhaurak nas galerias superiores do zigurate e desapareceu na descarga. Sua atuação permite acompanhar o custo de uma guerra que passou a tratar mediadores e salvo-condutos como ameaças.



Aparência e presença. Cabelo negro no queixo, sobrancelha atravessada por cicatriz e roupas práticas de viagem.



Avar Seneth



Especialista em tempo na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Especialista em tempo |
| Sinais distintivos | Cabelos negros presos por fios de cobre, rosto estreito e hábito de endireitar objetos enquanto falava. |
| Período | I Era |
| Vínculos principais | Ilyra Seneth; Primeiros Magos |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Descendente de Ilyra Seneth, integrou os Primeiros Magos e procurou construir um calendário que jamais falhasse. A morte de um sobrinho numa cheia repetida agravou sua incapacidade de aceitar descanso diante de um cálculo aberto. Era atencioso com aprendizes e passou a ler advertências como pedidos de tolerar outras perdas.



Vínculos e conflitos. Foi reconhecido como Arauto de Asterion por seguidores e parte do sacerdócio; esse reconhecimento permanece disputado. Após os nove anos iniciais do Selo, sustentou que corrigiria o desvio sem desligá-lo. Não enfrentou Zhaurak quando o dragão bloqueou inspeções necessárias.



Legado e limites do registro. No cerco final, percebeu a atuação do Inconcluso através dos instrumentos e cooperou com Serath no desligamento. Permaneceu junto ao Relógio durante a ruptura. O registro conserva sua última atuação sem acrescentar uma cena de morte que as fontes não descrevem.



Aparência e presença. Cabelos negros presos por fios de cobre, rosto estreito e hábito de endireitar objetos enquanto falava.



Serath Namar



Pesquisadora da memória na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Pesquisadora da memória |
| Sinais distintivos | Cabelos precocemente grisalhos; roupas de viagem mesmo em cerimônias; anotações críticas nas margens. |
| Período | I Era |
| Vínculos principais | Primeiros Magos; Maeriel Sorn |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Integra os Primeiros Magos como estudiosa da memória. Ambicionava demonstrar uma organização investigável das lembranças e ressentia-se quando seu trabalho era reduzido ao prestígio de Avar. A cooperação entre os dois atravessou afeto, competição e divergências sobre o direito de impor estabilidade ao mundo.



Vínculos e conflitos. Com Maeriel, identificou a Margem. Tentou reduzir a carga do Selo, foi presa e depois retirada da prisão pela diplomata. Nas Pontes de Asmarith, impediu uma inundação que atingiria famílias partidárias de Avar, mesmo permitindo a fuga de forças que voltariam a combater.



Legado e limites do registro. Na ruptura, acionou o Pergaminho para impedir que o Inconcluso atravessasse inteiramente. Seus cálculos sobre o retorno tardio de energia integram as explicações da Grande Punição, sem resolver sozinhos todas as evidências da catástrofe.



Aparência e presença. Cabelos precocemente grisalhos; roupas de viagem mesmo em cerimônias; anotações críticas nas margens.



Saelith Vora



Sacerdotisa da Aliança da Brasa na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Sacerdotisa da Aliança da Brasa |
| Sinais distintivos | Couro cabeludo tatuado e colares de cerâmica que estalavam quando se movia. |
| Período | I Era |
| Vínculos principais | Aliança da Brasa; Khorvath |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Devota de Azhravyr, estabeleceu a Aliança da Brasa entre cidades Eldenari e dragões Artífices. Conhecia a fome dos campos e buscava proteção e estabilidade. Sua defesa da parceria dracônica encontrou o problema do trabalho compulsório exigido por Zhaurak.



Vínculos e conflitos. Via na desconfiança de Nimea Aral uma posição distante de quem precisava responder por uma colheita. A aproximação com os Senhores do Zênite dividiu seus sacerdotes. Nas Cinzas de Uldar, retirou a bênção às tropas após a destruição de uma cidade neutra.



Legado e limites do registro. Perdeu o cargo e passou os últimos anos conduzindo refugiados que antes a aclamavam. Sua trajetória conserva a responsabilidade por alianças anteriores e a mudança de posição diante das consequências da guerra.



Aparência e presença. Couro cabeludo tatuado e colares de cerâmica que estalavam quando se movia.



Nimea Aral



Organizadora do Círculo das Testemunhas na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Organizadora do Círculo das Testemunhas |
| Sinais distintivos | Voz rouca, nariz quebrado num tumulto e pouca disposição para reverenciar colegas. |
| Período | I Era |
| Vínculos principais | Círculo das Testemunhas; Descompassos |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Defendia que uma entidade capaz de realizar maravilhas ainda podia mentir. Organizou o Círculo das Testemunhas para reunir relatos sem obrigar depoentes a concordar. O procedimento contrariava autoridades que buscavam uma versão única para cada manifestação.



Vínculos e conflitos. A disputa com o sacerdote Damar Esh atravessou a interpretação de Descompassos e encontros velários. Nimea procurava conservar o desacordo entre testemunhas como parte da evidência. A posição tensionava sacerdotes e patrocinadores que dependiam do reconhecimento de uma intervenção divina.



Legado e limites do registro. Sua prática influenciou a cultura de verificação herdada pelos pesquisadores posteriores. Não há uma data segura de nascimento ou morte neste recorte. O nome do Círculo continuou em uso por gerações; a atuação posterior da organização não implica a presença de sua fundadora em todos esses momentos.



Aparência e presença. Voz rouca, nariz quebrado num tumulto e pouca disposição para reverenciar colegas.



Teren Vos



Construtor dos instrumentos do Selo na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Construtor dos instrumentos do Selo |
| Sinais distintivos | Dedos deformados pelo trabalho; referência visual de rosto quadrado, cabelo crespo baixo e avental de oficina. |
| Período | I Era |
| Vínculos principais | Primeiros Magos; Selo do Tempo |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Integrou os Primeiros Magos como construtor de instrumentos. Sua pouca tolerância a discursos religiosos fazia-o insistir na diferença entre autoridade ritual e funcionamento de uma peça. A estabilidade de encaixes, suportes e conexões exigia conhecimentos que nenhum outro membro dominava sozinho.



Vínculos e conflitos. Na ampliação do recorte, seus registros distinguem defeito do instrumento, alteração do meio e erro de leitura. Essa rotina foi usada para comparar operações da rede sem atribuir toda falha à capacidade do operador. Sua confiança na repetição encontrava limites quando o projeto mudava mais depressa que as condições de ensaio.



Legado e limites do registro. Participou da construção do Selo com Avar, Serath, Melian e Eshara Vel. As fontes não oferecem um destino individual seguro na ruptura. O desaparecimento de instalações e oficinas também limitou a identificação de seus trabalhos posteriores.



Aparência e presença. Dedos deformados pelo trabalho; referência visual de rosto quadrado, cabelo crespo baixo e avental de oficina.



Melian Or



Estudioso dos caminhos do espaço na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Estudioso dos caminhos do espaço |
| Sinais distintivos | Referência visual: rosto oval, nariz achatado, olhos fundos, cabelos longos presos e casaco de bolsos de tecido. |
| Período | I Era |
| Vínculos principais | Primeiros Magos; Selo do Tempo |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Responsável pelos caminhos do espaço entre os Primeiros Magos, defendia partilhar o projeto entre cidades. Aceitou restrições de circulação para conservar o financiamento. Essa concessão colocou a pesquisa diante do conflito entre cooperação declarada e controle das instalações.



Vínculos e conflitos. Suas equipes faziam rotas de manutenção em pares, com registros de chegada e retorno. A prática protegia trabalhadores diante de mudanças nas passagens e gerava provas de acesso. Durante a crise, os mesmos registros passaram a servir à vigilância sobre quem podia atravessar cada setor.



Legado e limites do registro. Sua participação explica a dependência do Selo de uma rede instalada ao longo de décadas. Reunir as três peças fora dessa rede não reproduziria automaticamente a escala da operação antiga. Seu destino individual no colapso continua sem confirmação.



Aparência e presença. Referência visual: rosto oval, nariz achatado, olhos fundos, cabelos longos presos e casaco de bolsos de tecido.



Eshara Vel



Preparadora da Gema na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Preparadora da Gema |
| Sinais distintivos | Perda progressiva de audição; referência visual de cabelos curtos ruivos escuros, rosto miúdo e mãos expressivas. |
| Período | I Era |
| Vínculos principais | Primeiros Magos; Gema de Eshara |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Integrava os Primeiros Magos e interpretava variações da mana nos seres vivos. Preparou a Gema que recebeu seu nome. A lua Eshara já era conhecida antes dela: a pesquisadora fora nomeada em homenagem ao astro. A perda de audição durante o trabalho levou-a a desenvolver sinais manuais adotados pelos operadores.



Vínculos e conflitos. As oficinas passaram a registrar sinais de interrupção em suportes visíveis, permitindo alertar equipes mesmo em ruído intenso. O gesto de interromper uma operação tornou-se uma questão de autoridade: reconhecer o alerta exigia aceitar que um auxiliar pudesse suspender o trabalho de alguém prestigiado.



Legado e limites do registro. Seu conhecimento sustentou a ligação entre o Selo e Virtude. A Gema conservava mana acumulada e precisava de reposição. O destino pessoal de Eshara durante a ruptura não é estabelecido por um registro conclusivo.



Aparência e presença. Perda progressiva de audição; referência visual de cabelos curtos ruivos escuros, rosto miúdo e mãos expressivas.



Veska Tor



Barqueira de Elar-Tao na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Eldenari |
| Atuação | Barqueira de Elar-Tao |
| Sinais distintivos | Corpo robusto, cabelo negro enrolado em pano, lábio inferior cheio e cicatriz curta no queixo. |
| Período | I Era |
| Vínculos principais | Elar-Tao; Retirada dos Armazéns de Elar-Tao |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Transportava alimentos e famílias pelos canais de Elar-Tao. Durante a Retirada dos Armazéns, em 6337, confrontou a prioridade dada a instrumentos de pesquisa nos barcos de evacuação. Usava túnica de mangas curtas, faixas de lona e uma vara de travessia, guardando marcas de carga em pequenas peças de cerâmica.



Vínculos e conflitos. O Pacto das Barcas de 6338 reconheceu a presença de representantes das tripulações nas decisões sobre transporte emergencial. Veska defendia reservar espaço para pessoas, sementes e provisões, mesmo quando uma casa de estudo reivindicava o barco inteiro. Sua posição rendeu apoio de famílias e resistência dos proprietários das cargas.



Legado e limites do registro. O exemplo de Elar-Tao circulou nas discussões que antecederam o Selo. A pesquisa dependia de quem mantinha os caminhos e os corpos vivos durante as crises. Este recorte não fixa sua morte nem a transforma em testemunha de todos os acontecimentos finais.



Aparência e presença. Corpo robusto, cabelo negro enrolado em pano, lábio inferior cheio e cicatriz curta no queixo.



Naeris Ul



Mensageira dos salvo-condutos na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Elfa alta |
| Atuação | Mensageira dos salvo-condutos |
| Sinais distintivos | Rosto comprido com queixo curto, sardas escuras, trança castanha muito apertada e um incisivo lascado. |
| Período | I Era |
| Vínculos principais | Maeriel Sorn; Caerion Thalas |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Serviu nas rotas de correspondência entre observadores élficos e cidades Eldenari durante a última campanha. Levava estojo impermeável, manto curto e uma lâmina de uso cotidiano. Aprendeu a reconhecer postos onde a assinatura aceita numa semana era tratada como ameaça na seguinte.



Vínculos e conflitos. Naeris é a mensageira detida por aliados ao levar a Caerion a notícia enviada por Maeriel sobre a cooperação entre Avar e Serath. Os guardas desconfiaram do salvo-conduto emitido numa área disputada. A demora consumiu a possibilidade de comparar o novo acordo com a intervenção já preparada.



Legado e limites do registro. Sua atuação dá um rosto à falha das comunicações que a História Geral já registra. O recorte não atribui a ela a causa única da ruptura. A detenção ocorreu dentro de procedimentos de guerra que haviam tornado suspeitos os próprios mecanismos de verificação.



Aparência e presença. Rosto comprido com queixo curto, sardas escuras, trança castanha muito apertada e um incisivo lascado.



Conclaves das Asas



Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Reuniões dracônicas para arbitrar território, reprodução, acesso à mana e cuidado dos ovos. |



Formação e práticas. As reuniões não formavam um governo de todos os dragões. Participação, reconhecimento de uma decisão e capacidade de fazê-la cumprir dependiam dos vínculos entre os presentes. O costume mais antigo proibia atacar um ninho para resolver uma disputa entre adultos.



Disputas internas. Os Conclaves distinguem proteção de ninho e submissão territorial: aceitar abrigo para ovos não transfere automaticamente a um protetor a obediência dos adultos. A regra permitia negociações entre tradições rivais, embora cada uma interpretasse de modo diferente os deveres de proteção.



Na história da era. A violação dos ninhos na Guerra das Nove Vigílias destruiu possibilidades de reconciliação. A perda de ovos atingiu gerações futuras de um povo pouco numeroso e lento para se reproduzir. O cuidado dos sobreviventes ajuda a compreender a retirada para Eshara.



Custódios da Esmeralda



Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Tradição de Vaelthar dedicada a observar Descompassos e intervir diante de perigo imediato. |



Formação e práticas. Seus santuários nas montanhas acompanhavam ciclos da lua esmeralda, Eshara. A observação prolongada e a prudência forneciam uma alternativa às ambições de transformação dos Artífices e de domínio dos Senhores do Zênite.



Disputas internas. Havia uma disputa interna entre vigílias longas e auxílio imediato: parte dos Custódios temia que intervir modificasse o fenômeno observado; outros consideravam que a obrigação de abrigo já vinculava o observador à vida dos visitantes. Vaelthar não resolveu sempre essa tensão a tempo.



Na história da era. Após o ataque à delegação protegida por Vaelthar, os Custódios entraram na guerra. O refúgio preparado em Eshara tornou-se a saída para parte dos dragões, mas a travessia esgotou os instrumentos de acesso.



Artífices da Brasa



Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Tradição dracônica ligada a Khorvath e ao aperfeiçoamento de formas, materiais e encantamentos. |



Formação e práticas. Os Artífices ensinaram a concentrar mana em pedra e metal. A relação com cidades Eldenari gerou oficinas, aprendizagem e obras de grande escala. O trabalho do aerólito tornou essa cooperação especialmente importante para a construção de instrumentos.



Disputas internas. As oficinas distinguem o direito de aprender de uma obrigação de servir por toda a vida. Mestres e patrocinadores divergiam sobre a abertura dos registros de fabricação. O ensino podia emancipar uma cidade e, ao mesmo tempo, torná-la dependente de manutenção especializada.



Na história da era. O apoio de Khorvath ao Selo nasceu dessa confiança na possibilidade de corrigir uma construção. Sua ruptura com Zhaurak após Uldar mostra que a aliança técnica e política não foi uniforme durante toda a guerra.



Senhores do Zênite



Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Tradição reunida em torno de Zhaurak e da primazia política dos dragões sobre povos posteriores. |



Formação e práticas. A proteção oferecida por dragões do Zênite vinha acompanhada de tributos e serviços. Seus defensores alegavam que a longevidade permitia governar para além de interesses passageiros; comunidades tributadas contestavam o direito de transformar proteção em trabalho compulsório.



Disputas internas. Os domínios mantinham listas diferentes para cidades protegidas, tributárias e obedientes. A mudança de uma lista para outra permitia ampliar cobranças sem renegociar todos os acordos. A discrepância entre proteção proclamada e autonomia efetiva se tornou um foco de resistência.



Na história da era. Zhaurak condicionou sua adesão ao Pacto ao reconhecimento dos domínios, bloqueou inspeções e perseguiu críticos do Selo. A violência contra emissários e cidades neutras afastou antigos aliados. Outros dragões do Zênite participaram do ataque a Vaelthar.



Casa das Medidas



Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Associação Eldenari de agrimensores, astrônomos e representantes urbanos, envolvida em calendários, água e cobrança. |



Formação e práticas. Medir não era uma atividade afastada da política. Alterar a data de um tributo podia comprometer sementes e provisões. A Casa disputava com o sacerdócio a competência sobre cobranças e dependia do trabalho de equipes que transportavam, construíam e mantinham instrumentos.



Disputas internas. A Paralisação dos Nove Pátios obrigou a reservar mantimentos para trabalhadores. Na Guerra dos Reparos, a Casa tentou distinguir inspeção de ocupação das instalações; a arbitragem de 6266 ampliou a participação das comunidades afetadas. Os acordos não encerraram o uso político de mapas e registros.



Na história da era. Durante as Nove Vigílias, especialistas guiaram ofensivas, enquanto outros falsificaram mapas para proteger localidades. A divisão mostrou como um conhecimento útil ao cuidado dos canais também podia sustentar campanhas militares.



Círculo das Testemunhas



Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Organização criada por Nimea Aral para recolher relatos preservando diferenças entre depoentes. |



Formação e práticas. A prática admitia que duas testemunhas sinceras oferecessem versões incompatíveis. Essa diferença devia ser conservada para estudo, especialmente em encontros velários, reconhecimento de Arautos e Descompassos. Autoridades que buscavam um único relato frequentemente contestavam seus métodos.



Disputas internas. Os cadernos do Círculo separam o nome fornecido, o nome reconhecido e a descrição da aparência. Uma mesma figura podia ser identificada de modos diferentes por observadores próximos. O procedimento aproximava cuidado com o depoente e atenção à história da transmissão.



Na história da era. A organização sobreviveu por gerações à sua fundação. Durante a Guerra das Nove Vigílias, manteve corredores de troca de prisioneiros até receber acusações de espionagem dos dois lados. Essa atuação posterior pertence à instituição e não fixa a longevidade de Nimea.



Primeiros Magos



Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Círculo de cinco pesquisadores Eldenari que organizou uma disciplina comum e construiu o Selo do Tempo. |



Formação e práticas. O círculo formou-se por volta de 6360, diante de Descompassos como os de Elar-Tao. Avar Seneth, Serath Namar, Teren Vos, Melian Or e Eshara Vel reuniam especialidades distintas. Seu título expressa a organização comum dessas artes; encantamentos já existiam havia muito tempo.



Disputas internas. Avar estudava tempo, Serath memória, Teren instrumentos, Melian espaço e Eshara mana nos seres vivos. O trabalho dependia de tradução entre práticas, equipes de instalação e financiamento das cidades. Divergências pessoais e institucionais atravessavam decisões que nenhum integrante podia tomar sozinho com pleno conhecimento.



Na história da era. Com Khorvath, construíram as três peças do Selo. A cooperação inicial foi desgastada pelos efeitos da Margem e pelas disputas de inspeção. Na última campanha, Avar e Serath voltaram a cooperar, mas a guerra havia comprometido os mecanismos para comunicar e verificar o acordo.



Mesa das Portas



Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Instância da primeira Ordem dos Magos que examinava trabalhos e podia suspender intervenções. |



Formação e práticas. Reunia responsáveis pelas disciplinas da associação fundada em Aethravel. A revisão por mais de uma escola procurava impedir que prestígio e linhagem substituíssem demonstrações. Cuidadores de passagens, conservadores de instrumentos e pesquisadores participavam de uma instituição mais ampla que uma força de combate.



Disputas internas. Uma suspensão devia conservar os registros do trabalho e indicar as condições necessárias para retomá-lo. A regra protegia a possibilidade de revisão e também criava disputas sobre quem podia atrasar uma pesquisa. A contenção pública das divergências por Caerion dificultou esse ideal em momentos posteriores.



Na história da era. O conflito do Selo expôs a distância entre exigir interrupção e apresentar uma alternativa praticável para as comunidades dependentes da rede. A destruição de arquivos e instrumentos no fim da era comprometeu parte dos procedimentos que os fundadores haviam procurado preservar.



Aliança da Brasa



Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Período | I Era |
| Campo de atuação | Cooperação estabelecida por Saelith Vora entre cidades Eldenari e dragões Artífices. |



Formação e práticas. A aliança vinculava ensino, proteção e obras materiais. Saelith via nos dragões parceiros para enfrentar a fome e dar estabilidade às cidades. Khorvath oferecia conhecimentos de concentração da mana, especialmente no trabalho de pedra, metal e aerólito.



Disputas internas. Que os pactos locais tinham contrapartidas diferentes: manutenção de santuários, provisões para oficinas e abertura de aprendizagem. A variedade permitia adaptação, mas também favorecia a apresentação de obrigações novas como se sempre tivessem integrado um acordo anterior.



Na história da era. A aproximação de Saelith com Zhaurak tensionou a autonomia das comunidades e dividiu sacerdotes. Sua retirada das bênçãos após Uldar rompeu a associação automática entre proteção dracônica e legitimidade da guerra. A aliança deixou legados técnicos mais duradouros do que sua unidade política.



Selo do Tempo



Sistema Eldenari de três instrumentos e uma rede instalada para compatibilizar fluxos temporais presentes.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Ativação | c. 6384 da I Era |
| Componentes | Relógio, Pergaminho e Gema |
| Escala | Rede de instalações preparadas |
| Limite | Compatibilização presente; não reescreve o passado |



Construção e autorização. Os Primeiros Magos construíram o Selo com Khorvath. O Pacto das Três Testemunhas autorizou a operação sob observação de Eldenari, dragões e elfos altos. Caerion exigiu desligamento gradual diante de efeitos inesperados; Zhaurak obteve reconhecimento dos domínios. Avar e patrocinadores abreviaram etapas de verificação diante da fome.



Três funções complementares. O Relógio de Avar comparava ritmos e intervalos; o Pergaminho das Concordâncias estabelecia condições e interrupções; a Gema de Eshara ligava os procedimentos à rede material e distribuía energia. Cada parte limitava abusos que as outras não reconheciam sozinhas. A escala do sistema dependia de instalações preparadas durante décadas.



Estabilidade e custo. Ativado por volta de 6384 no Zigurate das Nove Vigílias, o Selo fez os Descompassos praticamente cessarem durante nove anos. Serath e Maeriel descobriram o desvio de experiências incompatíveis para a Margem. Três tentativas de redução enfrentaram mortes, efeitos de memória e bloqueios de inspeção.



Ruptura e limites. Na campanha final coincidiram o desligamento de Avar e Serath, o ataque de Zhaurak e a intervenção ordenada por Caerion. A unidade se perdeu e as peças foram dispersas. Mesmo reunido, o Selo não permitia voltar ao passado para escolher outro resultado. Encontrar os instrumentos em outra era não reconstrói a antiga rede.



Relógio de Avar



Instrumento que compara ritmos e delimita intervalos dentro do Selo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Tipo | Artefato do Selo |
| Estado no fim da I Era | Disperso após a ruptura |



Função no conjunto. O Relógio estabelecia a comparação temporal necessária à operação, sem decidir quais mudanças seriam admissíveis. Sua leitura dependia de referências e condições de instalação. Avar permaneceu junto a ele na ruptura.



Uso e limites. Separado do conjunto, podia revelar ou reduzir desajustes locais. Não reescrevia acontecimentos vividos. O instrumento tinha aros de bronze fosco, discos e ponteiros artesanais. Sua operação preservava a diferença entre medir uma relação e governar todo o tempo.



História e referência visual. A ruptura dispersou os instrumentos e alterou suas correspondências com a rede. Fora de uso, o Relógio deixou de emitir um padrão que permitisse encontrá-lo simplesmente buscando mana. Seu destino posterior não é resolvido por este recorte.



Pergaminho das Concordâncias



Registro reativo à mana das condições de operação e interrupção do Selo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Tipo | Artefato do Selo |
| Estado no fim da I Era | Disperso após a ruptura |



Função no conjunto. O Pergaminho estabelecia limites e procedimentos sem fornecer energia ou executar sozinho as alterações. A escrita reagia à mana e permitia comparar a resposta do sistema com as condições previstas.



Uso e limites. Isolado, ajudava a reconhecer instruções, falhas e condições de dispositivos da mesma tradição. Margens de revisão reservadas a objeções, cuja leitura exigia comparar versões. O valor do objeto dependia da compreensão do procedimento registrado.



História e referência visual. Serath o acionou para impedir a travessia completa do Inconcluso. Após a dispersão, os relatos de aparição tornaram-se contraditórios. O instrumento não permite ordenar qualquer coisa por meio de palavras e não garante reconstruir as instalações perdidas.



Gema de Eshara



Instrumento preparado por Eshara Vel para vincular o Selo à rede material e distribuir mana.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Tipo | Artefato do Selo |
| Estado no fim da I Era | Disperso após a ruptura |



Função no conjunto. A Gema recebeu o nome da pesquisadora que a preparou. Eshara Vel fora nomeada em homenagem à lua, já chamada Eshara. A peça distribuía energia captada e ligava procedimentos aos pontos preparados em Virtude.



Uso e limites. Utilizava mana acumulada e precisava de reposição. Isolada, podia alimentar e ampliar ligações preparadas, sem conhecer medida ou finalidade. O risco aumentava quando controles ausentes eram substituídos por operadores e seres vivos submetidos à carga.



História e referência visual. A ruptura dispersou a peça com as outras partes do Selo. O relato acompanha sua função e sua história na I Era; os acontecimentos posteriores permanecem nos verbetes e blocos da trama correspondentes. Sua referência visual é uma pedra esmeralda em suporte de metal e cerâmica.



Aerólito



Metal capaz de conservar padrões de mana, ensinado aos construtores Eldenari por Khorvath.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Material | Metal de retenção de padrões de mana |
| Tradição técnica | Oficinas dracônicas e Eldenari |



Ofício e transmissão. O trabalho do aerólito aproximou Artífices da Brasa, cidades Eldenari e elfos altos. Conservar um padrão exigia material, preparação e técnica. Oficinas e aprendizagem tinham tanta importância quanto a presença do metal.



Ampliação dos usos. Placas de comparação, encaixes de instrumentos e pequenos suportes de repetição eram usados nas oficinas da I Era. Uma peça conserva o padrão que foi preparada para receber; alterações do suporte ou desgaste podem prejudicar a leitura. A manutenção exige reconhecer o trabalho anterior.



Valor e dependência. A distribuição das oficinas criava desigualdades entre centros capazes de fabricar componentes e comunidades dependentes de reparo externo. A Guerra dos Reparos levou esse problema aos canais e às instalações de mana. O domínio do ofício se tornou uma fonte de autoridade e um motivo para defender a abertura de registros.



Eshara, a lua esmeralda



Lua acompanhada pelos Custódios da Esmeralda e sede do refúgio dos dragões sobreviventes.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Tipo | Lua |
| Refúgio | Área preparada com mana; acesso consumido |



Ciclos e vigílias. Os Custódios acompanhavam os ciclos de Eshara a partir de santuários nas montanhas. O astro oferecia uma referência de longa duração para observações que atravessavam vidas de povos mortais. Sua cor e seu nome integraram tradições e nomes pessoais.



Refúgio preparado. O refúgio de mana foi preparado pelos Custódios antes da retirada final. Após a ruptura do Selo, Vaelthar e Varesh conduziram para lá os dragões sobreviventes que conseguiram atravessar. A passagem consumiu os últimos instrumentos capazes de manter o caminho.



Isolamento e memória. O abrigo reunia terraços de repouso e pontos de distribuição da mana. Essas condições dizem respeito ao abrigo preparado, sem estabelecer que toda a lua possua o mesmo ambiente. O isolamento limitou os contatos com Virtude. Eshara Vel recebeu o nome do astro, e a Gema recebeu o nome da maga.



A Margem



Região de Eomundus sobrecarregada pelo desvio de experiências incompatíveis durante a operação do Selo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Plano | Eomundus |
| Condição | Sobrecarga produzida pelo Selo |



Acúmulo e reconhecimento. Serath Namar e Maeriel Sorn identificaram que a estabilidade de Virtude transferia experiências incompatíveis para uma região de Eomundus. Fragmentos de acontecimentos, consciências interrompidas e possibilidades acumulavam-se num espaço incapaz de comportar a carga.



O Inconcluso. Respostas persistentes e adaptativas surgiram no acúmulo e receberam o nome de Inconcluso. As hipóteses de presença velária e organização emergente da memória permaneceram em disputa. O reconhecimento de respostas observáveis não resolveu sua origem ou a extensão de sua identidade.



Custo do encerramento. As tentativas de reduzir a carga exigiam coordenar instalações e aceitar efeitos em comunidades diferentes. A guerra destruiu a confiança necessária a essa operação. A ruptura atingiu os Eldenari ligados à rede; cálculos de retorno tardio da energia integram uma das explicações da Grande Punição.



O Inconcluso



Nome dado às respostas adaptativas identificadas na Margem durante a crise do Selo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Natureza | Identidade e origem não demonstradas |
| Manifestação | Respostas persistentes e adaptativas na Margem |



Uma resposta que persiste. Serath descreveu respostas que se adaptavam às intervenções. Avar recebeu mensagens que pareciam completar seus pensamentos. O comportamento sugeria uma busca de continuidade pela incorporação de experiências ao alcance do acúmulo.



Hipóteses e limites. Caerion considerou uma entidade velária; outros pesquisadores propuseram uma organização emergente de memórias e possibilidades. As hipóteses explicavam aspectos diferentes sem resolver a origem. Os registros conservam observáveis as respostas e em aberto a natureza de quem respondia.



A última campanha. Avar percebeu a ação através dos instrumentos do Selo e preparou o desligamento com Serath. Na ruptura, a pesquisadora usou o Pergaminho para impedir que o Inconcluso atravessasse inteiramente. O episódio relaciona a falha técnica às condições políticas que impediram coordenação e verificação.



Leth Avar



Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Eomundus |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. A perda de estabilidade atingia nomes, formas e a vida em comum. Cidades mudavam segundo os sonhos de seus habitantes, tornando a memória uma condição incerta de orientação. A crise preparou a decisão de procurar corpos e caminhos mais estáveis em Virtude.



Vida e práticas locais. Havia pátios de reconhecimento onde famílias repetiam nomes, vínculos e tarefas antes de uma partida. A prática ajudava a reunir pessoas quando uma casa já não conservava a aparência da véspera. Objetos de uso cotidiano podiam servir como apoio de reconhecimento, sem garantir que uma identidade fosse restaurada.



Memória e situação histórica. A Travessia das Sete Portas reduziu o acesso à região. O temor de Arieth de não encontrar ninguém a quem devolver o caminho expressa a perda envolvida no acolhimento. Leth Avar pertence ao Entrelaço e não recebe coordenadas no mapa material de 788.



Elar-Tao



Localidade fluvial Eldenari atingida pela repetição de uma estação de cheia.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Virtude; geografia antiga |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. A crise comprometeu armazenamento, cultivo e memória. Alimentos apodreceram e tornaram a amadurecer, enquanto crianças preservavam recordações de pais ainda vivos. O fenômeno ampliou a pressão por uma intervenção capaz de proteger comunidades inteiras.



Vida e práticas locais. A ampliação situa a Retirada dos Armazéns em 6337 e o Pacto das Barcas em 6338. Veska Tor organizou transportes e reivindicou lugar para pessoas, sementes e mantimentos nos barcos disputados pelas casas de estudo. As marcas de carga conservaram a diferença entre o que fora prometido e o que efetivamente saiu.



Memória e situação histórica. O exemplo da localidade integrou o debate anterior à organização dos Primeiros Magos. Sua posição exata na geografia anterior à catástrofe não é convertida em coordenadas atuais. O artigo acompanha a relação entre rio, trabalho e pesquisa, preservando os limites da reconstrução.



Vel-Samar



Centro de arquivo cujo incêndio marcou a abertura da Guerra das Nove Vigílias.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Virtude; geografia antiga |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. Após Maeriel retirar Serath da prisão, Zhaurak atacou a escolta e incendiou o Arquivo de Vel-Samar. Emissários protegidos pelo Pacto morreram. O ataque tornou material a ruptura das garantias que sustentavam a observação conjunta do Selo.



Vida e práticas locais. O arquivo mantinha depósitos separados para cópias de pactos e registros de circulação. Essa divisão procurava impedir que a perda de um salão eliminasse todas as versões. O incêndio destruiu pessoas e cadeias de autenticação; documentos preservados fora da cidade passaram a carregar parte de sua memória.



Memória e situação histórica. A reconstrução de rotas e responsabilidades depende de cópias incompletas. A posição de Vel-Samar na geografia antiga continua aproximada e não recebe um marcador atual. O destino do arquivo ajuda a explicar por que versões posteriores da guerra divergem sobre decisões tomadas pelos mesmos aliados.



Uldar



Cidade neutra cuja destruição levou Khorvath a romper com Zhaurak na quinta campanha.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Virtude; geografia antiga |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. As Cinzas de Uldar são situadas aproximadamente em 6397. A destruição atingiu uma cidade que não participava da guerra como combatente. Para Khorvath, a violência tornou insustentável a aliança com Zhaurak.



Vida e práticas locais. Uldar conservava oficinas de manutenção que atendiam a comunidades rivais mediante acordos locais. A neutralidade protegia trabalho, acesso a peças e uma população que dependia da passagem de mercadorias. Esse papel explica sua importância para além do número de combatentes.



Memória e situação histórica. Após o ataque, Saelith retirou sacerdotes da bênção às tropas e perdeu o cargo. A cidade tornou-se referência nos debates sobre a proteção de lugares neutros. Seu traçado e sua posição exata anteriores à catástrofe permanecem fora da precisão do atlas de 788.



Refúgio de Eshara



Abrigo de mana preparado pelos Custódios na lua esmeralda e alcançado pelos dragões após a ruptura.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Lua Eshara |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. A preparação antecedia a retirada final e estava ligada às vigílias dos Custódios da Esmeralda. Vaelthar e Varesh conduziram para lá sobreviventes, enquanto alguns ovos permaneceram ocultos em Virtude. A passagem consumiu os instrumentos que a mantinham aberta.



Vida e práticas locais. O abrigo reunia terraços rochosos de repouso e pequenos reservatórios de distribuição da mana. O abrigo precisava sustentar dragões feridos e longos períodos de torpor. A experiência de cada sobrevivente passou a depender de recursos que já não podiam ser repostos por uma travessia regular.



Memória e situação histórica. O isolamento impede acompanhar sua história com a mesma continuidade dos registros materiais de Virtude. O refúgio é uma localidade lunar, sem marcador no mapa dos reinos de 788. Sua existência histórica no relato da retirada não estabelece uma rota disponível para viajantes posteriores.



Paralisação dos Nove Pátios



Trabalhadores interromperam serviços após a suspensão de pagamentos para financiar pesquisa.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era; anterior ao Selo, ano indeterminado |
| Precisão | Indeterminada |



Contexto. Barqueiros, carpinteiros e responsáveis pela conservação sustentavam os observatórios. Quando a Casa das Medidas suspendeu pagamentos, a pesquisa continuou a consumir trabalho e alimento de equipes sem garantia de manutenção. A paralisação levou essa dependência aos pátios das instituições.



Decisões e consequências. O acordo obrigou os estudiosos a reservar mantimentos para os trabalhadores. Que essas reservas fossem indicadas antes da abertura de novas frentes de serviço, permitindo comparar recursos prometidos e equipes convocadas. A medida criou uma proteção sujeita a disputa e fiscalização.



Memória e continuidade. A organização dos Primeiros Magos herdou instituições que já haviam enfrentado contestação do próprio trabalho de apoio. A conquista raramente recebia o destaque dado a novos encantamentos, embora ajudasse a manter cidades e oficinas funcionando. A data anual permanece indeterminada.



Guerra dos Reparos



Conflito entre cidades Eldenari pelo controle da manutenção dos canais e dos suportes de mana.

| Campo | Definição |
| --- | --- |
| Referência temporal | 6262–6266 da I Era |
| Precisão | Data adotada no Registro 2.7 |



Contexto. Equipes de reparo passaram a ser impedidas de atravessar instalações de cidades rivais. Patrocinadores cobravam exclusividade pelo trabalho em canais e suportes de aerólito, enquanto comunidades a jusante arcavam com interrupções e falta de água. Em 6262, apreensões de ferramentas e comboios deram lugar a escaramuças nas passagens.



Decisões e consequências. A guerra concentrou-se em diques, oficinas e depósitos. Cidades procuravam preservar a irrigação dos próprios campos sem conceder acesso aos rivais. Inspeções técnicas eram tratadas como reconhecimento militar. A Casa das Medidas dividiu-se entre defender a circulação das equipes e proteger contratos de seus membros.



Memória e continuidade. A arbitragem de 6266 previu inspeções acompanhadas por representantes de mais de uma cidade e voz das comunidades afetadas. A solução encerrou as campanhas locais, mas preservou desigualdades de fabricação e acesso. Mais tarde, os impasses de inspeção do Selo retomariam tensões dessa história, em escala muito maior.



Retirada dos Armazéns de Elar-Tao



Evacuação que tornou pública a disputa por barcos entre casas de estudo e famílias atingidas pelos Descompassos.

| Campo | Definição |
| --- | --- |
| Referência temporal | 6337 da I Era |
| Precisão | Data adotada no Registro 2.7 |



Contexto. Durante a cheia repetida de Elar-Tao, as condições dos armazéns deixaram de acompanhar uma sucessão previsível. Mantimentos conservados num dia apareciam deteriorados no seguinte, e instrumentos recebiam prioridade de transporte sobre alimentos. Tripulações precisavam decidir o que levar antes que o acesso aos cais mudasse outra vez.



Decisões e consequências. Veska Tor reuniu marcas de carga e testemunhos de famílias impedidas de embarcar. Organizou travessias com pessoas, sementes e provisões, enfrentando ordens de reservar barcos a caixas de pesquisa. O episódio deu visibilidade a uma decisão tratada até então como assunto exclusivo dos proprietários e estudiosos.



Memória e continuidade. O transporte emergencial preservou parte dos recursos da comunidade e deixou conflitos que seriam negociados no Pacto das Barcas. A retirada não encerrou os Descompassos. Sua memória ajudou a explicar tanto a urgência de Avar quanto a resistência a soluções que desconsiderassem quem suportava seus riscos.



Pacto das Barcas



Acordo de Elar-Tao que incluiu tripulações nas decisões de transporte durante emergências.

| Campo | Definição |
| --- | --- |
| Referência temporal | 6338 da I Era |
| Precisão | Data adotada no Registro 2.7 |



Contexto. O pacto foi negociado após a Retirada dos Armazéns. Famílias exigiam conservar espaço para pessoas e alimentos, enquanto casas de estudo argumentavam que a perda de instrumentos comprometeria uma solução duradoura. Os barqueiros contestaram a exigência de executar escolhas das quais não participavam.



Decisões e consequências. Veska Tor defendeu a reserva explícita de capacidade para passageiros, sementes e provisões. O acordo reconheceu representantes das tripulações na distribuição emergencial de cargas e exigiu registrar alterações de prioridade. Propriedade da carga e autoridade sobre a vida dos embarcados passaram a ser discutidas separadamente.



Memória e continuidade. O pacto se aplicava aos serviços negociados em Elar-Tao e não criou uma autoridade universal sobre todos os rios. Sua experiência circulou nas redes de manutenção. Quando a interrupção do Selo voltou a colocar comunidades diante de riscos impostos por outros, esses registros ofereceram linguagem para reivindicar participação.



Batalha das Pontes de Asmarith



Serath impediu uma inundação que atingiria famílias partidárias de Avar durante a segunda campanha.

| Campo | Definição |
| --- | --- |
| Referência temporal | c. 6394 da I Era; segunda campanha |
| Precisão | Aproximada |



Contexto. Os aliados podiam abrir comportas para deter uma força inimiga, mas a água atingiria campos habitados por famílias favoráveis a Avar. O controle da passagem militar se confundia com o controle da irrigação. Serath se opôs à abertura, tratando a vida dos moradores como uma responsabilidade anterior à vantagem de campanha.



Decisões e consequências. A decisão preservou agricultores e também permitiu que uma força adversária escapasse e voltasse a combater. Parte dos companheiros criticou Serath. Ela sustentou que a proteção das pessoas não podia depender da previsão do que fariam depois aqueles que fossem poupados.



Memória e continuidade. Relatos das margens conservaram a memória das comportas fechadas ao lado das listas de perdas militares. Essa diferença ajuda a compreender como uma mesma batalha podia ser lembrada como falha estratégica ou salvamento. Sua posição relativa na segunda campanha é mais segura que o ano retrospectivo.



Cinzas de Uldar



Destruição de uma cidade neutra que rompeu alianças entre dragões e sacerdotes.

| Campo | Definição |
| --- | --- |
| Referência temporal | c. 6397 da I Era; quinta campanha |
| Precisão | Aproximada |



Contexto. O ataque de Zhaurak atingiu Uldar na quinta campanha. Sua neutralidade era sustentada por acordos locais e pelo serviço de oficinas a comunidades de posições diferentes. A destruição eliminou pessoas, abrigo e parte da capacidade de manutenção que atravessava as frentes da guerra.



Decisões e consequências. Khorvath rompeu com Zhaurak. Saelith Vora retirou sacerdotes da bênção às tropas, perdeu o cargo e passou a conduzir refugiados. As decisões mostram que as antigas alianças se modificaram durante o conflito, sob o peso de consequências que seus participantes haviam ajudado a tornar possíveis.



Memória e continuidade. A tradição conserva Uldar como referência nas reivindicações de proteção de lugares de serviço comum. A história não apaga o apoio anterior de Khorvath ao Selo nem a aproximação de Saelith com o Zênite. A mudança de posição ganha sentido justamente por atravessar responsabilidades anteriores.



Os vinte e três dias de Xeo Taoju



Intervalo de ocupação e socorro entre a ruptura do Selo e a Grande Punição.

| Campo | Definição |
| --- | --- |
| Referência temporal | Fim da I Era, após a ruptura do Selo |
| Precisão | Aproximada |



Contexto. Após a perda de unidade do Selo, os vencedores ocuparam Xeo Taoju por vinte e três dias. O desaparecimento de muitos Eldenari, a destruição das instalações e a dispersão de refugiados tornavam incerta a dimensão da vitória. A correspondência entre instrumentos e lugares também havia mudado.



Decisões e consequências. Foram organizados pátios de reunião para procurar parentes e pequenos depósitos de água e grãos sob supervisão local. Listas de sobreviventes circulavam com lacunas, correções e nomes repetidos. O esforço de reconstruir vínculos era acompanhado por disputas sobre quem podia ocupar armazéns e conservar documentos.



Memória e continuidade. No vigésimo quarto dia da ocupação, o céu se incendiou. A Grande Punição atingiu cidades e caminhos, encerrando o horizonte da I Era. A numeração convencional próxima de 6400 não acrescenta um ano inteiro entre ruptura e catástrofe; os vinte e três dias constituem o intervalo narrado.



Guerra das Nove Vigílias



Sete campanhas nas quais a disputa pelo Selo desfez alianças entre cidades Eldenari, elfos altos e dragões.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Campanhas | Sete, c. 6393–6399 |
| Encerramento da era | c. 6400; ruptura e Punição separadas pelo intervalo narrado |



Abertura e coalizões. Por volta de 6393, Maeriel retirou Serath da prisão. Zhaurak atacou a escolta e incendiou Vel-Samar, matando emissários protegidos. A resposta élfica reuniu cidades contrárias ao Selo; outras apoiaram Avar por convicção, dependência ou medo da perda de proteção. As coalizões nunca coincidiram perfeitamente com a origem dos povos.



Guerra sobre a vida comum. Fortalezas e observatórios foram tomados e retomados. A Casa das Medidas dividiu seus mapas entre ofensivas e proteção de localidades. O Círculo das Testemunhas conservou trocas de prisioneiros sob suspeita dos dois lados. Nas Pontes de Asmarith, impedir uma inundação significou renunciar a uma vantagem militar.



Rupturas dentro da guerra. As Cinzas de Uldar afastaram Khorvath de Zhaurak e levaram Saelith a retirar bênçãos. Vaelthar entrou no conflito após sofrer um ataque ao proteger uma delegação. A destruição de ninhos produziu perdas futuras que tornaram a reconciliação especialmente difícil entre os dragões.



A última campanha. No cerco de Xeo Taoju, em torno de 6399, Avar e Serath prepararam um desligamento. A mensagem de Maeriel a Caerion foi retida, e o mago ordenou uma intervenção sem conhecer o novo acordo. O ataque de Zhaurak coincidiu com as outras ações. A ruptura foi seguida por vinte e três dias de ocupação e pela Grande Punição, no limite convencional próximo de 6400.



Damar Esh



Sacerdote Eldenari que defendia a interpretação divina das aparições antigas.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era; antes da chegada dos elfos altos |
| Povo | Eldenari |
| Atuação | Sacerdócio e interpretação das manifestações |
| Traço distintivo | Barba branca curta e faixa azul profunda |
| Vestimenta | Linho marfim |
| Posição | Defesa do caráter divino das aparições |
| Condição histórica | Figura histórica da I Era |



A autoridade das maravilhas. Damar Esh construiu uma escola influente ao tratar as manifestações e aparições como divinas. O crescimento dos relatos de Descompassos abriu espaço para sua interpretação. Sua posição oferecia uma explicação que comunidades e sacerdotes podiam incorporar à vida ritual.



A disputa com Nimea. Nimea Aral sustentava que produzir maravilhas não impedia uma entidade de mentir. O desacordo envolvia a maneira de recolher depoimentos e reconhecer autoridade. A influência de Damar não torna seus seguidores um grupo uniforme: havia pessoas em busca de proteção e dirigentes interessados em validar decisões.



Referência individual. Pele castanha escura, cabeça alongada, barba branca muito curta, olhos escuros e lábios cheios. Usava túnica de linho marfim com faixa azul profunda e uma placa de cerâmica ritual. A data anual de sua atuação continua indeterminada, anterior à chegada dos elfos altos nos relatos utilizados.



Hared Sen



Príncipe que procurou apoiar seu governo de Xeo Taoju no prestígio de uma criança oracular.

| Campo | Definição |
| --- | --- |
| Referência temporal | c. 3400 da I Era; data disputada |
| Povo | Eldenari |
| Atuação | Príncipe de Xeo Taoju |
| Traço distintivo | Sinal escuro ao lado da boca |
| Vestimenta | Linho azul escuro; placas douradas |
| Legado | Disputa política pelo reconhecimento oracular |
| Condição histórica | Figura histórica da I Era |



Governo e oráculo. Apoiado por sacerdotes, Hared tentou transformar a criança em fundamento de autoridade política. O caso é situado por alguns estudiosos perto de 3400 da I Era, com diferenças de gerações entre cópias. O recorte conserva essa aproximação.



A mudança de acusação. Quando a criança contrariou o príncipe, o santuário foi fechado sob suspeita de influência velária. Documentos posteriores apontaram fraude dos tutores sem resolver a origem das visões. Uma tradição afirma que a criança sobreviveu com outro nome, mas seu destino permanece desconhecido.



Aparência e memória. Hared tinha rosto cheio, olhos pequenos muito próximos, cabelo preto liso penteado para trás e um sinal escuro ao lado da boca. Vestia linho azul escuro e colar de pequenas placas douradas. Seu caso reforçou entre comunidades cautelosas a preocupação de proteger a pessoa antes de reconhecer um título religioso.



Doutrina dos Sinais Cruzados



Práticas de confronto de testemunhos destinadas a dificultar fraudes no reconhecimento de Arautos.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era e recepção posterior |
| Tipo | Prática de avaliação de reconhecimento |



Testemunhos e biografia. Templos reuniam depoimentos independentes, previsões registradas antes dos resultados e informações da vida anterior ao reconhecimento. Uma cura, uma visão ou a capacidade de ouvir mortos exigiam interpretação em conjunto com a trajetória da pessoa.



Limites da verificação. A prática reduzia facilidades para fraude sem produzir uma certificação absoluta. Responsáveis podiam ser corrompidos, pressionados ou enganados. O reconhecimento de Ilyra e Oren teve formas de sustentação diferentes, enquanto a condição reivindicada por Avar permaneceu disputada.



Proteção e poder. O caso de Hared Sen expôs o uso político do título e da acusação de falsidade. Recomendava-se preservar depoimentos contrários no mesmo conjunto dos favoráveis. Essa defesa da comparação aproximava a doutrina dos métodos do Círculo das Testemunhas, sem fundir suas instituições.



Pacto das Três Testemunhas



Acordo de observação entre Eldenari, dragões e elfos altos para autorizar o experimento do Selo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Partes | Eldenari, dragões e elfos altos |
| Objeto | Observação e condições da operação do Selo |



Autorização e contrapartidas. O pacto reuniu observação de três tradições e exigiu medições independentes e intervalos para verificar a resposta das regiões. Caerion pediu um desligamento gradual diante de efeitos inesperados. Zhaurak condicionou sua adesão ao reconhecimento de seus domínios, enquanto Vaelthar permaneceu contrário à tentativa.



A pressa da operação. Avar e patrocinadores abreviaram etapas diante da fome. A decisão foi registrada em ata, inclusive com apoio de estudiosos que depois afirmariam tê-la combatido. A ampliação distingue a preservação de uma ata da capacidade real de suas testemunhas de suspender o trabalho.



Garantias destruídas. O ataque de Zhaurak matou emissários protegidos em Vel-Samar. Durante a guerra, os mecanismos de verificação foram desfeitos por suspeitas, bloqueios e violência. A demora da mensagem levada por Naeris Ul no final do conflito expõe a perda das condições que antes permitiam um acordo comum.



Incidente de Thar-Sen



Passagem de quarenta peregrinos que regressaram dezessete anos depois de viverem uma única noite.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era, antes da chegada dos elfos altos; ano indeterminado |
| Intervalo relatado | Uma noite para os peregrinos; dezessete anos fora |



A procissão. Uma procissão seguiu luzes até um templo ausente na véspera. Quarenta peregrinos retornaram dezessete anos depois, afirmando ter vivido uma noite. Os efeitos foram diferentes: alguns trouxeram ensinamentos úteis e outros regressaram aterrorizados.



Vidas desencontradas. Os relatos acompanham o problema das obrigações interrompidas: famílias haviam reorganizado moradia e trabalho, enquanto os retornados ainda se orientavam pela noite da partida. O reconhecimento de uma pessoa não recompunha automaticamente o lugar que ela ocupara dezessete anos antes.



O nome de Veyr. Veyr foi associado ao episódio sem conclusão segura. A comparação de testemunhos integrou disputas sobre a autoridade das manifestações. O incidente antecede a chegada dos elfos altos nos relatos preservados, mas não recebe um ano inventado para preencher a cronologia.



Noite dos Dois Amanheceres



Descompasso observado por trabalhadores que passaram a discordar sobre os sete dias anteriores.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era, antes da chegada dos elfos altos; ano indeterminado |
| Efeito relatado | Divergências sobre sete dias de experiência |



Dois sóis por um instante. Trabalhadores do Observatório relataram dois sóis surgindo brevemente. Depois, suas lembranças dos sete dias anteriores deixaram de concordar. O episódio afetou tanto o reconhecimento de experiências quanto a confiança nos registros usados para ordenar a vida do trabalho.



Registros e cobrança. A comparação de marcas de serviço, entregas e relatos domésticos como parte da investigação. A disputa sobre qual semana fora vivida também se tornava disputa sobre serviços e pagamentos. A conservação de versões diferentes permitia estudar o fenômeno sem exigir que todos aceitassem uma lembrança única.



Interpretações. O episódio pertence aos relatos anteriores à chegada dos elfos altos. Damar Esh e a tradição crítica ligada a Nimea oferecem formas diferentes de pensar as manifestações. A data anual e a causa exata continuam abertas; a aparição não estabelece a existência permanente de um segundo sol.



Primeira Era



Dragões, eldenari, elfos altos e os conflitos em torno da criação e da magia.

| Campo | Definição |
| --- | --- |
| Duração estimada | Cerca de 6.400 anos, com margem de incerteza |
| Referência temporal | I Era; limite convencional c. 6400 |



Um horizonte de longa duração. A Primeira Era reúne cerca de 6.400 anos na cronologia retrospectiva, com margem de incerteza. Seu início convencional acompanha a memória dos primeiros dragões. A criação dos planos pertence a um horizonte anterior à contagem, enquanto a formação de cidades, instituições e conflitos compõe a história da era.



Dragões e cidades Eldenari. Assentamentos Eldenari aparecem por volta de 2100 nos vales do Taoju e Asmarith. Xeo Taoju se consolida aproximadamente em 2550. Ilyra Seneth e Oren Namar ligam astronomia e memória a instituições duradouras. As relações com dragões variavam entre aprendizado, proteção e tributo; Conclaves e alianças não formavam um governo único.



Pesquisa e disputa social. Talena Ors e Edris Vaun investigaram transmissão e permanência material. A Casa das Medidas disputava calendários e cobrança, enquanto o Círculo das Testemunhas conservava relatos divergentes. A Paralisação dos Nove Pátios e, mais tarde, a Guerra dos Reparos mostram a importância política do trabalho que sustentava as pesquisas.



Chegada dos elfos altos. A Travessia das Sete Portas, por volta de 5990, trouxe Aelthir de Leth Avar. Arieth Ilvar conduziu refugiados que assumiram corpos materiais e se tornaram elfos altos. Caerion fundou a Ordem em Aethravel aproximadamente em 6035. O intercâmbio com os Eldenari aproximou técnicas e expôs divergências sobre intervenção nos planos.



A aposta no Selo. A crise de Elar-Tao ampliou a urgência de uma solução. Por volta de 6360, os Primeiros Magos organizaram sua disciplina comum. O Selo foi ativado em torno de 6384 e trouxe nove anos de estabilidade. O desvio para a Margem tornou essa conquista uma questão de responsabilidade diante de experiências e comunidades que suportavam seu custo.



Guerra, ruptura e catástrofe. As sete campanhas das Nove Vigílias são colocadas em torno de 6393–6399. A ruptura dispersou as peças do Selo, atingiu os Eldenari ligados à rede e foi seguida pela retirada dos dragões para Eshara. Após vinte e três dias de ocupação de Xeo Taoju, veio a Grande Punição. Suas causas permanecem discutidas, incluindo hipóteses sobre energia acumulada, Velários e tradições setentrionais.



Grande Punição



O acontecimento enigmático que encerra a Primeira Era.

| Campo | Definição |
| --- | --- |
| Período | Fim da Primeira Era |
| Certeza | Causas e extensão discutidas |
| Referência temporal | Fim da I Era, c. 6400 |
| Intervalo | Após vinte e três dias de ocupação de Xeo Taoju |



O fim de uma sequência. A Grande Punição veio após a ruptura do Selo e os vinte e três dias de ocupação de Xeo Taoju. No vigésimo quarto dia, o céu se incendiou. Fogo atingiu cidades, cinzas cobriram os céus e caminhos entre os planos foram rompidos. Caerion morreu protegendo refugiados que seguiam para o norte.



Hipóteses preservadas. Os cálculos de Serath apontavam um retorno tardio de energia acumulada na Margem. Relatos de luzes organizadas sugeriam intervenção velária; sacerdotes transmitiram proibições divinas de reabrir passagens. A tradição de Bergen associaria os Thul Verenari ao acontecimento, mas os fragmentos da I Era não demonstram essa participação ou a identidade do povo mencionado.



Terras e sobreviventes. Nenhum mapa confiável preservou todo o mundo anterior. Mudanças de costas, altitude e passagem entre terras são discutidas com evidências fragmentárias. Muitos Eldenari já haviam sido atingidos pela ruptura; sobrevivências dispersas e misturas posteriores tornam inadequada a ideia de desaparecimento absoluto do povo.



Um limite histórico. O fim da era é arredondado para cerca de 6400. A reconstrução conserva a ordem entre ruptura, ocupação e catástrofe sem introduzir um ano adicional entre elas. A ampliação do Registro permite detalhar consequências e experiências sem encerrar as hipóteses de causa numa explicação única.



Thul Verenari



Lenda setentrional de um povo antigo cuja existência permanece controversa.

| Campo | Definição |
| --- | --- |
| Estado | Existência não confirmada |
| Região atribuída | Extremo norte |
| Referência temporal | Tradição posterior sobre a I Era; relatos até a III Era |



Uma tradição do extremo norte. Os Thul Verenari são descritos em relatos setentrionais como seres de cerca de um metro a um metro e vinte, pele clara azulada e grandes olhos negros amendoados. Atribuem-lhes afinidade com magia e tecnologia. Sua existência permanece controversa e sua localização é colocada além da região da Ordem.



A relação atribuída à I Era. A tradição de Bergen os aproxima da Grande Punição. As fontes antigas não demonstram se o nome correspondia a um povo existente, a uma classificação posterior de aparições ou à reunião de relatos distintos. O vínculo com a catástrofe pertence à história dessa atribuição.



Ampliação das leituras. Este recorte distingue uma leitura de intervenção, que procura ação organizada nas luzes, e uma leitura de transmissão, que investiga quando o nome passou a acompanhar o relato. São linhas de investigação dentro do universo, não descobertas de identidade. Elas permitem novas expedições e disputas sem transformar uma imagem em prova.



Aparência nos relatos. A ilustração representa a tradição descritiva: figura pequena, pele azulada e grandes olhos negros. Vestimentas e objeto geométrico são recursos interpretativos, sem confirmar material, função ou participação na Punição. A convicção de um viajante integra seu testemunho, com o valor e os limites desse contexto.



Ordem dos Magos



Instituição setentrional de estudo, proteção e disputa pelo controle do conhecimento.

| Campo | Definição |
| --- | --- |
| Centro | Aethravel |
| Leitura | Anais da Ordem dos Magos |



Responsabilidades pelo isolamento. A abertura da Ordem a pesquisadores de diferentes povos convive com disputas de acesso e autoridade. O isolamento de 731 exige distinguir autorização, execução, alteração de registros, conhecimento posterior e contestação.



Na história política de Vaelen Endor. Selvar II é imperador entre 2078 e 2149 da II Era. A correspondência de Tessia com a Mesa dos Instrumentos Reservados é datada em 2093, sem fixar a descoberta da Agulha. O processo de Leva Senn na Controvérsia do Espelho é situado em 2101. Aren Voss recusa condenação por possibilidade futura.



A fundação e seus dilemas. Caerion Thalas fundou a Ordem por volta de 6035 em Aethravel, sob proteção de Arieth Ilvar. A Mesa das Portas podia suspender trabalhos e exigir registros. Maeriel Sorn sustentou o intercâmbio com os Eldenari. A crise do Selo expôs o limite de procedimentos que dependiam de confiança entre comunidades em guerra.



Aethravel



Sede setentrional da Ordem dos Magos, com estatuto e regras de acesso próprios.

| Campo | Definição |
| --- | --- |
| Reino / estado | Reino de Aelvar |
| Instituição | Ordem dos Magos |
| Acesso | Controlado |



Descrição. Aethravel reúne sede e instalações de estudo da Ordem dos Magos. Situa-se no extremo norte do circuito de Aelvar, mas não deve ser tratada como outra denominação da corte de Emvale.



Descrição. O caminho de abastecimento atravessa setor chamado Serra das Duas Vigílias. Frio, queda de pedra e condição dos animais afetam o percurso, mesmo quando um mapa geral não desenha cada curva.



Descrição. A Ordem admite não elfos como membros plenos desde a Carta das Mãos Abertas de 326. Isso não converte laboratórios e arquivos reservados em visitas públicas; referência, formação e autorização continuam relevantes.



Aethravel na I Era. A fortaleza recebeu a associação fundada por Caerion Thalas. Seus trabalhos reuniam cuidadores de passagens, conservadores de instrumentos e estudiosos. A Mesa das Portas examinava intervenções e podia exigir suspensão. O fim da era destruiu parte dos registros e dos instrumentos que sustentavam esses procedimentos.



Xeo Taoju



Capital de Quinder, onde patrimônio Eldenari, restauro e vida urbana compartilham as margens do Taoju.

| Campo | Definição |
| --- | --- |
| Reino / estado | Quinder |
| Função | Capital |
| Rio | Taoju |
| Patrimônio | Zigurate, observatório, Pátio das Nove Sombras |
| Irrigação | Conselho das Duas Margens, 734 |



Capital junto ao Taoju. Xeo Taoju é a capital de Quinder e sede de Selyra Naereth. Bairros, hortas e oficinas se articulam com a irrigação do Taoju. Essa faixa cultivada pertence a uma região que passa de campos verdes a terrenos mais secos: água, sombra e áreas expostas fazem parte da paisagem da capital.



Patrimônio e restauro. O Zigurate das Nove Vigílias, o Observatório de Ilyra, o Pátio das Nove Sombras e os Arcos de Saelith marcam a visita. Construções Eldenari receberam reparos e usos posteriores. A Oficina dos Arcos, reconhecida em 758, protege fragmentos inscritos e disputa contratos de conservação. Humanos e elfos negros colaboram e concorrem pelas encomendas.



A cidade em 788. O Conselho das Duas Margens recebe pedidos de irrigação, mas seus assentos favorecem grandes propriedades, santuários e corporações. Moradores e trabalhadores mantêm a cidade além do circuito monumental. Nerion Fales divulga seus atrativos no Guia dos Viajantes de 788; o elogio à sua beleza é opinião de viajante. A tradição da décima sombra no Pátio permanece não confirmada.



Cotidiano. Nas margens do Taoju, o restauro do patrimônio Eldenari convive com a circulação diária. Oficinas e trabalhos de conservação ocupam a mesma cidade por onde passam moradores, cargas e viajantes.



Patrimônio em uso. A Oficina dos Arcos, reconhecida em 758 da III Era, denuncia a incorporação de fragmentos inscritos em casas privadas. Seus membros também disputam contratos de restauro, num debate em que conservação e remuneração se cruzam.



A cidade antes da Grande Punição. A consolidação urbana é situada por volta de 2550 da I Era. Calendários, irrigação e oficinas sustentavam a vida Eldenari. O Zigurate recebeu o Selo em torno de 6384 e tornou-se centro da guerra final. Após a ruptura, a cidade viveu vinte e três dias de ocupação e socorro antes da Grande Punição.



Samarith



Cidade de Quinder, sede da Torre do Grande Pombo e ponto de encontro dos caminhos.

| Campo | Definição |
| --- | --- |
| Reino | Quinder |
| Instituição | Torre do Grande Pombo |
| Rio | Asmarith |
| Marco histórico | Acordo das Lâmpadas, 2429 da II Era |
| Grande Pombo | Calven IX |



A cidade e o Asmarith. Samarith ocupa o corredor do Asmarith, em Quinder. Cais, hospedarias e mercados acompanham barcas e peregrinos. A água sustenta trechos cultivados num reino que passa de campos verdes a áreas mais secas. A Torre Sagrada é sua grande referência religiosa; moradores humanos e élficos negros compartilham trabalho, vizinhança e cerimônias.



A sede do Grande Pombo. Em 1398 da II Era, o Concílio das Sete Portas estabeleceu a comunhão dos Sete. Após a conquista, o Acordo das Lâmpadas de 2429 preservou o Grande Pombo, arquivos, santuários e peregrinação. A Torre conservou competências religiosas e privilégios dentro da soberania de Quinder, reunindo interesses de culto, comércio e reconhecimento político.



Samarith no início de 788. Calven IX ocupa o posto de Grande Pombo, enquanto Selyra Naereth mantém a autoridade civil. Procissões, taxas e escoltas exigem negociação. Ayak oferece conexão com o norte pela navegação e pelas estradas. Fora do recinto principal, O Pombo Torto, de Lethra Noll, recebe peregrinos em quartos comuns e cubículos familiares, com refeições, notícias e regras próprias.



Cotidiano. Viajantes que chegam pelos caminhos de Quinder encontram pouso no Pombo Torto, a estalagem de Lethra Noll. A Torre do Grande Pombo dá outra referência a quem circula pela cidade.



A cidade em dia de cerimônia. O movimento da Torre muda a circulação no bairro. Perto dali, o Pombo Torto oferece quartos comuns e cubículos para famílias. O Guia registra caldo de grãos com cebola tostada e pão achatado nos dias de maior movimento.



Memória e estudos da I Era. A Casa dos Nomes fundada por Oren Namar e as galerias da futura Torre Sagrada vinculavam Samarith ao cuidado da memória. Na Câmara do Limiar, observar os mortos não autorizava retê-los. Cópias dos Cadernos de Permanência de Talena Ors circularam na cidade e conservaram diferenças entre observação e comentário.



Ilyra Seneth



Astrônoma Eldenari da I Era, associada ao primeiro calendário celeste preservado em Xeo Taoju.

| Campo | Definição |
| --- | --- |
| Nome | Ilyra Seneth |
| Povo | Eldenari |
| Período | I Era |
| Atuação | Astronomia e calendário celeste |
| Marco documentado | c. 2700 da I Era |
| Lugar associado | Xeo Taoju; Observatório de Ilyra |
| Referência temporal | I Era |



Astronomia em Xeo Taoju. Por volta de 2700 da I Era, Ilyra Seneth estabeleceu em Xeo Taoju o primeiro calendário celeste preservado. Seus registros reuniam previsões corretas, erros e correções. O Observatório de Ilyra conserva sua tradição de tornar o céu compreensível pela observação e pelo cálculo.



O reconhecimento de Asterion. Entre os Eldenari, Ilyra foi reconhecida como a primeira Arauto de Asterion. Seus seguidores atribuíram a muitos cálculos uma infalibilidade que ela própria contestava. A avaliação desse reconhecimento variou entre escolas e tradições.



Traços e temperamento. Tinha cabelos muito claros, olhos de cores ligeiramente diferentes e o hábito de bater três vezes na mesa antes de aceitar um cálculo. Sua curiosidade vinha acompanhada de impaciência com ritmos de trabalho mais lentos. Avar Seneth, especialista em tempo entre os Primeiros Magos, era seu descendente.



Um legado disputado. Avar Seneth, seu descendente, procurou dar ao mundo um calendário que jamais falhasse. Sua ambição retomou a autoridade do conhecimento celeste, mas também expôs os riscos de transformar a correção de um cálculo numa missão exclusiva. A pesquisa de Ilyra havia preservado erros e revisões que seguidores por vezes apagavam ao tratá-la como profetisa infalível.



Oren Namar



Sacerdote Eldenari da I Era e fundador da Casa dos Nomes, em Samarith.

| Campo | Definição |
| --- | --- |
| Nome | Oren Namar |
| Povo | Eldenari |
| Período | I Era |
| Atuação | Sacerdócio e preservação dos nomes |
| Marco documentado | c. 2760 da I Era |
| Lugar associado | Casa dos Nomes, em Samarith |
| Referência temporal | I Era |



A Casa dos Nomes. Oren Namar fundou por volta de 2760 da I Era a Casa dos Nomes, em Samarith. Ali se registravam os mortos para conservar seus nomes na memória coletiva. A guarda dos arquivos tornou-se parte de seu compromisso religioso e público.



Memória e autoridade. Reconhecido como Arauto de Nereth, Oren recusou a ordem de um rei para apagar dos registros os nomes de uma cidade rebelada. Morreu defendendo seus arquivos. Documentos de cidades rivais preservaram relatos sobre experiências associadas a ele.



Traços e temperamento. Era largo de ombros e usava uma túnica remendada mesmo quando passou a administrar recursos. Guardava pequenas placas com os nomes que receava esquecer. Afável nas conversas privadas, tornava-se inflexível diante de pedidos de exceção aos registros.



A continuidade dos nomes. A defesa dos arquivos confrontou a ordem de apagar uma cidade rebelada. Oren morreu protegendo os registros. A Casa dos Nomes permaneceu ligada ao princípio de que poder político não concede direito de eliminar uma vida da memória.

## 40. Implantação da Primeira Era e manutenção da base



Wikia 0.32: 615 artigos, 182 marcos e 83 vínculos. O lote acrescenta 55 artigos, amplia os artigos centrais e conecta os dez marcos já existentes da I Era. O recorte tem entrada própria e referências ao Registro.



Lugares de Eomundus, localidades de posição antiga incerta e o refúgio lunar não recebem coordenadas no mapa material de 788. Retratos e composições são referências em fantasia estilizada, com diferenças individuais. A representação dos Thul Verenari ilustra a tradição, sem confirmar sua existência.

## 41. Thul Verenari: verdade do cenário e limites do conhecimento

Decisão autoral vigente e precedência

Esta decisão substitui o limite de confirmação de RC-P08 e a parte correspondente de RC-IE00. Os capítulos anteriores são conservados como histórico de edição. Afirmações de desconhecimento nos relatos históricos passam a descrever o conhecimento dos habitantes, sem negar os fatos autorais definidos aqui.

### RC-TV01 — Existência real e conhecimento dos povos

Os Thul Verenari existem. Os habitantes de Virtude, em geral, conhecem apenas lendas e testemunhos ocasionais ou rejeitam sua existência. O conhecimento de personagens não deve ser confundido com a verdade autoral do cenário.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV02 — Aparência vigente

Anatomia semelhante a um gray, com pele azulada, cabeça lisa sem cabelo, sem orelhas e sem nariz, boca pequena e olhos grandes, negros e amendoados. Preserva-se o porte de cerca de um metro a um metro e vinte. A imagem é substituída para retirar os traços élficos anteriores.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV03 — Origem, tecnologia e telepatia

Origem desconhecida, possivelmente exterior ao planeta de Virtude; a procedência extraplanetária não é confirmada como fato. Tecnologia extremamente avançada e comunicação telepática são fatos. Tecnologia, tempo e mente são interesses centrais.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV04 — Autoria e motivação da Grande Punição

A Grande Punição foi um ataque nuclear dos Thul Verenari contra Virtude. Eles avaliaram que o caos do planeta chamava a atenção de inteligências extraterrestres ameaçadoras e decidiram intervir. Essa avaliação é a motivação deles; identidade das inteligências e ameaça iminente não ficam automaticamente comprovadas. A população de Virtude desconhece a natureza nuclear, a autoria e a intenção do ataque. Não se alteram a ruptura anterior do Selo e o intervalo de vinte e três dias de ocupação.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV05 — Vigilância setentrional

Após a intervenção, os Thul se ocultaram no extremo norte do planeta para vigiar sua evolução, os Descompassos e os temas tecnológicos, temporais e mentais. São pragmáticos e discretos. Sua presença real não atribui automaticamente a eles todos os fenômenos do norte.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.

### RC-TV06 — Bergen, rumores e acesso à informação

Luzes e aparições ocasionais sustentam relatos em Bergen. Os habitantes não conhecem realmente esse povo. A localização precisa das instalações não é publicada no atlas como conhecimento corrente. Os artigos distinguem informações públicas no mundo e verdade reservada do cenário.

Base: Definição explícita do autor nesta atualização, 8 de novembro de 2026.

Aplicação: Registro Geral, wikia e próximas edições pertinentes; sem atribuir este conhecimento a personagens ou reinos.



Thul Verenari — dossiê vigente



Existência e conhecimento. Os Thul Verenari existem no universo de Virtude. Para os habitantes do planeta, porém, seu nome pertence sobretudo às lendas do extremo norte. Há quem o associe a aparições e luzes, quem rejeite sua existência e quem reúna relatos sem conseguir identificar com segurança os observados. A verdade do cenário e o conhecimento de suas sociedades são distintos.



Aparência. São pequenos e esguios, com cabeça relativamente grande, pele azulada e superfície craniana lisa. Não possuem cabelo, orelhas ou nariz. A boca é pequena e os olhos negros são grandes e amendoados.



Relatos do norte. Em Bergen, observadores ocasionalmente veem luzes ou encontram uma figura que não sabem explicar. Aparições isoladas podem se transformar em histórias contraditórias ao circular entre postos, viajantes e comunidades. Esses testemunhos compõem o conhecimento local; não fornecem aos reinos uma compreensão da organização, dos recursos ou dos propósitos desse povo.



Origem e comunicação. A origem dos Thul Verenari permanece desconhecida. A possibilidade de terem vindo de fora do planeta de Virtude integra o cânone como hipótese, sem planeta natal ou percurso de chegada estabelecidos. Possuem tecnologia extremamente avançada e comunicam-se por telepatia. Seu interesse se concentra especialmente em tecnologia, tempo e mente.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.



Vigilância no extremo norte. Depois da intervenção, os Thul Verenari se ocultaram no extremo norte do planeta para acompanhar o andamento de Virtude, os Descompassos e as transformações tecnológicas, temporais e mentais. São extremamente discretos e pragmáticos. Luzes e aparições ocasionais em Bergen podem decorrer dessa presença, sem que todo incidente setentrional seja automaticamente atribuído a eles. A localização precisa de suas instalações não é conhecida pelos povos do cenário.



Grande Punição — dossiê vigente



O fim de uma sequência. A Grande Punição veio após a ruptura do Selo e os vinte e três dias de ocupação de Xeo Taoju. No vigésimo quarto dia, o céu se incendiou. Fogo atingiu cidades, cinzas cobriram os céus e caminhos entre os planos foram rompidos. Caerion morreu protegendo refugiados que seguiam para o norte.



Interpretações dos sobreviventes. Os cálculos de Serath apontavam um retorno tardio de energia acumulada na Margem. Relatos de luzes organizadas sugeriam intervenção velária; sacerdotes transmitiram proibições divinas de reabrir passagens. A tradição de Bergen associaria os Thul Verenari ao acontecimento. Essas interpretações integram a história dos povos de Virtude, que desconhecem a natureza e os responsáveis pela catástrofe.



Terras e sobreviventes. Nenhum mapa confiável preservou todo o mundo anterior. Mudanças de costas, altitude e passagem entre terras são discutidas com evidências fragmentárias. Muitos Eldenari já haviam sido atingidos pela ruptura; sobrevivências dispersas e misturas posteriores tornam inadequada a ideia de desaparecimento absoluto do povo.



O limite entre as eras. O fim da era é arredondado para cerca de 6400. A sequência conserva a ruptura do Selo, os vinte e três dias de ocupação de Xeo Taoju e, no vigésimo quarto dia, a Grande Punição. O desconhecimento dos sobreviventes sobre a catástrofe não significa ausência de uma causa definida na verdade do cenário.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.

## 42. Aelthir: aparência, vínculos e travessia

Continuidade de aparência

Os Aelthir possuem aparência idêntica à dos elfos altos, apenas mais etérea em Eomundus. Esta definição orienta toda descrição e ilustração atual ou futura, preservando traços pessoais antes e depois da Travessia.

### RC-AT01 — Aparência dos Aelthir

Mesma anatomia, fisionomia, proporções, orelhas e diversidade individual dos elfos altos. Em Eomundus, apenas presença mais etérea por luz e contornos. A Travessia não troca os traços da pessoa. Não inventar órgãos, mudar cor de pele ou cabelo na Travessia, impor transparência ou deformar a anatomia para marcar a diferença.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT02 — Reconhecimento e vida comunitária

Casas de Reconhecimento conservam relações, objetos e testemunhos, sem impor uma identidade por versão única. As práticas e os conflitos descritos nos dossiês são adotados.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT03 — Guardiões das Soleiras

Cuidadores de passagens, buscas e condições de retorno; função comunitária que não equivale a comando automático da futura Ordem.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT04 — Ilenya Saar

Nova personagem Aelthir, depois elfa alta, com a mesma fisionomia nos dois planos. Cuida de vínculos, participa da Travessia e das negociações de acolhimento. Traços, roupas e trajetória do dossiê são vigentes.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT05 — Acordo das Soleiras

Novo marco situado em c. 6002 da I Era, entre postos de Aston e Emvale, com participação de Arieth e Ilenya. Organiza mantimentos, turnos e transmissão de informações sem condicionar ajuda a obediência presumida.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-AT06 — Adaptação material

A mudança é ontológica e envolve perda de capacidades e adaptação à vida material, preservando a aparência de elfo alto. Práticas de passagem, acolhimento e consentimento contribuem para o ambiente de formação da Ordem sem fundir todas as instituições.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.



Aelthir e a chegada dos elfos altos



Comunidades de Eomundus com a mesma aparência dos elfos altos, envoltas em uma presença mais etérea; sua travessia para Virtude marcou a origem material desse povo.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Origem | Eomundus |
| Travessia | c. 5990 da I Era |
| Transformação | Corpos materiais; origem dos elfos altos |
| Longevidade material | Muitos séculos; raramente mais de um milênio |
| Aparência | Idêntica à dos elfos altos; presença mais etérea em Eomundus |
| Travessia e fisionomia | Mesmos traços individuais antes e depois |
| Comunidades | Casas de Reconhecimento e redes de passagem |



Aparência e presença. Os Aelthir têm a mesma aparência dos elfos altos: rostos, corpos, proporções e orelhas pontudas seguem a mesma anatomia. Conservam diferenças individuais de pele, olhos, cabelo, idade e constituição. Em Eomundus, sua presença é mais etérea, percebida na luz suave e na menor firmeza dos contornos. Ao atravessar, a pessoa conserva sua fisionomia; a materialidade se torna mais estável.



Comunidades de Leth Avar. A vida em Leth Avar se organizava em torno de vínculos reconhecidos por outras pessoas. Casas, jardins e oficinas podiam mudar de acesso quando a memória de seus habitantes se alterava. As Casas de Reconhecimento conservavam objetos de uso, relatos de convivência e tarefas compartilhadas. O valor de um objeto estava na relação que ajudava a recordar: uma peça modesta podia sustentar mais reconhecimento que uma joia sem história.



Nomes e responsabilidade. Um nome era acompanhado por relações: quem o utilizava, quem o havia recebido e quais compromissos lembrava. Em períodos de instabilidade, os Aelthir evitavam decidir uma identidade por um único testemunho. Quem não reconhecia a própria casa podia ser acolhido sem precisar aceitar imediatamente a versão dos demais. Essa cautela protegia pessoas e também produzia disputas quando famílias reivindicavam vínculos incompatíveis.



Guardiões e caminhos. Os Guardiões das Soleiras cuidavam das condições de passagem. Reuniam relatos sobre acessos, procuravam viajantes e mantinham contato entre comunidades. Seu conhecimento dependia de observar mudanças e escutar quem atravessara. Um caminho conhecido podia deixar de servir à mesma família, tornando a promessa de retorno uma responsabilidade difícil de garantir.



A crise e a Travessia. Quando Leth Avar perdeu estabilidade, nomes e cidades deixaram de conservar relações suficientes para uma vida comum. Arieth Ilvar manteve postos de acolhimento e conduziu refugiados durante a Travessia das Sete Portas, situada por volta de 5990 da I Era. Ilenya Saar acompanhou famílias e conservou objetos de reconhecimento. A chegada a Virtude exigiu aprender a conviver com corpos e recursos de duração mais estável.



A vida material. Alimento, abrigo e conservação de ferramentas passaram a exigir estoques, trabalho e acordos que continuavam válidos mesmo quando alguém esquecia sua origem. O Acordo das Soleiras, por volta de 6002, organizou práticas de acolhimento entre postos de Aston e Emvale. O cuidado deixou de depender apenas da lembrança pessoal de um protetor. Algumas famílias receavam que registrar vínculos em nome do acolhimento também permitisse controlar seus movimentos.



O que atravessou com eles. A transformação em elfos altos preservou pessoas, divergências e parte das práticas das comunidades anteriores. Cuidar de passagens, conservar testemunhos e perguntar quem podia consentir numa intervenção contribuíram para o ambiente em que Caerion Thalas fundou a Ordem. A experiência do exílio continuou a ser lembrada de modos diferentes: como sobrevivência, perda de capacidades ou aceitação de uma existência menos vulnerável às mudanças do Entrelaço.



Leth Avar



Região de Eomundus de onde partiram os refugiados conduzidos por Arieth Ilvar.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Localização histórica | Eomundus |
| Tipo | Localidade histórica da I Era |
| Precisão cartográfica | Sem posição no atlas material de 788 |



Paisagem e função. A perda de estabilidade atingia nomes, formas e a vida em comum. Cidades mudavam segundo os sonhos de seus habitantes, tornando a memória uma condição incerta de orientação. A crise preparou a decisão de procurar corpos e caminhos mais estáveis em Virtude.



Vida e práticas locais. Havia pátios de reconhecimento onde famílias repetiam nomes, vínculos e tarefas antes de uma partida. A prática ajudava a reunir pessoas quando uma casa já não conservava a aparência da véspera. Objetos de uso cotidiano podiam servir como apoio de reconhecimento, sem garantir que uma identidade fosse restaurada.



Memória e situação histórica. A Travessia das Sete Portas reduziu o acesso à região. O temor de Arieth de não encontrar ninguém a quem devolver o caminho expressa a perda envolvida no acolhimento. Leth Avar pertence ao Entrelaço e não recebe coordenadas no mapa material de 788.



Continuidade das pessoas. As mudanças de Leth Avar atingiam vínculos, acessos e reconhecimento. Os Aelthir conservavam a aparência de elfos altos, com presença mais etérea no Entrelaço. A perda de estabilidade do lugar não estabelece uma anatomia diferente para seus habitantes.



Pátios e cuidado. As Casas de Reconhecimento e os Guardiões das Soleiras mantinham formas complementares de cuidado. Nos pátios, conservavam-se objetos e relatos de convivência; nos caminhos, comparavam-se condições de acesso e retorno. Durante a crise, a decisão de abandonar uma rota podia separar famílias e dividir responsáveis pelo mesmo abrigo.



Arieth Ilvar



Regente da Travessia na história da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Aelthir; depois elfa alta |
| Atuação | Regente da Travessia |
| Sinais distintivos | Rosto longo, pele escura e mecha branca trançada junto à têmpora. |
| Período | I Era |
| Vínculos principais | Aelthir e a chegada dos elfos altos; Leth Avar |
| Condição histórica | Figura histórica da I Era |



Trajetória e escolhas. Conduziu famílias de Leth Avar durante a Travessia das Sete Portas. Sua autoridade era marcada pela responsabilidade diante das pessoas que aceitara guiar. Manteve postos de acolhimento quando parte do conselho defendia fechar a passagem.



Vínculos e conflitos. A chegada exigiu organizar abrigo e recursos para corpos sujeitos a novas condições materiais. A regente protegeu a associação de estudiosos que Caerion transformaria na Ordem dos Magos. O consentimento nas intervenções e a conservação de conhecimentos de passagem pertencem a esse contexto.



Legado e limites do registro. Temia receber uma delegação que exigisse o retorno e descobrir que não restara ninguém a quem devolver o caminho. As fontes não estabelecem aqui uma data de morte ou uma sucessão completa de sua regência.



Aparência e presença. Arieth conservou rosto longo, pele escura e mecha branca trançada junto à têmpora antes e depois da Travessia. Em Eomundus, sua presença era mais etérea; em Virtude, seus traços de elfa alta adquiriram a firmeza da condição material.



Casas de Reconhecimento



Redes comunitárias de Leth Avar dedicadas ao acolhimento e à continuidade de vínculos.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Origem | Leth Avar, em Eomundus |
| Atividade | Acolhimento e conservação de vínculos |



Casas e convivência. Uma Casa de Reconhecimento reunia pessoas que se responsabilizavam por recordar umas às outras. Podia ocupar um pátio, uma oficina ou mais de uma residência. Ferramentas, tecidos reparados e refeições compartilhadas ajudavam a reconhecer uma história de convivência, mesmo quando o acesso a uma casa havia mudado.



Conservar sem impor. As Casas comparavam testemunhos e admitiam que um vínculo permanecesse em dúvida. Ilenya Saar defendia acolher a pessoa antes de resolver todas as versões sobre sua identidade. Essa prática enfrentava resistência de famílias que temiam perder autoridade ou responsabilidades antigas. A lembrança de um compromisso podia sustentar auxílio e também servir para exigir obediência.



Depois da partida. Na Travessia, pequenos conjuntos de objetos acompanharam famílias e grupos de cuidado. A perda de uma caixa podia significar a perda de uma forma de provar reconhecimento, sem apagar automaticamente a pessoa. Em Virtude, práticas das Casas foram adaptadas a listas, estoques e turnos de acolhimento. A solidariedade precisava funcionar entre pessoas que ainda não possuíam lembranças comuns.



Guardiões das Soleiras



Cuidadores Aelthir dos caminhos, encontros e condições de retorno entre comunidades.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Origem | Comunidades Aelthir |
| Atividade | Passagens, buscas e retorno |



Um trabalho de passagem. Os Guardiões das Soleiras observavam como acessos respondiam a nomes, compromissos e mudanças da paisagem de Eomundus. Acompanhavam viajantes e recolhiam descrições de encontros. Sua atividade exigia conhecer pessoas e relações de vizinhança, além de reconhecer arcos e caminhos.



Dever e conflito. Um guardião podia manter uma rota aberta para receber alguém atrasado e, com isso, expor outras famílias a uma passagem instável. Durante a crise de Leth Avar, grupos discordaram sobre quando interromper buscas e concentrar recursos na saída. Arieth Ilvar apoiou a continuidade dos postos de acolhimento diante de pressões para fechá-los.



Memória em Virtude. Alguns cuidadores continuaram a trabalhar nos postos da chegada, onde uma soleira passou a designar também a entrada de um abrigo. Seus conhecimentos sobre passagens contribuíram para práticas de conservação adotadas mais tarde por estudiosos da Ordem. A antiga função não conferia automaticamente cargo ou autoridade na nova instituição.



Ilenya Saar



Cuidadora Aelthir das Casas de Reconhecimento, participante da Travessia e do acolhimento nas comunidades setentrionais.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era |
| Povo | Aelthir; depois elfa alta |
| Atuação | Acolhimento e memória comunitária |
| Marco | Travessia; acordo de c. 6002 da I Era |
| Sinais distintivos | Cabelo negro encaracolado; olhos castanhos caídos |
| Vestimenta | Linho verde-musgo; cordão de objetos familiares |
| Aparência | Mesma anatomia e fisionomia de elfa alta; presença etérea em Eomundus |



Um rosto a reconhecer. Ilenya tinha pele castanha acobreada, rosto oval de queixo arredondado, nariz curto e olhos castanhos ligeiramente caídos. Prendia os cabelos negros muito encaracolados com uma tira de tecido. Usava linho verde-musgo e um cordão com pequenos objetos de família. Em Eomundus, a luz de seus contornos era mais etérea; depois da Travessia, sua fisionomia permaneceu a mesma.



As caixas de convivência. Trabalhou nas Casas de Reconhecimento conservando pequenos conjuntos de utensílios e relatos familiares. Sua paciência tinha um limite claro: contrariava dirigentes que tratavam uma versão discordante como prova de que o acolhido perdera o direito de falar por si. A convicção lhe custou apoio de algumas famílias que antes lhe confiavam objetos e crianças.



A Travessia e os postos. Acompanhou refugiados de Leth Avar e colaborou com o acolhimento protegido por Arieth. Em Virtude, precisou aceitar que objetos preservados já não resolviam falta de comida ou abrigo. Defendeu turnos de cuidado e reservas identificadas antes de novas promessas de acolhimento. Participou das negociações do Acordo das Soleiras por volta de 6002 da I Era.



Uma memória em disputa. Ilenya procurou conservar relatos de quem desejara atravessar e de quem partira por não ter outra saída. A diferença incomodava narrativas que apresentavam a mudança como escolha unânime. Seus registros transmitiram perdas e ressentimentos junto aos exemplos de cooperação, deixando a história da chegada aberta à experiência de pessoas diferentes.



Acordo das Soleiras



Acordo de acolhimento das comunidades da chegada, situado por volta de 6002 da I Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | c. 6002 da I Era |
| Precisão | Aproximada |
| Tipo | Acolhimento e acordo comunitário |



Depois da saída. As comunidades que receberam os Aelthir em Aston e Emvale enfrentaram demandas de abrigo e alimento que se prolongavam além de promessas pessoais. Famílias reconhecidas numa rota podiam chegar a um posto onde ninguém conhecia seus vínculos. O cuidado precisava acompanhar pessoas através de uma rede de abrigos.



O que foi acordado. O Acordo das Soleiras articulou reservas de mantimentos, turnos de cuidado e transmissão de informações entre postos. Ilenya Saar participou das negociações sob a proteção política de Arieth Ilvar. O acesso ao auxílio não dependia de o acolhido aceitar imediatamente uma genealogia ou um compromisso alegado por outros.



Os limites do registro. Listas facilitavam o trabalho, mas criavam poder sobre a circulação e as obrigações dos refugiados. Parte dos negociadores receava que a hospitalidade se transformasse numa dívida permanente. O acordo procurou manter separadas a responsabilidade de alimentar alguém e a decisão sobre a quem essa pessoa devia obediência. Suas práticas influenciaram debates posteriores sobre consentimento e conservação de testemunhos.



Eomundus



O Entrelaço: plano em que possibilidades ganham contorno, duração e identidade.

| Campo | Definição |
| --- | --- |
| Natureza do registro | Definição do cenário |
| Referência temporal | Antes da contagem das eras |



O Entrelaço. Eomundus aproxima possibilidades e vidas delimitadas. Seus caminhos respondem a expectativas, lembranças e vínculos, de modo que duas viagens pelo mesmo arco podem levar a encontros diferentes. Orientar-se envolve compreender relações de acesso, além de reconhecer formas da paisagem.



Povos e presenças. Os Aelthir, ancestrais dos elfos, os Namar que acompanham consciências após a morte e os Velários pertencem às descrições do Entrelaço. Ishrael, Oruven e Veyr, o Cortês, aparecem em narrativas de transformação, passagem e hospitalidade. A identidade por trás desses nomes varia entre os relatos.



Lugares e compromissos. A Enseada das Promessas e o Patamar dos Ecos exemplificam lugares cuja travessia depende da história do viajante. Seus mapas registram condições de encontro e retorno. Um compromisso reconhecido por outros pode orientar o caminho por mais tempo que uma intenção passageira, e a entrada em Eomundus nunca equivale a controle completo sobre sua paisagem.



Os Aelthir do Entrelaço. Os Aelthir possuíam os mesmos traços físicos dos elfos altos, com uma presença mais etérea em Eomundus. A ligação entre identidade e paisagem atravessava sua vida comunitária, sem eliminar diferenças pessoais. As Casas de Reconhecimento de Leth Avar e os Guardiões das Soleiras cuidavam de relações que a instabilidade tornaria difíceis de conservar.



Travessia das Sete Portas



Os Aelthir chegaram de Eomundus durante a Travessia das Sete Portas, situada por aproximação em 5990 da I Era.

| Campo | Definição |
| --- | --- |
| Data | c. 5990 da I Era |
| Era | I Era |
| Tipo | História e sociedade |
| Precisão | Aproximada |
| Natureza da evidência | Reconstrução aproximada |
| Referência temporal | c. 5990 da I Era |



Data e natureza do registro. Concordância de relatos élficos. A indicação “c.” conserva uma datação aproximada; ela não deve ser convertida em aniversário ou dia exato.



Relato e contexto. Os Aelthir chegaram de Eomundus durante a Travessia das Sete Portas, situada por aproximação em 5990 da I Era. Uma região do Entrelaço, chamada Leth Avar, vinha perdendo estabilidade: pessoas esqueciam o próprio nome e cidades inteiras mudavam de forma conforme os sonhos de quem dormia nelas. A regente Arieth Ilvar conduziu os refugiados até Virtude. Ao aceitarem corpos materiais, perderam parte de suas antigas capacidades e tornaram-se os elfos altos.



Percursos e consequências. Este marco se relaciona a Aelthir e a chegada dos elfos altos, Arieth Ilvar, Leth Avar. Os artigos associados apresentam as trajetórias, decisões e efeitos locais do acontecimento.



A fisionomia na Travessia. A passagem para Virtude preservou rostos, proporções e traços individuais dos Aelthir. A aparência era a dos elfos altos; a condição mais etérea de Eomundus cedeu lugar à estabilidade material. O acolhimento posterior é tratado no Acordo das Soleiras.

## 43. Thul Verenari: vigilância, telepatia e registros



As decisões RC-TV01–06 permanecem vigentes. Existência, aparência azulada sem nariz ou orelhas, tecnologia avançada, telepatia, ataque nuclear e vigilância não são revogados. Origem possivelmente extraplanetária e avaliação de ameaça continuam com os limites já definidos.

### RC-TV07 — Organização da Vigília e discrição

Vigília Setentrional e Ecos Silenciosos passam a designar a organização de observação e seus procedimentos. Há funções diferentes, registros de responsabilidade e divergências sobre intervenção. Não se fixa capital, governo completo ou origem exterior ao planeta.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV08 — Telepatia e individualidade

Comunicação telepática permite compartilhar impressões, intenções e imagens em graus distintos, sem estabelecer mente coletiva única ou controle automático dos habitantes. Os observadores conservam interpretações próprias.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV09 — Janelas de Escuta

Instrumentos comparam registros de Descompassos, mana, artefatos e instalações. Tecnologia avançada não elimina a necessidade de interpretar contexto e diferenciar perda de observação de ausência do fenômeno.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.

### RC-TV10 — Causa reservada do episódio de 785

O campo sem gelo e o ruído sob a neve registrados por Haldren Vesk em 785 da III Era decorreram da retirada de um captador Thul. Não houve reconhecimento de sua natureza pelo capitão; a inspeção posterior continuou sem objeto ou prova disponível a Bergen. Não se generaliza essa causa a todo incidente setentrional.

Base: Decisão autoral e expansão autorizada, 8 de novembro de 2026; Registro 2.8 preservado.

Aplicação: Registro Geral, textos e imagens da wikia e futuras gerações de imagens ou obras pertinentes.



Thul Verenari



Povo de tecnologia extremamente avançada, associado às lendas do extremo norte e às luzes observadas em Bergen.

| Campo | Definição |
| --- | --- |
| Existência | Confirmada no cânone do cenário |
| Conhecimento dos habitantes | Lenda, relatos fragmentários ou descrença |
| Aparência | Pele azulada; sem cabelo, orelhas ou nariz; boca pequena; olhos grandes amendoados |
| Porte | Cerca de um metro a um metro e vinte |
| Região dos relatos | Extremo norte de Virtude |
| Referência temporal | I Era à III Era |



Origem e comunicação. A origem dos Thul Verenari permanece desconhecida. A possibilidade de terem vindo de fora do planeta de Virtude integra o cânone como hipótese, sem planeta natal ou percurso de chegada estabelecidos. Possuem tecnologia extremamente avançada e comunicam-se por telepatia. Seu interesse se concentra especialmente em tecnologia, tempo e mente.



A decisão sobre Virtude. Durante a crise do fim da I Era, os Thul Verenari avaliaram que o caos de Virtude atraía a atenção de inteligências extraterrestres ameaçadoras. Essa avaliação orientou sua decisão de intervir. Sua atitude foi pragmática e devastadora: consideraram a destruição uma medida de contenção. A identidade dessas inteligências e a realidade de uma ameaça iminente continuam sem definição independente da avaliação dos Thul.



A Grande Punição. Os Thul Verenari realizaram um ataque nuclear contra Virtude. Esse ataque é a Grande Punição que encerra a I Era. Os habitantes não reconhecem a natureza nuclear da catástrofe nem conhecem seus responsáveis e objetivos. Suas tradições de castigo divino, intervenção velária e retorno de energia preservam interpretações históricas dos sobreviventes.



Vigilância no extremo norte. Depois da intervenção, os Thul Verenari se ocultaram no extremo norte do planeta para acompanhar o andamento de Virtude, os Descompassos e as transformações tecnológicas, temporais e mentais. São extremamente discretos e pragmáticos. Luzes e aparições ocasionais em Bergen podem decorrer dessa presença, sem que todo incidente setentrional seja automaticamente atribuído a eles. A localização precisa de suas instalações não é conhecida pelos povos do cenário.



Comunicar sem formar uma mente única. A telepatia dos Thul permite transmitir intenções, imagens e impressões com níveis diferentes de detalhe. Ela não apaga a experiência individual: uma observação partilhada pode produzir conclusões incompatíveis. A Vigília registra quem percebeu uma variação, quem a comparou com os arquivos e quem propôs agir. Assim, a interpretação de um observador continua identificável mesmo depois de partilhada com os demais.



A vida nos postos. A Vigília Setentrional mantém postos pequenos e especializados, associados à conservação das Janelas de Escuta. A rocha e as condições do extremo norte ajudam a ocultar instalações, sem que haja um reino conhecido ou uma capital divulgada. Manutenção, comparação de registros e períodos de recolhimento alternam-se no trabalho. Os nomes das funções usados neste artigo traduzem seu papel; não estabelecem uma língua falada pelos Thul.



Decisões depois da Punição. As consequências da intervenção acompanham as discussões entre observadores. Alguns veem sinais de risco que exigiriam contenção antecipada; outros receiam transformar toda mudança de Virtude numa repetição da crise antiga. Ecos Silenciosos procura conservar nos registros os efeitos das atividades Thul. A hipótese de origem exterior ao planeta permanece aberta, e a avaliação de ameaças extraterrestres continua sendo uma motivação deles, sem confirmar uma inteligência específica.



Vigília Setentrional



A organização da observação Thul, descrita nas informações reservadas do cenário.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era à III Era |
| Conhecimento dos povos | Estas informações não são conhecidas em Virtude |
| Natureza | Organização ou prática Thul de observação |



Postos e responsabilidades. A Vigília Setentrional reúne postos de observação, conservação de instrumentos e comparação de registros dos Thul Verenari. A designação identifica o trabalho mantido no extremo norte após a Grande Punição; não define o governo completo do povo ou seu lugar de origem. Equipes mantêm funções distintas para observação, interpretação e preservação dos dados.



Discordar em silêncio. A comunicação telepática permite partilhar observações e intenções sem fala, mas não elimina interpretações individuais. Observadores divergem sobre o peso de uma anomalia e sobre o custo de uma intervenção. A Vigília conserva essas diferenças em seus registros. Uma lembrança compartilhada pode transmitir a urgência sentida por alguém sem obrigar os demais a adotar sua conclusão.



Proteção e responsabilidade. Alguns defendem contenção antecipada diante de sinais que consideram semelhantes aos do fim da I Era. Outros sustentam que a presença dos próprios Thul precisa entrar no cálculo das perturbações observadas. A memória da Grande Punição é tratada como decisão cujas consequências continuam exigindo vigilância. O pragmatismo não torna suas avaliações infalíveis nem suas prioridades idênticas.



Janelas de Escuta



Instrumentos de observação dos Thul, conhecidos apenas nas informações reservadas do cenário.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era à III Era |
| Conhecimento dos povos | Estas informações não são conhecidas em Virtude |
| Natureza | Organização ou prática Thul de observação |



O que os postos acompanham. Os Thul chamam de Janelas de Escuta os conjuntos de instrumentos que comparam sinais de diferentes regiões e momentos. Acompanham Descompassos, alterações na circulação da mana e a atividade de artefatos e instalações. O registro de uma variação indica algo a investigar; a interpretação depende da comparação com outras observações.



Registros e ausência. A tecnologia avançada conserva sequências de sinais que os calendários locais não descrevem da mesma maneira. Uma janela pode mostrar continuidade onde um observador relata interrupção, ou recolher sinais cujo contexto cultural lhe escapa. A Vigília diferencia perda de observação, silêncio de uma região e ausência efetiva de um fenômeno. Os Thul continuam interessados no que os habitantes percebem, mesmo quando não tornam sua presença conhecida.



O episódio de 785. O campo sem gelo e o ruído sob a neve registrados por Haldren Vesk em 785 da III Era corresponderam à retirada de um captador Thul. A atividade deixou vestígios breves antes de o posto remover o equipamento. O capitão não reconheceu sua causa, e a inspeção posterior não encontrou objeto. O episódio permanece um relato inconclusivo para Bergen, embora sua causa seja definida no cânone reservado.



Ecos Silenciosos



Práticas de discrição e avaliação de contato adotadas pela vigilância Thul.

| Campo | Definição |
| --- | --- |
| Referência temporal | I Era à III Era |
| Conhecimento dos povos | Estas informações não são conhecidas em Virtude |
| Natureza | Organização ou prática Thul de observação |



A observação também modifica. Ecos Silenciosos é a designação dos procedimentos pelos quais a Vigília procura distinguir um fenômeno acompanhado dos efeitos da própria presença. Instrumentos, deslocamentos e contatos podem deixar vestígios que os povos de Virtude interpretarão por suas tradições. Um observador deve registrar quando sua atividade passou a integrar aquilo que está estudando.



Telepatia e encontro. Nos encontros entre Thul, impressões e intenções podem ser partilhadas sem palavras, com diferentes graus de detalhe. Essa comunicação sustenta cooperação e desacordo. O uso de telepatia não torna todos os indivíduos uma consciência única e não estabelece controle automático da mente de quem vive em Virtude. Contatos deliberados exigem uma decisão que os observadores não tratam como simples extensão de uma conversa entre si.



O custo de intervir. A discrição é uma prioridade, mas não uma promessa de nunca agir. A Grande Punição demonstra o alcance de uma decisão que os Thul consideraram necessária. Debates atuais examinam quando interromper uma observação, recolher equipamento ou propor uma medida de contenção. A origem dos observadores e a identidade das inteligências que temem continuam em aberto.



Incidente registrado no posto de Haldren



O capitão Haldren Vesk, humano largo de rosto e quase sem sobrancelhas depois de uma queimadura, patrulha um posto antigo e chama os Thul Verenari de histórias para assustar recrutas.

| Campo | Definição |
| --- | --- |
| Data | 785 da III Era |
| Era | III Era |
| Tipo | História e sociedade |
| Precisão | Datada |
| Natureza da evidência | Registro histórico adotado |
| Referência temporal | 785 da III Era |



O captador retirado. Em 785 da III Era, a retirada de um captador de uma Janela de Escuta deixou o campo sem gelo e o som sob a neve anotados por Haldren Vesk. Os Thul recolheram o equipamento antes da inspeção seguinte. A definição da causa no cânone reservado não transforma o relato do capitão em prova disponível aos reinos nem estabelece contato dele com a Vigília.

## 44. Implantação dos dossiês Aelthir e Thul Verenari



Wikia 0.34: 622 artigos, 183 marcos e 84 vínculos. Sete artigos novos, cinco ilustrações e ampliação dos dossiês centrais. Referências e ligações entre artigos conservam a distinção entre história conhecida e informações reservadas.



A regra de aparência dos Aelthir foi consolidada em política visual e aplicada às cenas da Travessia, de Leth Avar, aos grupos e à nova personagem. As imagens antigas permanecem apenas como histórico de arquivo quando substituídas nos artigos atuais.

## 45. Aelthir — aparência astral e continuidade visual

Referência visual vigente

Pele clara e cabelos loiros são a referência dos Aelthir, com anatomia de elfos altos e presença mais astral e etérea. Este capítulo prevalece sobre as descrições anteriores de suas cores de pele e cabelo. Os capítulos anteriores ficam preservados como histórico editorial.

### RC-AT07 — Aelthir e a aparência astral

Mesma anatomia, proporções e orelhas pontudas dos elfos altos, com pele clara e cabelos loiros em tons de mel, ouro pálido e platinado. A presença Aelthir em Eomundus é astral e etérea: luminosidade perolada, reflexos de estrelas e contornos envolvidos por luz prateada. Rostos permanecem legíveis e individualizados. A Travessia estabiliza a materialidade sem mudar pele, cabelo ou fisionomia.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.

### RC-AT08 — Arieth e Ilenya

Arieth Ilvar: pele clara, rosto longo, cabelos loiro-pálidos e mecha branca trançada à têmpora. Ilenya Saar: pele clara, cabelos loiro-mel muito encaracolados, rosto oval, queixo arredondado, nariz curto e olhos castanhos ligeiramente caídos. Vestimentas, trajetórias e vínculos permanecem. As descrições anteriores de pele escura ou castanha e cabelo negro dessas duas personagens são substituídas por esta decisão.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.

### RC-AT09 — Continuidade entre cenas

A anatomia e os traços individuais se mantêm antes e depois da Travessia. Eomundus acentua luminosidade perolada e presença astral; Virtude estabiliza os corpos materiais. A direção de arte continua fantasia estilizada, com rostos, penteados, expressões e gestos variados. Cinco imagens foram revistas: comunidade Aelthir, Leth Avar, Travessia das Sete Portas, Ilenya Saar e Arieth Ilvar.

Base: Decisão autoral de 8 de novembro de 2026.

Aplicação: Descrições, fichas, imagens e futuras representações dos Aelthir.

## 46. Povos de Virtude — origens, linhagens e formação histórica

Origem, linhagem e sociedade

A ampliação autorizada consolida ligações de ascendência Eldenari sem apagar origens Aelthir, Olek e dracônicas. A diferenciação ocorre em gerações; povo, aparência, profissão, moralidade e Estado não são equivalentes.

### RC-PO01 — A Dispersão dos Vales e a ancestralidade material

O intervalo c. 3600–5800 da I Era é adotado como síntese aproximada de múltiplas dispersões, não como evento único ou data documental exata. Ramos Eldenari e comunidades materiais associadas participam da formação de Tairim/humanos, Urakh/orcs, goblins dos contrafortes, anões de galerias e halflings ocidentais. Os processos são geracionais; a Grande Punição não produz todos os povos de uma vez. A raiz dos elfos permanece Aelthir e a dos oleakes permanece Olek.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO02 — Humanos — formação e descrição

Ramos Eldenari e comunidades Tairim. Dispersões na I Era; Nara em 173 da II Era. Peles, cabelos, olhos e constituições muito variados; orelhas curtas. Os Tairim dos vales orientais e meridionais constituem a principal ancestralidade das populações humanas atuais. A nova síntese de continuidade situa sua formação na dispersão de comunidades Eldenari entre cerca de 3600 e 5800 da I Era. Famílias de agricultores, condutores de rebanhos e trabalhadores de canais afastaram-se das grandes instalações de mana e se misturaram a comunidades materiais já presentes nesses vales. Durante muitas gerações, a longevidade secular tornou-se menos frequente. Tairim designava conjuntos de comunidades, sem uma coroa ou aparência única.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO03 — Elfos altos — formação e descrição

Aelthir de Leth Avar. c. 5990 da I Era; Ordem em c. 6035. Pele clara, cabelos predominantemente loiros, orelhas pontudas; corpos materiais. Os elfos altos descendem dos Aelthir que aceitaram a condição material durante a Travessia das Sete Portas, por volta de 5990 da I Era. Arieth Ilvar conduziu famílias de Leth Avar, região instável de Eomundus. Ilenya Saar conservou vínculos e objetos familiares nos postos de acolhimento. A passagem preservou pessoas e traços físicos; a luminosidade astral dos Aelthir cedeu lugar a corpos de duração estável. O Acordo das Soleiras, em torno de 6002, organizou parte do cuidado entre Aston e Emvale.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO04 — Elfos da floresta — formação e descrição

Aelthir meridionais e comunidades de acolhimento com ascendência Eldenari. Passagens no fim da I Era; formação durante o Milênio das Trevas. Orelhas pontudas; peles acobreadas e castanhas; cabelos castanhos, escuros ou avermelhados. Os ancestrais Aelthir deste povo atravessaram passagens meridionais antes da Grande Punição, fora da rede conduzida por Arieth. Foram recebidos por comunidades de bosques e vales com descendência Eldenari e vínculos próprios com a mana local. A formação dos elfos da floresta reuniu essas linhagens e modos de vida durante gerações. Thaelira aparece em suas tradições como guardiã desses vínculos. A diferença em relação aos elfos altos surgiu na longa adaptação material, sem uma troca instantânea de aparência ao atravessar.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO05 — Elfos negros — formação e descrição

Aelthir crepusculares; incorporações de sobreviventes materiais. Rupturas do fim da I Era e primeiros séculos da II. Peles escuras, de castanho profundo a tons acinzentados; cabelos brancos, prateados ou escuros. Os ancestrais deste povo eram Aelthir ligados às cavernas crepusculares de Eomundus. Chegaram durante as rupturas que marcaram o fim da I Era e a transição para a II. Nyravel Sareth conduziu refugiados até o vale de Naer-Sul. A materialização conservou inicialmente os traços Aelthir; a aparência própria dos elfos negros consolidou-se nas gerações seguintes, entre vínculos de mana crepuscular, casamentos e comunidades de acolhimento. Assim, sua origem preserva a raiz Aelthir e incorpora sobreviventes de ascendência Eldenari.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO06 — Anões — formação e descrição

Comunidades de galerias, descendentes de trabalhadores Eldenari e famílias materiais associadas. Formação nos primeiros séculos da II Era; Dorgamar em 1368. Baixa estatura, constituição larga e robusta; variadas peles, cabelos e barbas. A origem dos anões antecede Dorgamar. Comunidades de mineiros, mantenedores de galerias e suas famílias sobreviveram em abrigos subterrâneos próximos de fontes geotérmicas. Parte descendia de trabalhadores Eldenari que haviam deixado os centros de pesquisa; outras famílias materiais foram incorporadas às redes de abrigo. Ao longo das gerações, os vínculos de mana com pedra, calor e pressão acompanharam a consolidação de corpos baixos e robustos. Essa formação se intensificou nos primeiros séculos da II Era, sem um nascimento coletivo num único ano.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO07 — Halflings — formação e descrição

Comunidades ocidentais de ascendência Eldenari e vizinhanças materiais. Dispersão ocidental no fim da I Era; pactos da II Era. Pequeno porte, rostos adultos variados, pés largos e cabelos frequentemente ondulados ou encaracolados. Comunidades de pequena estatura já se distinguiam entre os ramos materiais afastados dos centros Eldenari no fim da I Era. Famílias deslocaram-se por passos ocidentais e conviveram com populações dos vales além da Cordilheira de Velkar. A nova síntese adota essa ascendência compartilhada, sem atribuir o pequeno porte à fome de uma única geração. A continuidade dos abrigos e os casamentos entre comunidades formaram os halflings ao longo do tempo; a Confederação surgiria depois como resposta política.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO08 — Orcs — formação e descrição

Urakh, ramo de planaltos da dispersão material Eldenari. Dispersões na I Era; pacto de Ursha na II Era. Constituição frequentemente robusta; presas inferiores; peles em tons de oliva e verde acinzentado. Os Urakh eram comunidades de planalto formadas na dispersão de populações Eldenari e outras famílias materiais durante a I Era. A nova continuidade situa sua diferenciação no amplo intervalo entre cerca de 3600 e 5800, sem converter esse intervalo em uma migração única. Mobilidade, manejo de rebanhos e manutenção de poços aproximaram grupos que antes possuíam vínculos diferentes. A constituição física e as identidades orcs consolidaram-se ao longo de muitas gerações, antes de existir uma Confederação.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO09 — Goblins — formação e descrição

Comunidades de contrafortes derivadas da dispersão Eldenari. Formação no fim da I Era e na II; Rede das Chaves Pequenas em 689 da III. Pequeno porte, orelhas largas e laterais, peles verdes ou oliva; rostos variados. Os ancestrais goblins viviam em comunidades menores dos contrafortes orientais. A continuidade agora liga parte dessas famílias aos ramos Eldenari que deixaram as cidades durante as dispersões da I Era, em convivência com outras populações materiais. O pequeno porte e as características próprias se consolidaram ao longo de gerações de circulação entre vales, ruínas e abrigos. A catástrofe ampliou deslocamentos já existentes, sem criar todos os goblins num único acontecimento.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO10 — Oleakes — formação e descrição

Olek de Eomundus; origem independente da linhagem Eldenari. Materialização no fechamento das passagens, transição entre I e II Eras. Pequeno porte, orelhas longas, feições e pelos leporinos; mãos adaptadas a ferramentas. Os ancestrais dos oleakes eram os Olek de Eomundus, ligados ao abrigo e à vigilância comunitária. Quando as passagens se fecharam, assumiram corpos materiais nas terras baixas e úmidas da futura Oleakia. A continuidade situa esse processo na transição entre I e II Eras, sem inventar um dia único para todas as comunidades. Sua origem é independente dos Eldenari: partilhar campos, ferramentas e redes de refúgio não equivale a descender do mesmo povo. Nancy é venerada como Mãe das Tocas.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO11 — Nogards — formação e descrição

Guardiões materiais de ascendência Eldenari e Tairim, ligados a filhotes de dragão por pacto de mana. Vigília das Escamas nos primeiros séculos da II Era. Meio-dragões bípedes com escamas, chifres ou cristas; grande variação individual. Nos primeiros séculos da II Era, guardiões de santuários dracônicos das ilhas meridionais encontraram ovos que já não eclodiam sem auxílio. As famílias dos guardiões reuniam descendentes Eldenari, Tairim e outras comunidades materiais. Na Vigília das Escamas, compartilharam parte de sua estabilidade material com os filhotes por vínculos de mana. O pacto renovado durante gerações transformou as linhagens envolvidas e deu origem aos nogards. Sua origem combina a descendência material dos guardiões e a herança dracônica.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO12 — Eldenari — legado e limites

A ancestralidade Eldenari é material e histórica, com ramos diferenciados antes da Punição. Adota-se a contribuição dessas linhagens para povos posteriores e para comunidades de acolhimento élficas. Não se afirma que criaram dragões, Aelthir, Olek ou Thul Verenari. A presença Eldenari individual em 788 continua excepcional, conforme a premissa da campanha.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO13 — Dragões e nogards

Dragões precedem os assentamentos Eldenari conhecidos. A Vigília das Escamas ocorre nos primeiros séculos da II Era, sem ano exato adotado. Guardiões materiais, entre eles descendentes Eldenari e Tairim, ligam-se a filhotes por estabilidade e mana. Nogards têm reprodução própria; cada nascimento não exige novo pacto com um dragão.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

### RC-PO14 — Continuidade das três linhagens élficas

A política Aelthir de pele clara, cabelos loiros e presença astral continua vigente. Na materialização, traços individuais não mudam instantaneamente. A aparência própria dos elfos da floresta e dos elfos negros consolida-se ao longo das gerações em Virtude, por vínculos de mana e comunidades de acolhimento. Elfos altos conservam a referência Aelthir em condição material.

Base: História Geral de Virtude, pp. 13–18 e 25–28; Livro de Regras 0.3, pp. 8–10; expansão autoral autorizada em 8 de novembro de 2026.

Aplicação: Registro Geral, artigos, imagens, ligações e futuras obras pertinentes.

## 47. Dossiês dos povos e das origens



Eldenari



Povo de vidas seculares, associado às primeiras cidades dos vales do Taoju e do Asmarith e às grandes instituições de pesquisa da I Era.

| Campo | Descrição |
| --- | --- |
| Referência temporal | I Era |
| Longevidade | Vários séculos |
| Primeiros assentamentos | c. 2100 da I Era |
| Centros históricos | Vales do Taoju e Asmarith |
| Depois da ruptura | Mortes, deslocamentos e sobrevivências dispersas |
| Origem e descendência | Ver Dispersão dos Vales e os dossiês de cada povo |



Cidades e gerações. Vestígios situam assentamentos Eldenari por volta de 2100 da I Era. A consolidação urbana de Xeo Taoju é colocada em torno de 2550. Asterion e Nereth aparecem nas tradições de origem de um povo sensível à mana e dedicado a registrar experiências. Vidas de vários séculos permitiam pesquisas prolongadas, mas também concentravam autoridade em famílias e casas de estudo.



Trabalho e conhecimento. Calendários orientavam plantio, cobrança e armazenamento. Ilyra Seneth procurou tornar o céu compreensível; Oren Namar defendeu a permanência dos nomes dos mortos. Talena Ors e Edris Vaun distinguiram relato e observação. A manutenção dos centros dependia de barqueiros, carpinteiros, cuidadores e trabalhadores de oficina, cuja remuneração se tornou uma questão pública na Paralisação dos Nove Pátios.



Cidades em desacordo. A Casa das Medidas e os templos disputavam competências, enquanto alianças com dragões podiam trazer proteção, ensino ou tributo compulsório. A Guerra dos Reparos aprofundou conflitos pelo acesso à manutenção dos canais. Mais tarde, o Selo dividiu comunidades que temiam perder colheitas e outras que denunciavam o custo de sua estabilidade.



Ruptura e sobrevivência. A ligação de corpos e memórias aos instrumentos de pesquisa tornou os centros Eldenari particularmente vulneráveis à ruptura. Muitos morreram, outros foram arrastados à Margem e pequenos grupos sobreviveram longe das instalações. Seus descendentes se misturaram a outros povos. A perda de arquivos e comunidades explica a fragmentação posterior de sua história.



A aparência dos primeiros povos. Os Eldenari eram humanoides materiais, com grande variedade de pele, cabelo, olhos e constituição. Traços de famílias e regiões não correspondiam a uma aparência universal. Os cabelos muito claros de Ilyra, os cabelos escuros de Avar e a figura larga de Oren pertencem a pessoas específicas. Instrumentos, mantos e adornos de pesquisa distinguem atividades e posições sociais. A sensibilidade à mana e as vidas seculares não significavam que todos fossem magos ou que mantivessem as mesmas capacidades.



A dispersão antes da Punição. Entre cerca de 3600 e 5800 da I Era, famílias se afastaram dos centros dos vales em movimentos hoje reunidos sob o nome Dispersão dos Vales. O intervalo é uma convenção da nova síntese, não a data de uma expedição única. Alguns grupos procuravam terras, outros fugiam de tributos, recrutamento ou controle de pesquisa. Encontros com comunidades materiais menos registradas ampliaram a diversidade. Mudanças de duração da vida e de vínculos de mana se consolidaram em muitas gerações, antes da Grande Punição.



Os povos que vieram dessas redes. Os Tairim, principais ancestrais humanos, os Urakh dos planaltos e comunidades dos contrafortes, galerias e vales ocidentais conservaram graus diferentes de ascendência Eldenari. Essas redes participaram da formação de humanos, orcs, goblins, anões e halflings. Não houve uma transformação simultânea em cinco povos. A formação dos elfos da floresta reuniu Aelthir meridionais e comunidades materiais de acolhimento; os elfos negros também incorporaram sobreviventes materiais. Os nogards descendem de guardiões de santuários, parte deles de origem Eldenari, ligados a dragões por mana.



O que essa ancestralidade não explica sozinha. Os elfos altos preservam origem Aelthir independente; os oleakes vêm dos Olek de Eomundus. A história dos dragões começa antes dos assentamentos Eldenari conhecidos. Misturas familiares e trocas de técnica ligam esses povos sem apagar suas origens. Em 788, os Eldenari não constituem uma população comum de um estado preservado. Ruínas e inscrições conservam parte de sua experiência, enquanto a reivindicação de descendência pode ser usada para defender direitos que os documentos antigos não concedem.



Dragões



Primeiros habitantes corpóreos duradouros lembrados pelas tradições de Virtude, de grande longevidade e vínculos profundos com a mana.

| Campo | Descrição |
| --- | --- |
| Referência temporal | I Era |
| Longevidade | Sem morte por velhice; vulneráveis a ferimentos e esgotamento |
| Reprodução | Ovos entre os descendentes |
| Horizonte tradicional | c. 1 da I Era |
| Origem e descendência | Primeiros dragões ligados a Azhravyr e Ithélion; descendentes nascem de ovos |



Origem e duração. As tradições ligam a formação dos primeiros dragões a Azhravyr e Ithélion, em encontros dos caminhos da mana. O ano 1 da I Era é um horizonte convencional dessa memória. Os primeiros teriam se formado diretamente desses encontros; seus descendentes nasceram de ovos. Dragões não morrem de velhice, mas podem morrer por ferimentos, perda de vínculos com a mana e esgotamento de grandes encantamentos.



Paciência, torpor e responsabilidade. Séculos de existência permitem conhecimentos vastos e também criam desencontros com sociedades de vida mais breve. O torpor recupera forças, mas pode deixar lacunas e dificultar o reconhecimento de mudanças políticas. Uma promessa ainda recente para um dragão pode sustentar a vida de muitas gerações Eldenari. Os Conclaves das Asas procuravam arbitrar território, acesso à mana e cuidado dos ovos.



Tradições e dissidências. Os Custódios da Esmeralda, os Artífices da Brasa e os Senhores do Zênite desenvolveram orientações diferentes. Varesh preservou vínculos sem aderir permanentemente a nenhuma delas. A Guerra das Nove Vigílias atravessou essas divisões: Khorvath rompeu com Zhaurak, enquanto Vaelthar abandonou a neutralidade após sofrer um ataque.



Depois da ruptura. Vaelthar e Varesh conduziram sobreviventes ao refúgio de Eshara. O caminho consumiu os instrumentos capazes de mantê-lo, isolando o grupo. Ovos permaneceram em santuários de Virtude. As tradições posteriores de Nogard conservam o culto a figuras dracônicas, distinguindo a vida histórica de Khorvath e Varesh das interpretações religiosas de sua memória.



Escala e individualidade. Escamas, chifres, membranas de asas e constituições variam entre linhagens e indivíduos. Vaelthar apresenta escamas verdes opacas e uma fratura branca no chifre esquerdo; Khorvath tem tons de cobre e cicatrizes de metal fundido; Zhaurak é lembrado por escamas vermelhas com bordas douradas. Cor e forma não determinam moralidade. A ilustração precisa transmitir peso, idade e gestos próprios, sem reproduzir um mesmo dragão em cores diferentes.



Dragões e Eldenari. Os dragões já existiam antes dos primeiros assentamentos Eldenari datados de cerca de 2100 da I Era. Khorvath ensinou técnicas do aerólito a construtores; alianças como a da Brasa criaram redes de ensino, proteção e obrigações. Os Senhores do Zênite converteram parte dessas relações em exigência de tributo e trabalho. Os Eldenari não deram origem aos dragões, mas suas comunidades participaram da história dos santuários e, mais tarde, da formação dos nogards.



O pacto que originou os nogards. Depois da Grande Punição, guardiões materiais de santuários ajudaram ovos em risco a eclodir. A Vigília das Escamas estabeleceu um compartilhamento de estabilidade por mana, renovado por gerações. Desse processo surgiram linhagens de meio-dragões capazes de gerar seus próprios descendentes. A origem não corresponde a um casamento obrigatório entre humano e dragão, nem transforma cada nogard num dragão jovem. É uma história particular de sobrevivência, convivência e transformação de linhagens.



Memória depois da I Era. O refúgio de Eshara, os ovos preservados e as tradições dos santuários mantêm os dragões ligados às eras posteriores. O ano convencional de sua origem não deve ser usado para calcular uma idade exata de cada indivíduo. Relatos de aparição podem ser testemunhos, cultos ou interesses locais. A afirmação de uma dinastia nogard de ser herdeira exclusiva dos dragões constitui uma pretensão política e religiosa, não um direito universal conferido pela história do povo.



Humanos



Os Tairim dos vales orientais e meridionais constituem a principal ancestralidade das populações humanas atuais.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Ramos Eldenari e comunidades Tairim |
| Marcos históricos | Dispersões na I Era; Nara em 173 da II Era |
| Aparência | Peles, cabelos, olhos e constituições muito variados; orelhas curtas |
| Comunidades e presença | Reinos Centrais, Bergen e muitas outras regiões |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Dos Eldenari aos Tairim. Os Tairim dos vales orientais e meridionais constituem a principal ancestralidade das populações humanas atuais. A nova síntese de continuidade situa sua formação na dispersão de comunidades Eldenari entre cerca de 3600 e 5800 da I Era. Famílias de agricultores, condutores de rebanhos e trabalhadores de canais afastaram-se das grandes instalações de mana e se misturaram a comunidades materiais já presentes nesses vales. Durante muitas gerações, a longevidade secular tornou-se menos frequente. Tairim designava conjuntos de comunidades, sem uma coroa ou aparência única.



Corpo, duração e diferenças. Os humanos apresentam grande variedade de pele, cabelo, olhos, altura e constituição. A vida costuma ser medida em décadas; as condições de alimentação, trabalho e cuidado têm grande peso em sua duração. A aparência de um habitante de Bergen não serve de modelo para todas as famílias de Valerith ou das terras meridionais. Nas cidades portuárias, a circulação de pessoas ampliou antigas diferenças regionais e criou famílias com vínculos em mais de um reino.



Os celeiros de Nara. A destruição das cidades Eldenari espalhou sobreviventes entre os Tairim e levou suas comunidades para áreas antes controladas pelos antigos centros. Em 173 da II Era, Nara dos Sete Celeiros reuniu aldeias humanas e famílias de outros povos em armazéns comuns. Recusou uma coroa e morreu durante um inverno distribuindo reservas. Sua veneração como Arauto de Nancy pertence à história religiosa; o auxílio que organizou não depende de provar essa condição. Os pactos de alimento contribuíram para a recuperação dos campos.



Impérios e reinos. Na II Era, populações humanas participaram da reconstrução, das cidades mercantis e do Império de Vaelen Endor, proclamado em 1896 e dissolvido em 2431. Isso não tornou todos os humanos súditos imperiais. Bergen, as terras ocidentais e comunidades livres preservaram trajetórias distintas. A III Era ampliou as disputas por fronteiras, tributos e sucessões. Cultos, guildas e direitos de residência atravessam essas fronteiras, permitindo alianças entre pessoas de povos diferentes.



Vida em 788. Camponeses, navegadores, estudiosos, soldados e artesãos convivem sob regimes diferentes. Demer Vault pertence a uma experiência particular de estrada e combate; não representa uma disposição natural humana para a guerra. Nas margens dos rios, heranças Eldenari sobrevivem em calendários, medidas e técnicas de irrigação, muitas vezes transmitidas por trabalhadores sem acesso aos arquivos antigos. O prestígio de uma ascendência pode facilitar um casamento ou uma reivindicação patrimonial, mas não demonstra superioridade de uma família sobre outra.



Elfos altos



Os elfos altos descendem dos Aelthir que aceitaram a condição material durante a Travessia das Sete Portas, por volta de 5990 da I Era.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Aelthir de Leth Avar |
| Marcos históricos | c. 5990 da I Era; Ordem em c. 6035 |
| Aparência | Pele clara, cabelos predominantemente loiros, orelhas pontudas; corpos materiais |
| Comunidades e presença | Aelvar, Iltharion e comunidades dispersas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



A Travessia. Os elfos altos descendem dos Aelthir que aceitaram a condição material durante a Travessia das Sete Portas, por volta de 5990 da I Era. Arieth Ilvar conduziu famílias de Leth Avar, região instável de Eomundus. Ilenya Saar conservou vínculos e objetos familiares nos postos de acolhimento. A passagem preservou pessoas e traços físicos; a luminosidade astral dos Aelthir cedeu lugar a corpos de duração estável. O Acordo das Soleiras, em torno de 6002, organizou parte do cuidado entre Aston e Emvale.



Aparência e longevidade. Pele clara, cabelos loiros em tons de mel, ouro pálido e platinado e orelhas pontudas formam a referência visual deste povo. Nariz, mandíbula, lábios, olhos, idade e penteado distinguem indivíduos. Em Virtude, possuem corpos materiais: a presença astral pertence sobretudo à condição Aelthir em Eomundus. Sua longevidade alcança muitos séculos, raramente mais de um milênio. Viver muito permite conservar experiências; perdas de arquivos, doenças e mudanças de governo ainda interrompem a transmissão do conhecimento.



Norte e leste. Os primeiros assentamentos setentrionais deram origem a Emvale e Aston. Outros grupos alcançaram o leste e participaram da formação de Iltharion. Aelvar e Iltharion não constituem um único governo, nem a mesma população obedece automaticamente a ambas as coroas. A separação de rotas e instituições produziu usos de língua, precedência e herança diferentes. Redes familiares mantiveram correspondência, enquanto cortes disputaram a autoridade de falar em nome dos descendentes da Travessia.



A Ordem e seus limites. Caerion Thalas fundou a Ordem dos Magos em Aethravel por volta de 6035 da I Era. O intercâmbio com os Eldenari ampliou técnicas de proteção e o trabalho do aerólito. Esse contato criou parentescos e comunidades mistas, sem fazer dos elfos altos um ramo Eldenari. A associação tornou-se uma instituição com regras próprias, que a coroa de Aelvar não controla integralmente. A Carta das Mãos Abertas, de 326 da III Era, reconheceu membros plenos de outros povos.



Memória, trabalho e poder. O cuidado de pomares, a navegação, a conservação de instrumentos e a manutenção de edifícios sustentam uma sociedade frequentemente descrita apenas por seus magos e príncipes. Famílias antigas podem acumular propriedades durante séculos, dificultando o acesso de gente mais jovem à terra e aos cargos. O Acordo dos Pomares de Aston, de 631 da III Era, reconheceu direitos de cultivo fora das grandes casas. A memória longa favorece continuidade e também pode conservar obrigações injustas.



No início de 788. Arriot Ilvar governa Aelvar desde 622 da III Era; Elyndra governa Iltharion desde 741. Le Rink participa das redes de diplomacia e estudo de Aelvar. Marevim Aethros, nascido em 462, é jovem segundo a duração de seu povo, embora sua experiência e cansaço não correspondam à aparência de um adolescente. Nenhum desses percursos transforma um elfo alto em representante de todos os demais. As relações entre casa, corte, Ordem e cidade precisam ser observadas separadamente.



Elfos da floresta



Os ancestrais Aelthir deste povo atravessaram passagens meridionais antes da Grande Punição, fora da rede conduzida por Arieth.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Aelthir meridionais e comunidades de acolhimento com ascendência Eldenari |
| Marcos históricos | Passagens no fim da I Era; formação durante o Milênio das Trevas |
| Aparência | Orelhas pontudas; peles acobreadas e castanhas; cabelos castanhos, escuros ou avermelhados |
| Comunidades e presença | Thaelorien e comunidades de outras regiões |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Passagens meridionais. Os ancestrais Aelthir deste povo atravessaram passagens meridionais antes da Grande Punição, fora da rede conduzida por Arieth. Foram recebidos por comunidades de bosques e vales com descendência Eldenari e vínculos próprios com a mana local. A formação dos elfos da floresta reuniu essas linhagens e modos de vida durante gerações. Thaelira aparece em suas tradições como guardiã desses vínculos. A diferença em relação aos elfos altos surgiu na longa adaptação material, sem uma troca instantânea de aparência ao atravessar.



Corpos e marcas pessoais. Peles acobreadas e castanhas, orelhas pontudas e cabelos castanhos, escuros ou avermelhados orientam a ilustração das comunidades mais presentes nos relatos. Há variação familiar e regional. Vestimentas de fibras, lã e couro acompanham chuva, trabalho e deslocamento; roupa verde e arco não são exigências de pertencimento. Seus ciclos de vida atravessam gerações humanas, mas os materiais não fixam aqui uma expectativa numérica universal. Liana Meywood mantém sua pele acobreada, a mecha branca e a cicatriz do lábio como traços individuais.



Guerras das Raízes. A fome da II Era aproximou cidades, campos e bosques numa relação violenta. Governantes mandavam derrubar árvores para obter cultivo e combustível; guardiões respondiam destruindo plantações e caminhos. Thessara Folha-Clara encerrou as Guerras das Raízes por meio de um acordo que distinguiu terras de cultivo, áreas de proteção e deveres de abastecimento. A sequência pertence à reconstrução da II Era; não recebe um ano exato enquanto os registros não o sustentam. O pacto exigiu manutenção e novas negociações ao longo do tempo.



Reino e floresta. Thaelorien consolidou uma ordem de pactos entre cidades e bosques. Nael-Sul é a capital e também dá nome à grande floresta; o Bosque de Let-Thalara permanece em Aelvar. O reino nunca integrou o Império de Vaelen Endor. Portos, estradas, cultivos e oficinas fazem parte de sua vida tanto quanto os bosques preservados. Povoados de floresta dependem de comércio e trabalho especializado, e seus habitantes podem discordar sobre o uso de madeira, caça, terra e água.



Desigualdades e partidas. Grandes casas transformaram certas responsabilidades de proteção em direitos de propriedade duradouros. Famílias sem acesso à terra emigraram, inclusive para os Reinos Centrais. A Confraria das Raízes Fundas atua em conservação, contratos e circulação de madeira, enfrentando interesses internos conflitantes. A migração não apaga pertencimentos: uma elfa que cresceu numa cidade pode conhecer pouco uma mata específica e ainda participar da história de seu povo.



Em 788. Ariessa Folha-Clara governa desde 588 da III Era. As disputas envolvem comunidades de cultivo, casas antigas, trabalhadores de madeira, guardiões e habitantes dos portos. Liana representa uma trajetória ligada ao rastreamento e à investigação, enquanto outros elfos exercem ofícios urbanos e funções de cuidado. A herança Eldenari aparece em práticas de medida e nas comunidades ancestrais de acolhimento; a raiz Aelthir permanece parte essencial de sua origem.



Elfos negros



Os ancestrais deste povo eram Aelthir ligados às cavernas crepusculares de Eomundus.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Aelthir crepusculares; incorporações de sobreviventes materiais |
| Marcos históricos | Rupturas do fim da I Era e primeiros séculos da II |
| Aparência | Peles escuras, de castanho profundo a tons acinzentados; cabelos brancos, prateados ou escuros |
| Comunidades e presença | Naerath, Quinder, Sularien e diásporas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Os caminhos crepusculares. Os ancestrais deste povo eram Aelthir ligados às cavernas crepusculares de Eomundus. Chegaram durante as rupturas que marcaram o fim da I Era e a transição para a II. Nyravel Sareth conduziu refugiados até o vale de Naer-Sul. A materialização conservou inicialmente os traços Aelthir; a aparência própria dos elfos negros consolidou-se nas gerações seguintes, entre vínculos de mana crepuscular, casamentos e comunidades de acolhimento. Assim, sua origem preserva a raiz Aelthir e incorpora sobreviventes de ascendência Eldenari.



Aparência e vida à superfície. Peles de castanho profundo, tons escuros acinzentados e cabelos brancos, prateados ou escuros aparecem nas comunidades descritas. Orelhas pontudas, diferentes formatos de rosto, penteados e constituições permitem individualização. Nyssara Veyl conserva suas tranças brancas finas e olhos castanhos. O nome coletivo não indica caráter ou alinhamento moral. Muitos vivem à superfície, em cidades, campos e bordas de floresta; a memória das cavernas de Eomundus não torna todo assentamento atual subterrâneo.



A autoridade de Nyravel. Seguidores reconheceram Nyravel como Arauto de Eilistraee, associada ao amparo dos exilados e à liberdade dos caminhos noturnos. Tradições dissidentes recusaram esse reconhecimento. A sacerdotisa organizou acolhimento, mas também autorizou campanhas brutais contra comunidades que considerava ameaças. Religião e crítica política coexistiram desde esse período. Depois de sua morte, herdeiros e casas disputaram responsabilidades, terras e autoridade sobre refugiados, contribuindo para a formação de estados diferentes.



Três trajetórias políticas. Naerath, Quinder e Sularien possuem histórias próprias. Forças originadas em Naerath conquistaram Quinder nas campanhas de 2424 a 2428 da II Era; o Acordo das Lâmpadas foi firmado em 2429. A Guerra das Duas Cortes, de 61 a 74 da III Era, levou à independência de Quinder. Esses acontecimentos explicam rivalidades entre casas e reivindicações patrimoniais, sem converter cada família atual em participante ou beneficiária das conquistas antigas.



Casas, ofícios e arquivos. As casas organizam parte da propriedade, do amparo e do acesso a cargos. Há famílias que dependem delas para obter trabalho e outras que procuram redes urbanas ou instituições independentes. Resina, cultivo, navegação e pesquisa convivem com a política de corte. Em Quinder, o estudo das ruínas Eldenari tornou-se uma atividade técnica e política: interpretar uma inscrição pode afetar direitos sobre água, terra ou patrimônio. A ascendência material compartilhada não concede a uma casa posse automática dessas ruínas.



Em 788. Zeryssa Sareth governa Naerath desde 703 da III Era, em relação com o conselho das casas. O Acordo de Vel-Narim, de 722, converteu algumas pretensões antigas em indenização e rejeitou outras. Em Quinder, Nyssara trabalha com inscrições e pesquisa; suas escolhas pertencem à sua biografia. Nas diásporas, muitos preferem identificar-se pela cidade, vale ou família. Essa diversidade continua presente mesmo onde estrangeiros enxergam um povo único.



Anões



A origem dos anões antecede Dorgamar.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Comunidades de galerias, descendentes de trabalhadores Eldenari e famílias materiais associadas |
| Marcos históricos | Formação nos primeiros séculos da II Era; Dorgamar em 1368 |
| Aparência | Baixa estatura, constituição larga e robusta; variadas peles, cabelos e barbas |
| Comunidades e presença | Dorgamar, portos, montanhas e cidades de outros reinos |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Antes do império. A origem dos anões antecede Dorgamar. Comunidades de mineiros, mantenedores de galerias e suas famílias sobreviveram em abrigos subterrâneos próximos de fontes geotérmicas. Parte descendia de trabalhadores Eldenari que haviam deixado os centros de pesquisa; outras famílias materiais foram incorporadas às redes de abrigo. Ao longo das gerações, os vínculos de mana com pedra, calor e pressão acompanharam a consolidação de corpos baixos e robustos. Essa formação se intensificou nos primeiros séculos da II Era, sem um nascimento coletivo num único ano.



Bram e a forja compartilhada. Bram Dorgal organizou trabalho, alimento e proteção em torno das galerias. Dorgann manifestou-se em sonhos de uma forja que exigia várias pessoas para funcionar. Bram não era Arauto. A importância da narrativa está na responsabilidade compartilhada pelo ar, pela água e pela manutenção: uma casa podia possuir ferramentas, mas não conservar uma galeria habitável sozinha. Seus sucessores abriram caminhos seguros e cobraram passagem, criando alianças comerciais e conflitos com antigos usuários das montanhas.



Aparência e vida cotidiana. Baixa estatura, ombros largos e constituição robusta formam a referência física, com variações de pele, rosto, cabelo e idade. Barbas e tranças podem indicar hábitos pessoais ou familiares, sem pertencer a todos. Mulheres e homens exercem navegação, ensino, cultivo e trabalho de oficina. Vestimentas acompanham calor de forja, umidade dos canais ou vento do litoral. Lentes e instrumentos de precisão fazem parte de alguns ofícios; a lente de Sera é uma marca pessoal, não uma característica biológica do povo.



Da Paz de Dorgal a Dorgamar. A Paz de Dorgal, de 1084 da II Era, e a fundação convencional do Império de Dorgamar, em 1368, pertencem à história política posterior à formação do povo. A coroa articulou cidades, casas e redes de passagem, sem absorver todos os anões de Virtude. O comércio com Vaelen Endor ampliou o peso de Morvek. O Tratado das Águas é de 2032; as obras começaram em 2039, o primeiro conjunto entrou em serviço em 2058 e as ligações principais estavam prontas em 2116.



Trabalho, risco e dissidência. Direitos de água, ventilação e passagem produzem disputas entre proprietários, operadores de canais e moradores. Um contrato pode prolongar por gerações a dívida de uma comunidade que depende da mesma galeria. O desastre das Galerias de Anver, de 318 da III Era, permanece entre as referências de risco e responsabilidade. Há também anões marítimos, agricultores de encosta e habitantes de cidades estrangeiras. A associação entre povo e uma única profissão esconde essa variedade.



Em 788. Brunna IV Dorgenn governa Dorgamar desde 754 da III Era. Assembleias, casas e cidades participam das negociações sobre obras e tributos. Sera procura autoria e autonomia no trabalho com mecanismos de mana e vortics, mostrando uma experiência que atravessa as fronteiras do império. A herança Eldenari está nos ancestrais materiais e nas técnicas transmitidas; os anões desenvolveram instituições e identidades próprias durante milênios de história.



Halflings



Comunidades de pequena estatura já se distinguiam entre os ramos materiais afastados dos centros Eldenari no fim da I Era.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Comunidades ocidentais de ascendência Eldenari e vizinhanças materiais |
| Marcos históricos | Dispersão ocidental no fim da I Era; pactos da II Era |
| Aparência | Pequeno porte, rostos adultos variados, pés largos e cabelos frequentemente ondulados ou encaracolados |
| Comunidades e presença | Pellanor, a oeste e além da Cordilheira de Velkar; diásporas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



A travessia para os vales ocidentais. Comunidades de pequena estatura já se distinguiam entre os ramos materiais afastados dos centros Eldenari no fim da I Era. Famílias deslocaram-se por passos ocidentais e conviveram com populações dos vales além da Cordilheira de Velkar. A nova síntese adota essa ascendência compartilhada, sem atribuir o pequeno porte à fome de uma única geração. A continuidade dos abrigos e os casamentos entre comunidades formaram os halflings ao longo do tempo; a Confederação surgiria depois como resposta política.



Aparência e escala. Pequeno porte, pés largos e cabelos muitas vezes ondulados ou encaracolados orientam a representação. Rostos, tons de pele, idade e constituição variam; um adulto halfling deve ser desenhado com feições adultas. Casas, ferramentas e mobiliário acompanham sua escala, mas encontros com viajantes exigem adaptações. Sapatos e pés descalços dependem do trabalho e do lugar. Roupas, adornos e gestos distinguem profissões e histórias individuais.



Pella e os pactos de abrigo. Pella Três-Pontes ligou vilas por compromissos de pouso, reparo de travessias e proteção de celeiros. Enchentes, banditismo e tentativas de anexação exigiam cooperação sem concentrar todas as reservas num único centro. A memória de Meliva amparou esses pactos; Tívaro e Merovél, também chamados Tivim e Mero, foram invocados nas viagens. A tradição situa Pella na reorganização da II Era, mas não conserva aqui um ano seguro de fundação de cada vila.



A Confederação. Pellanor fica a oeste de Velkar, além da cordilheira, na região ocidental a sudoeste de Aelvar. Sua Confederação articula comunidades e pousos; uma representação de assembleia não deve sugerir uma capital única que governa todas as vilas. O direito de abrigo envolve manutenção de estradas e partilha de custos. Famílias podem divergir sobre taxas, recebimento de estrangeiros e responsabilidades diante de uma colheita perdida. O gosto pela hospitalidade não elimina conflitos de propriedade.



Uma história além das hospedarias. Cultivo, construção de pontes, comércio, ensino e serviços de viagem participam da economia, mas não esgotam os ofícios. Pessoas que vivem fora de Pellanor podem manter parentesco e correspondência sem depender de uma autoridade confederada para cada decisão. A Mesa das Sete Panelas, cuja reunião inaugural ocorreu em 208 da III Era, pertence a uma história de sociabilidade e cooperação que atravessa pertencimentos; não deve ser confundida com a origem biológica dos halflings.



Em 788. As rotas ocidentais mantêm ligações com Aelvar e outras regiões, embora o mapa central registre apenas parte desses caminhos. A distância das cortes centrais favoreceu autonomias locais e também dificultou reparação diante de abusos nas fronteiras. A ascendência Eldenari integra a história remota do povo; práticas de abrigo e pactos de vila explicam melhor suas instituições atuais do que uma suposta personalidade comum a todos.



Orcs



Os Urakh eram comunidades de planalto formadas na dispersão de populações Eldenari e outras famílias materiais durante a I Era.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Urakh, ramo de planaltos da dispersão material Eldenari |
| Marcos históricos | Dispersões na I Era; pacto de Ursha na II Era |
| Aparência | Constituição frequentemente robusta; presas inferiores; peles em tons de oliva e verde acinzentado |
| Comunidades e presença | Confederação Orc, planaltos, cidades e rotas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Dos ramos materiais aos Urakh. Os Urakh eram comunidades de planalto formadas na dispersão de populações Eldenari e outras famílias materiais durante a I Era. A nova continuidade situa sua diferenciação no amplo intervalo entre cerca de 3600 e 5800, sem converter esse intervalo em uma migração única. Mobilidade, manejo de rebanhos e manutenção de poços aproximaram grupos que antes possuíam vínculos diferentes. A constituição física e as identidades orcs consolidaram-se ao longo de muitas gerações, antes de existir uma Confederação.



Aparência. Porte frequentemente robusto, mandíbulas marcadas e presas inferiores compõem a referência visual. Tons de pele variam entre oliva e verde acinzentado, com diferenças familiares. Tamanho das presas, nariz, olhos, cabelo e constituição distinguem as pessoas. Kharug Venn tem uma presa quebrada e cabelo raspado; Druvak mantém tranças curtas e uma cicatriz junto ao queixo. A força de um indivíduo não define seu temperamento, profissão ou posição política.



Ursha e as Pedras Falantes. Durante a fome da II Era, reinos humanos e senhores anões disputaram terras de passagem, poços e pastagens. Ursha Mão-Aberta reuniu tribos para defender esses acessos. Dizia servir Urraka, sem reivindicar encarnação divina. O Pacto das Pedras Falantes preservou autonomias e estabeleceu assembleias comuns; dele se desenvolveria a Confederação Orc. Sua vitória sobre saqueadores humanos de Terval foi seguida pela libertação de cativos, uma decisão contestada entre seus próprios aliados.



Pacto e divergência. A Confederação reúne tribos com interesses diferentes sobre comércio, guerra, terras e relações com vizinhos. A autoridade de uma assembleia depende das obrigações aceitas e de quem reconhece seus representantes. Comunidades orcs também vivem fora dela, e vínculos urbanos podem ser tão antigos quanto os de planalto. Um chefe não governa cada pessoa de ascendência orc. Conflitos por restituição ou indenização atravessam famílias e podem produzir respostas opostas à mesma violência.



Trabalho e memória. Contratos de caravanas, criação de animais, cultivo, artesanato e estudo fazem parte de sua vida. Khoram Tesh trabalha na biblioteca de Ihfarilse; Nerka Voss pilota vortics. Essas trajetórias convivem com a memória das expulsões e das guerras, sem serem exceções a uma natureza supostamente guerreira. Pedras de assembleia, sinais de poço e histórias de libertação são conservados de modos diferentes por cada comunidade.



Em 788. A querela de Terval, entre 763 e 770 da III Era, continua a pesar sobre famílias ligadas a Kharug e Druvak. Negociações de reparação enfrentam reivindicações de proprietários, tribunais e comunidades deslocadas. A herança Eldenari oferece um parentesco remoto com outros povos materiais, mas não resolve por si só direitos atuais. Esses direitos dependem de história local, compromissos e decisões políticas.



Goblins



Os ancestrais goblins viviam em comunidades menores dos contrafortes orientais.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Comunidades de contrafortes derivadas da dispersão Eldenari |
| Marcos históricos | Formação no fim da I Era e na II; Rede das Chaves Pequenas em 689 da III |
| Aparência | Pequeno porte, orelhas largas e laterais, peles verdes ou oliva; rostos variados |
| Comunidades e presença | Populações dispersas; sem reino soberano conhecido em 788 |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Comunidades dos contrafortes. Os ancestrais goblins viviam em comunidades menores dos contrafortes orientais. A continuidade agora liga parte dessas famílias aos ramos Eldenari que deixaram as cidades durante as dispersões da I Era, em convivência com outras populações materiais. O pequeno porte e as características próprias se consolidaram ao longo de gerações de circulação entre vales, ruínas e abrigos. A catástrofe ampliou deslocamentos já existentes, sem criar todos os goblins num único acontecimento.



Corpo e identificação. Pequeno porte, orelhas largas projetadas para os lados e peles em tons de verde e oliva compõem a referência visual. Nariz, olhos, lábios, cabelo e forma das orelhas variam. Marcas de trabalho e roupas dependem de cada trajetória. Rul Aven tem cabelos encaracolados e orelhas com queimaduras antigas; suas roupas de conservação e pesquisa pertencem ao seu ofício. Equipamentos adaptados ao porte permitem atividades que uma oficina estrangeira pode tornar desnecessariamente difíceis.



Zikka e a água. Na II Era, Zikka Ven desenvolveu filtros para recuperar antigas cisternas. Quando um senhor tentou expulsar sua comunidade das fontes, foi acusada de envenenamento. A Guerra das Cisternas terminou num acordo entre aldeias goblins, humanas e orcs. Não se fixa aqui um ano exato para a guerra. A acusação continuou a circular depois do acordo, enquanto os filtros eram usados por comunidades que recusavam reconhecer sua autoria. A história da água tornou-se também uma disputa por memória e acesso.



Dispersão e pertencimento. Em 788, não há reino, estado ou território soberano goblin definido no mundo conhecido. Há moradores antigos em cidades, campos, minas, portos e caravanas. Um bairro com muitas famílias goblins não constitui uma nação soberana; uma associação de ofício também não representa todas elas. Migração, expulsão, busca de trabalho e escolhas familiares produziram experiências diversas. Muitos reconhecem como casa a cidade onde nasceram, sem imaginar um retorno obrigatório aos contrafortes.



A Rede das Chaves Pequenas. Hospedarias e associações de famílias organizaram a Rede das Chaves Pequenas em 689 da III Era. Referências de residência, cópias de documentos e auxílio de viagem reduzem a vulnerabilidade de quem não dispõe de uma corte protetora. A rede inclui parceiros de outras origens e não exige obediência política. Rul e Fen utilizaram seus serviços em circunstâncias distintas. Nas instituições de estudo, o direito formal de ingresso continua a conviver com custos, suspeitas e desigualdades de acesso.



Em 788. O trabalho com instrumentos, cultivo, ensino, comércio e cuidado aparece entre suas atividades, sem uma profissão comum obrigatória. Rul participa da Ordem dos Magos e conserva vínculos afetivos com Liana Meywood; sua biografia não deve substituir a história coletiva. Reconhecer a ascendência Eldenari amplia a história dos goblins para antes das ruínas e do reaproveitamento. Eles também herdaram comunidades de cultivo e transmissão de conhecimentos próprios.



Oleakes



Os ancestrais dos oleakes eram os Olek de Eomundus, ligados ao abrigo e à vigilância comunitária.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Olek de Eomundus; origem independente da linhagem Eldenari |
| Marcos históricos | Materialização no fechamento das passagens, transição entre I e II Eras |
| Aparência | Pequeno porte, orelhas longas, feições e pelos leporinos; mãos adaptadas a ferramentas |
| Comunidades e presença | Oleakia, Bosque de Aurenval e comunidades externas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



Dos Olek aos corpos materiais. Os ancestrais dos oleakes eram os Olek de Eomundus, ligados ao abrigo e à vigilância comunitária. Quando as passagens se fecharam, assumiram corpos materiais nas terras baixas e úmidas da futura Oleakia. A continuidade situa esse processo na transição entre I e II Eras, sem inventar um dia único para todas as comunidades. Sua origem é independente dos Eldenari: partilhar campos, ferramentas e redes de refúgio não equivale a descender do mesmo povo. Nancy é venerada como Mãe das Tocas.



Aparência leporina. São pessoas pequenas de traços leporinos: orelhas longas, feições com focinho curto, pelo e mãos capazes de usar ferramentas. Pelagens castanhas, cinzentas e claras podem variar entre indivíduos; o registro de Ima Teren menciona explicitamente pelo castanho nas mãos. A ilustração representa pessoas de aspecto leporino, com vestimenta e gestos próprios. Não se fixa uma altura universal, uma cor única ou um corpo idêntico para todo o povo. Idade, orelhas, rosto, pelo e roupa permitem distinguir cada pessoa.



Mira e as reservas dispersas. A tradição de Mira Olek associa autonomia à dispersão de depósitos. Um invasor que tomasse um celeiro não deveria controlar toda a alimentação. Refúgios, sinais e caminhos mantidos em comum completavam essa estratégia. A orientação atribuída a Nancy convive com trabalho concreto de cultivo, transporte e conservação. A época de Mira pertence às tradições de formação das comunidades materiais; não é confundida com a anfitriã Ima Teren nem com a coordenação atual de Ima Olek.



Tocas e assembleias. A União das Tocas de Oleakia reúne tribos e assembleias com competências próprias. Matriarca, coordenadora, anfitrião e responsável por um depósito exercem funções diferentes. Ima Olek articula relações sem possuir cada toca. Famílias podem divergir sobre acolhimento, reservas e autoridade de quem viveu fora do território. Túneis e casas baixas são espaços de vida e defesa; a existência de moradias pequenas não transforma seus moradores em atrações para visitantes.



Encontros que ficaram registrados. Ima Teren aparece no relato de Odran Velis publicado em 2386 da II Era. Rima Vel é interlocutora de Maelis Varen no caderno de 785 da III Era. Happidoh observa acessos costeiros, Form examina relatos e Forty participa da defesa comunitária. Esses nomes correspondem a épocas e funções diferentes. Nima Tel permanece exemplo de criação de personagem no Guia do Jogador, sem adquirir por isso uma biografia confirmada nos romances.



Em 788. A pressão naval de Nogard levou a confrontos e a um acordo provisório em 786. As disputas por ancoradouros, taxas e passagens continuam, junto ao comércio e às relações entre populações. Conhecimento de canais, reservas e terreno participa da defesa. Há também oleakes fora de Oleakia, em estudo, navegação e ofícios diversos. O povo conserva a memória dos Olek e as relações históricas com outros habitantes de Virtude, sem precisar receber uma ancestralidade Eldenari artificial.



Nogards



Nos primeiros séculos da II Era, guardiões de santuários dracônicos das ilhas meridionais encontraram ovos que já não eclodiam sem auxílio.

| Campo | Descrição |
| --- | --- |
| Referência temporal | Início de 788 da III Era |
| Origem | Guardiões materiais de ascendência Eldenari e Tairim, ligados a filhotes de dragão por pacto de mana |
| Marcos históricos | Vigília das Escamas nos primeiros séculos da II Era |
| Aparência | Meio-dragões bípedes com escamas, chifres ou cristas; grande variação individual |
| Comunidades e presença | Nogard, ilhas dos estreitos meridionais e comunidades marítimas |
| Diversidade | Pertencimento não determina profissão, caráter, religião ou lealdade |



A Vigília das Escamas. Nos primeiros séculos da II Era, guardiões de santuários dracônicos das ilhas meridionais encontraram ovos que já não eclodiam sem auxílio. As famílias dos guardiões reuniam descendentes Eldenari, Tairim e outras comunidades materiais. Na Vigília das Escamas, compartilharam parte de sua estabilidade material com os filhotes por vínculos de mana. O pacto renovado durante gerações transformou as linhagens envolvidas e deu origem aos nogards. Sua origem combina a descendência material dos guardiões e a herança dracônica.



Um povo capaz de continuar. Os nogards geram seus próprios descendentes. Cada nascimento não exige repetir a primeira Vigília nem unir fisicamente um humano a um dragão. A história não é uma receita de criação de soldados: os filhotes e os guardiões foram participantes de um pacto de sobrevivência, cujo cuidado exigiu alimento, abrigo e convivência. A palavra meio-dragões indica essa herança, sem significar que cada pessoa possua metade exata dos poderes ou do corpo de um dragão.



Escamas e feições. Corpos bípedes, escamas, chifres ou cristas e mãos capazes de trabalho fino orientam a ilustração. Cores, formato do focinho, olhos, altura e constituição variam; cobre, bronze, verdes e cinzentos aparecem como referências possíveis. Asas, sopro ou capacidades mágicas não são atribuídos automaticamente a todo indivíduo. Vestes marítimas, roupas de oficina e adornos de culto acompanham ofícios e escolhas. Nenhuma cor de escama demonstra por si só lealdade a uma dinastia.



Azhren e as comunidades. Azhren da Primeira Escama reuniu comunidades ligadas aos antigos santuários. Sua memória foi apropriada por herdeiros que afirmavam ser os únicos sucessores legítimos dos dragões. Outros nogards preservaram a ideia de um pacto de cuidado, que não concedia domínio sobre povos vizinhos. Varesh, a Asa das Marés, e Khorvath, dragões históricos, passaram a receber culto ao lado de Azhravyr. A relação entre memória, divinização e poder permanece disputada entre sacerdotes e famílias.



Povo e império. O Império de Nogard organiza casas, comandos navais e fiscalização de passagens, mas não equivale a todos os nogards. A Corte do Estreito é seu centro político; Mirasse participa das rotas. Marinheiros, negociantes e trabalhadores de cais podem apoiar ou contestar cobranças feitas em nome do império. Famílias que rejeitam pretensões dinásticas não abandonam por isso sua ancestralidade. Os descendentes dos guardiões também conservaram conhecimentos materiais recebidos dos Eldenari.



Em 788. Azhvar VIII Khor-Azhar governa o império. A tensão naval com Oleakia produziu um acordo provisório em 786 e permanece ligada a taxas e ancoradouros. O piloto Azrek Vhar demonstra outro uso de conhecimentos de mana e construção, fora das narrativas de corte. As relações com os dragões são históricas, religiosas e de linhagem; não dão ao império autoridade automática sobre ovos, santuários ou sobreviventes dracônicos de outras regiões.



Dispersão dos Vales



Movimentos de comunidades Eldenari e suas vizinhanças que contribuíram para a formação dos povos materiais posteriores.

| Campo | Descrição |
| --- | --- |
| Referência temporal | I–III Eras |
| Natureza | Síntese histórica de continuidade |
| Horizonte adotado | c. 3600–5800 da I Era |
| Precisão | Intervalo aproximado de síntese; múltiplas migrações |
| Linhas materiais | Tairim, Urakh, contrafortes, galerias e vales ocidentais |



Um processo de longa duração. Entre cerca de 3600 e 5800 da I Era, movimentos de agricultores, mineiros, barqueiros e famílias de ofício levaram comunidades para além dos grandes centros Eldenari. O nome Dispersão dos Vales reúne processos separados por séculos. A nova datação serve como horizonte de continuidade: não afirma que um arquivo preserve o começo e o fim de cada migração. Os primeiros assentamentos Eldenari conhecidos são de cerca de 2100, e a urbanização de Xeo Taoju é situada por volta de 2550.



Por que partir. Abertura de terras, exigências de tributo, recrutamento de trabalho e conflitos sobre a manutenção dos canais impulsionaram partidas. Algumas famílias seguiram para vales orientais e meridionais; outras, para planaltos, contrafortes, galerias ou passos ocidentais. Afastar-se das instalações de mana não obrigava a abandonar todo conhecimento. Calendários, formas de registro e técnicas de água foram adaptados a lugares em que não existiam os mesmos instrumentos ou concentrações de energia.



A diferenciação das comunidades. A duração secular da vida dependia em parte de vínculos materiais e de mana que se tornaram diferentes fora dos centros. Ao longo de muitas gerações, comunidades formaram características próprias em convivência com populações menos presentes nos arquivos. Tairim e Urakh são nomes históricos desse processo; outros grupos são reconhecidos sobretudo por suas moradas em contrafortes, galerias e vales ocidentais. A II Era consolidou identidades humanas, orcs, goblins, anãs e halflings sem reduzi-las a uma transformação repentina.



O encontro com outras origens. Os Aelthir e os Olek vieram de Eomundus por histórias distintas. Comunidades de descendência Eldenari acolheram parte dos grupos élficos e participaram de famílias mistas. Guardiões materiais de santuários dracônicos participaram da Vigília das Escamas, origem dos nogards. Os oleakes preservaram a origem Olek, embora compartilhassem refúgios e saberes com habitantes materiais. A história admite parentescos e heranças de contato sem declarar que todo povo nasceu dos Eldenari.



Da ascendência ao direito. Durante a II e a III Eras, cortes usaram genealogias para reivindicar terras e monumentos. Uma filiação remota não demonstra posse sobre cada ruína ou responsabilidade por cada ato dos ancestrais. Adoção, convivência e alianças de abrigo também criaram pertencimentos. A comparação entre histórias de origem deve distinguir linhagem, formação cultural e criação de um estado. Dorgamar, Pellanor, Thaelorien e a Confederação Orc pertencem a etapas políticas posteriores às comunidades que os constituíram.



Povos e origens de Virtude



Guia para comparar as origens, a aparência, as comunidades e os marcos históricos dos povos de Virtude.

| Campo | Descrição |
| --- | --- |
| Referência temporal | I–III Eras |
| Natureza | Síntese histórica de continuidade |



As origens se cruzam. Os povos materiais preservam diferentes graus de ancestralidade Eldenari; as linhagens élficas têm raízes Aelthir, e os oleakes vêm dos Olek de Eomundus. Os nogards reúnem guardiões materiais e herança dracônica por um pacto de mana. Essas origens não exigem que toda família tenha a mesma genealogia. Os dossiês distinguem o que forma um povo, os estados que surgiram depois e as tradições religiosas associadas a cada história.



Ler os marcos históricos. O ano 1 da I Era é o horizonte convencional dos primeiros dragões. Cerca de 2100 indica os primeiros assentamentos Eldenari identificados, não o nascimento de todas as pessoas desse povo. A Dispersão dos Vales recebe o intervalo de síntese de cerca de 3600 a 5800. A Travessia das Sete Portas é situada em cerca de 5990. Muitos processos da II Era continuam sem ano exato; uma identidade coletiva pode se consolidar antes de possuir um nome de reino.



Pessoas em seus próprios contextos. Aparência, parentesco e memória são partes de uma história, sem impor caráter ou profissão. Cidades contêm moradores de origens diferentes. Um povo pode viver em vários reinos, e um reino pode reunir vários povos. No início de 788, os goblins não possuem estado soberano próprio, a Confederação Halfling fica além de Velkar a oeste e os elfos altos têm formações políticas distintas no norte e no leste. Os Thul Verenari conservam um dossiê próprio, com informações reservadas separadas do conhecimento local.

## 48. Implantação do dossiê dos povos



Wikia 0.36: 631 artigos, doze dossiês centrais de povos, sete verbetes de povos criados e dois artigos de síntese. Dez imagens novas e reaproveitamento das ilustrações históricas de Eldenari e dragões. Novos intervalos aproximados são identificados como expansão de continuidade, sem alterar datas antigas ou o segredo dos Thul Verenari.



A Dispersão dos Vales integra a cronologia geral como EV-184, com intervalo de síntese c. 3600–5800 da I Era e referência RC-PO01. Os 183 marcos anteriores são preservados. A cronologia passa a reunir 184 registros, mantendo 84 vínculos de personagens.


## 49. Nogards — história e organização na III Era

### RC-NG01 — História e alcance da expansão

Expansão autoral autorizada sobre a III Era. Preservam-se Vigília na II Era, início documental da expansão em 521, Apresamento em 778 e acordo provisório em 786. A síntese anterior a 521 permanece sem novas datas exatas. Povo, estado, casas, consórcios e cultos possuem interesses distintos.

### RC-NG02 — Política e casas

Câmara das Escamas negocia receita, serviço e títulos. Casas de Embarcação articulam parentesco, adoção, trabalho e patrimônio com direitos desiguais. Azhvar VIII depende de concessões; Sevra Khor e Drazhen Ul disputam política naval. Nenhuma genealogia ou coroação não documentada é fixada.

### RC-NG03 — Economia e trabalho

Escama de prata com três placas preservada. Agricultura, pesca, conservação, estaleiros, importações e crédito sustentam rotas. Mesa do Lastro é um consórcio privado; Mirasse continua pertencendo a Thaelorien. Pátios da Quilha são setor de oficinas, não monopólio imperial.

### RC-NG04 — Cultura e religião

Costumes da Vigília variam entre comunidades; cuidado, aprendizagem e adoção coexistem com desigualdade. Santuário da Vigília do Porto integra a Corte do Estreito. Veyra Tal coordena acolhimento sem controlar todos os cultos. Dragões históricos não equivalem automaticamente a deuses.

### RC-NG05 — Forças navais

Frota dos Estreitos é o nome coletivo dos comandos e embarcações mobilizadas. Alimentação, reparo, tripulação e financiamento limitam campanhas. Armas e sinais pré-industriais; mana especializada não concede poderes universais. Não são inventados efetivos, guerras novas ou vitórias.

### RC-NG06 — Relações externas

Acordo provisório dos Ancoradouros designa o episódio já registrado em 786. Novas disposições: comunicação de retenções, registro de taxas contestadas e negociação de acessos. Oleakia preserva soberania; nenhum ancoradouro estrangeiro passa automaticamente ao império.

### RC-NG07 — Aparência padronizada

Referência principal v36-nogards: meio-dragões bípedes com feições humanoides expressivas, nariz e lábios legíveis, escamas integradas, cabelos possíveis e chifres ou cristas variados. A imagem contém variação individual, inclusive traços mais dracônicos; não impor cabeça reptiliana alongada a todos. Preservar variação de idade, cor, corpo, roupa e postura. Asas, sopro e magia não são universais. Azrek conserva chassi e atividade, recebendo imagem corrigida. Traços individuais de Azhvar e Sevra já documentados são preservados.

### RC-NG08 — Personagens e transmissão

Novos perfis de Azhvar VIII, Sevra e Drazhen desenvolvem pessoas já citadas. Narevi Senn e Veyra Tal são novas personagens; sobrenomes não estabelecem parentesco automático. Azrek recebe passado de oficina sem resultados novos para a temporada de 788. Dossiês completos do capítulo 50 são parte normativa desta edição.

## 50. Dossiês dos Nogards na III Era

### Os Nogards na III Era

Dos pactos entre santuários à potência naval: governo, trabalho e disputas no início de 788.

Antes da expansão imperial: A Vigília das Escamas pertence aos primeiros séculos da II Era. Muito antes da expansão documentada em 521 da III Era, os nogards viviam em comunidades de pesca, navegação, cultivo insular e conservação de santuários. Azhren da Primeira Escama reuniu comunidades; sua memória passou a sustentar interpretações concorrentes sobre cuidado e autoridade. A existência desse povo antecede a dinastia Khor-Azhar e não depende de um título imperial.

O caminho para um império naval: Nos primeiros séculos da III Era, casas de embarcação associaram parentes, tripulações e credores para manter barcos que uma família isolada não conseguiria financiar. A proteção de comboios ampliou a influência dos comandos navais. A partir de 521, a expansão Khor-Azhar tornou a cobrança sobre passagens um instrumento imperial. Essa data marca a expansão documentada, não a fundação de Nogard. Comunidades negociaram proteção, mas também perderam autonomia sobre ancoradouros.

A sociedade que sustenta as frotas: O poder marítimo depende de agricultores, pescadores, salineiros, tecelões, carpinteiros e trabalhadores de cais. Mulheres e homens podem chefiar casas, comandar navios e dirigir oficinas. Famílias com pouco patrimônio entram nas casas como tripulantes ou dependentes, sem receber a mesma voz que seus financiadores. O trabalho remunerado convive com obrigações de serviço, dívidas e associações de auxílio.

Uma paz incompleta: O Apresamento das Três Bandeiras, em 778, expôs conflitos entre documentos, seguros e propriedade da carga. A crise com Oleakia levou ao acordo provisório de 786. No início de 788, Azhvar VIII Khor-Azhar governa com receitas disputadas. Sevra Khor propõe tratados e Drazhen Ul exige presença militar permanente. Nenhum dos dois representa sozinho os nogards, e os oleakes mantêm sua própria autoridade sobre os acessos de Oleakia.

Percursos para leitura: A Câmara das Escamas explica a negociação política; as Casas de Embarcação, o parentesco e o crédito; a Frota dos Estreitos, os limites do poder militar. A Escama e os mercados de Nogard e os Costumes da Vigília mostram como o cotidiano atravessa essas instituições. Azhvar VIII Khor-Azhar, Sevra Khor, Drazhen Ul, Narevi Senn e Varesh Khor permitem acompanhar interesses que às vezes cooperam e às vezes colidem.

### Câmara das Escamas

Conselho de casas e comandos de frota que negocia receita, serviço naval e títulos de ancestralidade.

Composição e acesso: A Câmara das Escamas reúne delegados de casas reconhecidas e comandos de frota na Corte do Estreito. O imperador preside ou envia um representante. A influência acompanha navios, receita e alianças, sem equivaler a uma representação igual de toda a população. Oficinas e comunidades podem apresentar petições por intermédio de uma casa ou pedir uma audiência; esse acesso depende de relações e pode ser contestado.

O que se decide: A Câmara negocia repartição das cobranças de passagem, obrigações de escolta e reconhecimento de títulos associados a Khorvath e Varesh. Um título ritual não torna o portador dono dos dragões históricos nem concede soberania sobre um santuário estrangeiro. O imperador nomeia comandos e expede ordens, mas precisa obter navios, recursos e obediência para executá-las.

Sessões e dissenso: Propostas são lidas por escrivães, discutidas e registradas com as obrigações assumidas por cada casa. Quando um acordo não se forma, o adiamento de verbas e o fornecimento incompleto de tripulações podem bloquear uma decisão já anunciada. Sevra Khor busca garantias comerciais verificáveis; Drazhen Ul pede recursos para ocupação. Pequenas casas temem pagar por campanhas cujo lucro ficará com as maiores.

### Casas de Embarcação

Associações nogards de parentesco, trabalho e patrimônio naval, com direitos desiguais entre seus membros.

Uma casa para além do sangue: Uma Casa de Embarcação pode reunir parentes, famílias adotadas, mestres de ofício e tripulantes contratados. Seu núcleo é a continuidade de barcos, conhecimentos e compromissos. Ingressar por serviço ou acolhimento é possível, mas não transfere automaticamente participação patrimonial ou voz na escolha da chefia. Casamentos entre casas podem fortalecer alianças sem fundir todos os seus bens.

Contratos e dependência: Cotas de embarcação distribuem investimento, perdas e receitas. Oficinas recebem adiantamentos; trabalhadores podem aceitar pagamento parcialmente vinculado ao retorno de uma viagem. Uma temporada ruim prolonga dívidas. Os compromissos escritos e os testemunhos de cais tornam possível cobrar uma obrigação, mas as casas mais ricas sustentam disputas por mais tempo.

Serviço e pertencimento: Cada casa reconhecida negocia fornecimento de navios, marinheiros ou dinheiro à defesa. Filhos aprendem ofícios entre familiares e mestres contratados, e podem deixar a casa ao atingir autonomia de trabalho. Narevi Senn defende que dívidas não aprisionem aprendizes. A identificação de uma casa em um navio não significa que toda sua tripulação apoie a política da chefia.

### A Escama e os mercados de Nogard

Alimento, construção naval, moeda e crédito sustentam uma economia insular vulnerável a bloqueios e colheitas ruins.

Alimentar as ilhas: Pesca, hortas, pomares e pequenos cultivos insulares abastecem moradores e tripulações. A conservação por sal e secagem permite preparar viagens. Grão, madeira de determinadas dimensões, fibras e metais também chegam de outros portos. Nem toda ilha produz o mesmo, e a interrupção de rotas encarece alimento antes de enfraquecer uma muralha.

O trabalho dos portos: Estaleiros empregam carpinteiros, calafates, cordoeiros e artífices de ferragens. Tecidos de vela, resinas, tonéis e peças de reposição formam circuitos próprios. Os Pátios da Quilha oferecem reparo e aprendizagem na Corte do Estreito. Conhecimentos de equilíbrio e materiais circulam entre oficinas; o percurso de Azrek Vhar até os vortics é um uso especializado desse saber, sem tornar os barcos comuns veículos de mana.

Moeda, tributo e caução: A Escama é a moeda de prata com três placas usada em Nogard; ouro aparece em grandes pagamentos. Cobre, moedas estrangeiras e crédito têm aceitação negociada. Valor nominal e quantidade de metal podem divergir conforme desgaste e origem. Taxa de passagem remunera a autorização; caução garante obrigações e deve ter condição de restituição. Confundir as duas práticas permite cobranças abusivas.

Crédito e interesses: A Mesa do Lastro reúne armadores e agentes de seguro. Ela adianta recursos e distribui riscos, mas pode exigir garantias sobre receita futura. Duplicar seguros sem declarar beneficiários transfere perdas a terceiros, como mostrou o Apresamento das Três Bandeiras. Varesh Khor participa desse ambiente. Seu negócio não equivale ao tesouro imperial, embora ambos dependam dos mesmos portos.

Mirasse e o continente: Mirasse fica em Thaelorien, na margem continental diante de Nogard. Seus negociantes tratam com casas nogards sem que a cidade pertença ao império. A estrada para Edramil ajuda a conectar cargas marítimas e caminhos continentais. Tarifas estáveis favorecem oficinas e compradores; ocupações militares podem assegurar um ponto de desembarque e destruir a confiança necessária ao comércio.

### Mesa do Lastro

Consórcio de armadores e agentes de seguro com negócios nos portos ligados a Nogard.

Origem e funcionamento: A Mesa do Lastro reúne investidores e agentes que financiam fretes, avaliam garantias e dividem riscos de viagem. Mantém correspondentes em diferentes portos, contratados conforme cada negócio. A pertença ao consórcio não concede cargo imperial. Relações familiares com oficiais facilitam acesso, mas não dispensam licença ou audiência.

Quem assume a perda: Contratos precisam distinguir dono do navio, proprietário da mercadoria, credor e beneficiário do seguro. Uma carga pode envolver vários interessados legítimos. Varesh Khor acompanha contas e garantias e explora a vantagem de conhecer os documentos antes de outros negociantes. Famílias de marinheiros enfrentam dificuldades quando a indenização pela carga tem prioridade prática sobre auxílio aos dependentes.

Disputas em 788: O consórcio prefere rotas previsíveis, mas seus membros divergem sobre o custo da proteção naval e a vantagem de concessões exclusivas. Parte pode financiar escoltas e outra reclamar da mesma cobrança. A Mesa tem interesses próprios; sua atuação não deve ser lida como vontade uniforme de todos os nogards.

### Frota dos Estreitos

Nome coletivo dos comandos navais a serviço do império, abastecidos por casas com interesses e recursos diferentes.

Comando e mobilização: A Frota dos Estreitos reúne navios de serviço imperial e embarcações fornecidas por casas sob obrigações negociadas. Azhvar VIII Khor-Azhar distribui comandos; a Câmara das Escamas discute contribuições. Não existe uma reserva ilimitada de navios e tripulações. Reparos, períodos de pesca e transporte de alimento condicionam o tempo que uma força pode permanecer mobilizada.

Como se combate: Escolta, reconhecimento de canais e bloqueio são atividades centrais. Embarcações à vela e a remo transportam arqueiros, lanceiros e equipes de abordagem com escudos e ganchos. Sinais de bandeira, luzes e mensageiros coordenam distâncias curtas. Armaduras pesadas cansam a tripulação e agravam riscos no mar; proteção de placas e couro varia conforme função. Escamas não tornam ninguém invulnerável.

Mana e seus custos: Artífices podem preparar instrumentos e reparos especializados, conforme formação e recursos. Não se presume que cada marinheiro possua sopro, asas ou magia. Conduzir mana exige conhecimento, manutenção e descanso; não substitui água potável, vela íntegra ou leitura de correntes. O acesso a especialistas é disputado entre comandos e serviços de porto.

Limites da ocupação: Drazhen Ul sustenta que guarnições nos estreitos reduzem surpresas. Sevra Khor argumenta que ocupação sem acordo multiplica resistência e despesas. A defesa oleake utiliza depósitos dispersos, refúgios e acessos que grandes navios não controlam. O acordo provisório de 786 não resolve quem arrecada, fiscaliza e responde por cada incidente. Nenhuma vitória ou guerra nova é declarada no início de 788.

### Costumes da Vigília

Memória dos guardiões, cuidado comunitário e transmissão de ofícios nas comunidades nogards.

Uma memória vivida: A Vigília das Escamas é lembrada por refeições compartilhadas, lâmpadas protegidas do vento e relatos sobre os guardiões que sustentaram filhotes. Os costumes variam entre ilhas e casas, sem calendário idêntico obrigatório. Participar de uma vigília pode significar devoção, vínculo familiar ou compromisso comunitário. Crianças recebem a história por narradores e tarefas de cuidado.

Ritos de aprendizagem: Aprendizes apresentam uma peça, um reparo ou um serviço diante de quem os ensinou. O reconhecimento depende da utilidade e do testemunho, não de exibir poderes dracônicos. Cordas trançadas e placas pequenas podem registrar pertencimentos ou lembranças, sem constituir um alfabeto universal. Músicas de trabalho marcam remadas e içamento de velas; em casa, histórias preservam também fracassos e perdas.

Família, acolhimento e desigualdade: Parentesco pode incluir adoção e cuidado continuado. Comunidades mantêm fundos e refeições de auxílio para feridos e dependentes de tripulantes mortos, mas a cobertura depende de recursos locais. A invocação do cuidado ancestral não impede exclusões. Veyra Tal critica casas que celebram a Vigília enquanto recusam auxílio a trabalhadores endividados.

Culto e poder: Azhravyr, Khorvath e Varesh recebem devoções com ênfases diferentes: formação do mundo, ofício e travessia. Dragões históricos e presença divina não são categorias idênticas. A memória de Azhren pode justificar solidariedade entre comunidades ou precedência dinástica. Não há uma religião única imposta pela aparência, e cor de escama não define crença ou posição política.

### Santuário da Vigília do Porto

Espaço de acolhimento e memória dracônica junto aos cais da Corte do Estreito.

Lugar e uso: O Santuário da Vigília do Porto é um dos lugares de culto da Corte do Estreito. Possui pátio aberto, nichos de lâmpadas e um abrigo mantido por doações de moradores e tripulações. As cerimônias recordam os primeiros guardiões, mas as tarefas diárias pertencem ao porto: preparar alimento, limpar o abrigo e receber notícias de embarcações atrasadas.

Veyra Tal e o acolhimento: Veyra Tal coordena refeições e testemunhos de auxílio. O santuário acolhe náufragos e feridos antes de negociar ressarcimento com casas. Isso gera dívidas materiais e pressão de doadores que querem prioridade para seus dependentes. Ofertas são anotadas separadamente dos auxílios para tornar visível quem paga e quem é atendido.

A disputa pela memória: Representantes dinásticos procuram associar cerimônias públicas à proteção imperial. Outros devotos lembram que o pacto dos guardiões foi de cuidado, não licença para conquista. A Câmara das Escamas pode reconhecer títulos, mas não controla cada narração feita no pátio. Visitantes devem respeitar o uso comunitário e a conservação do abrigo.

### Pátios da Quilha

Conjunto de oficinas e rampas de reparo naval na Corte do Estreito.

Trabalho junto à água: Os Pátios da Quilha são oficinas e rampas usadas para construir e reparar embarcações de casas diferentes. Madeira precisa secar; peças de reposição e resinas ocupam armazéns; a maré condiciona o acesso aos cascos. A denominação designa um setor de trabalho e não uma corporação que possua todos os estaleiros de Nogard.

Mestres e aprendizes: Narevi Senn dirige uma oficina e negocia prazos com fornecedores e oficiais. Mestres recebem aprendizes mediante compromisso de ensino e serviço. Salários atrasados, encomendas militares urgentes e madeira inadequada podem produzir conflitos. Uma embarcação lançada antes do tempo transfere o risco aos marinheiros.

Saber que viaja: Gabaritos, desenhos e demonstrações preservam técnicas; mestres também guardam segredos que valorizam seu trabalho. Conhecimentos de distribuição de massa e resistência das juntas circulam entre trabalhadores que mudam de porto. Azrek Vhar aprendeu nesse ambiente antes de adaptar sua experiência à preparação de vortics, atividade que exige especialistas próprios.

### Acordo provisório dos Ancoradouros

Designação adotada para as disposições provisórias de 786 entre Nogard e Oleakia.

O que o acordo representa: O acordo provisório de 786 conteve parte da crise naval sem encerrar disputas por taxas e ancoradouros. Conhecido nos portos como Acordo provisório dos Ancoradouros, preserva as posições das partes enquanto permite tratar incidentes sem interromper toda a circulação.

Disposições e execução: O acordo estabelece comunicação de retenções de embarcações, registro das cobranças contestadas e negociação de acessos autorizados, com mensageiros de ambas as partes. A obrigação de registrar um incidente não significa concordar com ele. Comandantes e comunidades precisam verificar quem ordenou uma cobrança e a que acesso ela se aplica.

As tensões que permanecem: Sevra Khor acompanha tratativas para converter garantias pontuais em práticas estáveis. Drazhen Ul considera a execução vulnerável a evasões. Ima Olek defende a autonomia das comunidades oleakes e exige que controle de navegação não se converta em ocupação terrestre. O acordo não resolve todos os reclamos sobre santuários nem apaga perdas anteriores.

### Azhvar VIII Khor-Azhar

Imperador de Nogard que equilibra comandos navais, casas credoras e pretensões de ancestralidade.

Poder recebido e poder negociado: Azhvar VIII Khor-Azhar governa a partir da Corte do Estreito. Apresenta os interesses da dinastia como continuidade da proteção oferecida pelos dragões, mas depende de receita e concessões para obter obediência. Nas audiências, procura ouvir separadamente credores e comandantes antes de reuni-los. A informação que cada parte esconde é um dos recursos de seu governo.

Entre dois caminhos: O imperador recebe propostas de Sevra Khor para consolidar comércio por tratados e de Drazhen Ul para ocupar passagens. Pode conceder uma escolta e adiar uma campanha para preservar alianças. Sua margem de decisão diminui quando casas comprometem receitas futuras com a Mesa do Lastro. Prefere compromissos que conservem sua autoridade de árbitro, mesmo que perpetuem ambiguidades.

Aparência e presença: Escamas bronze escurecido, cabelo cinza-escuro penteado para trás e um chifre mais curto que o outro. O rosto conserva nariz, lábios e expressão humanoides sob escamas integradas. Usa manto azul profundo com fecho de três placas; escuta contas com atenção e apresenta concessões materiais como reconhecimento de lealdade.

### Sevra Khor

Oficial nogard que defende tratados comerciais, fiscalização verificável e limites às ocupações.

Uma oficial das passagens: Sevra Khor atua na articulação entre comandos, agentes de porto e negociantes. Defende expandir o comércio por tratados porque uma passagem segura exige compradores, abastecimento e confiança. Não rejeita escoltas nem inspeções, mas pede obrigações registradas e responsáveis identificáveis. O sobrenome Khor, compartilhado por outras pessoas, não prova parentesco próximo ou acordo político.

A prática dos tratados: Após o acordo provisório de 786, acompanha a comunicação de incidentes entre Nogard e Oleakia. Prefere ouvir pilotos e trabalhadores antes de fixar uma condição de acesso. Seus adversários afirmam que reduz a liberdade dos comandantes; Sevra responde que uma cobrança arbitrária pode custar mais do que rende. Ela também aceita garantias que pequenos negociantes têm dificuldade de oferecer, limite que seus aliados precisam enfrentar.

Rivalidade e risco: Drazhen Ul acusa sua política de expor os portos a bloqueios. Sevra considera que ele transforma proteção em dependência de guarnições. Ambos procuram apoio na Câmara das Escamas e usam a memória ancestral como argumento. O debate antecede a crise de Marevim e possui causas locais.

Traços individuais: Escamas escuras, olhos amarelados e chifres curtos serrados após um acidente. Cabelo escuro em trança curta; rosto humanoide escamado, casaco azul-esverdeado de trabalho e pasta de documentos protegida da água. Sua limitação física não reduz sua competência naval.

### Drazhen Ul

Comandante nogard que propõe ocupação de estreitos para assegurar navegação e abastecimento.

A segurança pela presença: Drazhen Ul sustenta que taxas acordadas não bastam quando um ancoradouro pode fechar durante uma crise. Defende guarnições, patrulhas permanentes e depósitos controlados. Seu argumento encontra apoio em casas que perderam cargas e em oficiais cuja posição depende de comandos ativos. Também exige despesas que essas mesmas casas nem sempre querem pagar.

Método e contradição: Valoriza exercícios de abordagem, conhecimento de canais e disciplina de abastecimento. A força que pretende manter precisa ser alimentada por rotas cuja instabilidade justifica a ocupação. Narevi Senn contesta prazos de reparo impostos por seus agentes. Drazhen admite adiar saídas por risco de casco, mas reluta em expor essa dependência em público.

A disputa com Sevra: Acusa Sevra Khor de conceder a comunidades estrangeiras poder sobre a segurança nogard. Ela aponta que patrulha não domina todos os túneis e acessos oleakes. Nas sessões da Câmara, transforma relatos de cargas perdidas em argumentos por verbas; seus adversários exigem que apresente também o custo dos navios imobilizados. No início de 788, sua proposta segue em disputa.

Aparência: Robusto, escamas verde-ardósia, olhos âmbar, crista baixa e cabelo castanho preso na nuca; cicatriz na sobrancelha esquerda. Feições humanoides escamadas. Usa colete de placas sobre tecido azul e leva instrumentos de navegação. Evita ornamentos que prendam em cordas.

### Narevi Senn

Mestra de estaleiro que disputa prazos, pagamento e liberdade de aprendizagem com casas e comandos.

A oficina: Narevi Senn dirige uma oficina dos Pátios da Quilha. Aprendeu por serviço e passou a assumir reparos em nome próprio depois de reunir ferramentas e parceiros. A reputação de seu trabalho cresceu com reparos que voltaram ao mar sem exigir correções imediatas. Contrata por tarefa e mantém aprendizes sob compromisso de ensino, com tempo reservado à demonstração de técnicas.

Uma quilha não obedece a decreto: Recusa madeira inadequada e exige registrar quando um oficial manda antecipar o lançamento de um casco. Drazhen Ul considera algumas exigências lentas; Narevi responde com inspeções e cálculos de material. Defende quitação de salários antes da repartição do lucro de uma encomenda. Sua oficina também depende de crédito e não consegue oferecer trabalho em todas as temporadas.

Família e trabalho: Narevi participa de fundos locais para trabalhadores feridos e contesta dívidas usadas para impedir a saída de aprendizes. Troca conhecimentos com oficinas que recebem competidores de vortics, mas não é declarada responsável por toda a preparação de Azrek Vhar.

Aparência: Escamas cinza-esverdeadas, cabelo castanho em trança grossa, um chifre arredondado e outro estreito. Rosto humanoide expressivo e dedos manchados de resina. Avental ocre, mangas dobradas e ferramentas de medida distinguem seu ofício sem substituir seus traços individuais.

### Veyra Tal

Cuidadora do Santuário da Vigília do Porto que confronta a distância entre memória ancestral e assistência cotidiana.

O cuidado como obrigação: Veyra Tal coordena acolhimento no Santuário da Vigília do Porto. Mantém relação com cozinheiros, pescadores e famílias de tripulantes. Para ela, a continuidade da Vigília aparece em quem recebe alimento e abrigo. Seu trabalho exige negociar combustível, turnos e pagamento de reparos, além de conduzir relatos e cerimônias.

Doadores e dependentes: Recusa conceder prioridade apenas pelo valor da oferta, mas a queda de doações pode reduzir a capacidade do abrigo. Publica contas por leitura comunitária para incluir quem não lê. A Câmara das Escamas ouve suas petições quando elas chegam por uma casa, condição que Veyra critica. Não possui autoridade sobre todos os santuários ou cultos nogards.

Presença individual: Nogard idosa, escamas cobre-avermelhadas, cabelos brancos presos e chifres largos curvados para trás. Usa camadas de linho, manto vinho e pequenos adornos de cobre reparados. Seu rosto humanoide escamado é expressivo; fala com humor seco e reconhece pessoas pelo trabalho que compartilhou com elas. Na imagem comunitária que acompanha o artigo, a referência é a vida de seu povo e de seus santuários.

### Nogards

Nos primeiros séculos da II Era, guardiões de santuários dracônicos das ilhas meridionais encontraram ovos que já não eclodiam sem auxílio.

A Vigília das Escamas: Nos primeiros séculos da II Era, guardiões de santuários dracônicos das ilhas meridionais encontraram ovos que já não eclodiam sem auxílio. As famílias dos guardiões reuniam descendentes Eldenari, Tairim e outras comunidades materiais. Na Vigília das Escamas, compartilharam parte de sua estabilidade material com os filhotes por vínculos de mana. O pacto renovado durante gerações transformou as linhagens envolvidas e deu origem aos nogards. Sua origem combina a descendência material dos guardiões e a herança dracônica.

Um povo capaz de continuar: Os nogards geram seus próprios descendentes. Cada nascimento não exige repetir a primeira Vigília nem unir fisicamente um humano a um dragão. A história não é uma receita de criação de soldados: os filhotes e os guardiões foram participantes de um pacto de sobrevivência, cujo cuidado exigiu alimento, abrigo e convivência. A palavra meio-dragões indica essa herança, sem significar que cada pessoa possua metade exata dos poderes ou do corpo de um dragão.

Escamas e feições: Corpos bípedes, escamas, chifres ou cristas e mãos capazes de trabalho fino orientam a ilustração. Cores, formato do focinho, olhos, altura e constituição variam; cobre, bronze, verdes e cinzentos aparecem como referências possíveis. Asas, sopro ou capacidades mágicas não são atribuídos automaticamente a todo indivíduo. Vestes marítimas, roupas de oficina e adornos de culto acompanham ofícios e escolhas. Nenhuma cor de escama demonstra por si só lealdade a uma dinastia.

Azhren e as comunidades: Azhren da Primeira Escama reuniu comunidades ligadas aos antigos santuários. Sua memória foi apropriada por herdeiros que afirmavam ser os únicos sucessores legítimos dos dragões. Outros nogards preservaram a ideia de um pacto de cuidado, que não concedia domínio sobre povos vizinhos. Varesh, a Asa das Marés, e Khorvath, dragões históricos, passaram a receber culto ao lado de Azhravyr. A relação entre memória, divinização e poder permanece disputada entre sacerdotes e famílias.

Povo e império: O Império de Nogard organiza casas, comandos navais e fiscalização de passagens, mas não equivale a todos os nogards. A Corte do Estreito é seu centro político; Mirasse participa das rotas. Marinheiros, negociantes e trabalhadores de cais podem apoiar ou contestar cobranças feitas em nome do império. Famílias que rejeitam pretensões dinásticas não abandonam por isso sua ancestralidade. Os descendentes dos guardiões também conservaram conhecimentos materiais recebidos dos Eldenari.

Em 788: Azhvar VIII Khor-Azhar governa o império. A tensão naval com Oleakia produziu um acordo provisório em 786 e permanece ligada a taxas e ancoradouros. O piloto Azrek Vhar demonstra outro uso de conhecimentos de mana e construção, fora das narrativas de corte. As relações com os dragões são históricas, religiosas e de linhagem; não dão ao império autoridade automática sobre ovos, santuários ou sobreviventes dracônicos de outras regiões.

História e organização na III Era: Os Nogards na III Era acompanha a passagem das comunidades e casas à expansão naval Khor-Azhar. A Câmara das Escamas concentra negociação de receita e títulos, enquanto Casas de Embarcação reúnem parentesco, trabalho e crédito. A Frota dos Estreitos depende de oficinas, alimento e tripulações. Nos Costumes da Vigília, o cuidado ancestral também fundamenta críticas às obrigações impostas pelos poderosos.

### Império de Nogard

Terra dos meio-dragões, cujo império insular controla passagens orientais do Mar das Espadas.

Escalas e documentos: O Guia recomenda confirmar portos autorizados e documentos antes da travessia. Na Corte do Estreito, as tratativas comuns passam por agentes, oficiais e casas de serviço.

Governo e interesses em 788: Azhvar VIII Khor-Azhar negocia serviço e receita na Câmara das Escamas. Sevra Khor defende comércio por tratados; Drazhen Ul propõe presença militar nos estreitos. A Mesa do Lastro e as Casas de Embarcação financiam viagens e disputam garantias. Os Pátios da Quilha e o Santuário da Vigília do Porto mostram atividades que a política de corte não esgota.

### Corte do Estreito

Centro político insular de Nogard, articulado às casas e comandos de frota dos meio-dragões.

Território e vida local: A Corte do Estreito é o centro de referência de Nogard, no núcleo insular do império. Azhvar VIII Khor-Azhar depende de relações com casas e comandos navais, não apenas do título imperial.

Relações e caminhos: A fiscalização de cargas e passagens envolve funcionários, negociantes e trabalhadores. As comunidades de meio-dragões têm posições variadas sobre comércio, ancestralidade e domínio de estreitos. Uma autorização pedida por agente não é necessariamente uma autorização concedida. Acesso ao porto, circulação de carga e audiência de governo são condições distintas.

Dinastia e poder naval: A expansão de Khor-Azhar é documentada a partir de 521. A Câmara das Escamas reúne casas e comandos na disputa por títulos e ancestralidade. No início de 788, Azhvar VIII governa entre projetos de comércio por tratados e ocupação de estreitos. A disputa com Oleakia continua após o acordo provisório de 786.

Cotidiano: Os comandos de frota e as casas dos meio-dragões se articulam neste centro insular. No cais, o trânsito de embarcações liga as decisões da Corte às passagens do estreito.

Acesso à corte: O desembarque e a autorização para circular são etapas próprias. O relato de Nerion Fales mostra a diferença entre o recibo de um pedido e a licença que um oficial aceita.

Porto, corte e trabalho: A Câmara das Escamas articula casas e comandos; os Pátios da Quilha reúnem oficinas de construção e reparo. O Santuário da Vigília do Porto recebe moradores e viajantes. Essas instituições convivem na cidade com mercados e moradias, sem que todos os trabalhadores participem das decisões da corte.

### Azrek Vhar

Azrek veio de Nogard e ganhou atenção em Atlante por manter o vortic estável nas rajadas que atravessam o estuário.

Perfil: Azrek veio de Nogard e ganhou atenção em Atlante por manter o vortic estável nas rajadas que atravessam o estuário. Trabalha com a oficina para equilibrar um chassi largo com propulsores laterais.

Estilo de pilotagem: Conserva espaço para corrigir a trajetória nas curvas expostas e acelera quando o casco volta a alinhar.

Chassi e configuração: Azrek utiliza um chassi largo, com cockpit profundo e dois módulos laterais alongados ligados por travessas visíveis. A separação física dos módulos permite à oficina trabalhar o equilíbrio de cada lado e acomodar seu porte nogard. A proa curta em cunha e os reforços de cobre distinguem esse conjunto da plataforma mais fechada de Torek.

Mana, equipe e pilotagem: A equipe ajusta a condução lateral para as rajadas de Atlante. A largura e a massa dos módulos pedem antecipação nas mudanças de linha, e expõem mais componentes ao desgaste e aos impactos. Azrek acelera quando volta a alinhar o conjunto, em vez de tratar potência como substituto da estabilidade.

Ofício e origem: Azrek Vhar cresceu entre oficinas e serviços de reparo ligados à Corte do Estreito. Aprendeu a observar juntas, distribuição de carga e comportamento de cascos antes de aplicar parte desse conhecimento à corrida. A passagem aos vortics exigiu aprendizagem específica com a equipe; a experiência naval ajuda, mas não substitui a condução de mana.

Aparência nogard padronizada: Azrek tem feições humanoides com nariz e lábios legíveis, escamas cobre-ferrugem integradas ao rosto e às mãos, olhos turquesa, cabelo preto curto preso e dois chifres recurvados curtos. A anatomia segue a referência do povo Nogard. Seu equipamento preserva roupas de piloto e o cockpit profundo do chassi largo; nenhuma asa ou sopro é presumido.

### Varesh Khor

Atua num consórcio de armadores e agentes de seguro.

Perfil: Atua num consórcio de armadores e agentes de seguro. A Mesa possui interesses e parentescos em portos, mas não se confunde com o governo inteiro de Nogard.

Vínculos e atividade: Contador e agente da Mesa do Lastro é a atividade explicitada nos materiais. As fontes não estabelecem uma biografia anterior suficiente para preencher outras etapas de vida como fatos.

Contas e limites de autoridade: Varesh Khor negocia garantias na Mesa do Lastro. Seu acesso a correspondentes e escrituras torna possível antecipar a reação de credores, mas ele não representa toda a Câmara das Escamas nem recebe autoridade sobre passagens apenas por ser nogard. O dragão Varesh da I Era é outra figura, sem identidade ou parentesco estabelecido com este contador.

### União das Tocas de Oleakia

Comunidades oleakes, refúgios e depósitos dispersos numa união de tribos e assembleias.

Terras baixas e refúgios: A União das Tocas de Oleakia reúne oleakes, pessoas pequenas de traços leporinos, em terras baixas e úmidas. Bosques, caminhos, refúgios e acessos costeiros participam da vida local. Depósitos de alimento dispersos e túneis de abrigo favorecem uma defesa que não depende de um único centro. O verbete Oleakes distingue o povo, suas características e seus registros da organização política de Oleakia.

Memória dos Olek: As tradições ligam os oleakes aos Olek de Eomundus e à orientação de Nancy, a Mãe das Tocas. Mira Olek é lembrada pela organização de reservas dispersas. Assembleias e matriarcas preservaram a autonomia das tribos, articulando acolhimento, vigilância e defesa. O Bosque de Aurenval integra esse território vivido.

A União no início de 788: Ima Olek coordena relações sem governar cada toca como propriedade pessoal. A pressão naval de Nogard sobre passagens e ancoradouros provocou confrontos e um acordo provisório em 786. Happidoh, Form e Forty participaram da defesa e da verificação de acessos. Comércio e vínculos entre populações continuam, enquanto taxas e controle costeiro permanecem em disputa.

Hospedagem e autorização: O Guia distingue as autoridades comunitárias de quem oferece hospedagem ou passeio. Nos caminhos de Aurenval, convém confirmar com a comunidade quem autoriza a visita e a quem comunicar o retorno.

Depois de 786: O Acordo provisório dos Ancoradouros reúne disposições para comunicação de incidentes e cobranças contestadas. Ima Olek exige preservar a autonomia das comunidades. Sevra Khor e Drazhen Ul representam posições divergentes em Nogard; nenhum deles substitui a voz das comunidades oleakes na definição de seus acessos.

## 51. Implantação e padronização dos Nogards

Wikia 0.37: 15 artigos novos, 6 artigos ampliados, cinco ilustrações novas, seis vínculos. Mantidos 48 capítulos e 184 marcos históricos; nenhum novo ano de guerra, coroação ou fundação. O episódio de 786 ganha artigo específico sem duplicar EV-083. As demais imagens nogards anteriores são referências históricas/contextuais; a anatomia da imagem do povo orienta as novas figuras.



## 52. Guerras e conflitos — fichas, baixas e continuidade

### RC-GC01 — Guerras e responsabilidade

Dossiês estruturados de dezessete conflitos. Lados políticos e militares distinguem-se dos povos. Governos, casas e comunidades não recebem responsabilidade coletiva automática por uma liderança.

### RC-GC02 — Baixas e efetivos

Todos os intervalos numéricos da ampliação são novos elementos autorais, adotados como estimativas históricas, sem alegar que já constavam dos livros. Mortos incluem falecidos dos ferimentos dentro do recorte; feridos são sobreviventes. População não atribuída aos lados aparece à parte; em repressões, os lados podem incluir civis. Desaparecidos sem confirmação não são mortos certos. Mobilizados acumulados não são efetivo simultâneo.

### RC-GC03 — Recortes e somas

Pontes de Asmarith e Cinzas de Uldar integram Guerra das Nove Vigílias; Casas de Grão e Porta de Cal integram Guerra da Sucessão. A Grande Punição e a ocupação posterior ficam fora da Guerra das Nove Vigílias. A conquista de Quinder possui teatro e contagem externos separados. Crise naval: apenas confrontos de 786, sem somar toda a expansão de 521 em diante.

### RC-GC04 — História e acordos

Preservadas todas as datas prévias. Adotados nomes Arbitragem das Margens (6266 I), Ajuste das Margens (1546 II) e Pacto dos Postos (2388 II), além de fases de campanha identificadas como ampliação. Nenhum novo dia ou mês é criado. Os agrupamentos de Reparos e Postos são alianças do conflito, não estados eternos.

### RC-GC05 — Lideranças

Neravel Issar, Talven Uld, Tervan Rell, Oren Vald, Keldan Orr, Hadran Vossel, Yrsa Hald e Vaeressa Sareth são novos perfis. Vaeressa exerce regência de campanha, sem alterar a sucessão régia. Sobrenomes não criam genealogias. O piloto das Três Bandeiras permanece sem nome ou povo identificados.

### RC-GC06 — Informação reservada e mudança de alianças

Acontecimentos posteriores ao início de 788 ficam em capítulo e artigos sob controle de spoilers. As fichas distinguem autoridades, comandos e lideranças de socorro; nem toda pessoa listada esteve fisicamente no campo. Alianças podem mudar durante uma campanha. Manifestação dissipada não equivale a morte de pessoa; agrupamento sob coerção não implica culpa individual.

## 53. Dossiês de guerras e conflitos históricos

### Guerra dos Reparos

A arbitragem de 6266 encerrou as campanhas e abriu inspeções compartilhadas; a fabricação de peças permaneceu desigual.

| Campo | Descrição |
| --- | --- |
| Datas | 6262–6266 da I Era |
| Local | Canais, oficinas e travessias das cidades Eldenari |
| Causa | Controle dos contratos de manutenção, da irrigação e da circulação de artífices. |
| Estopim | Apreensão de ferramentas e comboios em 6262. |
| Resultado | A arbitragem de 6266 encerrou as campanhas e abriu inspeções compartilhadas; a fabricação de peças permaneceu desigual. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Liga das Margens Abertas | Comunidades a jusante e cidades favoráveis ao acesso às equipes; Eldenari e comunidades materiais associadas | Neravel Issar | 700–1000 | 1500–2100 |
| Pacto dos Contratos | Cidades e patrocinadores que exigiam exclusividade de manutenção; Eldenari; trabalhadores locais de várias origens | Talven Uld | 650–900 | 1300–1900 |

Civis fora dos grupos: 900–1500 mortos e 1600–2600 feridos. Moradores atingidos por combates, fome local e ruptura de canais; não incluídos nos contingentes das duas ligas. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 6262 | Confisco de ferramentas transforma disputa contratual em confronto armado nas passagens. |
| 6263–6264 | Guardas ocupam oficinas e desvios; equipes de reparo passam a viajar escoltadas. |
| 6265 | Falhas de irrigação pressionam financiadores e comunidades a aceitar inspeções conjuntas. |
| 6266 | Arbitragem das Margens encerra as campanhas e institui acompanhamento por cidades e comunidades. |

### A manutenção como poder

Os canais e suportes de mana exigiam trabalho periódico. Uma cidade podia possuir oficinas e materiais sem controlar o curso inteiro da água. Patrocinadores transformaram essa dependência em contratos de exclusividade: quem aceitasse uma equipe rival arriscava perder peças e crédito. A apreensão de ferramentas atingiu profissionais que haviam servido comunidades dos dois lados. A disputa passou a envolver o direito de chegar a uma instalação antes que ela falhasse.

### Dois agrupamentos incompletos

Neravel Issar articulou a Liga das Margens Abertas, reunindo cidades dependentes de reparadores itinerantes e comunidades a jusante. Talven Uld negociou o Pacto dos Contratos em nome de patrocinadores e autoridades que defendiam exclusividade. As duas denominações descrevem alianças de campanha, não reinos estáveis. A Casa das Medidas dividiu-se: membros defendiam a circulação das equipes, enquanto outros protegiam contratos que sustentavam seus aprendizes.

### Campanhas e pontos de passagem

As operações concentraram-se em travessias, depósitos e oficinas. Tomar uma passagem podia deter uma escolta e também impedir que técnicos alcançassem um dique perigoso. Nenhum lado conseguia inutilizar toda a rede sem prejudicar seus próprios fornecedores. Inspeções passaram a ser tratadas como reconhecimento militar, aumentando a suspeita sobre pessoas que precisavam atravessar as linhas. As campanhas de 6263–6264 ampliaram o uso de guardas contratadas e oneraram o transporte de alimento.

### Arbitragem e efeitos

Em 6265, a degradação de instalações que atendiam apoiadores dos dois lados reduziu o valor da vitória local. A Arbitragem das Margens de 6266 estabeleceu inspeções com representantes de mais de uma cidade e voz das comunidades afetadas. Não aboliu dívidas nem distribuiu igualmente os meios de fabricar peças. A memória da guerra reapareceu nas discussões sobre quem poderia inspecionar o Selo: impedir acesso técnico já havia mostrado como um problema reparável podia ganhar escala política.

### Depósitos, aprendizes e circulação

Uma oficina não podia simplesmente acompanhar as tropas. Fornos, bancadas e estoques de peças exigiam instalação e tempo; a captura de seus trabalhadores tinha efeitos maiores do que a perda de uma carroça. As ligas passaram a exigir testemunhas para a entrega de ferramentas, temendo que um empréstimo fosse convertido em confisco. Aprendizes enviados como auxiliares podiam ficar retidos em cidades que recusavam devolver especialistas. A negociação de 6266 incluiu a restituição de conjuntos identificáveis de ferramentas, mas peças consumidas durante a campanha exigiram compensação e prolongaram disputas.

### Quem recebeu voz na paz

Dar voz às comunidades afetadas não lhes concedeu a propriedade das oficinas. Representantes das margens podiam acompanhar medições e contestar impedimentos, mas dependiam de técnicos para demonstrar certos riscos. A Casa das Medidas tornou-se espaço de cooperação e disputa porque seus membros podiam servir de testemunhas e também vender o trabalho cuja necessidade atestavam. A guerra terminou com procedimentos mais compartilhados, preservando uma desigualdade decisiva sobre quem conseguia produzir e interpretar a prova técnica.

### Guerra das Nove Vigílias

As coalizões se fragmentaram; o desligamento negociado falhou durante o cerco final e o Selo rompeu-se. A Grande Punição pertence a uma sequência posterior.

| Campo | Descrição |
| --- | --- |
| Datas | c. 6393–6399 da I Era; sete campanhas |
| Local | Cidades Eldenari, observatórios e rede do Selo; cerco final em Xeo Taoju |
| Causa | Disputa pelo Selo, pela concentração de mana e pelo direito de impor estabilidade às comunidades. |
| Estopim | Resgate de Serath por Maeriel e ataque de Zhaurak à escolta e ao Arquivo de Vel-Samar. |
| Resultado | As coalizões se fragmentaram; o desligamento negociado falhou durante o cerco final e o Selo rompeu-se. A Grande Punição pertence a uma sequência posterior. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Coalizão de oposição ao Selo | Cidades contrárias ao Selo, expedição élfica e aliados variáveis; Eldenari, elfos altos e dragões dissidentes | Serath Namar, Maeriel Sorn, Caerion Thalas, Vaelthar | 8400–10600 | 16000–21000 |
| Defensores do Selo e comandos associados | Cidades ligadas a Avar; forças de Zhaurak com crescente autonomia; Eldenari e dragões; comunidades dependentes das instalações | Avar Seneth, Zhaurak, Khorvath | 10200–13400 | 19000–25000 |

Civis fora dos grupos: 12000–18000 mortos e 18000–28000 feridos. Estimativa da guerra até a ruptura, sem vítimas da ocupação de vinte e três dias ou da Grande Punição. Inclui as vítimas civis de Uldar; não somar novamente. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| c. 6393 · 1ª campanha | Resgate de Serath, ataque a Vel-Samar e formação das coalizões. |
| c. 6394 · 2ª campanha | Batalha das Pontes de Asmarith; Serath impede a inundação dos campos. |
| c. 6395 · 3ª campanha | Disputas por observatórios, depósitos e circulação de mapas. |
| c. 6396 · 4ª campanha | Campanhas de desgaste e ataques às rotas que mantêm fortalezas e ninhos. |
| c. 6397 · 5ª campanha | Cinzas de Uldar; Khorvath rompe com Zhaurak e Saelith retira as bênçãos. |
| c. 6398 · 6ª campanha | Evacuações e propostas de mediação acompanham a concentração das forças em torno de Xeo Taoju. |
| c. 6399 · 7ª campanha | Avar e Serath negociam o desligamento; mensagem retida, intervenção da Ordem e ataque de Zhaurak convergem na ruptura. |
| Após a ruptura | Vinte e três dias de ocupação e, depois, a Grande Punição, perto do limite convencional de 6400; episódios fora das baixas desta ficha. |

### O motivo da guerra

O Selo prometia estabilidade, mas concentrava decisões e recursos. Comunidades que dependiam de sua proteção temiam o desligamento; outras sofriam com a distribuição de mana e recusavam que essa dependência justificasse prisão e coerção. O resgate de Serath tornou pública a crise. A destruição de emissários protegidos em Vel-Samar rompeu a possibilidade de tratar o episódio apenas como disputa interna entre pesquisadores.

### Alianças que mudam

Serath e Maeriel buscavam conter os efeitos do Selo; Caerion conduzia a intervenção da Ordem segundo informações nem sempre atualizadas. Avar procurava preservar a obra e depois aceitou preparar um desligamento. Zhaurak mantinha comandos próprios e radicalizou a violência. Khorvath apoiou o Selo antes de romper com Zhaurak em Uldar. Por isso, a ficha apresenta agrupamentos por fase: não transforma todos os opositores em uma cadeia de comando única nem faz de Khorvath aliado permanente do ataque final.

### Sete campanhas sobre a rede

As forças disputaram observatórios, fortalezas, depósitos e rotas de manutenção. A destruição de um ninho comprometia gerações futuras; tomar uma oficina alterava o acesso a peças para cidades distantes. Trocas de prisioneiros e proteção de campos continuaram sob suspeita. As Pontes de Asmarith, na segunda campanha, e Uldar, na quinta, mudaram tanto os meios de combater quanto as justificativas usadas para prosseguir.

### O cerco e a falha de comunicação

Na última campanha, Avar e Serath prepararam uma intervenção para desligar o Selo. A mensagem que deveria informar Caerion foi retida. A Ordem avançou sem conhecer o acordo, ao mesmo tempo que Zhaurak atacava. A ruptura não decorreu de um único gesto isolado. Khorvath sustentou fundações para permitir evacuação; Maeriel e Zhaurak desapareceram na descarga, e Serath acionou o Pergaminho para conter a travessia do Inconcluso.

### Desfecho e contagem

A destruição da unidade do Selo impediu uma vitória política duradoura. As três partes foram dispersas, e a guerra deu lugar à ocupação e à catástrofe. As cifras reconstituem perdas das campanhas e da ruptura imediata; o destino de desaparecidos sem confirmação fica fora do total de mortos. Khorvath está entre as perdas confirmadas da última fase, enquanto o desaparecimento de Maeriel não é convertido automaticamente em morte contabilizada.

### Caminhos, prisioneiros e mapas

O Círculo das Testemunhas manteve trocas de prisioneiros em corredores onde a passagem de um mensageiro era confundida com reconhecimento militar. Libertações podiam ser adiadas pela falta de um nome ou pela acusação de que o capturado ocultava sua função. A Casa das Medidas forneceu mapas usados tanto para localizar instalações vulneráveis quanto para retirar moradores. Retirar informações de um mapa protegia uma oficina e podia também impedir que uma equipe de socorro encontrasse o acesso necessário. A circulação do conhecimento tornou-se parte da guerra.

### A fragmentação da última aliança

Avar e Serath aproximaram-se na avaliação de que a estabilidade imposta precisava ser interrompida, sem apagar suas divergências anteriores. O entendimento não alcançou a tempo todos os agentes armados. Caerion interpretou o silêncio através do perigo que acreditava enfrentar; Zhaurak agiu segundo seu próprio projeto. A retenção da mensagem de Maeriel é, portanto, um acontecimento político e militar: alterou o conjunto de escolhas disponíveis a um comando. O desfecho mostra o limite de negociar uma intervenção técnica num campo em que as informações chegavam de modo desigual.

### Batalha das Pontes de Asmarith

A coalizão conservou as pontes principais, mas parte dos defensores do Selo escapou; a recusa de Serath em abrir comportas evitou uma inundação deliberada.

| Campo | Descrição |
| --- | --- |
| Datas | c. 6394 da I Era; segunda campanha |
| Local | Pontes e comportas do Asmarith |
| Causa | Controle de uma travessia que conectava abastecimento militar e irrigação de campos habitados. |
| Estopim | Tentativa da coalizão de deter forças adversárias junto às pontes. |
| Resultado | A coalizão conservou as pontes principais, mas parte dos defensores do Selo escapou; a recusa de Serath em abrir comportas evitou uma inundação deliberada. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Coalizão nas pontes | Forças contrárias ao Selo e guardas locais; Eldenari e contingentes élficos altos | Serath Namar, Maeriel Sorn | 260–340 | 620–800 |
| Coluna defensora do Selo | Destacamentos das cidades ligadas a Avar; Principalmente Eldenari | Avar Seneth | 310–420 | 700–930 |

Civis fora dos grupos: 40–70 mortos e 120–190 feridos. Vítimas dos combates e deslocamentos junto à passagem; a inundação ampla foi evitada. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

Perdas já incluídas em Guerra das Nove Vigílias.

| Data / fase | Acontecimento |
| --- | --- |
| Antes da batalha | Concentração de comboios e reforços torna a travessia alvo dos dois agrupamentos. |
| Combate pelas pontes | A coalizão ocupa acessos e propõe abrir comportas para fechar a retirada. |
| Decisão de Serath | A abertura é recusada por ameaçar campos e famílias favoráveis a Avar. |
| Retirada e balanço | Parte da coluna adversária se retira; as pontes permanecem utilizáveis e a coalizão conserva a posição. |

### A posição disputada

As pontes não eram apenas uma passagem de soldados. Barcos, animais de carga e equipes de manutenção dependiam dos mesmos acessos. Quem controlasse a posição podia atrasar reforços e cobrar obediência de moradores. A ofensiva aproximou combatentes de casas e plantações, reduzindo a possibilidade de separar o campo de batalha da infraestrutura cotidiana.

### A escolha das comportas

Uma abertura deliberada aumentaria o fluxo sobre os campos por onde a coluna adversária pretendia escapar. Serath avaliou que os danos atingiriam moradores que não haviam escolhido participar do combate. Recusou a medida mesmo sabendo que parte das tropas poupadas poderia voltar a lutar. Maeriel sustentou a necessidade de conservar a negociação entre comunidades que continuariam vizinhas após a passagem dos exércitos.

### Resultado militar e memória

A coalizão controlou as pontes principais e interrompeu o trânsito imediato de reforços, mas não destruiu a coluna retirada. Comandantes que esperavam uma vitória decisiva trataram a decisão como oportunidade perdida. Nas margens, a lembrança predominante foi a permanência dos campos fora da água. O episódio tornou-se argumento sobre os limites de uma vantagem obtida à custa de pessoas sem papel de comando.

### Lugar nas perdas da guerra

Os totais das pontes já integram a Guerra das Nove Vigílias. Avar aparece como autoridade do campo defensor; não se estabelece sua presença física na passagem. A data aproximada decorre da posição na segunda campanha. Não há dia ou mês seguro para transformar a batalha em aniversário exato.

### O problema depois da passagem

Manter a travessia exigiu reparar superfícies e organizar turnos de circulação. Dar prioridade a reforços atrasava alimento; deixar partir moradores permitia que mensageiros adversários se misturassem ao movimento. Guardas passaram a registrar cargas e acompanhantes, medida que produziu novas retenções. A decisão de não inundar preservou o terreno para cultivo, mas não retirou os soldados de sua vizinhança nem impediu que famílias sofressem requisições durante as semanas seguintes.

### Cinzas de Uldar

Uldar foi destruída; Zhaurak obteve a posição, mas perdeu o apoio de Khorvath e de sacerdotes ligados a Saelith Vora.

| Campo | Descrição |
| --- | --- |
| Datas | c. 6397 da I Era; quinta campanha |
| Local | Cidade neutra de Uldar e suas oficinas |
| Causa | Pressão de Zhaurak contra serviços e abastecimento que atravessavam as linhas de guerra. |
| Estopim | Ataque a uma cidade que mantinha neutralidade e oficinas abertas a comunidades rivais. |
| Resultado | Uldar foi destruída; Zhaurak obteve a posição, mas perdeu o apoio de Khorvath e de sacerdotes ligados a Saelith Vora. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Força atacante | Comandos associados a Zhaurak; Destacamentos Eldenari e apoio dracônico | Zhaurak | 80–130 | 150–240 |
| Defesa local | Guardas das oficinas e moradores mobilizados de Uldar; Eldenari e comunidades materiais residentes | Saelith Vora | 320–470 | 450–680 |

Civis fora dos grupos: 2400–3600 mortos e 1700–2500 feridos. População sem função de defesa atingida por ataque, incêndios e colapsos; valores incluídos no balanço da Guerra das Nove Vigílias. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

Perdas já incluídas em Guerra das Nove Vigílias.

| Data / fase | Acontecimento |
| --- | --- |
| Antes do ataque | A neutralidade de Uldar se apoia em oficinas que servem comunidades de diferentes alianças. |
| Ataque e incêndios | As posições locais são ultrapassadas e a destruição alcança bairros e serviços comuns. |
| Retirada | Saelith Vora organiza a saída de sacerdotes e refugiados. |
| Após Uldar | Khorvath rompe com Zhaurak; a condenação do ataque altera o equilíbrio entre os dragões. |

### A neutralidade e seus interesses

Uldar não era um espaço sem relações econômicas. Suas oficinas serviam comunidades dos dois agrupamentos e dependiam desse trânsito. Os acordos locais buscavam preservar manutenção e abrigo, mas não impediam que comandantes vissem na cidade uma fonte de vantagem para o rival. Zhaurak tratou a circulação de recursos como desafio à sua autoridade.

### Destruição e retirada

A defesa local não possuía meios para sustentar um confronto prolongado com a força atacante e seu apoio dracônico. O colapso de posições foi seguido por incêndios e interrupção de vias de saída. Saelith Vora retirou sacerdotes e acompanhou grupos de moradores, perdendo a posição institucional que lhe permitira abençoar tropas. O salvamento de parte da população não reduziu a escala da perda de casas, alimento e ferramentas.

### Uma vitória que rompe alianças

Zhaurak impediu a continuidade das oficinas, mas converteu o episódio em prova da arbitrariedade de seu comando. Khorvath, que apoiara a construção do Selo, rompeu com ele depois da destruição. A mudança não apaga responsabilidades anteriores: mostra uma aliança que deixou de se sustentar diante das consequências de sua própria campanha.

### Reconstituição das perdas

Uldar é tratada como ataque contra cidade neutra, e não como batalha entre duas coalizões nacionais equivalentes. Guardas e moradores armados estão no lado da defesa; a população restante aparece na linha civil. As faixas são parciais e incluem mortes durante incêndios e colapsos imediatos, sem somar uma segunda vez as pessoas já incluídas nos totais da guerra.

### Perder uma cidade de serviço

A destruição das oficinas reduziu a capacidade de reparar instalações longe de Uldar. Mestres sobreviveram sem ferramentas; outros locais receberam refugiados com conhecimento útil, mas sem recursos para reconstruir a atividade. A saída de trabalhadores redistribuiu técnicas e dependências. As famílias que chegavam a comunidades de um dos campos da guerra precisavam demonstrar que ter servido clientes rivais não significava espionagem. A neutralidade anterior podia converter-se, na retirada, em motivo de suspeita para os dois agrupamentos.

### Guerra dos Diques

O Ajuste das Margens de 1546 impôs fiscalização compartilhada e limites às prioridades vendidas; a liga preservou acesso à água, mas não recuperou todas as cidades perdidas.

| Campo | Descrição |
| --- | --- |
| Datas | 1517–1546 da II Era |
| Local | Quinder: bacias do Taoju e do Asmarith |
| Causa | Concentração do acesso à água e venda de prioridade pela Companhia das Comportas. |
| Estopim | Retenção de água e cobrança de proteção contra inundações agravadas pela própria operação dos diques. |
| Resultado | O Ajuste das Margens de 1546 impôs fiscalização compartilhada e limites às prioridades vendidas; a liga preservou acesso à água, mas não recuperou todas as cidades perdidas. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Liga das Cidades Menores | Cidades e comunidades prejudicadas pelos desvios; Humanos, orcs, elfos negros e artífices anões | Marel Tovan, Berik Oss | 4800–6200 | 9000–12000 |
| Companhia e aliados de montante | Companhia das Comportas e proprietários com prioridade de derivação; Humanos e elfos negros; guardas de origens variadas | Tervan Rell | 4100–5600 | 7800–10500 |

Civis fora dos grupos: 11000–17000 mortos e 7000–11000 feridos. Inclui mortes adicionais ligadas a cercos e privação de água; a parcela indireta é a mais incerta. Feridos não incluem toda a população adoecida. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 1517 | Disputas por vazão e cobrança passam a confrontos armados. |
| 1518–1524 | Marel Tovan articula cidades menores; invasões de canais provocam perda de cultivos. |
| 1525–1531 | Greves de barqueiros e os registros revelados por Berik Oss expõem manipulação das prioridades. |
| 1532–1537 | A liga vence em Baixo Asmarith, mas perde duas cidades em outras frentes. |
| 1538–1545 | O custo dos reparos e a disputa por indenizações enfraquecem os dois agrupamentos. |
| 1546 | Ajuste das Margens estabelece regras de fiscalização e encerra as campanhas principais. |

### Água, propriedade e risco

A Companhia das Comportas surgiu para administrar obras de uma bacia compartilhada. Ao vender prioridade, favoreceu plantações de montante e reduziu o fluxo que irrigava e lavava os terrenos mais baixos. A evaporação agravou a concentração de sais em alguns campos. A empresa cobrava ainda por proteção contra cheias que suas próprias decisões ajudavam a agravar. O controle de registros passou a ter valor militar: uma vazão insuficiente podia ser apresentada como efeito natural da estação.

### A formação da liga

Marel Tovan reuniu cidades menores e comunidades com necessidades diferentes. Agricultores orcs queriam irrigação, pescadores humanos defendiam circulação e proprietários élficos temiam perder terra produtiva. Berik Oss, empregado da Companhia, comprovou alterações nas contas, mas hesitou enquanto sua família dependia do salário. Prisões durante uma greve de barqueiros transformaram sua colaboração com a liga em ruptura com a direção de Tervan Rell.

### Uma guerra de muitas frentes

A liga obteve uma vitória em Baixo Asmarith ao conservar acesso a passagens e obras. Em outras frentes, perdeu duas cidades. A vitória num setor não restituiu automaticamente estoques nem devolveu famílias deslocadas. Xeo Taoju e Samarith participaram por crédito, abastecimento e direitos de margem; moradores e casas das duas cidades apoiaram lados diferentes. Nenhuma dessas posições corresponde ainda à monarquia de Quinder de 788.

### O Ajuste das Margens

O acordo de 1546 criou acompanhamento das medições, limitou a venda de prioridades em períodos críticos e previu contestação de cobranças. A Companhia conservou técnicos e parte dos contratos, agora sujeitos a inspeções externas. A liga não conseguiu uma indenização comum para todos os atingidos. Marel tentou converter sua liderança de guerra em autoridade urbana, provocando resistência dentro do próprio agrupamento.

### Efeitos de longa duração

O conflito fortaleceu a noção de que a operação de uma comporta produz obrigações perante outras margens. Permaneceram dívidas e diferenças entre proprietários, arrendatários e famílias sem título formal. A guerra precede o Império de Vaelen Endor e os canais orientais anões. Sua geografia não deve ser transferida aos futuros reinos de Rácia e Cávia nem às obras posteriores de Dorgamar.

### Como se sustentaram as campanhas

A liga utilizou embarcações rasas para acompanhar canais e transportar alimento a posições sem estrada regular. Proprietários de montante procuravam obrigar adversários a gastar homens na proteção de desvios secundários. Destruir uma comporta podia produzir vantagem imediata e exigir depois uma obra que nenhum dos lados conseguia pagar sozinho. Por essa razão, oficinas e estoques de madeira foram disputados tanto quanto a própria água. O apoio dos barqueiros tornava possível transferir reservas entre cidades e sua paralisação expunha a vulnerabilidade de todos os comandos.

### O custo político de indenizar

Depois da vitória em Baixo Asmarith, a liga discutiu se ressarciria primeiro quem fornecera tropas, quem perdera terra ou quem ainda passava fome. As categorias se sobrepunham sem coincidir. Marel queria recompensar os compromissos que haviam mantido sua autoridade; comunidades menores temiam que uma nova administração repetisse a prioridade vendida pela Companhia. O Ajuste das Margens incorporou fiscalização, mas deixou parte da reparação dependente de negociações locais. A paz alterou as regras de acesso sem produzir uma distribuição igual de patrimônio.

### Guerra das Correntes

A liga venceu e conservou tropas, depósitos e receitas; a proclamação imperial de Vaela em 1896 sucedeu à guerra.

| Campo | Descrição |
| --- | --- |
| Datas | 1881–1895 da II Era |
| Local | Rotas centrais; regiões dos futuros sete Reinos Centrais e Quinder |
| Causa | Abastecimento fragmentado por pedágios concorrentes e recusa de recibos comuns. |
| Estopim | Autoridades de travessia interrompem comboios organizados pela liga de Vaela. |
| Resultado | A liga venceu e conservou tropas, depósitos e receitas; a proclamação imperial de Vaela em 1896 sucedeu à guerra. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Liga do Abastecimento | Cidades e comunidades vinculadas aos pactos de Vaela; Humanos; comunidades orcs; artífices e contingentes de outras origens | Vaela Endorin, Dorrik Venn, Sorenna Vale, Rughan das Duas Margens | 7200–9400 | 13000–17000 |
| Senhorios das travessias | Autoridades e casas que recusavam o selo e os recibos comuns; alianças locais mutáveis; Predomínio humano, com forças contratadas de outras origens | Oren Vald | 8600–11200 | 15000–20500 |

Civis fora dos grupos: 9000–14000 mortos e 11000–16000 feridos. Mortes por combates, cercos e privação de abastecimento atribuíveis às campanhas; não inclui toda a mortalidade das secas anteriores. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 1876–1880 · antecedentes | Pacto dos Celeiros de Reth e organização de reservas e escoltas. |
| 1881 | Campanhas contra postos que interrompem comboios ou recusam recibos comuns. |
| 1887 | Sorenna Vale toma o Posto das Três Argolas; distribuição do grão atinge depósitos de duas aldeias. |
| 1889 | Compensações pelas reservas das aldeias são fixadas. |
| 1892 | Acordo das Contas de Madeira reconhece contribuições comunitárias específicas. |
| 1894 | A casa de Arven-Doss adere ao selo comum e conserva funcionários. |
| 1895 | Cessam as principais campanhas; a liga retém os instrumentos de comando. |
| 1896 · consequência | Vaela é proclamada imperatriz após a exclusão de três delegações. |

### Socorro que se tornou comando

Secas e disputas sucessórias entre 1872 e 1880 ampliaram a escassez nas cidades centrais. Vaela articulou reservas, fornecedores e escoltas por trechos. O acordo sobre como socorrer uma cidade transformou-se em poder para exigir passagem, aceitar medidas comuns e nomear agentes. A recusa de um posto já não era lida apenas como decisão local: podia interromper alimento destinado a uma aliança inteira.

### Adversários heterogêneos

Oren Vald reuniu temporariamente casas de pedágio que temiam perder receita. Outras autoridades combateram a liga em um ano e negociaram adesão em outro. Dorrik Venn coordenava escoltas, Sorenna Vale conduzia operações como a das Três Argolas, e Rughan negociava contribuições com comunidades orcs. Tais acordos não transferiam a Vaela soberania geral sobre todos os orcs ou sobre potências externas.

### Três Argolas e a disputa do grão

A captura de 1887 parecia confirmar que um senhor escondia alimento para especular. Parte das reservas, porém, pertencia a duas aldeias que o haviam entregado como garantia. A distribuição alimentou a força ocupante e moradores próximos, mas retirou sementes dos depositantes. As compensações de 1889 reconheceram o dano sem reconstituir integralmente o tempo de cultivo perdido.

### Vitória e nova ordem

A adesão de Arven-Doss, em 1894, mostra que o encerramento não dependeu apenas da destruição dos postos. Autoridades conservaram funcionários mediante aceitação do selo. Em 1895, a liga mantinha receita, tropas e depósitos que antes eram emergenciais. A proclamação de 1896 formalizou esse poder e produziu um império. Os futuros sete reinos ainda não existiam com as fronteiras da III Era; seus nomes servem aqui como orientação regional.

### A guerra como sucessão de escoltas

As forças da liga evitavam manter todos os contingentes reunidos: proteger um grande comboio numa estrada podia expor depósitos em outra. Escoltas sucessivas dividiam o serviço entre autoridades e tornavam necessário reconhecer recibos entregues por pessoas de fora. Oren Vald procurava romper esse reconhecimento, apresentando a cobrança local como defesa de direitos antigos. Vaela respondia associando passagem e socorro. Cada posto tomado podia fornecer uma nova rota e também exigir o pagamento de uma guarda antes sustentada pelo próprio pedágio.

### Comunidades e anexação

A contribuição negociada por Rughan tinha alcance específico. Um grupo que fornecia animais ou alimento não aceitava, por isso, entregar decisões sobre seus campos à futura corte. A liga ganhou apoio ao reconhecer limites em 1892, mas o novo império herdou meios para reinterpretar essas obrigações. Bar-Terval, em 1904, mostrou o conflito entre a memória dos compromissos e a pretensão de sujeição geral. A vitória das Correntes deixou instituições comuns e uma disputa duradoura sobre o que cada participante havia concordado em entregar.

### Repressão de Bar-Terval

Tropas ocuparam campos, mas a repressão rompeu a colaboração de Rughan com a corte e enfraqueceu a legitimidade dos acordos comunitários.

| Campo | Descrição |
| --- | --- |
| Datas | 1904 da II Era |
| Local | Campos e rotas comunitárias de Bar-Terval |
| Causa | Imposição de responsabilidade coletiva e reféns para assegurar comboios imperiais. |
| Estopim | Ataques contra um comboio seguidos de exigências dirigidas a comunidades diferentes. |
| Resultado | Tropas ocuparam campos, mas a repressão rompeu a colaboração de Rughan com a corte e enfraqueceu a legitimidade dos acordos comunitários. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Força imperial | Administração de Vaela e coluna de cobrança e escolta; Principalmente humanos; auxiliares recrutados localmente | Vaela Endorin, Keldan Orr | 90–130 | 210–300 |
| Resistência comunitária | Grupos locais que recusaram reféns e ocupação; comunidades não eram um comando único; Comunidades orcs e vizinhos humanos | Rughan das Duas Margens | 160–240 | 320–460 |

Civis fora dos grupos: 430–650 mortos e 600–900 feridos. Moradores fora dos grupos de resistência, atingidos por repressão, deslocamento e perda imediata de acesso aos campos. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| Início da crise | Ataques ao comboio provocam envio de uma coluna imperial. |
| Exigência de reféns | Keldan Orr amplia a cobrança para comunidades sem responsabilidade individual demonstrada. |
| Ocupação dos campos | Tropas fecham percursos necessários aos animais e ao abastecimento local. |
| Ruptura de Rughan | O negociador recusa reinterpretar contribuições antigas como submissão geral e rompe com a corte. |

### Do acordo à sujeição

O Acordo das Contas de Madeira reconhecia contribuições específicas de comunidades. Na crise de Bar-Terval, oficiais trataram esse vínculo como fundamento para exigir reféns e prestação coletiva de contas. As comunidades não aceitavam responder por qualquer ataque ocorrido numa rota próxima. O desacordo atingia o significado da colaboração que havia ajudado a formar o império.

### A operação de Keldan Orr

A coluna ocupou campos de circulação dos animais e procurou compelir famílias a entregar pessoas indicadas como garantia. A presença militar podia assegurar um trecho do comboio, mas retirava alimento e mobilidade dos moradores. Alguns grupos organizaram resistência, outros negociaram passagem e houve quem fugisse. A existência desses comportamentos diferentes não impediu que a administração tratasse as comunidades como um conjunto responsável.

### Rughan e a consequência política

Rughan tentara preservar limites para os compromissos comunitários. A repressão tornou insuficiente continuar mediando cada cobrança. Seu afastamento não significou criar um reino orc único ou obter vitória de campo sobre o império. Tornou visível que uma aliança construída por negociação podia ser rompida quando uma das partes mudava unilateralmente o sentido das obrigações.

### Reféns e circulação

Os reféns eram apresentados pela coluna como garantia de cooperação, enquanto as comunidades os viam como pessoas expostas a responder por decisões alheias. A ocupação dos campos cortou trajetos usados para conduzir animais e espalhou a crise para famílias que não haviam resistido com armas. A retirada de rebanhos impedia requisição imediata e deixava áreas sem abastecimento. A perda militar local foi acompanhada por um deslocamento de lealdades que a presença dos soldados não conseguia reverter.

### Guerra dos Postos do Norte

O Pacto dos Postos de 2388 limitou ocupações e repartiu obrigações de passagem; o império reteve alguns postos sem pacificar a região ou recompor as contas.

| Campo | Descrição |
| --- | --- |
| Datas | 2376–2388 da II Era |
| Local | Rede setentrional de travessias e postos, nas relações entre o império e Bergen |
| Causa | Receita de passagem, garantias de guarnição e disputa pelo alcance da autoridade imperial no norte. |
| Estopim | Recusa local a novas exigências de serviço e cobrança sobre postos de travessia. |
| Resultado | O Pacto dos Postos de 2388 limitou ocupações e repartiu obrigações de passagem; o império reteve alguns postos sem pacificar a região ou recompor as contas. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Império de Vaelen Endor | Corte de Odravel III e comandos provinciais; Humanos, auxiliares locais e contratados de outras origens | Odravel III, Hadran Vossel, Halven Reth | 6400–8300 | 11500–15000 |
| Liga das Passagens do Norte | Comunidades e casas de Bergen e das travessias que resistiam às cobranças; Principalmente humanos, com aliados comunitários locais | Yrsa Hald, Sora Hald | 5100–6900 | 9200–12500 |

Civis fora dos grupos: 7000–11000 mortos e 8000–12000 feridos. Moradores atingidos por incursões, deslocamento e interrupção de reservas. Não inclui episódios posteriores da III Era junto à Grande Muralha de Hravn. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 2376 | Incidentes de cobrança e ocupação de postos abrem as campanhas. |
| 2377–2380 | Avanços imperiais asseguram travessias maiores; grupos locais evitam confronto prolongado. |
| 2381–2384 | Ataques a depósitos e rotas secundárias elevam o custo de manter guarnições. |
| 2385–2387 | Casas financiadoras condicionam novas verbas à revisão das obrigações. |
| 2388 | Pacto dos Postos encerra a fase principal de campanhas sem estabelecer fronteira permanente. |

### A rede disputada

Os postos eram casas de cobrança, pontos de abrigo e posições defensivas de alcance variável. Não formavam uma muralha contínua. Odravel III buscava tornar previsíveis o pagamento e o fornecimento de guarnições. Autoridades locais aceitavam certos serviços e recusavam que eles significassem sujeição sem limite. Uma travessia ocupada podia render receita e depender, para sobreviver, de aldeias que rejeitavam o comando que a ocupava.

### Estratégias adversárias

Hadran Vossel concentrou forças em travessias capazes de receber depósitos e proteger comboios. Yrsa Hald articulou o fechamento de ramais e a retirada de reservas de alcance imediato. Seus aliados não obedeciam a uma coroa única. A força local podia perder um posto e preservar capacidade de interromper o abastecimento que o mantinha. O império ganhava posições, mas precisava pagar para continuar nelas.

### O desgaste financeiro

As campanhas exigiram adiantamentos e garantias sobre receitas futuras. Comandantes e credores discordavam sobre quanto de cada cobrança deveria permanecer no norte. Moradores sofreram requisições de ambos os agrupamentos, enquanto transportadores aumentavam o preço dos trajetos arriscados. O custo da presença se tornou um dos argumentos favoráveis à trégua.

### Um encerramento sem fronteira única

O Pacto dos Postos de 2388 previu revisão de exigências e manutenção de certas travessias sob arranjos diferentes. Não tornou Bergen uma província integral nem retirou todos os agentes imperiais. A fase pertence ao governo de Odravel III, anterior à crise sucessória. Seus postos não se confundem com a Grande Muralha de Hravn e com as ameaças narradas na III Era.

### A estação e o custo da guarnição

O frio encurtava parte do trabalho de transporte e tornava a conservação de reservas um problema militar. Hadran priorizava postos capazes de receber mais de um percurso de abastecimento; perder um ramal podia obrigar a abandonar uma posição aparentemente intacta. Yrsa negociava a retirada de estoques antes da chegada das colunas, mas precisava assegurar que os próprios moradores os recuperassem depois. A dispersão protegia recursos da tomada e aumentava o esforço para alimentar grupos locais de defesa.

### A trégua na vida das passagens

As cláusulas de 2388 precisavam ser aplicadas em lugares com obrigações anteriores diferentes. Um posto podia conservar cobradores imperiais e negociar serviço com comunidades que recusavam outra exigência. Em outro, a retirada dos soldados deixava a manutenção de abrigos e pontes aos moradores. A paz diminuiu certas operações, sem cancelar dívidas tomadas para sustentá-las. A corte conservou posições e enfrentou uma receita comprometida, enquanto as comunidades tiveram de reconstruir reservas já consumidas.

### Negociar a mesma passagem

Halven Reth, comissário imperial, defendia receitas prometidas a credores. Sora Hald, negociadora de Bergen, exigia abandonar a taxa sobre rebanhos que passavam pelo mesmo lugar duas vezes numa estação. Os cobradores apresentavam dois serviços; pastores sustentavam que o retorno já estava permitido pelo primeiro acordo. A divergência tornou concreta a discussão sobre sujeição e garantia: manter uma guarnição não resolvia o significado do recibo aceito por cada parte. Hadran tratava da execução militar e Yrsa articulava a defesa local, enquanto Halven e Sora negociavam obrigações que determinavam a continuidade da mobilização.

### Guerra da Sucessão de Vaelen Endor

Nenhum pretendente reunificou o império; a Concordata de 2431 reconheceu os reinos sucessores e encerrou as pretensões efetivas de comando comum.

| Campo | Descrição |
| --- | --- |
| Datas | 2418–2431 da II Era |
| Local | Vaelen Endor e províncias do império em dissolução |
| Causa | Ausência de sucessão reconhecida, receitas comprometidas e disputa por nomeações e concessões. |
| Estopim | Morte de Odravel IV em 2418 sem reconhecimento comum de um sucessor. |
| Resultado | Nenhum pretendente reunificou o império; a Concordata de 2431 reconheceu os reinos sucessores e encerrou as pretensões efetivas de comando comum. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Partidários de Maeressa | Funcionários e casas que defendiam continuidade dinástica Endorin; Predomínio humano; moradores e contratados de outras origens | Maeressa Endorin | 7800–10400 | 14000–18500 |
| Partidários de Aldren | Credores e governadores que exigiam confirmação de concessões; Predomínio humano; contingentes provinciais diversos | Aldren Veyr | 8400–11200 | 15000–20000 |
| Comandos de Soren e alianças de emergência | Tropas da capital e autoridades que buscavam reconhecimento assemblear; Principalmente humanos; guardas urbanas e contratados | Soren Talv | 5900–8100 | 11000–15000 |

Civis fora dos grupos: 22000–35000 mortos e 19000–29000 feridos. População fora dos três agrupamentos militares. As baixas da conquista de Quinder são um teatro externo separado e não se somam a esta ficha sem declarar o recorte. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 2418 | Morte de Odravel IV e apresentação das três reivindicações principais. |
| 2419 | Duas Chancelarias emitem ordens concorrentes e paralisam nomeações. |
| 2420 | Cerco das Casas de Grão interrompe alimento em dois bairros da capital. |
| 2421 | Abertura da Porta de Cal dá a Aldren acesso a depósitos, sem controle duradouro da cidade. |
| 2422–2423 | Autoridades provinciais retêm receitas e passam a negociar sua própria defesa. |
| 2424–2428 · teatro externo | Vaeliss Sareth conquista Quinder enquanto os pretendentes disputam o centro. |
| 2429 | Acordo das Lâmpadas organiza a convivência institucional em Quinder. |
| 2431 | Concordata de Vaelen reconhece os sucessores; o ano seguinte torna-se 1 da III Era. |

### A crise antes da morte

O Segundo Amanhecer ligara expectativas de pesquisa, promessas financeiras e recursos da corte. Dívidas, concessões e garantias reduziam a receita disponível para um novo governante. A morte de Odravel IV não criou esses problemas, mas retirou a autoridade que ainda permitia adiar sua resolução. Cada pretendente prometia preservar a cidade e garantir pagamentos, combinando argumentos dinásticos com interesses materiais.

### Três reivindicações

Maeressa Endorin era sobrinha do imperador e contava com parte dos funcionários. Aldren Veyr invocava uma linha matrimonial mais distante e reunia credores e governadores. Soren Talv comandava tropas da capital e buscava reconhecimento por assembleia de emergência. Nenhum recebeu aceitação comum como imperador de todo o conjunto. A distribuição de selos e salários podia conservar uma repartição e perder a lealdade de uma guarnição.

### A capital e o alimento

Em 2419, nomeações contraditórias permitiram às cidades registrar ordens sem executá-las. No ano seguinte, o cerco atingiu casas de grão e bairros dependentes de suas entradas. Nessa Veld abriu uma passagem noturna mediante compromisso de pagamento de conselheiros. A abertura da Porta de Cal por Rovan Sel, em 2421, ofereceu depósitos a Aldren, mas não os meios para controlar toda a capital.

### A autonomia das províncias

Governadores e assembleias passaram a reter receitas para pagar tropas e fornecedores próprios. Essa retenção dificultava qualquer reconquista do centro e tornava útil negociar com mais de um pretendente. Naerath aproveitou a perda de coordenação para conquistar Quinder entre 2424 e 2428. O conflito externo tinha agentes e perdas próprios: a dissolução imperial não foi uma única batalha travada por três exércitos imóveis.

### Concordata e consequências

A Concordata de 2431 tratou de dívidas, arquivos, depósitos, passagens e direitos. Maeressa renunciou sob condições de proteção a dependentes; representantes de Aldren buscaram garantias patrimoniais; comandos ligados a Soren receberam opções de serviço e desmobilização. Os futuros reinos conservaram instituições imperiais e disputas de fronteira. O ano seguinte passou a ser 1 da III Era, sem ano zero.

### Soldos e mudanças de lealdade

O pagamento de uma companhia podia vir de um credor favorável a Aldren e de uma repartição que ainda reconhecia Maeressa. Na falta de soldo, comandantes negociavam abastecimento com conselhos locais e passavam a aceitar ordens que garantissem continuidade. Isso não tornava cada mudança simples traição pessoal: dependentes, fornecedores e soldados pressionavam por decisões diferentes. A impossibilidade de identificar uma autoridade capaz de pagar favoreceu a autonomia dos governos regionais e prolongou o conflito mesmo quando nenhum pretendente tinha condições de vencer.

### Arquivos e governo depois da guerra

A Concordata precisou distribuir documentos porque propriedade, dívida e serviço eram demonstrados por cópias guardadas em instituições rivais. Levar o arquivo para uma capital sucessora podia favorecer certos credores e dificultar petições de moradores de outra região. Enna Vossel, Maela Torr e Dorven Keld participaram de negociações que davam ao encerramento uma forma administrativa. O trabalho posterior consistiu em tornar possível governar sem fingir que todos os contratos anteriores tinham perdido valor no mesmo dia.

### Cerco das Casas de Grão

O bloqueio foi parcialmente rompido por passagens negociadas; o cerco terminou sem decidir a sucessão.

| Campo | Descrição |
| --- | --- |
| Datas | 2420 da II Era |
| Local | Dois bairros e depósitos de Vaelen Endor |
| Causa | Controle do abastecimento para obter receita e obediência durante a disputa sucessória. |
| Estopim | Bloqueio das entradas de grão e contestação dos responsáveis pelos depósitos. |
| Resultado | O bloqueio foi parcialmente rompido por passagens negociadas; o cerco terminou sem decidir a sucessão. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Forças do bloqueio | Destacamentos alinhados a Aldren e credores que pressionavam depósitos; Guardas e contratados, principalmente humanos | Aldren Veyr | 180–260 | 390–560 |
| Defesa e distribuição dos bairros | Guardas urbanas divididas; depósitos que negociavam com Maeressa e Soren; Moradores e guardas de diversas origens | Nessa Veld, Maeressa Endorin, Soren Talv | 230–340 | 520–740 |

Civis fora dos grupos: 900–1400 mortos e 600–950 feridos. Civis fora dos grupos de defesa e distribuição; inclui mortes atribuídas à privação durante o bloqueio, não todas as mortes dos bairros naquele ano. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

Perdas já incluídas em Guerra da Sucessão de Vaelen Endor.

| Data / fase | Acontecimento |
| --- | --- |
| Abertura do cerco | Entradas de alimento e acessos aos depósitos são bloqueados. |
| Passagem noturna | Nessa Veld negocia garantia de pagamento e abre um trajeto para cargas. |
| Alívio parcial | Novos pequenos percursos reduzem a interrupção, sem restaurar distribuição regular. |
| Fim do episódio | O bloqueio direto cede a outras operações; a autoridade sobre os depósitos permanece disputada. |

### Quem controlava o grão

As casas de grão reuniam alimento, títulos de depósito e obrigações financeiras. Tomá-las não equivalia a possuir todo o conteúdo: mercadores, conselheiros e famílias tinham pretensões distintas sobre a mesma reserva. As forças do bloqueio buscavam condicionar a liberação à aceitação de garantias e à retirada de adversários. Os bairros atingidos dependiam da continuidade dos trajetos, mesmo quando seus moradores não apoiavam qualquer pretendente.

### A decisão de Nessa Veld

Nessa podia facilitar uma saída, mas não criar alimento que deixara de chegar. Negociou uma passagem noturna mediante promessa de pagamento de conselheiros. A operação atendeu parte dos bairros e abriu disputa sobre quem receberia primeiro. Guardas ligadas a Maeressa e a Soren cooperaram em trechos sem abandonar suas ordens rivais. Nessa é liderança de distribuição e negociação, não chefe de todos esses contingentes.

### Um cerco sem decisão dinástica

O alívio reduziu o poder de pressão imediato e permitiu a saída de parte dos moradores. Não encerrou a disputa pelos selos ou pelas rendas. As perdas do episódio estão incluídas na Guerra da Sucessão. A duração interna é conhecida por fases, sem dias e meses seguros para datar cada passagem noturna.

### Distribuir sob bloqueio

A passagem aberta não recebia carga suficiente para atender todos ao mesmo tempo. Responsáveis por depósitos comparavam listas de moradores, comprovantes de entrega e compromissos feitos a guardas. A falta de documentos podia excluir uma família recém-chegada do lugar onde fugira. Conselheiros que prometiam pagamento futuro obtinham vantagens de acesso, enquanto trabalhadores de transporte procuravam garantir ao menos parte da remuneração antes de arriscar o trajeto noturno. O alívio do cerco criou escolhas de distribuição que permaneceram em disputa depois da retirada das forças.

### Conflito da Porta de Cal

Aldren tomou acessos e depósitos, mas não consolidou o domínio da capital; dependentes de Rovan sofreram represálias e perda de direitos.

| Campo | Descrição |
| --- | --- |
| Datas | 2421 da II Era |
| Local | Porta de Cal e depósitos contíguos em Vaelen Endor |
| Causa | Disputa por acesso aos depósitos e pela legitimidade de ordens durante a sucessão. |
| Estopim | Rovan Sel abre o portão a Aldren após obter salvo-conduto para parentes. |
| Resultado | Aldren tomou acessos e depósitos, mas não consolidou o domínio da capital; dependentes de Rovan sofreram represálias e perda de direitos. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Força de entrada | Partidários de Aldren e pessoal do portão que aderiu à abertura; Principalmente humanos | Aldren Veyr, Rovan Sel | 75–110 | 160–230 |
| Defensores das posições internas | Guardas locais vinculadas a Maeressa e ordens concorrentes da capital; Principalmente humanos; auxiliares urbanos | Maeressa Endorin | 95–140 | 190–280 |

Civis fora dos grupos: 60–100 mortos e 120–180 feridos. Pessoas fora das forças envolvidas, atingidas em tumultos, deslocamento e represálias imediatas. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

Perdas já incluídas em Guerra da Sucessão de Vaelen Endor.

| Data / fase | Acontecimento |
| --- | --- |
| Negociação anterior | Rovan Sel obtém compromisso de salvo-conduto para parentes. |
| Abertura do portão | Tropas de Aldren entram e alcançam depósitos. |
| Resposta interna | Guardas e autoridades rivais impedem converter a entrada em domínio de toda a capital. |
| Represálias | Maeressa trata o ato como traição de uma casa; dependentes sem participação perdem direitos. |

### O valor do portão

A Porta de Cal dava acesso a depósitos e trajetos que tornavam possível manter uma força dentro da cidade. Rovan Sel recebeu ordens cuja legitimidade dependia do pretendente que as emitia. Garantir a segurança de parentes tornou-se sua condição para abrir o acesso. A proteção particular ajudou a resolver o problema imediato de uma família sem estabelecer proteção para todos os moradores próximos.

### A entrada e seu limite

As tropas de Aldren atravessaram o portão e ocuparam pontos de armazenamento. A capital, porém, continha outras guardas, percursos e repartições. A força que obtivera a abertura não tinha meios para receber obediência uniforme. A perda de coordenação favoreceu bloqueios internos e acordos de curto prazo, em lugar de uma vitória dinástica.

### Responsabilidade coletiva

Maeressa acusou uma casa inteira de traição, atingindo dependentes que não haviam participado da negociação. O episódio revela como disputas entre pretendentes podiam transformar parentesco e dependência em fundamento de punição. As baixas deste artigo pertencem ao total da Guerra da Sucessão e não constituem perdas adicionais.

### O salvo-conduto e seus limites

A promessa negociada por Rovan assegurava proteção a parentes indicados, sem obrigar todas as guardas da cidade a reconhecer cada condição. O caminho entre a saída de uma casa e a passagem por outra posição continuava sujeito a ordens rivais. Aldren aproveitou a entrada para reforçar presença junto aos depósitos, mas precisava negociar com quem os operava. O episódio não entregou alimento, funcionários e obediência como um conjunto: cada um desses recursos teve de ser obtido separadamente.

### Conquista de Quinder por Naerath

Naerath conquistou Quinder em 2428; o Acordo das Lâmpadas de 2429 preservou Calven III e garantias de culto, sem restituir todas as famílias expulsas.

| Campo | Descrição |
| --- | --- |
| Datas | 2424–2428 da II Era; acordo institucional em 2429 |
| Local | Quinder, Xeo Taoju, Samarith e caminhos de retirada para Valerith |
| Causa | Expansão de Naerath sobre Quinder durante a desagregação imperial; proteção religiosa como justificativa pública. |
| Estopim | Vaeliss Sareth inicia a invasão em 2424 alegando proteger santuários e comunidades. |
| Resultado | Naerath conquistou Quinder em 2428; o Acordo das Lâmpadas de 2429 preservou Calven III e garantias de culto, sem restituir todas as famílias expulsas. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Exército de Naerath | Coroa de Vaeliss e casas associadas; Predomínio de elfos negros, com auxiliares e aliados locais de outras origens | Vaeliss Sareth, Ilvess Nor | 3800–5100 | 7600–10200 |
| Defesas imperiais e urbanas de Quinder | Guarnições remanescentes e casas locais sem comando único; Humanos e elfos negros; contratados e guardas locais diversos | Maeressa Endorin, Aldren Veyr | 5700–7600 | 9800–13100 |

Civis fora dos grupos: 8000–12000 mortos e 10000–15000 feridos. Inclui mortes em cercos e expulsões; deslocados sobreviventes não são mortos. As perdas deste teatro não integram o subtotal dos três agrupamentos da guerra sucessória central. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 2424 | Vaeliss inicia a campanha e apresenta a proteção de santuários como fundamento. |
| 2425–2426 | Forças imperiais e locais perdem coordenação; estradas e reservas são disputadas. |
| 2427 | Aressa Tonn conserva listas de famílias; Ilvess Nor garante corredor de saída e exige animais registrados. |
| 2428 | Consolidação da conquista e expulsão de parte das famílias humanas. |
| 2429 | Acordo das Lâmpadas preserva Calven III, peregrinação e proteção formal de santuários. |

### O contexto da invasão

A disputa de sucessão retirou de Quinder a perspectiva de receber apoio central regular. Vaeliss Sareth apresentava sua força como proteção a comunidades e santuários ameaçados. A campanha também ampliava a receita e a posição territorial de Naerath. Casas locais avaliaram submissão, resistência e retirada conforme os custos que cada opção impunha a suas pessoas e propriedades.

### Conquista e expulsão

O avanço expulsou guarnições imperiais e atingiu famílias humanas que viviam na região havia gerações. Nem todos os moradores élficos apoiaram as mesmas medidas, e parte dos habitantes de outras origens negociou proteção com a força vencedora. A identificação de uma casa como inimiga podia transformar a ausência de uma família em argumento para tomar sua terra.

### Listas e corredores

Em 2427, Aressa Tonn distinguiu residência, cultivo e propriedade em listas de famílias para impedir declarações automáticas de abandono. Ilvess Nor assegurou um corredor de saída, mas exigiu entrega de animais presentes nos mesmos registros. Uma medida que permitia preservar vidas também transferia recursos essenciais para o governo conquistador. A retirada para Valerith não encerrou as pretensões patrimoniais dos exilados.

### O acordo com Calven III

Em Samarith, Calven III recusou abandonar a Torre. O Acordo das Lâmpadas de 2429 garantiu sua permanência, circulação de peregrinos e proteção formal dos santuários em troca do reconhecimento do novo governo. A acomodação preservou convivência institucional sem apagar o custo da campanha. Quinder permaneceu ligado a Naerath até a Guerra das Duas Cortes, já na III Era.

### Ocupar e administrar

A vitória militar exigiu reconhecer arrecadadores, prover guarnições e decidir quais acordos locais sobreviveriam. Algumas casas colaboraram para manter direitos; outras perderam bens por serem associadas à administração imperial. A proteção dos santuários ajudou a legitimar o novo governo e não determinou por si só como seriam distribuídas as terras. Ilvess Nor precisava preservar percursos que seus soldados também utilizavam, enquanto a remoção de animais de famílias em retirada ampliava a capacidade de transporte da força ocupante.

### Memórias que atravessaram a independência

A conquista deixou listas, testemunhos e títulos conservados fora de Quinder. Uma família podia provar que cultivara um campo sem demonstrar que possuíra o título reconhecido pelo novo governo. A divergência entre residência, uso e propriedade permitiu restringir restituições durante gerações. Quando Nerissa liderou a ruptura com Naerath, sua vitória recebeu apoio de pessoas que não concordavam sobre o que reparar. A independência posterior mudou a autoridade responsável pela resposta, sem tornar idênticas as histórias das famílias que permaneceram e das que partiram.

### Guerra das Duas Cortes

Nerissa venceu e consolidou Quinder como monarquia independente, preservando o Acordo das Lâmpadas.

| Campo | Descrição |
| --- | --- |
| Datas | 61–74 da III Era |
| Local | Quinder e rotas de ligação com Naerath |
| Causa | Disputa pela remessa das receitas de Quinder e pelo direito de confirmar seu governo. |
| Estopim | Nerissa Sareth recusa enviar à corte de Naerath a maior parte da receita local. |
| Resultado | Nerissa venceu e consolidou Quinder como monarquia independente, preservando o Acordo das Lâmpadas. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Corte de Quinder | Governo de Nerissa e casas favoráveis à retenção das receitas; Elfos negros; mercadores humanos, artífices anões e aliados locais | Nerissa Sareth | 4200–5600 | 8000–10600 |
| Corte de Naerath | Casas que defendiam remessas e direitos sobre a administração de Quinder; Predomínio de elfos negros; guardas e auxiliares de outras origens | Vaeressa Sareth | 4900–6500 | 9100–12100 |

Civis fora dos grupos: 6000–9500 mortos e 7500–11000 feridos. População fora das forças, atingida por cercos e requisições. Reivindicações de famílias expulsas na II Era permanecem distintas das perdas desta guerra. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 61 | Recusa das grandes remessas e ruptura da obediência fiscal. |
| 62–65 | Disputa por guarnições, depósitos e estradas de cobrança. |
| 66–69 | Nerissa amplia apoio entre compradores, artífices e sacerdotes; as remessas passam a exigir escolta crescente. |
| 70–73 | Naerath perde capacidade de sustentar posições sem colaboração local suficiente. |
| 74 | Reconhecimento da vitória de Nerissa e consolidação da independência; preservação do Acordo das Lâmpadas. |

### A receita e o governo

A ligação estabelecida pela conquista transferia parte substancial da receita de Quinder à corte de Naerath. Nerissa Sareth recusou continuar a remessa nos termos exigidos. A disputa fiscal envolvia quem pagaria guarnições, obras e casas credoras. Para seus apoiadores, conservar recursos na região era também obter influência sobre sua aplicação.

### Duas cortes, povos compartilhados

A rainha de Quinder recebeu apoio de mercadores humanos, artesãos anões e sacerdotes que temiam decisões de uma corte distante. Elfos negros serviram aos dois lados. Vaeressa Sareth, regente de campanha da corte de Naerath, coordenou casas interessadas em preservar remessas e direitos de nomeação. O sobrenome não estabelece parentesco de primeiro grau com Nerissa ou com Vaeliss.

### Uma guerra de permanência

Naerath podia conquistar posições, mas precisava alimentar guardas e receber informações de comunidades que se dividiam. Nerissa combinou defesa de depósitos e alianças comerciais, mantendo condições de culto já negociadas. Requisições de ambos os lados atingiram famílias com pouca capacidade de escolher. A continuidade da circulação em alguns caminhos impediu que a guerra assumisse uma frente única e contínua.

### Independência e reparação incompleta

A vitória de 74 assegurou uma monarquia própria e preservou o Acordo das Lâmpadas. Não resolveu todas as reivindicações de famílias humanas expulsas durante a conquista. Algumas retornaram, outras conservaram a memória da perda fora de Quinder. A autonomia do reino não deve ser confundida com uma reconciliação patrimonial completa nem com a ruptura de toda relação comercial com Naerath.

### A guerra dos postos fiscais

Reter receita podia começar sem batalha, pela instrução de entregar pagamentos a um agente de Quinder. Naerath reagia reconhecendo outro cobrador e oferecendo garantia a quem o obedecesse. O contribuinte arriscava pagar duas vezes ou sofrer represália por ter apresentado o recibo considerado errado. Depósitos e estradas eram disputados porque permitiam dar efeito às ordens. Nerissa fortaleceu sua posição quando seus agentes se tornaram mais capazes de manter proteção e continuidade do que os enviados da corte distante.

### Garantias depois de 74

A preservação do Acordo das Lâmpadas permitiu aos sacerdotes defender continuidade institucional durante a mudança de soberania. Mercadores buscaram confirmação de passagem e artífices exigiram que encomendas antigas não fossem anuladas pela derrota de seus contratantes. Nerissa podia confirmar um compromisso e recusar outro, tornando a pacificação também uma seleção de interesses. A vitória deu ao governo local instrumentos para resolver conflitos, sem garantir que todos os atingidos recebessem a mesma possibilidade de apresentar sua perda.

### Revolta de Sarn

A repressão retomou o serviço; em 2339 a arbitragem reconheceu parte dos salários, mas autorizou descontos e manteve exclusões profissionais.

| Campo | Descrição |
| --- | --- |
| Datas | 2337 da II Era; arbitragem em 2339 |
| Local | Distrito portuário de Sarn, região de Trogu |
| Causa | Salários atrasados, descontos sobre alimento e disputa pelo direito de paralisar a descarga. |
| Estopim | Trabalhadores retêm a descarga de comboios considerados essenciais pela Liga dos Portos. |
| Resultado | A repressão retomou o serviço; em 2339 a arbitragem reconheceu parte dos salários, mas autorizou descontos e manteve exclusões profissionais. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Trabalhadores mobilizados | Estivadores, famílias e redes de apoio à paralisação; Moradores de várias origens; sem identidade de povo exclusiva | Mira Tovel | 120–170 | 310–430 |
| Tropas de retomada | Forças financiadas por comerciantes da Liga dos Portos e autoridades de serviço; Guardas e contratados de origens variadas | Aven Doss | 30–45 | 85–120 |

Civis fora dos grupos: 25–40 mortos e 70–110 feridos. Moradores e transeuntes fora dos grupos mobilizados. As perdas dos trabalhadores, em grande parte civis, já estão no primeiro lado e não se repetem nesta linha. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 2337 · paralisação | Livros de jornada e descontos sobre alimento sustentam as reivindicações. |
| 2337 · repressão | Aven Doss retoma acessos e descarga; ocorrem saques e desaparecimento de cargas. |
| 2337–2338 · consequências | Famílias buscam salários e alguns trabalhadores são impedidos de contratar. |
| 2339 | Arbitragem reconhece parcela dos salários e autoriza descontos; Mira apresenta livros por uma casa vizinha. |

### A origem da paralisação

As remunerações atrasavam enquanto descontos reduziam o alimento disponível às famílias. Paralisar a descarga atingia comerciantes que defendiam seu próprio direito de suspender remessas. Quando trabalhadores usaram a interrupção como instrumento de pressão, parte desses comerciantes financiou tropas para retomá-la. Sarn era distrito portuário, não coroa em guerra contra outra coroa.

### Livros, cargas e repressão

Mira Tovel organizou a guarda dos registros de jornada, fundamentais para demonstrar serviço e pagamento devido. Aven Doss alegou destruição de cargas pelos insurgentes. A investigação posterior distinguiu perdas na paralisação, saques durante a repressão e mercadorias retiradas antes de serem declaradas desaparecidas. A disputa não se resumia a verificar se algum bem fora danificado, mas a quem podia definir sua causa.

### A arbitragem e a marca de Sarn

Em 2339, a decisão reconheceu parte dos salários e permitiu descontos por equipamentos perdidos. Alguns retomaram o ofício, outros permaneceram excluídos sob a marca de Sarn. Mira apresentou os livros por uma casa vizinha porque não podia entrar no escritório que recebia a petição. Obter parte da reivindicação financeira não lhe devolveu acesso igual às instituições.

### Contar uma repressão

A ficha identifica participantes de cada agrupamento sem transformar os trabalhadores em exército regular. Mortos e feridos entre eles são, em grande parte, vítimas civis de violência repressiva. A linha adicional registra apenas moradores que não estavam nos grupos mobilizados. As faixas resultam de listas incompletas de famílias, atendimento e guardas, não do pressuposto de que cada corpo encontrado pertencia a um combatente.

### Trabalho e poder de interromper

A descarga exigia coordenação entre pessoas de funções diferentes. Bastava faltar um grupo num trecho para atrasar a saída de outro, mas a paralisação também reduzia a renda das famílias que a sustentavam. Comerciantes ofereciam pagamento seletivo para reabrir parte do serviço. Os livros guardados por Mira ajudavam a demonstrar que a tarefa fora realizada antes da suspensão e que a cobrança por alimento não podia ser tratada como salário recebido. Preservar esses registros foi uma forma de resistir à versão de que toda a dívida resultara da revolta.

### Apresamento das Três Bandeiras

Meren Voss apresou o cargueiro; parte da carga foi recuperada depois, e o caso abriu disputa sobre seguros duplicados.

| Campo | Descrição |
| --- | --- |
| Datas | 778 da III Era; dia e mês não preservados |
| Local | Rotas entre o Mar das Espadas e o Mar de Lombonia |
| Causa | Apropriação de carga, documentos e pessoas para receita de resgate. |
| Estopim | A Viúva de Sal intercepta um cargueiro com documentos de Jacomb, garantia nogard e carga financiada em Trogu. |
| Resultado | Meren Voss apresou o cargueiro; parte da carga foi recuperada depois, e o caso abriu disputa sobre seguros duplicados. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Viúva de Sal | Tripulação pirata que buscava carga e resgate; Origem variada; não representa um reino ou povo | Meren Voss | 2–4 | 5–8 |
| Cargueiro e escolta de bordo | Tripulação mercante; documentos de Jacomb, garantia nogard e investidores de Trogu; Marinheiros humanos e nogards; sem guerra entre esses povos | Piloto do cargueiro das Três Bandeiras | 5–8 | 11–17 |

Civis fora dos grupos: 0 mortos e 2–4 feridos. Passageiros fora da tripulação e da defesa. Nenhuma morte confirmada nesse grupo; um passageiro desaparecido permanece fora do total de mortos. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| Intercepção | A Viúva de Sal aproxima-se e bloqueia a continuação da viagem. |
| Abordagem | A defesa do cargueiro é vencida; o piloto morre e documentos são apreendidos. |
| Reclamações | Agentes de Jacomb, casa garantidora nogard e investidores de Trogu exigem restituição. |
| Apuração posterior | Parte da carga é recuperada; garantias e seguros duplicados passam a ser objeto de processo. |

### Três vínculos sobre uma carga

Os documentos de Jacomb não tornavam toda mercadoria propriedade da cidade. A garantia de uma casa nogard também não fazia do cargueiro um navio imperial. Investidores de Trogu possuíam interesses sobre bens embarcados. A capitã Meren Voss aproveitou essa multiplicidade: papéis e pessoas podiam render negociação mesmo depois da venda de parte do carregamento.

### Abordagem e decisão

A Viúva de Sal venceu a defesa de bordo e retirou documentos que ajudavam a identificar credores e destinatários. O piloto do cargueiro morreu na abordagem. Sua função de condução não o tornava representante de um governo, e o nome pessoal não foi preservado com segurança. A disputa posterior conferiu mais atenção à titularidade da carga do que ao sustento de sua família.

### O processo de restituição

Cada interessado apresentou a si mesmo como principal lesado. A recuperação parcial não atendia todas as garantias prometidas sobre os mesmos bens. A apuração de seguros duplicados precisava distinguir dano real, cobertura declarada e tentativa de receber duas vezes. A Mesa do Lastro pertence a esse ambiente de crédito, mas não se estabelece que todos os seus membros tenham participado da fraude.

### Escala e limites

Trata-se de incidente de pirataria, não de guerra entre Jacomb, Nogard e Trogu. Os números da ficha são pequenos e deliberadamente apresentados em faixas, porque as listas de tripulantes e de feridos não coincidem integralmente. Desaparecimento sem prova de morte não é convertido em certeza para fechar uma soma.

### Papéis como parte do saque

Os documentos permitiam descobrir quem tinha interesse em evitar a divulgação de uma garantia ou de uma rota. A capitã podia negociar restituição de um papel sem devolver toda a mercadoria que ele descrevia. Aos credores interessava controlar as cópias apresentadas ao processo, enquanto a tripulação buscava demonstrar que não perdera a carga por negligência. O custo de sustentar essa disputa favorecia quem podia pagar agentes em mais de um porto, prolongando a desvantagem da família do piloto morto.

### Crise Naval dos Ancoradouros

O acordo provisório de 786 conteve os combates principais, mas não resolveu taxas, acessos ou reivindicações; Oleakia conservou sua autonomia.

| Campo | Descrição |
| --- | --- |
| Datas | 786 da III Era; tensão política ainda aberta no início de 788 |
| Local | Passagens e ancoradouros disputados entre Nogard e Oleakia |
| Causa | Taxas de passagem, inspeção de cargas e tentativa de controlar acessos costeiros e santuários. |
| Estopim | Retenções de embarcações e contestação de cobranças desencadeiam confrontos locais em 786. |
| Resultado | O acordo provisório de 786 conteve os combates principais, mas não resolveu taxas, acessos ou reivindicações; Oleakia conservou sua autonomia. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Comandos e casas nogards | Império de Nogard; casas e comandos com posições divergentes; Nogards; tripulações auxiliares de outras origens | Azhvar VIII Khor-Azhar, Drazhen Ul, Sevra Khor | 48–70 | 120–170 |
| Defesa das comunidades oleakes | União das Tocas e comunidades que coordenaram vigilância e acesso; Oleakes, com redes locais de apoio | Ima Olek, Happidoh, Form, Forty | 36–55 | 95–140 |

Civis fora dos grupos: 18–30 mortos e 50–80 feridos. Pescadores, viajantes e moradores não mobilizados; cifras limitadas aos confrontos de 786, não a toda a expansão iniciada em 521. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 786 · escalada | Retenções e exigências de pagamento atingem embarcações que utilizam passagens disputadas. |
| 786 · confrontos | Patrulhas e defesas locais enfrentam-se em acessos; depósitos dispersos limitam o efeito do bloqueio. |
| 786 · negociação | Comunicação de retenções e registro de cobranças contestadas entram no acordo provisório. |
| 787–início de 788 | Mantêm-se fiscalização, reivindicações e debate entre tratados comerciais e ocupação permanente; nenhuma nova campanha é afirmada nesta ficha. |

### Proteção e cobrança

Nogard tratava a presença naval como garantia de navegação e fundamento para cobrar passagem. Comunidades oleakes contestavam tanto as taxas quanto a pretensão de decidir quem usaria seus próprios acessos. Reivindicações sobre santuários acrescentavam uma linguagem ancestral a disputas sobre território e receita. A origem dracônica dos nogards não lhes concedia autoridade reconhecida pelas comunidades vizinhas.

### Uma frente de canais e depósitos

As embarcações nogards podiam vigiar passagens abertas e reter carga, mas não controlar todos os caminhos, túneis e locais de reserva. As comunidades oleakes dispersaram depósitos e coordenação de vigilância. Happidoh, Form e Forty participaram da defesa e da verificação de acessos sob articulação de Ima Olek. Nenhum único ponto tomado encerrava a capacidade local de resistir.

### Divergência dentro de Nogard

Drazhen Ul defendia que apenas posições permanentes impediriam o fechamento das rotas. Sevra Khor procurava tornar taxas e acesso verificáveis por acordo. Azhvar VIII precisava equilibrar essa disputa com receita e apoio das casas. A posição favorável a tratados não eliminava exigências pesadas para pequenos comerciantes; a posição de ocupação não resolvia o custo de abastecer guarnições.

### O acordo e o que ficou aberto

O acordo de 786 estabeleceu comunicação de retenções, registro de cobranças contestadas e negociação de acessos. Não converteu o litoral oleake em possessão imperial. No início de 788, a tensão continuava como problema político e comercial. As baixas dizem respeito apenas aos confrontos daquele ano; não são o total retrospectivo das campanhas Khor-Azhar desde 521.

### Fiscalização e sobrevivência

Uma retenção curta podia estragar pescado e deixar a tripulação sem receita mesmo quando a carga era liberada. As garantias exigidas por oficiais recaíam de modo desigual sobre grandes casas e pequenos proprietários. Do lado oleake, dispersar reservas preservava defesa e exigia trabalho adicional de transporte e vigilância. A experiência dos confrontos tornou a comunicação sobre retenções uma medida concreta: saber onde estava uma embarcação e quem a detinha podia evitar uma busca armada baseada em rumor.

### O cumprimento do acordo

Mensageiros precisavam distinguir cobrança autorizada de exigência feita por um agente em nome próprio. Sevra buscava identificar responsáveis para que uma reclamação pudesse ser tratada sem mobilizar toda a frota. Drazhen considerava que esse procedimento retardava respostas em passagens vulneráveis. Ima Olek procurava impedir que a obrigação de comunicar incidentes se tornasse reconhecimento de autoridade imperial sobre as comunidades. A paz provisória manteve trabalho diplomático porque as partes não atribuíam o mesmo significado a cada prática de fiscalização.

## 54. Lideranças e funções nos conflitos

### Neravel Issar

Articuladora da Liga das Margens Abertas durante 6262–6266 da I Era.

### Atuação

Defendeu acesso de equipes de reparo e representação das comunidades a jusante. Negociava com patrocinadores sem admitir que cada contrato desse direito de impedir uma inspeção urgente.

### Escolhas e consequências

A circulação de artífices era para ela uma obrigação entre vizinhos, mas sua liga dependia de cidades que também cobravam passagem. A arbitragem de 6266 permitiu encerrar campanhas sem abolir essas contradições.

### Traços individuais

Cabelos castanhos presos, rosto comprido e mãos marcadas por trabalho de medição; veste de linho cru com faixas verdes.

### Talven Uld

Negociador do Pacto dos Contratos durante 6262–6266 da I Era.

### Atuação

Representou patrocinadores e autoridades que associavam exclusividade de manutenção à proteção de aprendizes, peças e crédito. Coordenava compromissos entre cidades que mantinham autonomia.

### Escolhas e consequências

Aceitou inspeções acompanhadas em 6266 quando os danos da interrupção ameaçaram também seus financiadores. Não reconheceu acesso igual aos meios de fabricar componentes, preservando uma das assimetrias da paz.

### Traços individuais

Cabelo escuro rente, rosto arredondado, sobrancelhas espessas e roupas de lã azul com bolso para pequenos instrumentos.

### Tervan Rell

Diretor da Companhia das Comportas durante 1517–1546 da II Era.

### Atuação

Chefiou a articulação entre diretores e proprietários que financiavam obras em troca de prioridade. Defendia que o investimento justificava remuneração diferenciada e dava tratamento político às disputas de medição.

### Escolhas e consequências

Os registros revelados por Berik Oss enfraqueceram sua defesa pública. Na negociação de 1546, procurou conservar técnicos e contratos mesmo aceitando inspeção externa e limitação de prioridades.

### Traços individuais

Cabelo grisalho curto, pele morena, rosto largo e uma pálpebra caída; casaco de trabalho bem conservado e anéis usados para marcar selos.

### Oren Vald

Articulador de casas de pedágio durante 1881–1895 da II Era.

### Atuação

Reuniu autoridades que temiam perder renda e funcionários sob os recibos comuns da liga de Vaela. Sua força dependia da disposição de casas independentes para fornecer guardas e depósitos.

### Escolhas e consequências

A cada adesão negociada à liga, precisava refazer promessas de proteção. O fracasso de sua articulação não significou execução ou extinção de todas as casas que a haviam apoiado.

### Traços individuais

Homem de meia-idade, barba curta castanha, nariz quebrado antigo e casaco vinho gasto nas mangas; conserva um estojo de recibos.

### Keldan Orr

Comandante da coluna em Bar-Terval durante 1904 da II Era.

### Atuação

Conduziu a imposição de reféns e ocupação de campos após ataques a um comboio. Justificava a responsabilidade coletiva como meio de produzir informação e desestimular novas interdições.

### Escolhas e consequências

A operação obteve posições sem recompor o acordo político com as comunidades. A ruptura de Rughan expôs o custo de tratar compromissos específicos como submissão geral.

### Traços individuais

Cabelo castanho cortado curto, face estreita, cicatriz no queixo e capa escura com fecho de ferro; leva ordens dobradas em bolsa impermeabilizada.

### Hadran Vossel

Comandante imperial nas travessias do norte durante 2376–2388 da II Era.

### Atuação

Coordenou a concentração de guarnições em postos que pudessem receber reservas e proteger comboios. Respondia às exigências de Odravel III e à necessidade de negociar recursos com autoridades provinciais.

### Escolhas e consequências

Preferia uma posição abastecida a um avanço difícil de manter, mas aceitou ocupações cujo custo ampliou as garantias a credores. Participou da execução da trégua de 2388. O sobrenome não fixa parentesco com outras pessoas chamadas Vossel.

### Traços individuais

Cabelos negros com mechas brancas, barba curta, pele clara curtida pelo frio; capa cinza sobre proteção de couro e placas.

### Yrsa Hald

Articuladora da Liga das Passagens do Norte durante 2376–2388 da II Era.

### Atuação

Negociou apoio entre comunidades e casas que resistiam às cobranças e ocupações imperiais. Coordenava deslocamento de reservas e fechamento de ramais sem dispor de autoridade régia sobre todo o norte.

### Escolhas e consequências

Precisava conter requisições de aliados que ameaçavam o apoio dos moradores. Defendeu a trégua quando a continuidade dos ataques já destruía recursos locais. Seu sobrenome não estabelece parentesco com personagens da III Era.

### Traços individuais

Cabelos castanho-claros em tranças curtas, rosto quadrado, olhos cinzentos e roupas de lã castanha com remendos de tons diferentes.

### Vaeressa Sareth

Regente de campanha da corte de Naerath durante 61–74 da III Era.

### Atuação

Coordenou casas empenhadas em conservar remessas e direitos de nomeação sobre Quinder. Sua função era de regência de campanha, sem criação de uma nova soberana para substituir a sucessão já estabelecida.

### Escolhas e consequências

A mobilização exigiu conciliar credores e comandos cujos ganhos dependiam de uma receita que a guerra dificultava arrecadar. A vitória de Nerissa limitou o projeto. O sobrenome comum não demonstra vínculo de primeiro grau entre as duas.

### Traços individuais

Pele escura, cabelos brancos curtos penteados para trás, nariz largo e uma marca clara na testa; roupa de viagem azul-escura com bordado discreto.

### Piloto do cargueiro das Três Bandeiras

Piloto morto durante o apresamento de 778, cujo nome pessoal não foi preservado com segurança.

### O trabalho e a perda

Conduzia o cargueiro apreendido pela Viúva de Sal. A defesa da embarcação não impediu a tomada, e o piloto morreu durante a abordagem. Sua família aparece no registro das consequências, com menos atenção que os credores da carga.

### O limite do nome

Piloto é uma função de navegação, não prova de que fosse proprietário ou comandante de toda a embarcação. O nome e o povo do indivíduo permanecem desconhecidos. Sua presença entre as lideranças de bordo identifica responsabilidade técnica e não o torna governante.

## 55. Samarith — forças, cronologia e baixas

### Batalha de Samarith

As forças rivais coordenaram uma operação; Marevim morreu na Câmara no dia 23. A vitória encerrou sua ofensiva imediata, sem eliminar as disputas entre reinos.

| Campo | Descrição |
| --- | --- |
| Datas | 18–23 do nono mês de 788 da III Era |
| Local | Samarith, Pontes das Lâmpadas, Torre e Câmara |
| Causa | Disputa por acesso à Câmara, autoridade territorial e efeitos da ação de Marevim. |
| Estopim | Convergência de forças rivais e sinais falsificados que provocam abertura de fogo. |
| Resultado | As forças rivais coordenaram uma operação; Marevim morreu na Câmara no dia 23. A vitória encerrou sua ofensiva imediata, sem eliminar as disputas entre reinos. |

| Lado | Grupos e povos | Lideranças | Mortos | Feridos sobreviventes |
| --- | --- | --- | --- | --- |
| Forças de Quinder | Governo de Selyra e guardas da cidade; Elfos negros, humanos e moradores de outras origens | Selyra Naereth | 310–420 | 700–930 |
| Expedição de Aelvar | Força enviada sob autoridade de Arriot Ilvar; Predomínio de elfos altos; auxiliares diversos | Arriot Ilvar, Elthara Sorn | 180–250 | 430–590 |
| Contingentes de Tavian | Veteranos de Valerith e forças articuladas por acordos distintos; Predomínio humano; contingentes de origens diferentes | Tavian Ordel | 220–300 | 510–700 |
| Forças de Marevim | Agentes, seguidores e grupos sob coerção ligados à ofensiva; Origem heterogênea; manifestações de névoa não são contadas como pessoas | Marevim | 260–340 | 140–220 |

Civis fora dos grupos: 540–760 mortos e 1200–1700 feridos. Civis sem função nos quatro agrupamentos, inclusive durante evacuação. Feridos coercivamente ligados a Marevim não são julgados culpados por essa classificação. Estimativas históricas adotadas no Registro 2.13. Feridos são sobreviventes ao encerramento do recorte; quem morreu dos ferimentos entra apenas entre os mortos. Limites inferiores e superiores não são censos exatos.

| Data / fase | Acontecimento |
| --- | --- |
| 18 do nono mês | Escaramuças entre forças estatais e bloqueio de passagens. |
| 19 do nono mês | Confirmam-se núcleos de névoa junto à cidade. |
| 20 do nono mês | Forma-se acordo de coordenação contra Marevim. |
| 20–22 do nono mês | Combates nas Pontes das Lâmpadas; evacuação e disputa de reservas. |
| 23 do nono mês | Operação na Câmara e morte de Marevim. |
| Dias seguintes | Socorro, identificação de mortos e apuração de responsabilidades entre comandos. |

### A convergência dos exércitos

Selyra bloqueou duas pontes a estrangeiros. Elthara Sorn ocupou uma passagem para assegurar acesso à Câmara, enquanto Tavian avançou confiando em acordo anterior. Uma guarda de Quinder encontrou sinais falsificados e abriu fogo. Marevim pagara agentes para agravar a crise, mas encontrou desconfianças e interesses já existentes: a manipulação foi eficaz porque cada comando estava disposto a interpretar o movimento do outro como ameaça.

### Do confronto à coordenação

As escaramuças começaram no dia 18. Os núcleos de névoa confirmados no dia 19 alteraram a avaliação do perigo. O acordo de coordenação tomou forma no dia 20, sem dissolver cadeias de comando ou apagar as perdas já causadas entre os contingentes. Garantir passagem, compartilhar informação e evitar novos erros de identificação tornou-se condição para alcançar a Câmara.

### Pontes, alimento e retirada

A luta nas Pontes das Lâmpadas prosseguiu até o dia 22. Refugiados foram confundidos com infiltrados, mensageiros retidos e comboios requisitados. Ysenda e casas locais dos Guerreiros mantiveram uma rota de evacuação enquanto negociavam responsabilidade por seus homens. Yarine reteve parte das reservas contra uma ordem senhorial; o alimento preservado ajudou a evitar fome nos dias seguintes, mas a recusa lhe trouxe acusação de traição.

### A Câmara e o dia 23

A operação final culminou na morte de Marevim. A Batalha de Samarith abrange os seis dias de combate e coordenação, não apenas o confronto dentro da Torre. Manifestação dissipada não é automaticamente uma pessoa morta, e seguidores sob coerção não recebem culpa coletiva por constarem no agrupamento adversário. O balanço distingue pessoas identificáveis de efeitos sobrenaturais.

### Vitória e consequências

A cooperação encerrou a ofensiva imediata, mas deixou feridos, famílias sem notícias e acusações sobre quem agravara a crise. O auxílio posterior exigiu reconstruir percursos e documentos além de recolher armas. As cifras são estimativas consolidadas para o episódio, apresentadas apenas com spoilers. A contagem não atribui a todos os elfos altos, humanos ou elfos negros a responsabilidade das decisões de seus comandantes.

### Reconhecer quem saía da cidade

A mesma ponte recebia moradores que fugiam, homens procurando suas unidades e mensageiros com ordens de procedência contestada. Uma guarda capaz de deter infiltrados podia também impedir a saída de uma família. A coordenação entre comandos precisou produzir sinais reconhecíveis e estabelecer a quem entregar suspeitos, sob pena de multiplicar represálias. A rota mantida por Ysenda e casas dos Guerreiros ofereceu continuidade parcial num ambiente em que acordos mudavam mais depressa do que a notícia chegava a cada posto.

### O balanço depois do dia 23

Identificar os mortos exigiu cruzar listas de unidades com registros de abrigo e atendimento. Pessoas vistas junto às forças de Marevim podiam ter sido coagidas, enquanto homens de um reino apareciam feridos num posto de outro. O inventário preserva agrupamento para reconstituir a operação, sem transformar essa posição em julgamento moral. A apuração das reservas retidas por Yarine e das ordens dadas nas pontes mostra que a vitória comum não eliminou a necessidade de examinar decisões de cada comando.

## 56. Implantação dos dossiês de conflitos

Wikia 0.38: 17 dossiês de conflitos, 12 verbetes novos e 658 no total. Três imagens novas, fichas comparativas de lados, cronologias por fase e oito vínculos de novas lideranças. Preservados 51 capítulos anteriores, 184 marcos e 90 vínculos; acrescentados cinco marcos e oito vínculos. O dossiê posterior ao marco de 788 permanece sob controle de spoilers.



## 57. Eldenari — padrão de aparência vigente

### RC-EL01 — Anatomia e diversidade Eldenari

Eldenari possuem anatomia humanoide material e orelhas predominantemente humanas: curtas, próximas da cabeça e de contorno arredondado. Algumas linhagens admitem apenas uma ponta discreta no alto da hélice, sem alongamento do pavilhão nem projeção lateral élfica. Orelhas alongadas e nitidamente pontudas continuam características dos povos élficos. Preservar grande variedade de pele, olhos, cabelos, rosto, corpo, idade e vestuário. O formato da orelha não determina mana, longevidade, caráter ou hierarquia. Não tornar todos os Eldenari iguais nem convertê-los visualmente em elfos.

### RC-EL02 — Referências individuais

Ilyra Seneth, Avar Seneth e Melian Or admitem ponta mínima na hélice, mantendo tamanho humano. Oren Namar, Talena Ors, Edris Vaun, Serath Namar, Saelith Vora, Nimea Aral, Teren Vos, Eshara Vel, Veska Tor, Damar Esh, Hared Sen, Neravel Issar e Talven Uld seguem orelhas curtas arredondadas. A lista fixa referências individuais, sem inventar parentescos ou linhagens nomeadas. Cabelos, peles, olhos, idades e sinais particulares anteriores permanecem.

### RC-EL03 — Cenas mistas e alcance da revisão

Nas cenas mistas, corrigir somente Eldenari. Arieth Ilvar, Caerion Thalas, Maeriel Sorn, Naeris Ul e os demais elfos preservam a anatomia élfica e seus traços individuais. Todas as reutilizações correntes das imagens revistas devem apontar para a versão 0.39, inclusive cronologia, índices de vínculos, recortes de era e artigos relacionados. A revisão é visual; não altera acontecimentos, datas, forças ou baixas. Arquivos de livros e edições anteriores não são reescritos nesta atualização.

## 58. Eldenari — fichas e aplicação às imagens

Os Eldenari têm orelhas predominantemente humanas: curtas, próximas da cabeça e arredondadas. Algumas linhagens apresentam somente uma ponta discreta no alto da hélice, sem o alongamento característico dos elfos. A variação acompanha famílias e indivíduos, sem indicar poder, posição social ou maior proximidade com a mana. Pele, cabelos, olhos e constituição continuam diversos; a identidade Eldenari não exige uma silhueta élfica.

| Personagem | Orelhas | Imagem vigente |
| --- | --- | --- |
| Ilyra Seneth | Orelhas curtas e de proporção humana, com uma ponta mínima no alto da hélice, sem alongamento ou projeção lateral élfica. | v39-ilyra-seneth.webp |
| Oren Namar | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-oren-namar.webp |
| Talena Ors | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-talena-ors.webp |
| Edris Vaun | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-edris-vaun.webp |
| Avar Seneth | Orelhas curtas e de proporção humana, com uma ponta mínima no alto da hélice, sem alongamento ou projeção lateral élfica. | v39-avar-seneth.webp |
| Serath Namar | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-serath-namar.webp |
| Saelith Vora | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-saelith-vora.webp |
| Nimea Aral | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-nimea-aral.webp |
| Teren Vos | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-teren-vos.webp |
| Melian Or | Orelhas curtas e de proporção humana, com uma ponta mínima no alto da hélice, sem alongamento ou projeção lateral élfica. | v39-melian-or.webp |
| Eshara Vel | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-eshara-vel.webp |
| Veska Tor | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-veska-tor.webp |
| Damar Esh | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-damar-esh.webp |
| Hared Sen | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-hared-sen.webp |
| Neravel Issar | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-neravel-issar.webp |
| Talven Uld | Orelhas humanas curtas, de contorno arredondado e próximas da cabeça. | v39-talven-uld.webp |

| Imagem anterior | Imagem vigente |
| --- | --- |
| v30-ilyra-seneth.webp | v39-ilyra-seneth.webp |
| v30-oren-namar.webp | v39-oren-namar.webp |
| v31-talena-ors.webp | v39-talena-ors.webp |
| v31-edris-vaun.webp | v39-edris-vaun.webp |
| v32-avar-seneth.webp | v39-avar-seneth.webp |
| v32-serath-namar.webp | v39-serath-namar.webp |
| v32-saelith-vora.webp | v39-saelith-vora.webp |
| v32-nimea-aral.webp | v39-nimea-aral.webp |
| v32-teren-vos.webp | v39-teren-vos.webp |
| v32-melian-or.webp | v39-melian-or.webp |
| v32-eshara-vel.webp | v39-eshara-vel.webp |
| v32-veska-tor.webp | v39-veska-tor.webp |
| v32-damar-esh.webp | v39-damar-esh.webp |
| v32-hared-sen.webp | v39-hared-sen.webp |
| v32-vaelthar.webp | v39-vaelthar.webp |
| v32-khorvath.webp | v39-khorvath.webp |
| v32-zhaurak.webp | v39-zhaurak.webp |
| v32-varesh.webp | v39-varesh.webp |
| v32-cidades-eldenari.webp | v39-cidades-eldenari.webp |
| v32-elar-tao.webp | v39-elar-tao.webp |
| v32-pontes-asmarith.webp | v39-pontes-asmarith.webp |
| v32-cinzas-uldar.webp | v39-cinzas-uldar.webp |
| v32-punicao.webp | v39-punicao.webp |
| v32-refugio-eshara.webp | v39-refugio-eshara.webp |
| v28-hist-eldenari.webp | v39-hist-eldenari.webp |
| v35-arieth-ilvar.webp | v39-arieth-ilvar.webp |

Neravel Issar e Talven Uld passam a ter retratos próprios; as cenas Eldenari de fundo deixam de funcionar como retrato individual desses personagens. Em Arieth oferecendo água, a alteração atinge apenas os acolhidos Eldenari; Arieth continua elfa alta.

## 59. Implantação da padronização Eldenari

Wikia 0.39: 658 artigos, 16 perfis Eldenari padronizados e 28 imagens atualizadas, com propagação a 58 artigos que as utilizam. Preservados 56 capítulos anteriores, 189 marcos cronológicos e 98 vínculos. A definição física é nova e expressamente autorizada; não altera a origem independente dos Aelthir nem os traços dos povos élficos.



## 60. O Primeiro Conflito e a expansão de Vaelen Endor — definições

### RC-PC01 — O Primeiro Conflito: nome, período e alcance

O nome oficial é O Primeiro Conflito. Trata-se da principal guerra das primeiras Guerras da Fome, composta de campanhas e batalhas. Adota-se c. 62–146 da II Era como intervalo aproximado de reconstrução. As Guerras da Fome são um conjunto maior e não recebem o mesmo limite. Nara dos Sete Celeiros permanece ligada ao marco de 173, posterior à guerra.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-PC02 — Coalizões e posição dos humanos

A Liga das Margens e o Pacto dos Altos Caminhos são as duas coalizões da guerra. Chefes humanos iniciaram ocupações dos campos centrais; comunidades humanas aderiram a ambos os lados ou buscaram neutralidade. Nenhuma coalizão equivale a todos os indivíduos dos povos participantes. Não projetar Dorgamar, Pellanor, Thaelorien ou a Confederação Orc posteriores sobre os comandos da guerra.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-PC03 — Batalhas, consequências e baixas

As batalhas das Sementeiras Tomadas (c. 67), Juncos Partidos (c. 83), Escarpa da Cinza (c. 111) e Três Celeiros (c. 139) são partes do Primeiro Conflito. Suas perdas já estão incluídas no total da guerra. Os Acordos dos Celeiros Abertos (c. 146) encerram as campanhas principais sem criar soberania regional única ou excluir todos os povos não humanos.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-EX01 — Formação territorial e limites de Vaelen Endor

Detalham-se campanhas e adesões dentro dos marcos adotados: Guerra das Correntes 1881–1895, proclamação em 1896, dissolução em 2431. Os futuros sete Reinos Centrais e Quinder são referências regionais, não estados de 788 já formados na II Era. As demais potências preservam soberania própria.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-EX02 — Marcos regionais de incorporação

Adotam-se os marcos dos dossiês: núcleo de Valerith 1876–1896; Rácia 1882–1884; Cávia 1885–1893; Sokeria 1886–1888; Heria 1887–1891; Milles 1890–1893; adesão de Arven-Doss/Nobilith 1894; concordância de Quinder 1895 e incorporação imperial em 1896. Preservadas Três Argolas 1887, compensações 1889 e Contas de Madeira 1892.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-EX03 — Exército e gerações de comando

A força imperial reúne quadros regulares, contingentes provinciais e de casas, auxiliares e especialistas contratados. Capacidade de mana e engenharia tem custos e limites. Logística depende de depósitos, estradas, barcas e consentimentos locais. Sorenna e Dorrik não comandam automaticamente campanhas de séculos posteriores; novas lideranças têm períodos próprios.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

### RC-EX04 — Expedições fracassadas e soberania

Nogard derrota a expedição imperial de 1962–1964, sob Teren I; Thaelorien resiste em 1988–1990, sob Isera I; Dorgamar repele a coerção de Orvath em 2026–2028, sob Selvar I. Tratado de Morvek 2032, obras 2039, operação 2058 e ligações principais 2116 continuam distintos. A Guerra dos Postos do Norte 2376–2388 conserva seu desfecho fragmentado; não se torna conquista de Bergen inteira.

Base: Solicitação autoral retomada em 9 de novembro de 2026; Registro 2.14 e história política de Vaelen Endor preservados como base.

## 61. Dossiês do Primeiro Conflito e das campanhas imperiais

### Sélia Tern

Organizadora da Liga das Margens na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Elfa da floresta |
| Atuação | Organizadora da Liga das Margens |
| Período de atuação | 62–146 da II Era |
| Sinais distintivos | Pele acobreada, rosto comprido, cabelo castanho preso baixo, cicatriz na sobrancelha esquerda |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Manteve corredores de sementes entre aldeias, abrigos e bosques. Recusou que o comando militar desse posse perpétua dos depósitos aos seus aliados.

Decisões e consequências. Na batalha dos Juncos Partidos aceitou retirar o posto central para preservar as barcas de reserva. A escolha salvou sementes e deixou aldeias expostas. Nos acordos finais defendeu a devolução de garantias tomadas durante a guerra.

Aparência e época. Pele acobreada, rosto comprido, cabelo castanho preso baixo, cicatriz na sobrancelha esquerda. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Orvek Durn

Coordenador militar do Pacto dos Altos Caminhos na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Anão |
| Atuação | Coordenador militar do Pacto dos Altos Caminhos |
| Período de atuação | 62–146 da II Era |
| Sinais distintivos | Cabeça raspada, barba curta grisalha, nariz largo, túnica de lã cinza e martelo de sinalização |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Articulou comunidades de galerias e passagens de planalto contra a perda de acesso aos armazéns de várzea. Respondia a assembleias de fornecedores, sem possuir autoridade sobre todos os anões.

Decisões e consequências. Defendia a apreensão de reservas como garantia militar. A dependência de carros e animais de carga limitou seus avanços nas terras alagadas. Ao final da guerra aceitou inspeções mistas em depósitos que antes queria manter sob sua guarda.

Aparência e época. Cabeça raspada, barba curta grisalha, nariz largo, túnica de lã cinza e martelo de sinalização. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Vasha Ur

Chefe de contingentes Urakh no Pacto dos Altos Caminhos na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Orc |
| Atuação | Chefe de contingentes Urakh no Pacto dos Altos Caminhos |
| Período de atuação | 62–146 da II Era |
| Sinais distintivos | Pele oliva escura, presas assimétricas, três tranças curtas, manto de couro remendado |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Comandou a defesa de poços e pastagens usados por grupos Urakh. Sua associação com Orvek era uma obrigação de campanha, anterior às instituições confederadas de épocas posteriores.

Decisões e consequências. Resistiu à extensão de requisições para aldeias humanas que haviam mantido livre passagem aos rebanhos. Divergiu de comandantes anões sobre a duração dos bloqueios e participou dos entendimentos que encerraram as campanhas principais.

Aparência e época. Pele oliva escura, presas assimétricas, três tranças curtas, manto de couro remendado. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Nema Ors

Negociadora de abrigos e comboios independentes na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Humana |
| Atuação | Negociadora de abrigos e comboios independentes |
| Período de atuação | 83–146 da II Era |
| Sinais distintivos | Pele morena, rosto quadrado, cabelo preto cortado rente, mãos marcadas por cordas |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Reuniu comunidades humanas que recusavam entregar seus celeiros a qualquer coalizão. Negociava passagens com ambas e registrava entregas para impedir cobrança repetida.

Decisões e consequências. Não foi neutra diante de toda violência: interrompeu fornecimento a comandos que retinham moradores como garantia. Sua rede abrigou famílias de vários povos. Os pactos finais limitaram o uso militar dos comboios que ela ajudara a proteger.

Aparência e época. Pele morena, rosto quadrado, cabelo preto cortado rente, mãos marcadas por cordas. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Varren Tol

Almirante imperial da campanha dos estreitos na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Humano |
| Atuação | Almirante imperial da campanha dos estreitos |
| Período de atuação | 1962–1964 da II Era |
| Sinais distintivos | Pele clara, cabelo ruivo ralo, queixo curto, marca de queimadura na mão direita |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Recebeu de Teren I a missão de impor fiscalização permanente a ancoradouros de Nogard. Confiou que o controle dos grandes navios compensaria a falta de pilotos locais.

Decisões e consequências. A concentração da frota agravou a escassez de água e o risco nas correntes. Perdeu navios de transporte nos Baixios das Três Lanternas e ordenou retirada em 1964. A corte preservou sua patente, mas lhe retirou o comando de expedições.

Aparência e época. Pele clara, cabelo ruivo ralo, queixo curto, marca de queimadura na mão direita. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Ishara Khor

Capitã de defesa dos ancoradouros de Nogard na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Nogard |
| Atuação | Capitã de defesa dos ancoradouros de Nogard |
| Período de atuação | 1962–1964 da II Era |
| Sinais distintivos | Escamas cinza-azuladas, chifres curtos voltados para trás, rosto largo e manto de lã azul |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Coordenou pilotos, vigias e pequenas embarcações de comunidades nogards. Sua autoridade derivava de compromissos de defesa entre ancoradouros, sem se estender a todas as casas do arquipélago.

Decisões e consequências. Evitou expor as embarcações leves a uma batalha frontal. Fechou pontos de aguada, mudou sinais e concentrou ataques nos transportes imperiais. Depois da retirada, enfrentou casas que pretendiam transformar o esforço de defesa em novas taxas privadas.

Aparência e época. Escamas cinza-azuladas, chifres curtos voltados para trás, rosto largo e manto de lã azul. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Maura Vel

Comandante imperial na campanha meridional na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Humana |
| Atuação | Comandante imperial na campanha meridional |
| Período de atuação | 1988–1990 da II Era |
| Sinais distintivos | Pele castanha, cabelo escuro entremeado de grisalho, nariz aquilino, capa curta de viagem |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Isera I lhe confiou a imposição de postos de garantia em rotas ao norte de Thaelorien. Maura organizou colunas leves, mas dependeu de depósitos que não se podiam manter sem cooperação local.

Decisões e consequências. Nos Vaus de Lethen, foi obrigada a abandonar máquinas de cerco e carros para retirar os feridos. Assinou a suspensão da campanha sem obter guarnições permanentes. Defendeu seus subordinados da acusação de covardia e registrou a falta de abastecimento.

Aparência e época. Pele castanha, cabelo escuro entremeado de grisalho, nariz aquilino, capa curta de viagem. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Elven Aros

Coordenador da defesa dos Vaus de Lethen na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Elfo da floresta |
| Atuação | Coordenador da defesa dos Vaus de Lethen |
| Período de atuação | 1988–1990 da II Era |
| Sinais distintivos | Pele acobreada, cabelo castanho encaracolado, lábio superior fino, capa ocre e verde |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Ligou guardas de bosque, barqueiros e comunidades de cultivo ameaçadas pelos postos imperiais. Precisou assegurar que a defesa não destruísse as mesmas plantações que procurava proteger.

Decisões e consequências. Concentrou a resistência nas travessias e na conservação de reservas fora do alcance das colunas. Aceitou intercâmbio de feridos e uma retirada negociada. O êxito militar não resolveu as disputas de terra entre casas e agricultores de Thaelorien.

Aparência e época. Pele acobreada, cabelo castanho encaracolado, lábio superior fino, capa ocre e verde. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Oren Keld

Comissário militar imperial na disputa de Orvath na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Humano |
| Atuação | Comissário militar imperial na disputa de Orvath |
| Período de atuação | 2026–2028 da II Era |
| Sinais distintivos | Pele pálida, sobrancelhas espessas, cabelo preto ondulado, casaco ferrugem |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Selvar I o encarregou de obter garantias coercivas de passagem nas aproximações da Espinha de Orvath. Oren tentou converter contratos de serviço em direito de guarnição.

Decisões e consequências. As comunidades de Dorgamar recusaram o novo alcance das obrigações. Sem acesso às galerias de reserva, sua coluna ficou presa a uma única estrada. A retirada de 2028 preservou parte da força e demonstrou o custo de enfrentar a infraestrutura anã.

Aparência e época. Pele pálida, sobrancelhas espessas, cabelo preto ondulado, casaco ferrugem. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Briga Durn

Responsável pela defesa e manutenção das Portas de Orvath na história da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Povo | Anã |
| Atuação | Responsável pela defesa e manutenção das Portas de Orvath |
| Período de atuação | 2026–2028 da II Era |
| Sinais distintivos | Pele castanha escura, rosto arredondado, tranças negras com argolas de ferro, mão esquerda enfaixada |
| Estatuto | Figura histórica da expansão 2.15 |

Atuação e responsabilidades. Coordenou guardas de passagem e trabalhadores de manutenção em comunidades da Espinha de Orvath. Respondeu às assembleias de cidades e oficinas, sem possuir cada galeria como patrimônio pessoal.

Decisões e consequências. Limitou o acesso das tropas invasoras e manteve circulação de água e alimento aos moradores. Recusou destruir uma galeria habitada para acelerar a retirada imperial. Seus relatórios contribuíram para negociações posteriores, sem fazer dela autora única do Tratado das Águas de 2032.

Aparência e época. Pele castanha escura, rosto arredondado, tranças negras com argolas de ferro, mão esquerda enfaixada. O intervalo de atuação não fixa nascimento, morte ou parentesco com outras figuras de sobrenome semelhante.

### Guerras da Fome

Conjunto de guerras, cercos, incursões e conflitos por abastecimento da reconstrução da II Era; O Primeiro Conflito foi sua principal guerra entre coalizões.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |

Um período de reconstrução desigual. Os primeiros quarenta anos da II Era concentraram escuridão e destruição. O sol regressou antes de campos, rotas e instituições recuperarem estabilidade. As Guerras da Fome abrangem episódios diferentes ao longo do Milênio das Trevas, sem comando comum, começo único ou tratado final que tenha encerrado todas as violências. A Liga das Brasas e a Mesa dos Invernos ligavam abrigos de vários povos, mas seus membros também disputavam a distribuição de reservas.

A principal guerra. O Primeiro Conflito, situado por reconstrução entre cerca de 62 e 146 da II Era, reuniu as maiores coalizões identificadas no começo desse conjunto. Sua continuidade entre campanhas e acordos permite tratá-lo como uma guerra específica. Incluiu batalhas de várzea, bloqueios de passos, disputas de celeiros e tentativas de proteger comboios. A guerra terminou antes dos pactos de Nara dos Sete Celeiros, datados de 173, que pertencem a uma etapa posterior da reorganização.

Outras violências e heranças. A Guerra das Cisternas, as Guerras das Raízes, as lutas de poços e numerosos cercos locais conservam histórias próprias. Não se tornam automaticamente batalhas do Primeiro Conflito e não recebem datas exatas por associação. Partilha de sementes, requisições, cativeiro e expulsões marcaram aldeias humanas e de outros povos. O parentesco remoto com os Eldenari não eliminou as divergências por terra e sobrevivência.

### Liga das Margens

A Liga das Margens reuniu comunidades de elfos da floresta, goblins e halflings, além de aldeias humanas e sobreviventes ligados aos abrigos de várzea.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |

Composição e propósito. A Liga das Margens reuniu comunidades de elfos da floresta, goblins e halflings, além de aldeias humanas e sobreviventes ligados aos abrigos de várzea. Defendia a restituição de sementes e o acesso dos moradores aos depósitos tomados por autoridades de emergência. Sélia Tern coordenou parte dos corredores. Não representava todos os integrantes desses povos.

Aliança e limites. A aliança foi de campanha, anterior às monarquias e fronteiras de 788. Compromissos eram renegociados conforme reservas, perdas e acesso às passagens. Existiam parentes e aldeias da mesma origem em posições opostas. As exigências dos comandos podiam ameaçar as comunidades que sustentavam suas forças.

### Pacto dos Altos Caminhos

O Pacto dos Altos Caminhos articulou comunidades anãs de galerias, contingentes Urakh e grupos de elfos negros, além de senhorios e aldeias humanas de planalto.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |

Composição e propósito. O Pacto dos Altos Caminhos articulou comunidades anãs de galerias, contingentes Urakh e grupos de elfos negros, além de senhorios e aldeias humanas de planalto. Defendia garantias de abastecimento para os caminhos altos e reconhecia apreensões como caução de transporte. Orvek Durn e Vasha Ur exerceram funções distintas; casas e contingentes mantiveram autonomia.

Aliança e limites. A aliança foi de campanha, anterior às monarquias e fronteiras de 788. Compromissos eram renegociados conforme reservas, perdas e acesso às passagens. Existiam parentes e aldeias da mesma origem em posições opostas. As exigências dos comandos podiam ameaçar as comunidades que sustentavam suas forças.

### O Primeiro Conflito

Principal guerra das Guerras da Fome, formada por campanhas e batalhas entre a Liga das Margens e o Pacto dos Altos Caminhos, c. 62–146 da II Era.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | c. 62–146 da II Era |
| Teatro | Campos e rotas da região dos futuros Reinos Centrais |
| Desfecho | Acordos dos Celeiros Abertos; encerramento das campanhas principais sem soberania regional única. |

A tomada das terras centrais. Após o regresso gradual da luz, chefes de comunidades humanas tomaram a iniciativa de ocupar campos recuperáveis, confluências e antigos depósitos na região dos futuros Reinos Centrais. Alguns ocupavam áreas abandonadas; outros expulsavam moradores e convertiam reservas comunitárias em garantia de proteção. A concentração de abrigo e cultivo ampliou a presença humana numa região em que os humanos continuam majoritários em 788. Não existia ainda um reino humano unificado nem o Império de Vaelen Endor.

Duas coalizões. A recusa em devolver sementes e em reconhecer direitos de passagem aproximou comunidades antes separadas. A Liga das Margens associou grupos florestais e ribeirinhos; o Pacto dos Altos Caminhos articulou fornecedores de galerias e planaltos. As coalizões possuíam compromissos e comandos reconhecíveis, embora não fossem estados uniformes. A guerra assumiu forte dimensão entre povos e reuniu a maior mobilização coordenada das primeiras Guerras da Fome. A pertença a um povo não obrigava uma comunidade a integrar determinado lado.

Os humanos e a neutralidade. Os chefes humanos que iniciaram ocupações não conservaram uma frente comum. Aldeias humanas aderiram a ambos os lados, negociando proteção e restituição, enquanto redes como a de Nema Ors buscaram manter comboios fora do serviço militar. Houve humanos que defenderam antigas expulsões e outros que devolveram campos ou acolheram os deslocados. Neutralidade podia significar fornecer alimento a moradores dos dois lados; também podia ocultar comércio com forças que mantinham cativos.

Uma guerra de campanhas. O intervalo c. 62–146 é uma reconstrução autoral aproximada para a guerra principal. Não corresponde a oitenta e quatro anos de batalha contínua. Estações de fome, negociações, tréguas e deslocamentos de famílias separaram as operações. As Sementeiras Tomadas, os Juncos Partidos, a Escarpa da Cinza e os Três Celeiros foram batalhas de uma guerra maior, com objetivos e efeitos diferentes. Cada vitória criava obrigação de alimentar guarnições e proteger o retorno do cultivo.

Povos e instituições ainda em formação. Os nomes coletivos facilitam acompanhar linhagens que se consolidavam durante a II Era. O Pacto dos Altos Caminhos não era Dorgamar, fundado como império em 1368, nem uma Confederação Orc já organizada. A Liga das Margens não equivalia ao reino posterior de Thaelorien ou a Pellanor. Grupos de elfos altos prestaram auxílio e escolta sem comprometer todos os assentamentos setentrionais. Comunidades Olek e oleakes ampararam deslocados; os santuários que originavam linhagens nogards não formaram uma potência naval participante dessa guerra.

Os acordos de encerramento. A fome atingiu também os campos de quem requisitava grão. A retomada de depósitos em 139 deixou ambos os lados incapazes de manter a mesma concentração de forças. Os Acordos dos Celeiros Abertos, em torno de 146, reconheceram corredores de retorno, reservas de sementes sob inspeção mista e limites à retenção de famílias como garantia. Encerraram as principais campanhas sem resolver toda disputa de terra. Nenhuma coalizão obteve soberania sobre os futuros Reinos Centrais.

Heranças. A maioria humana posterior resultou de ocupações, migrações, acolhimento e crescimento de comunidades por séculos. A guerra não extinguiu os demais povos da região. Algumas autoridades transformaram antigas guardas de celeiro em senhorios hereditários; outras comunidades conservaram recibos de restituição para contestá-los. Nara dos Sete Celeiros, em 173, pertence à geração política posterior e não é apresentada como comandante da guerra. O nome O Primeiro Conflito designa esta guerra no contexto das Guerras da Fome, sem reivindicar o primeiro combate de toda a história de Virtude.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Liga das Margens | Elfos da floresta, goblins, halflings e comunidades humanas | Sélia Tern | [11500, 15500] | [19000, 26000] |
| Pacto dos Altos Caminhos | Anões, Urakh/orcs, elfos negros e comunidades humanas | Orvek Durn, Vasha Ur | [12500, 17000] | [20500, 28000] |

Civis: mortos [25000, 39000]; feridos [18000, 27000]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Batalha das Sementeiras Tomadas

A Liga das Margens recupera dois depósitos, mas perde a maior parte das reservas já distribuídas.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | c. 67 da II Era |
| Teatro | Postos de cultivo e depósitos de semente na região central |
| Desfecho | A Liga das Margens recupera dois depósitos, mas perde a maior parte das reservas já distribuídas. |

Objetivo e participantes. A Liga atacou postos mantidos por chefes humanos e seus aliados do Pacto, após a recusa em restituir sementes a moradores deslocados. Sélia Tern procurou ocupar os depósitos antes do novo plantio.

Combate e consequências. A vitória sobre os guardas permitiu o retorno de famílias, mas revelou que o grão já havia alimentado guarnições. O primeiro levantamento de restituição diferenciou campos ocupados e reservas consumidas.

Lugar na guerra. Esta batalha integra O Primeiro Conflito. Suas baixas estão incluídas no total da guerra; os intervalos não devem ser somados novamente ao balanço geral.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Liga das Margens | Contingentes de comunidades da Liga | Sélia Tern | [1300, 1900] | [1900, 3300] |
| Pacto dos Altos Caminhos | Contingentes de comunidades do Pacto | Orvek Durn, Vasha Ur | [1600, 2300] | [2300, 4000] |

Civis: mortos [700, 1400]; feridos [900, 1700]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Batalha dos Juncos Partidos

Vitória tática do Pacto; retirada da Liga preserva suas barcas de reserva.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | c. 83 da II Era |
| Teatro | Travessias de várzea e canais de abrigo |
| Desfecho | Vitória tática do Pacto; retirada da Liga preserva suas barcas de reserva. |

Objetivo e participantes. Orvek concentrou carros e escudos numa passagem de baixa água. Sélia evitou cercar o grupo numa área que voltaria a alagar e mandou retirar sementes pelas barcas.

Combate e consequências. O Pacto tomou o posto e não conseguiu conservar todos os caminhos de acesso. A retirada da Liga salvou alimento, mas os moradores ficaram sujeitos a nova requisição. Nema negociou a saída de famílias sem aceitar seu recrutamento.

Lugar na guerra. Esta batalha integra O Primeiro Conflito. Suas baixas estão incluídas no total da guerra; os intervalos não devem ser somados novamente ao balanço geral.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Liga das Margens | Contingentes de comunidades da Liga | Sélia Tern | [1700, 2400] | [2400, 3800] |
| Pacto dos Altos Caminhos | Contingentes de comunidades do Pacto | Orvek Durn, Vasha Ur | [1500, 2200] | [2200, 3900] |

Civis: mortos [700, 1400]; feridos [900, 1700]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Batalha da Escarpa da Cinza

O Pacto conserva a passagem; a Liga interrompe o comboio principal.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | c. 111 da II Era |
| Teatro | Rota de planalto entre campos e galerias |
| Desfecho | O Pacto conserva a passagem; a Liga interrompe o comboio principal. |

Objetivo e participantes. Contingentes da Liga tentaram impedir a cobrança de caução sobre animais e sementes. Vasha Ur manteve a defesa da encosta enquanto grupos anões retiravam os carros de abastecimento.

Combate e consequências. O fogo em depósitos de palha atingiu também moradores aliados do Pacto. A posse da estrada não compensou a perda dos animais de carga. Os dois lados reduziram operações durante a estação seguinte.

Lugar na guerra. Esta batalha integra O Primeiro Conflito. Suas baixas estão incluídas no total da guerra; os intervalos não devem ser somados novamente ao balanço geral.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Liga das Margens | Contingentes de comunidades da Liga | Sélia Tern | [2200, 3100] | [3100, 4500] |
| Pacto dos Altos Caminhos | Contingentes de comunidades do Pacto | Orvek Durn, Vasha Ur | [2300, 3300] | [3300, 5000] |

Civis: mortos [700, 1400]; feridos [900, 1700]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Batalha dos Três Celeiros

Batalha inconclusiva; destruição das reservas acelera a negociação.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | c. 139 da II Era |
| Teatro | Conjunto de reservas e campos na região central |
| Desfecho | Batalha inconclusiva; destruição das reservas acelera a negociação. |

Objetivo e participantes. As duas coalizões concentraram forças junto aos três depósitos que sustentavam as campanhas tardias. Disputavam sua administração e o direito de reconhecer os recibos de moradores.

Combate e consequências. Um incêndio destruiu parte do grão durante a troca de posições. Nenhum lado conseguiu alimentar a força concentrada. As conversações seguintes levaram a inspeções mistas e aos acordos de cerca de 146.

Lugar na guerra. Esta batalha integra O Primeiro Conflito. Suas baixas estão incluídas no total da guerra; os intervalos não devem ser somados novamente ao balanço geral.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Liga das Margens | Contingentes de comunidades da Liga | Sélia Tern | [2700, 3800] | [3800, 5200] |
| Pacto dos Altos Caminhos | Contingentes de comunidades do Pacto | Orvek Durn, Vasha Ur | [3000, 4100] | [4100, 5800] |

Civis: mortos [700, 1400]; feridos [900, 1700]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Incorporação da região de Valerith

Liga, comando de abastecimento e proclamação na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Liga, comando de abastecimento e proclamação |
| Marcos | 1876–1896 da II Era |

Campanha, adesão e negociação. O Pacto dos Celeiros de Reth, em 1876, articulou fornecedores, depósitos e escoltas no núcleo de Vaela. A região da futura Valerith entrou na liga por compromissos de abastecimento e serviu de base às campanhas. Em 1896, a proclamação concentrou essas funções em Vaelen Endor.

Autoridades e consequências. A corte herdou autoridades e contratos anteriores. A região não foi conquistada por uma coroa imperial já existente: dela partiu o comando que se tornaria imperial.

Região e reino posterior. O nome Valerith situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Rácia

Campanhas de travessia e acordo de barcas na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Campanhas de travessia e acordo de barcas |
| Marcos | 1882–1884 da II Era |

Campanha, adesão e negociação. A liga procurou controlar as travessias que ligavam campos e mercados da região da futura Rácia. Entre 1882 e 1884, escoltas de Dorrik Venn enfrentaram guardas de cobrança e negociaram com responsáveis por barcas. O Acordo das Barcas de Atlante, de 1884, reconheceu recibos comuns e preservou conselhos de embarque.

Autoridades e consequências. A adesão abriu circulação e impôs contribuições de soldados e alimento. Casas que perdiam pedágios resistiram, enquanto barqueiros receberam proteção limitada. Em 1896, a estrutura regional foi incorporada ao império com esses compromissos.

Região e reino posterior. O nome Rácia situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Cávia

Campanhas de estrada e adesão dos portos na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Campanhas de estrada e adesão dos portos |
| Marcos | 1885–1893 da II Era |

Campanha, adesão e negociação. Colunas da liga disputaram entre 1885 e 1890 os acessos entre campos interiores e portos da região da futura Cávia. O bloqueio de armazéns mostrou que tomar uma estrada não bastava para manter os navios carregados. Em 1893, o Termo dos Cais de Trogu reconheceu a circulação sob selo comum e contribuições de estaleiros.

Autoridades e consequências. Os responsáveis portuários conservaram competências de carga e procuraram limitar requisições. A futura província reunia grupos que haviam aderido e outros derrotados nas estradas. O termo não submeteu portos estrangeiros nem antecipou a Liga dos Portos de 2312.

Região e reino posterior. O nome Cávia situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Sokeria

Adesão de comunidades costeiras e tomada de postos na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Adesão de comunidades costeiras e tomada de postos |
| Marcos | 1886–1888 da II Era |

Campanha, adesão e negociação. Na região da futura Sokeria, a liga enfrentou senhores de travessia e obteve apoio de comunidades que forneciam madeira, reparos e alimentos. As campanhas de 1886 a 1888 terminaram no Termo dos Pousos de Sokeria, que reconheceu passagem e garantia de pagamento aos fornecedores.

Autoridades e consequências. Houve apreensão de madeira e embarcações de serviço, contestada em inventários posteriores. A entrada não correspondeu à rendição de um reino de Sokeria com as fronteiras de 788. A incorporação imperial de 1896 transformou obrigações de campanha em arrecadação regular.

Região e reino posterior. O nome Sokeria situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Heria

Conquista de postos e confirmação de garantias na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Conquista de postos e confirmação de garantias |
| Marcos | 1887–1891 da II Era |

Campanha, adesão e negociação. A tomada do Posto das Três Argolas por Sorenna Vale, em 1887, ocorreu na região da futura Heria. A distribuição das reservas atingiu sementes de duas aldeias; as compensações foram fixadas em 1889. Em 1891, o Termo das Garantias de Heria articulou casas que aceitaram o selo após rever suas obrigações.

Autoridades e consequências. A vitória militar não tornou legítima toda apreensão. Os pedidos de compensação acompanharam a integração de guardas locais e a cobrança regional. O termo ampliou a liga sem apagar os direitos dos depositantes.

Região e reino posterior. O nome Heria situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Milles

Campanhas interiores e reconhecimento de depósitos na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Campanhas interiores e reconhecimento de depósitos |
| Marcos | 1890–1893 da II Era |

Campanha, adesão e negociação. Entre 1890 e 1893, a liga avançou sobre postos e armazéns da região da futura Milles. Autoridades urbanas negociaram o reconhecimento das medidas e recibos comuns; casas resistentes perderam cobrança de passagem. O Acordo dos Depósitos de Milles, de 1893, vinculou a cidade e fornecedores do interior à rede da liga.

Autoridades e consequências. Milles designa tanto a cidade quanto a região do reino posterior, cuja capital é a cidade de Milles. A negociação não tornou uniformes todos os distritos costeiros e interiores. Sua incorporação imperial em 1896 conservou responsabilidades locais por estoques e escoltas.

Região e reino posterior. O nome Milles situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Nobilith

Adesão negociada de Arven-Doss na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Adesão negociada de Arven-Doss |
| Marcos | 1894–1894 da II Era |

Campanha, adesão e negociação. A casa de Arven-Doss aderiu ao selo comum em 1894 e conservou funcionários, conforme a história já estabelecida. Controlava parte dos percursos associados à futura Nobilith. A ampliação detalha que suas garantias incluíram passagem de comboios e reconhecimento de registros locais.

Autoridades e consequências. A Serra de Sar-Nobil corta predominantemente a região de norte a sul; a Passagem de Sar-Nobil liga os percursos que descem de Quinder ou Valerith pela futura Nobilith em direção a Sokeria. Guardas e cavaleiros locais foram incorporados por obrigações específicas, antecedendo a importância posterior da casta de cavaleiros na nobreza.

Região e reino posterior. O nome Nobilith situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Incorporação da região de Quinder

Pressão sobre rotas e concordância com cidades e santuários na formação de Vaelen Endor.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Processo | Pressão sobre rotas e concordância com cidades e santuários |
| Marcos | 1895–1896 da II Era |

Campanha, adesão e negociação. Ao fim da Guerra das Correntes, a liga pressionou acessos e arrecadação da bacia do Taoju e do Asmarith, mas não destruiu a autoridade dos santuários. A Concordância das Margens de Samarith, de 1895, aceitou o selo de abastecimento e garantias de manutenção dos canais. A proclamação de 1896 converteu o vínculo em incorporação imperial.

Autoridades e consequências. Direitos de margem e culto permaneceram em negociação. A incorporação foi anterior à conquista de Quinder por Naerath, nas campanhas de 2424–2428. Guerras, acordos e governos posteriores não devem ser fundidos numa única anexação.

Região e reino posterior. O nome Quinder situa a região em relação ao mapa de 788. Não projeta para a II Era a monarquia, a soberania ou as fronteiras do reino sucessor. As contribuições à liga foram convertidas em obrigações imperiais depois da proclamação.

### Exército de Vaelen Endor

Forças imperiais articuladas por quadros de serviço, contingentes provinciais, auxiliares e uma rede de abastecimento sujeita a contratos.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |

Da escolta à instituição. A organização começou nas escoltas sucessivas propostas por Dorrik Venn. Depois de 1896, guardas de comboio, tropas de posto e contingentes regionais receberam pagamentos e obrigações mais regulares. A corte conservou oficiais e depósitos, sem dispor em cada reinado da mesma capacidade de mobilização. A reorganização posterior reuniu comandos de estrada e de campo; nove corredores de referência não significavam nove legiões idênticas.

Quem combatia. Infantaria com lanças, escudos e armas de haste formava o núcleo mais acessível. Arqueiros, besteiros e cavaleiros eram reunidos conforme terreno e recursos. Cavalaria e guardas de casas dependiam de animais, ferradores e contratos; a conferência dos cavalos de 1951 pertence a essa história. Auxiliares orcs, artífices anões e gente de outras origens podiam servir mediante obrigações determinadas, sem submeter seus povos ou estados à coroa.

Comando e tamanho. Oficiais de campo respondiam ao soberano e precisavam negociar homens e recursos com governadores, conselhos e financiadores. A unidade operacional podia reunir algumas centenas de soldados e ser reforçada para uma campanha, sem efetivo permanente universal. Conselhos de guerra recebiam informações de batedores e mestres de depósito. A força declarada em contratos frequentemente diferia da disponível: doenças, deserção, escoltas destacadas e atrasos de pagamento reduziam as colunas.

Mana e engenharia. Engenheiros, carpinteiros, barqueiros e responsáveis por animais sustentavam pontes, cercos e transporte. Magos de proteção, observação e cura prestavam serviços limitados por formação, materiais e fadiga. Não havia comunicação instantânea irrestrita nem cura capaz de apagar perdas. A contratação de especialistas ligados a Dorgamar ou de um estudioso élfico não conferia ao exército comando sobre seus estados ou instituições.

Depósitos e custos humanos. Carros, barcas, animais e celeiros permitiam manter operações por mais de uma estação. A derrota podia começar pela perda de uma aguada ou do direito de usar uma galeria. Requisições atingiam aliados e adversários; guias forçados e famílias retidas como garantia alimentavam resistência. Os registros precisavam distinguir compra, contribuição pactuada e apreensão. Oficiais capazes de manter tropas numa estrada podiam deixar uma região sem sementes para o ano seguinte.

Comandantes e mudanças de época. Sorenna Vale e Dorrik Venn pertencem à formação da liga e à primeira consolidação. Varren Tol comandou a expedição de 1962–1964 a Nogard; Maura Vel conduziu a campanha meridional de 1988–1990; Oren Keld atuou em Orvath em 2026–2028. Hadran Vossel pertence às operações do norte em 2376–2388. São gerações e contextos diferentes: o serviço não passou intacto pelas mãos dos mesmos comandantes durante quinhentos anos.

### Campanha dos Estreitos de Nogard

Nogard permaneceu independente.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | 1962–1964 da II Era |
| Teatro | Nogard e acessos aos ancoradouros meridionais |
| Desfecho | Nogard permaneceu independente. Houve restituição parcial de cargas e retomada gradual de escalas comerciais. A corte não estabeleceu guarnição permanente nem recebeu tributo de submissão. |

Objetivo imperial. Teren I procurou impor postos de fiscalização e garantias de aguada nos estreitos. O acordo de serviço proposto aos portos foi acompanhado por uma frota capaz de bloquear cargas. As comunidades de Nogard recusaram transformar autorização de escala em direito de ocupação.

Batalha e retirada. Ishara Khor articulou pequenas embarcações, pilotos e vigilância. Em 1963, a derrota imperial nos Baixios das Três Lanternas atingiu transportes e aguadas; em 1964, navios avariados obrigaram Varren Tol a retirar a frota. O nome da batalha designa baixios, não o Acordo das Três Lanternas de 893.

Resultado e relações posteriores. Nogard permaneceu independente. Houve restituição parcial de cargas e retomada gradual de escalas comerciais. A corte não estabeleceu guarnição permanente nem recebeu tributo de submissão.

Alcance e perdas. As estimativas abrangem os participantes das campanhas e os civis diretamente atingidos. A derrota da expedição não significa destruição de todo o exército imperial. Os efetivos acumulados incluem contingentes que se substituíram durante as operações.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Expedição imperial | Predomínio humano e contingentes contratados | Teren I Endorin, Varren Tol | [3600, 4800] | [4800, 6800] |
| Defesa das comunidades e autoridades locais | Populações e aliados das comunidades defensoras | Ishara Khor | [1900, 2700] | [2700, 4500] |

Civis: mortos [1200, 2400]; feridos [1800, 3100]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Campanha dos Vaus de Lethen

Thaelorien não integrou o império.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | 1988–1990 da II Era |
| Teatro | Rotas meridionais de aproximação a Thaelorien |
| Desfecho | Thaelorien não integrou o império. A suspensão da campanha permitiu reabrir rotas mediante autorização e reparação, sem transferir soberania. A resistência foi sustentada por guardas, comunidades de cultivo e transporte, além das casas da floresta. |

Objetivo imperial. Isera I autorizou uma expedição para impor postos de garantia e inspeção de cargas em caminhos que ligavam a região central a Thaelorien. Casas imperiais esperavam converter dependência comercial em sujeição, enquanto agricultores e barqueiros locais recusavam requisições permanentes.

Batalha e retirada. Elven Aros coordenou defesa das travessias e afastamento de reservas. A derrota imperial dos Vaus de Lethen, em 1989, separou carros e infantaria; Maura Vel abandonou máquinas de cerco para salvar feridos. Operações de retirada prolongaram-se até 1990.

Resultado e relações posteriores. Thaelorien não integrou o império. A suspensão da campanha permitiu reabrir rotas mediante autorização e reparação, sem transferir soberania. A resistência foi sustentada por guardas, comunidades de cultivo e transporte, além das casas da floresta.

Alcance e perdas. As estimativas abrangem os participantes das campanhas e os civis diretamente atingidos. A derrota da expedição não significa destruição de todo o exército imperial. Os efetivos acumulados incluem contingentes que se substituíram durante as operações.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Expedição imperial | Predomínio humano e contingentes contratados | Isera I, Maura Vel | [4100, 5600] | [5600, 7600] |
| Defesa das comunidades e autoridades locais | Populações e aliados das comunidades defensoras | Elven Aros | [2400, 3300] | [3300, 5100] |

Civis: mortos [1200, 2400]; feridos [1800, 3100]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Campanha das Portas de Orvath

Dorgamar permaneceu independente.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |
| Datas do conflito | 2026–2028 da II Era |
| Teatro | Aproximações da Espinha de Orvath e passagens de Dorgamar |
| Desfecho | Dorgamar permaneceu independente. O fracasso contribuiu para substituir coerção por negociação; o Tratado das Águas de Morvek, de 2032, pertence a essa etapa posterior. As obras começaram em 2039 e o primeiro conjunto entrou em serviço em 2058, sem anexação anã. |

Objetivo imperial. O comando de Selvar I tentou impor garantias de passagem e direito de guarnição a cidades de Dorgamar. Oren Keld tratou contratos de transporte como fundamento para ocupação. Assembleias de cidades e oficinas recusaram o alcance da exigência.

Batalha e retirada. Briga Durn coordenou guardas e manutenção, conservando água e reservas nas galerias habitadas. Em 2027, a derrota imperial diante das Portas de Orvath deixou a coluna dependente de uma estrada. Oren retirou as forças em 2028, abandonando equipamentos e garantias exigidas.

Resultado e relações posteriores. Dorgamar permaneceu independente. O fracasso contribuiu para substituir coerção por negociação; o Tratado das Águas de Morvek, de 2032, pertence a essa etapa posterior. As obras começaram em 2039 e o primeiro conjunto entrou em serviço em 2058, sem anexação anã.

Alcance e perdas. As estimativas abrangem os participantes das campanhas e os civis diretamente atingidos. A derrota da expedição não significa destruição de todo o exército imperial. Os efetivos acumulados incluem contingentes que se substituíram durante as operações.

| Lado | Povos | Lideranças | Mortos | Feridos |
| --- | --- | --- | --- | --- |
| Expedição imperial | Predomínio humano e contingentes contratados | Selvar I, Oren Keld | [2800, 3900] | [3900, 5900] |
| Defesa das comunidades e autoridades locais | Populações e aliados das comunidades defensoras | Briga Durn | [1400, 2200] | [2200, 4000] |

Civis: mortos [1200, 2400]; feridos [1800, 3100]. Estimativas autorais em intervalos. Feridos são sobreviventes ao recorte; mortes decorrentes de ferimentos entram apenas nos mortos. Mobilizados ao longo dos anos não são um exército simultâneo.

### Formação territorial e campanhas de Vaelen Endor

Conquistas, adesões e tratados que formaram o núcleo imperial, e campanhas externas cujo fracasso preservou a soberania de potências vizinhas.

| Campo | Definição |
| --- | --- |
| Referência temporal | II Era |

Uma liga antes de uma coroa. Entre 1881 e 1895, a Guerra das Correntes ampliou a liga de abastecimento. A proclamação de Vaela em 1896 transformou compromissos de passagem, fornecimento e comando em estrutura imperial. Os nomes dos futuros sete Reinos Centrais ajudam a localizar processos distintos; não significam sete coroas que se renderam juntas.

Regiões incorporadas. Valerith constituiu o núcleo; Rácia, Cávia, Sokeria, Heria, Milles e Nobilith entraram por combinações de campanha e adesão. Quinder foi incorporada por pressão sobre rotas e uma concordância que preservou direitos de margem e culto. A confirmação imperial não tornou idêntica a administração de cada região.

Onde a expansão fracassou. A Campanha dos Estreitos de Nogard, em 1962–1964, os Vaus de Lethen, em 1988–1990, e as Portas de Orvath, em 2026–2028, encerraram-se em derrotas e retirada. Nogard, Thaelorien e Dorgamar permaneceram independentes. Em Bergen, a Guerra dos Postos do Norte, de 2376–2388, conservou domínio fragmentado e não criou uma província integral.

Expansão e dissolução. O custo de depósitos, salários e garantias limitava a distância das campanhas. Sob Selvar II, de 2078 a 2149, a Paz das Estradas e as obras ampliaram circulação sem apagar as derrotas anteriores. A crise de 2418–2431 desfez o comando comum; a Concordata reconheceu sucessores. As conquistas de Quinder por Naerath, em 2424–2428, pertencem a outro agente e outra guerra.

## 62. Implantação das campanhas e vínculos de consulta

Wikia 0.40: 689 artigos, 205 marcos. Novos dossiês de guerra, batalhas, incorporações regionais, organização militar e lideranças. Três imagens novas e ilustrações contextuais identificadas. Preservados os 59 capítulos da edição 2.14, as definições visuais, os segredos dos Thul Verenari e os spoilers de Samarith.

Foram acrescentados nove vínculos de comando, oposição e negociação entre as novas lideranças e governantes. A base reúne 107 vínculos. Datas do Primeiro Conflito e de suas batalhas recebem a indicação c. de reconstrução aproximada.



## 63. Das Guerras da Fome aos primeiros poderes — continuidade

### RC-RP01 — Reconstrução e formação dos poderes

O Primeiro Conflito continua c. 62–146 da II Era, principal guerra das primeiras Guerras da Fome. Seu encerramento não encerra todo o conjunto. A formação dos poderes decorre de retomadas de campo, guarda de reservas, caminhos, assembleias e cultos, em ritmos distintos. A proclamação de Vaelen Endor permanece em 1896; não é consequência inevitável da fome.

Base: História Geral de Virtude pp. 25–31 e 36; Registro 2.11, 2.15 e solicitação autoral de 9 de novembro de 2026. Processos novos declarados como ampliação autoral.

### RC-RP02 — Retornos e Várzea das Estacas

Ampliação autoral: retornos e direitos de sementeira nas várzeas centrais c. 146–220. O direito de plantar não equivale sempre a propriedade plena. A Várzea das Estacas é um lugar histórico no interior da futura Valerith, sem coordenada ou identidade urbana de 788 fixada. Acordos dos Celeiros Abertos c. 146 distinguem ração e reserva de semente, com mediação de retornos.

Base: História Geral de Virtude pp. 25–31 e 36; Registro 2.11, 2.15 e solicitação autoral de 9 de novembro de 2026. Processos novos declarados como ampliação autoral.

### RC-RP03 — Instituições e direitos de passagem

Ampliação autoral: disputas por mandatos de celeiros c. 200–350; consolidação de senhorios de passagem c. 350–550; difusão de mesas de vizinhança c. 650–850. São intervalos de processos regionais, não datas simultâneas de fundação. Liga das Brasas, Mesa dos Invernos e Liga das Margens continuam distintas; sem genealogia institucional universal. Guarda de reservas e manutenção podem gerar tributo e privilégios, com resistências.

Base: História Geral de Virtude pp. 25–31 e 36; Registro 2.11, 2.15 e solicitação autoral de 9 de novembro de 2026. Processos novos declarados como ampliação autoral.

### RC-RP04 — Fundadores, biografias e representações

Criam-se verbetes de Nara dos Sete Celeiros, Bram Dorgal, Ursha Mão-Aberta, Zikka Ven, Pella Três-Pontes, Thessara Folha-Clara e Nyravel Sareth, a partir da História Geral pp. 25–27 e da continuidade 2.11. Detalhes de práticas e traços individuais explicitamente desenvolvidos na 2.16 são ampliação autoral. Não se fixam anos pessoais ausentes. Guerra das Cisternas, Guerras das Raízes e Pacto das Pedras Falantes permanecem sem datas exatas; não são automaticamente partes do Primeiro Conflito. Também se criam as páginas de Brenna I Dorgenn (História Geral p. 36) e Elen Sar (p. 30). A aparência individual de ambas e a identificação de Elen como humana são ampliações autorais desta edição. O concílio não estabelece que Elen tenha sido a primeira Grande Pombo.

Base: História Geral de Virtude pp. 25–31 e 36; Registro 2.11, 2.15 e solicitação autoral de 9 de novembro de 2026. Processos novos declarados como ampliação autoral.

### RC-RP05 — Datas, gerações e retratos tardios

Nara está associada à união de 173, não a uma morte comprovada nesse ano. 893 data a cópia mais antiga das Três Lanternas, não a fundação. Preservam-se Dorgal 1084, Três Margens 1261, Dorgamar 1368, Sete Portas 1398, fome 1872–1880, Correntes 1881–1895 e império 1896. Nema é associada a c. 83–146 e está muito idosa no episódio final, sem nascimento ou morte fixados. Vasha está envelhecida nas negociações. Os intervalos da guerra não comprovam atuação individual contínua. Nenhum parentesco é criado entre nomes semelhantes. O retrato de Nyravel representa fase material posterior, não transformação instantânea na travessia.

Base: História Geral de Virtude pp. 25–31 e 36; Registro 2.11, 2.15 e solicitação autoral de 9 de novembro de 2026. Processos novos declarados como ampliação autoral.

## 64. Dossiês da reconstrução e dos primeiros poderes

Textos integrais dos novos verbetes. As biografias separam material anterior, ampliação autoral e datas ainda não fixadas.

### Nara dos Sete Celeiros

Organizadora de reservas comuns; recusou a coroa na história dos primeiros poderes de Virtude.

Os sete depósitos — No ano 173 da II Era, Nara reuniu aldeias humanas e famílias de outros povos em torno de armazéns comuns. O nome Sete Celeiros conservou a memória de uma rede distribuída: perder um depósito não deveria permitir que um chefe submetesse todas as comunidades. A união era um pacto de abastecimento, não a criação de um reino humano único.

Recusar a coroa — Chefes desejavam transformar a administração das reservas em autoridade hereditária e separar porções para os guerreiros. Nara recusou a coroa e morreu durante um inverno distribuindo o alimento que pretendiam reter. O ano 173 data a união; não estabelece, por si só, o ano de sua morte. A nova continuidade não preenche essa lacuna com uma data inventada.

Culto e disputa — A veneração como Arauto de Nancy pertence à tradição religiosa e continua sem comprovação universal. Santuários posteriores usaram seu nome tanto para defender o acolhimento quanto para tentar limitar a ajuda aos próprios fiéis. A memória de suas entregas a famílias de origens diferentes sustenta a contestação dessas restrições.

Depois do Primeiro Conflito — Sua atuação é posterior aos Acordos dos Celeiros Abertos, de cerca de 146. O intervalo de aproximadamente 27 anos separa os dois marcos, mas não prova que Nara tenha sido discípula, filha ou sucessora pessoal de Nema Ors. Sua rede retoma problemas semelhantes em novas condições.

Aparência e representação — Rosto largo e moreno, olhos escuros fundos, nariz largo, cabelos grisalhos encaracolados presos em pano; lã ocre e avental remendado. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Bram Dorgal

Organizador de galerias e de uma forja compartilhada na história dos primeiros poderes de Virtude.

A forja que exigia várias mãos — A tradição atribui a Bram a organização de trabalho, alimento e proteção em galerias de abrigo. Dorgann teria aparecido em sonhos numa forja que uma pessoa sozinha não conseguiria manter. Bram não é um Arauto: a experiência religiosa acompanha uma responsabilidade prática pelo ar, pela água e pelas reservas.

O dever de manter — Na ampliação atual, a forja compartilhada também funciona como lugar de prestação de contas. Famílias oferecem turnos de manutenção e recebem acesso a ferramentas e abrigo. Quem dirige o trabalho deve mostrar o que reteve para reparos. Isso não elimina hierarquias, mas oferece uma base para contestar a apropriação privada de recursos necessários a todos.

Sucessores e pedágios — Seus sucessores abriram caminhos seguros e passaram a cobrar por eles. O encargo de conservar uma passagem pôde tornar-se renda de uma casa, especialmente quando a mesma família controlava guardas, ferramentas e registros. A Paz de Dorgal de 1084 e a coroa de Dorgamar de 1368 pertencem a fases posteriores; Bram não é colocado entre seus signatários.

Limites da biografia — O sobrenome não estabelece parentesco com todos os governantes ou habitantes de Dorgal. Também não demonstra ligação familiar com Orvek Durn. Nascimento, morte e sequência nominal dos primeiros responsáveis pela forja permanecem sem data fixada.

Aparência e representação — Pele castanha escura, rosto arredondado, cabeça calva no alto, barba preta curta e bifurcada; avental de couro marcado pelo calor. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Ursha Mão-Aberta

Articuladora do Pacto das Pedras Falantes na história dos primeiros poderes de Virtude.

Poços e pastagens — Ursha reuniu tribos Urakh para defender água, pastagens e terras de passagem contra apropriações de senhores humanos e anões. Dizia servir Urraka sem reivindicar encarnação divina. Sua autoridade dependia de reunir compromissos entre comunidades que podiam discordar sobre migração, guerra e distribuição de rebanhos.

As pedras e as vozes — O Pacto das Pedras Falantes preservou a autonomia tribal e o compromisso com assembleias comuns. A ampliação distingue a chefia de campanha da representação em assembleia: comandar combatentes não concede automaticamente posse dos poços nem o direito de escolher sozinho os representantes da geração seguinte.

Os cativos de Terval — Depois de vencer saqueadores humanos de Terval, Ursha libertou seus cativos. Parte dos aliados queria trabalho forçado ou reféns em compensação. A decisão tornou-se precedente contra tratar todo estrangeiro como dívida de guerra, sem encerrar o cativeiro nas regiões vizinhas.

Da aliança à confederação — A Confederação Orc se formaria por consolidações e disputas posteriores. Não se projeta sua estrutura de 788 sobre o Primeiro Conflito. Ursha e Vasha Ur são pessoas distintas; não há parentesco, encontro ou subordinação comprovados entre elas. O pacto e a vitória de Terval continuam sem ano exato.

Aparência e representação — Pele verde-sálvia, rosto largo e quadrado, duas presas inferiores curtas, cabelos prateados numa trança grossa; manto de lã sem tingimento. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Zikka Ven

Inventora de filtros e defensora do acesso às cisternas na história dos primeiros poderes de Virtude.

Água recuperada — Zikka desenvolveu filtros que permitiram reutilizar antigas cisternas. O trabalho envolvia observar sedimentos, manter recipientes e substituir materiais saturados. Na ampliação, seus filtros de camadas de areia e carvão reduzem sujeira e certos resíduos; não anulam qualquer veneno, doença ou descompasso de mana.

Acusação e guerra — Um senhor tentou expulsar os goblins das fontes e a acusou de envenenamento. A Guerra das Cisternas terminou com um acordo entre aldeias goblins, humanas e orcs. O nome da inventora tornou-se parte de uma disputa sobre quem podia explicar uma falha, examinar a água e permanecer junto ao abastecimento.

Conhecimento e exclusão — A reconstrução acrescenta o costume de fazer testes de água diante de representantes de mais de uma aldeia. Isso limita a possibilidade de uma autoridade produzir uma acusação sem testemunhas. O acordo não encerrou o preconceito: relatos posteriores continuaram a associar injustamente goblins à contaminação.

Uma trajetória, muitas comunidades — Não houve um reino goblin criado por Zikka nem uma chefia que represente todos os goblins atuais. Sua história é uma referência de ofício e de direitos de residência. Não se fixa data para a Guerra das Cisternas nem se a transforma em batalha do Primeiro Conflito; o sobrenome Ven não prova parentesco com pessoas chamadas Venn.

Aparência e representação — Pele verde-oliva, orelhas grandes pontudas, nariz comprido e curvo, boca larga, cabelos escuros curtos e encaracolados; colete de trabalho índigo. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Pella Três-Pontes

Articuladora de pactos de abrigo nos vales ocidentais na história dos primeiros poderes de Virtude.

Além da Cordilheira de Velkar — Pella ligou vilas por pontes, abrigos e depósitos nos vales a oeste da Cordilheira de Velkar. A rede que contribuiria para a Confederação Halfling de Pellanor responde a enchentes, banditismo e ameaças de anexação. Não ocupa o leste do mapa nem exige atravessar a cordilheira para encontrar sua base principal.

Abrigo sem capital única — Pella recusou concentrar a rede numa capital. A ampliação descreve assembleias hospedadas alternadamente nas vilas, acompanhadas por apresentação de estoques e necessidades de reparo. Uma vila podia coordenar determinada ponte sem obter domínio sobre as demais.

Viagem e religião — Meliva acompanha os pactos de acolhimento; Tívaro e Merovél, chamados Tivim e Mero, são invocados nas viagens. O direito de pedir abrigo não dispensava negociação: reservas pequenas exigiam combinar estadias, contribuição de trabalho e proteção contra bandos que se apresentavam como viajantes.

Memória e gerações — Três-Pontes é um nome de memória ligado à rede, não uma lista suficiente para localizar três monumentos no mapa atual. Não se atribui a Pella a assinatura de todos os tratados posteriores de Pellanor. Datas pessoais e parentescos com famílias atuais permanecem em aberto.

Aparência e representação — Rosto adulto arredondado, pele morena, pequenos olhos cor de avelã, cabelos ruivos encaracolados presos no alto; xale vermelho-terra e pés largos. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Thessara Folha-Clara

Rainha e negociadora de pactos de cultivo e proteção na história dos primeiros poderes de Virtude.

A fome nas bordas do bosque — Nas Guerras das Raízes, cidades famintas derrubavam bosques para cultivo e combustível; guardiões respondiam destruindo plantações. Thessara encerrou o ciclo principal por um acordo que distinguiu terras de cultivo, áreas protegidas e deveres recíprocos. A negociação reconheceu que conservar floresta exigia também abastecer quem vivia junto dela.

Autoridade e limites — A ampliação acrescenta mediadores de campo e de bosque para examinar limites após cheias, incêndios e colheitas perdidas. A palavra de uma casa não deveria bastar para alterar uma demarcação. Na prática, casas com guardas e arquivos conseguiram converter parte desses encargos em direitos duradouros sobre a terra.

Um reino que se consolida — Thessara pertence à história de formação da ordem florestal da II Era. Isso não transforma todas as comunidades de elfos da floresta num único exército nem faz do acordo a fundação pontual de cada cidade de Thaelorien. Nael-Sul permanece capital; Let-Thalara é o bosque de Aelvar.

Uma rainha de outra época — Ariessa Folha-Clara governa desde 588 da III Era. O sobrenome compartilhado não permite completar uma árvore genealógica entre as duas rainhas. Não se fixa a duração da vida ou do reinado de Thessara; as Guerras das Raízes não se confundem com o Acordo das Raízes Baixas de 742 da III Era.

Aparência e representação — Pele acobreada, rosto anguloso, nariz longo, olhos escuros estreitos, cabelos castanhos escuros presos em coque baixo; tecidos ocres e verdes, aro simples de madeira. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Nyravel Sareth

Sacerdotisa e condutora de refugiados até Naer-Sul na história dos primeiros poderes de Virtude.

A travessia e o vale — Nyravel conduziu refugiados ligados aos caminhos crepusculares de Eomundus até o vale de Naer-Sul. A continuidade preserva a raiz Aelthir e as comunidades materiais de acolhimento. A travessia não mudou instantaneamente a aparência: os traços dos elfos negros consolidaram-se durante gerações de adaptação, vínculos de mana e incorporações familiares.

Abrigo e violência — Parte dos seguidores a reconheceu como Arauto de Eilistraee; tradições dissidentes recusaram esse estatuto. Ela organizou acolhimento e também autorizou campanhas brutais contra comunidades que considerava ameaças. A veneração não elimina a responsabilidade por suas decisões nem estabelece que todos os exilados aceitaram sua autoridade.

Herdeiros e casas — Após sua morte, herdeiros e casas disputaram terras, deveres de proteção e precedência religiosa. A ampliação distingue descendência biológica, herança de cargo e apropriação de símbolos. Nenhuma dessas categorias fornece, sozinha, a genealogia das cortes que surgiriam muitos séculos depois.

Representação e cronologia — O retrato desta edição interpreta uma fase material tardia da sacerdotisa; não representa o instante da chegada dos Aelthir. Datas de nascimento e morte não estão fixadas. Zeryssa Sareth, governante desde 703 da III Era, não recebe aqui filiação direta a Nyravel apenas por compartilhar o sobrenome.

Aparência e representação — Retrato de fase material posterior: pele castanha muito escura, rosto fino de maçãs altas, olhos cinzentos grandes, cabelos brancos numa trança assimétrica; lã azul-noturna e broche de crescente. O retrato é uma definição visual autoral desta edição; não pretende ser uma imagem preservada da época.

### Das Guerras da Fome aos primeiros poderes

Como reservas, abrigos e caminhos deram origem a assembleias, senhorios e reinos, sem uma fundação única para todos os povos.

Uma paz incompleta — Os Acordos dos Celeiros Abertos, de cerca de 146 da II Era, encerraram as campanhas principais do Primeiro Conflito. Não encerraram todas as Guerras da Fome. Comunidades retornaram a campos ocupados, encontraram depósitos vazios e tiveram de decidir quem podia semear, cobrar passagem e falar pelos ausentes. A reconstrução começou enquanto persistiam cercos locais, epidemias e deslocamentos.

Do socorro ao governo — Quem guardava sementes podia exigir trabalho; quem mantinha uma ponte podia cobrar passagem; quem copiava compromissos podia decidir quais direitos eram lembrados. Esses encargos criaram poder antes de existir uma coroa estável. A mesma instituição podia proteger uma aldeia contra soldados e impor-lhe uma dívida que atravessava gerações.

Caminhos diferentes — Nara dos Sete Celeiros defendeu reservas comuns. Bram Dorgal organizou a manutenção compartilhada das galerias. Ursha Mão-Aberta e Pella Três-Pontes ligaram comunidades sem suprimir toda autonomia local. Thessara Folha-Clara negociou cultivo e proteção. Nyravel Sareth reuniu exilados, mas também concentrou autoridade e autorizou violência. Zikka Ven tornou o acesso à água uma disputa técnica e política. Não viveram necessariamente todos na mesma geração.

A distância até o império — Entre o fim aproximado do Primeiro Conflito, em 146, e a proclamação de Vaelen Endor, em 1896, passaram cerca de 1750 anos da II Era. Paz de Dorgal, tratados de água, assembleias religiosas e coroas regionais ocupam esse intervalo. Vaela Endorin herdou um mundo com instituições antigas e rivais; sua vitória não foi o resultado inevitável dos primeiros pactos.

Como acompanhar a sequência — A cronologia geral distingue anos documentados, intervalos aproximados e episódios ainda sem data. A conferência de datas e gerações reúne essas diferenças e impede que o nome de um fundador substitua séculos de sucessores. As páginas de cada pessoa apresentam o que é conhecido e os limites da biografia.

### Acordos dos Celeiros Abertos

Compromissos de cerca de 146 da II Era que encerraram as campanhas principais do Primeiro Conflito.

Fim das campanhas, não da escassez — A Liga das Margens, o Pacto dos Altos Caminhos e comunidades de comboios independentes aceitaram limitar requisições e devolver acesso a campos e depósitos. Os acordos não criaram soberania continental nem converteram uma coalizão em governo de todos os povos.

Semente, passagem e retorno — A ampliação estabelece que a semente reservada à próxima colheita deve ser separada da ração imediata, com conferência por representantes de lados diferentes. Retornados podem apresentar testemunhas de residência e trabalho quando perderam marcas e registros. O direito de retorno não autoriza expulsar automaticamente famílias que também fugiram da guerra e passaram a cultivar o lugar.

O problema da aplicação — Cada vau e depósito dependia de guardas e mediadores capazes de fazer cumprir o compromisso. A apreensão de ferramentas, a morte de testemunhas e a alteração de cursos de água tornaram muitas decisões provisórias. O acordo produziu novas disputas sobre a execução da paz, não uma recuperação imediata.

Uma mesa de pessoas idosas — Sélia Tern, Orvek Durn e Vasha Ur pertencem à geração da guerra. Nema Ors aparece desde cerca de 83 e permanece associada aos compromissos finais como uma negociadora muito idosa. Não se imagina que todos tenham comandado pessoalmente cada batalha ao longo de 84 anos.

### Retornos e direitos de sementeira

A disputa por campos, sementes e pertencimento depois das grandes campanhas da fome.

Duas famílias diante do mesmo campo — Entre cerca de 146 e 220 da II Era, os retornos aumentaram os conflitos nas várzeas centrais. Uma família dizia ter aberto o terreno antes da guerra; outra mostrava valas que fizera durante a ausência. A nova continuidade descreve decisões por colheita: permitir o cultivo de uma estação enquanto mediadores investigavam o direito mais duradouro.

Direito de plantar e direito de possuir — O direito de sementeira autorizava plantar e recolher parte acordada da produção. Não equivalia sempre à propriedade integral da terra. A distinção permitiu acolher deslocados, mas também criou dependência quando guardas passaram a renovar a autorização apenas mediante trabalho ou serviço armado.

A Várzea das Estacas — Na Várzea das Estacas, marcas de madeira registravam níveis de cheia e limites provisórios. Cada nova estação exigia conferir as marcas diante de moradores antigos e recém-chegados. O arranjo pertence a uma área histórica do interior da futura Valerith; não dá à localidade as fronteiras ou o estatuto de uma cidade de 788.

O que passou adiante — Termos de uso, testemunhas e reconhecimento de melhorias reapareceriam em contratos muito posteriores. Essa persistência é institucional, não uma linha genealógica comprovada. Nara dos Sete Celeiros enfrenta problemas da mesma reconstrução em 173, sem dirigir todos os retornos do continente.

### Várzea das Estacas

Área de cultivo e mediação de retornos no interior da futura Valerith, lembrada por seus limites de cheia.

Um lugar de reocupação — A Várzea das Estacas é uma localidade histórica acrescentada nesta edição, ativa na reconstrução de cerca de 146–220 da II Era. Ocupa uma planície alagável do interior da região que muito depois integraria Valerith. Sua posição exata e seu nome em 788 não estão fixados; por isso não recebe marcador no mapa.

Madeira que a água deslocava — Estacas talhadas marcavam a cheia observada, o limite de cultivo e os caminhos de acesso ao depósito. Um marco deslocado podia fazer uma família perder terra ou assumir trabalho de drenagem. A conferência pública das marcas servia de proteção contra fraude e também se tornava ocasião de pressão dos guardas.

Cotidiano e conflito — Casas de madeira, barro e cobertura vegetal eram reconstruídas depois de chuvas fortes. A vida dependia de sementes secas, ferramentas partilhadas e caminhos transitáveis. Não se descreve um castelo ou uma cidade de pedra. A importância do lugar está na experiência de conciliar retornados e moradores que haviam mantido o campo durante a guerra.

### Guardas e depositários dos celeiros

Funções locais de conservação, distribuição e defesa que se tornaram bases de autoridade.

Cargos antes de uma ordem comum — A expressão reúne funções encontradas em várias comunidades; não é o nome de uma guilda continental. Depositários medem entrada e saída, protegem semente de umidade e registram obrigações. Guardas defendem portas e comboios. Em certas aldeias as funções alternam entre famílias; em outras uma casa consegue acumulá-las.

Mandatos e herança — Entre cerca de 200 e 350 da II Era, a reconstrução acrescenta disputas recorrentes por prorrogação de mandatos nos vales centrais. Famílias argumentam que ensinar o ofício aos filhos preserva a reserva; moradores respondem que conhecer o depósito não dá direito de possuí-lo. Parte dos primeiros senhorios nasce da transformação de encargo temporário em privilégio familiar.

Contrapesos frágeis — Dupla contagem, abertura diante de testemunhas e separação entre ração e semente reduzem alguns abusos. Também exigem tempo e pessoas capazes de fazer valer a decisão. Nos anos ruins, uma casa armada pode apresentar como empréstimo o alimento que já pertencia à comunidade.

Nara e a memória do dever — Nara dos Sete Celeiros oferece uma referência para contestar a retenção de comida e a exclusão de estrangeiros. Seu exemplo não elimina os conflitos entre depósitos, santuários e chefes. Instituições de socorro podem sobreviver ao fundador e alterar profundamente seus critérios de acesso.

### Os primeiros senhorios de passagem

Como manutenção de trilhas, pontes e galerias se converteu em direito de cobrar e governar.

Cobrar por um caminho mantido — Depois das guerras, uma ponte segura e uma galeria ventilada podiam valer mais que uma antiga proclamação de soberania. Comunidades pagavam para obter escolta e reparos. O poder se concentrava quando os responsáveis pelo trajeto controlavam também ferramentas, depósito e homens armados.

A conta que se tornava tributo — A ampliação situa entre cerca de 350 e 550 da II Era uma fase de consolidação desses direitos em diferentes rotas, sem afirmar que surgiram simultaneamente. Uma contribuição ligada a uma obra podia continuar após o reparo. Para justificar a cobrança, casas invocavam obrigações de ancestrais e exigiam serviço de famílias que nunca haviam aceitado o compromisso original.

Casas e comunidades — Bram Dorgal pertence à memória do trabalho compartilhado; seus sucessores não formam uma lista pessoal conhecida até a Paz de Dorgal. Comunidades de galeria, viajantes e aldeias de encosta contestavam cobranças, fechavam caminhos alternativos ou negociavam garantias. Nem todo mantenedor tornou-se senhor, e nem todo senhor controlava uma região inteira.

Dos pedágios aos tratados — A Paz de Dorgal, em 1084, garantiu passagem entre vales humanos e mercados anões. Ela pertence a um mundo com muitas gerações de práticas e conflitos anteriores. Em 1368, Brenna I Dorgenn receberia reconhecimento de cidades e casas de Dorgamar. Nenhum dos dois marcos retroage à vida de Bram.

### Mesas de vizinhança

Assembleias locais que negociavam água, cultivo, abrigo e reparos, sem formar um governo continental.

Quem tinha lugar à mesa — A denominação reúne assembleias de povoados vizinhos, responsáveis por ouvir perdas de colheita, dividir turnos de reparo e negociar passagem. Na ampliação, sua difusão entre cerca de 650 e 850 da II Era acompanha a recuperação desigual de rotas. Há regiões onde mulheres, recém-chegados e trabalhadores sem terra obtêm voz; em outras só famílias reconhecidas podem apresentar reclamação.

A medida e o testemunho — As mesas comparam marcas de nível, recipientes de medida e cópias de compromissos. Aceitar uma testemunha de outra origem pode abrir direitos; recusá-la pode tornar impossível provar residência. A preservação dos arquivos torna-se uma forma de poder, sobretudo quando os escribas dependem de quem cobra o tributo.

Arranjos próprios de cada povo — As assembleias de Ursha, a rede de Pella e os pactos de cultivo de Thessara possuem origens e regras próprias. A semelhança de certos problemas não demonstra que uma organização tenha criado todas as outras. As mesas são uma categoria de comparação histórica, não uma filial dessas instituições.

O custo de negociar — Comunidades distantes precisavam alimentar mensageiros e aguardar respostas enquanto uma cheia ou um cerco alterava a situação. A vantagem de uma chefia permanente era decidir mais rápido; seu risco era decidir sem ouvir os afetados. Essa tensão ajudou a formar tanto ligas e confederações quanto senhorios e coroas.

### Guerra das Cisternas

Conflito da reconstrução em torno das fontes recuperadas por Zikka Ven e do direito de permanecer junto à água.

Trabalho transformado em acusação — Os filtros de Zikka Ven permitiram reutilizar cisternas. A acusação de envenenamento acompanhou a tentativa de um senhor de expulsar os goblins do abastecimento. A disputa por água envolveu também direitos de residência e controle do conhecimento técnico.

Acordo entre aldeias — A guerra terminou com um acordo entre comunidades goblins, humanas e orcs. A ampliação acrescenta a conferência da água diante de testemunhas de diferentes aldeias. Isso ofereceu um procedimento para examinar suspeitas, mas não eliminou a desigualdade entre proprietários, usuários e mantenedores.

Data e alcance — O episódio pertence à reconstrução da II Era e continua sem anos de início e fim fixados. Não integra automaticamente O Primeiro Conflito nem recebe suas baixas, seus líderes ou suas datas. Não há estimativa numérica de mortos adotada para esta guerra.

### Guerras das Raízes

Confrontos entre cultivo, sobrevivência e proteção dos bosques na reconstrução da II Era.

Campos e bosques em guerra — Cidades derrubavam bosques para obter terra e combustível; guardiões destruíam plantações e caminhos em resposta. Famílias sem reservas pagavam o custo de medidas tomadas em nome da sobrevivência ou da proteção da floresta. Não houve um alinhamento uniforme de todos os humanos contra todos os elfos.

O compromisso de Thessara — Thessara Folha-Clara encerrou o ciclo principal por meio de terras de cultivo reconhecidas, áreas protegidas e deveres recíprocos. Na ampliação, mediadores de campo e de bosque acompanham a manutenção dos limites. A necessidade de abastecer as comunidades permanece parte do pacto.

Uma paz que precisava de manutenção — Colheitas perdidas, incêndios e expansão de grandes casas exigiram novas negociações. Obrigações de proteção foram transformadas em propriedade em certas regiões. A história ajuda a explicar desigualdades posteriores de Thaelorien, sem fazer de toda migração um efeito direto de uma única guerra.

Marcos separados — Os anos das Guerras das Raízes não estão fixados. O Acordo das Raízes Baixas, de 742 da III Era, é outro acontecimento. Sem uma data para as guerras antigas, não se coloca Thessara na mesa desse acordo posterior.

### Pacto das Pedras Falantes

Compromisso de autonomia tribal e assembleia comum ligado à chefia de Ursha Mão-Aberta.

Defesa em comum — Ursha Mão-Aberta reuniu tribos para defender poços e pastagens durante a reconstrução. O pacto preservou autonomia e estabeleceu compromissos de reunião. Não entregou todas as terras a uma dinastia nem deu a uma chefe voz automática sobre qualquer comunidade orc.

Depois de Terval — A libertação dos cativos de Terval dividiu aliados e tornou visível a diferença entre comandar uma vitória e decidir o destino de seus prisioneiros. A ampliação consolida o precedente de que defesa de poços não equivale a posse das pessoas que deles dependem.

Uma origem institucional — A Confederação Orc se formaria a partir de pactos e disputas posteriores. A data do primeiro compromisso continua aberta. Não se conclui que os signatários fossem os mesmos comandantes do Primeiro Conflito ou que as fronteiras atuais já estivessem estabelecidas.

### Liga das Brasas

Rede de abrigo e auxílio dos primeiros tempos da II Era, anterior aos grandes poderes regionais.

Uma brasa de outro abrigo — A Liga das Brasas ligava abrigos de vários povos durante o Milênio das Trevas. A ampliação desenvolve seu caráter de auxílio: transportar reservas, avisar sobre caminhos fechados e compartilhar técnicas de manter fogo, água e alimento em condições precárias. Não era uma liga de estados já constituídos.

Solidariedade disputada — A decisão de enviar comida podia proteger um abrigo e enfraquecer outro. Guardas tentaram condicionar o socorro à obediência; trabalhadores pressionaram para reconhecer famílias recém-chegadas. A rede não anulou conflitos internos nem permaneceu imutável por todo o milênio.

Um nome e seus limites — Liga das Brasas e Liga das Margens são organizações distintas. A primeira pertence ao auxílio entre abrigos; a segunda é uma coalizão do Primeiro Conflito. Não se adota uma data exata de fundação, extinção ou filiação integral entre elas.

### Mesa dos Invernos

Articulação de reservas e necessidades entre abrigos de diferentes povos durante a escassez.

Comparar o que ainda restava — A Mesa dos Invernos ligava abrigos durante as Guerras da Fome. Nesta ampliação, sua atividade consiste em comparar reservas e necessidades antes das estações de maior isolamento. Não tinha autoridade para ordenar a colheita de todo o continente e dependia do que as comunidades declaravam.

A disputa pela medida — Esconder sacos podia preservar um abrigo e deixar outro sem socorro. Uma mesma quantidade de grão não equivalia à mesma duração de estoque quando havia crianças, doentes ou perdas por umidade. O esforço de registrar essas diferenças produziu acordos e também novas formas de manipular a distribuição.

Sem sucessão universal — As mesas de vizinhança retomam problemas semelhantes em fases posteriores, mas não são apresentadas como filiais ou sucessoras diretas de uma administração central. A Mesa dos Invernos não possui uma lista de dirigentes ou datas pessoais estabelecida nesta edição.

### Datas e gerações da reconstrução

Leitura comparada dos marcos da II Era, distinguindo pessoas, cargos, instituições e tradições.

Contar sem fabricar precisão — O Primeiro Conflito ocupa cerca de 62–146 da II Era. Os pactos de Nara são de 173. O intervalo aproximado de 27 anos separa o fim da guerra desse marco; não estabelece parentesco ou transmissão direta de cargo. O começo do Milênio das Trevas não significa escuridão uniforme até o ano 1000, nem todo conflito local terminou em 146.

Pessoas durante uma guerra longa — Sélia Tern, Orvek Durn e Vasha Ur estão associados ao período geral de cerca de 62–146, sem presença pessoal comprovada em cada batalha. São 84 anos entre os extremos; duração institucional e atividade contínua de um indivíduo não são a mesma coisa. Nema Ors é citada de cerca de 83 a 146, aproximadamente 63 anos: sua participação final é a de uma negociadora muito idosa, não de uma combatente jovem durante toda a guerra.

O que não foi datado — Bram, Ursha, Zikka, Pella e Thessara não recebem nascimento, morte ou reinado exatos. A chegada de Nyravel pertence às rupturas finais da I Era e ao começo da II, sem duração pessoal fixada. Datas de instituições posteriores não são usadas para estender artificialmente essas biografias.

Cópia não é fundação — 893 data a cópia preservada mais antiga do Acordo das Três Lanternas, ligado à segurança de escavações. A Paz de Dorgal é de 1084; o Tratado das Três Margens, de 1261; a fundação convencional de Dorgamar, de 1368; o Concílio das Sete Portas, de 1398. Esses marcos não compartilham necessariamente autores ou signatários.

Da reconstrução a Vaelen Endor — Entre 1084 e 1896 passaram 812 anos; entre 1368 e 1896, 528. A fome de 1872–1880 e a Guerra das Correntes de 1881–1895 precedem a proclamação de Vaela em 1896. O vínculo é a transformação e disputa de instituições ao longo de muitas gerações. A II Era termina com a Concordata de 2431; a III começa em 1, sem ano zero.

Família, cargo e memória — Um sobrenome compartilhado, um título herdado ou a veneração de um fundador não bastam para construir uma genealogia. Thessara e Ariessa Folha-Clara são figuras de eras diferentes; Nyravel e Zeryssa Sareth não recebem filiação direta sem registro. Direitos sobre terra e passagem podem continuar mesmo quando mudam as famílias e os povos que os exercem.

### Brenna I Dorgenn

Primeira imperatriz reconhecida na fundação convencional de Dorgamar.

O reconhecimento de 1368 — Brenna I Dorgenn recebeu reconhecimento de cidades e casas que já compartilhavam defesa e arbitragens. O ano 1368 da II Era é a fundação imperial convencional de Dorgamar. A coroa procurava colocar o pacto comum acima de senhorios e concessões particulares; sua criação não significou domínio sobre todos os anões de Virtude.

Uma coroa entre muitas obrigações — A ampliação interpreta seu governo como dependente de compromissos entre cidades, mantenedores de caminhos e casas de galeria. Uma autoridade permanente podia arbitrar disputas e organizar defesa, mas precisava negociar contribuições e preservar acesso às rotas. O título não tornava cada decisão consensual.

Antes e depois — A Paz de Dorgal de 1084 precede o reconhecimento em 284 anos. Bram Dorgal pertence à memória mais antiga das galerias, não a uma biografia que se estende até a fundação imperial. O Tratado das Águas de Morvek, em 2032, é ainda muito posterior; Brenna não figura como sua signatária.

Datas e imagem — A referência de 1368 data o reconhecimento, não fixa nascimento, início de toda atividade política, duração de reinado ou morte. O retrato desta edição adota os traços descritos na ficha como ampliação visual autoral.

### Elen Sar

Sacerdotisa de Eleanora e articuladora do Concílio das Sete Portas.

Santuários que acolhiam — Elen Sar reuniu santuários de Samarith que recebiam refugiados. Devota de Eleanora, articulou em 1398 da II Era o Concílio das Sete Portas. A comunhão reconheceu Ardanus, Nancy, Eleanora, Viormund, Tívaro, Merovél e Nereth, aproximando práticas de socorro e uma autoridade religiosa comum.

A memória das aves — O título de Grande Pombo conservou a memória das aves usadas para levar pedidos de alimento e cessar-fogo entre comunidades sitiadas. O título foi atribuído ao sumo sacerdote; as fontes citadas não permitem concluir que a própria Elen tenha sido sua primeira ocupante.

Uma instituição com poder — A ampliação destaca a tensão entre acolher e governar: reunir santuários permitia coordenar ajuda e arbitrar disputas, mas também controlar quem era ouvido. A ausência de Asterion entre os Sete não o retirou da cosmologia nem encerrou seus cultos. O concílio estabelece uma comunhão, não um catálogo completo das divindades.

Gerações e representação — Elen pertence ao marco de 1398 e não recebe uma vida que alcance os conflitos de Samarith na III Era. Nascimento e morte permanecem sem data. Esta edição a define visualmente como humana para individualizar sua representação, sem atribuir essa informação aos livros anteriores.

## 65. Conferência de datas, gerações e implantação

A conferência distingue precisão da fonte, intervalo de processo, vida individual e continuidade institucional. Lacunas biográficas são mantidas quando preencher a data criaria uma certeza falsa.

| Referência | Data ou intervalo | Decisão vigente |
| --- | --- | --- |
| O Primeiro Conflito | c. 62–146 da II Era | Intervalo aproximado; 84 anos entre extremos; não ação pessoal contínua. |
| Nema Ors | c. 83–146 | 63 anos entre episódios associados; retrato final muito idoso, sem nascimento/morte fixados. |
| União de Nara | 173 | União de depósitos, não morte automaticamente datada; c. 27 anos depois dos acordos. |
| Bram, Ursha, Zikka, Pella e Thessara | Sem anos pessoais fixados | Nenhuma participação atribuída a tratados de séculos posteriores. |
| Nyravel | Rupturas do fim da I Era / início da II | Fase material tardia no retrato; nenhuma filiação direta a Zeryssa demonstrada. |
| Três Lanternas | 893 | Data da cópia preservada, não da fundação. |
| Paz de Dorgal / Três Margens | 1084 / 1261 | Passagem e irrigação; tratados distintos preservados. |
| Dorgamar / Sete Portas | 1368 / 1398 | Coroa e comunhão religiosa; instituições distintas. |
| Fome / Correntes / Vaelen Endor | 1872–1880 / 1881–1895 / 1896 | Marcos imperiais preservados; c. 1750 anos desde 146 até 1896. |
| Troca de era | 2431 da II → 1 da III | Sem ano zero; não transportar pessoas por mudança de contagem. |
| Nomes e parentescos | Folha-Clara, Sareth, Ven/Venn, Ursha/Vasha | Sem árvores genealógicas ou identidades presumidas. |

Wikia 0.41: 711 artigos, 209 marcos, 116 vínculos. Acrescentados 22 verbetes, nove biografias antes sem página, quatro processos na cronologia, treze retratos pessoais e uma cena de reconstrução. Preservados integralmente os 62 capítulos anteriores como histórico editorial.

